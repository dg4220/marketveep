<?php


$client_email = '834685533743-mgco5mnlf53kbsgtbpbnd3tvseequumi@developer.gserviceaccount.com';
$private_key = 'AIzaSyD_tH573SkrKN0pzVY5Yo3wjmEu8al55p4';
$scopes = array('https://www.googleapis.com/auth/drive');
$credentials = new Google_Auth_AssertionCredentials(
    $client_email,
    $scopes,
    $private_key
);




$client = new Google_Client();
$client->setApplicationName("MMC DOCS");
$client->setDeveloperKey('AIzaSyD_tH573SkrKN0pzVY5Yo3wjmEu8al55p4');






/**
 * Insert new file.
 *
 * @param Google_Service_Drive $service Drive API service instance.
 * @param string $title Title of the file to insert, including the extension.
 * @param string $description Description of the file to insert.
 * @param string $parentId Parent folder's ID.
 * @param string $mimeType MIME type of the file to insert.
 * @param string $filename Filename of the file to insert.
 * @return Google_Service_Drive_DriveFile The file that was inserted. NULL is
 *     returned if an API error occurred.
 */
function insertFile('https://www.googleapis.com/auth/drive', 'First Doc', 'N/A', '', '', $filename) {
  $file = new Google_Service_Drive_DriveFile();
  $file->setTitle($title);
  $file->setDescription($description);
  $file->setMimeType($mimeType);

  // Set the parent folder.
  if ($parentId != null) {
    $parent = new Google_Service_Drive_ParentReference();
    $parent->setId($parentId);
    $file->setParents(array($parent));
  }

  try {
    $data = file_get_contents($filename);

    $createdFile = $service->files->insert($file, array(
      'data' => $data,
      'mimeType' => $mimeType,
    ));

    // Uncomment the following line to print the File ID
    print 'File ID: %s' % $createdFile->getId();

    return $createdFile;
  } catch (Exception $e) {
    print "An error occurred: " . $e->getMessage();
  }
}






echo "<html>
<head>

<META HTTP-EQUIV=\"refresh\" CONTENT=\"0;
URL=https://www.googleapis.com/drive/v2/files/0Bz2Av5rKd4lLaFRXdmY2bHg0bDQ?updateViewedDate=true&alt=media&key=AIzaSyD_tH573SkrKN0pzVY5Yo3wjmEu8al55p4\">";




   

?>
