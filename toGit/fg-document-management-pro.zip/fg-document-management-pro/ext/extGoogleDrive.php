<?PHP
/*************************************************************
 * Adding file to google drive */


function insertFile($service,
					$title,
					$description,
					$parentId,
					$mimeType,
					$filename,
					$entry) {

  $file = new Google_Service_Drive_DriveFile();
  $file->setTitle($title);
  $file->setDescription($description);
  $file->setMimeType($mimeType);

  // Set the parent folder.
  if ($parentId != null) {
    $parent = new Google_Service_Drive_ParentReference();
    $parent->setId($parentId);
    $file->setParents(array($parent));
  }

  try {
    $data = file_get_contents($filename);

    $createdFile = $service->files->insert($file, array(
      'data' => $data,
      'mimeType' => $mimeType,
      'uploadType' => 'media',
    ));

    // Uncomment the following line to print the File ID
    // print 'File ID: %s' % $createdFile->getId();
    $google_link = "https://docs.google.com/uc?id=" . $createdFile->getId() . "&export=download";
	update_post_meta($entry['post_id'], 'property_doc_file', $google_link);
    return $createdFile;
  } catch (Exception $e) {
    print "An error occurred: " . $e->getMessage();
  }
}

 /* Done Adding file to google drive */
 /*************************************************************/


//add_action( "gform_after_submission", "run_form_process", 10, 4 );


/* begin custom */

//add_filter("gform_pre_render_8", "google_auth");
function google_auth($form) {

  if ( !require_once( 'google-api-php-client/examples/templates/base.php' ) ) {
          echo "<h3>Base Fail</h3>";
        } else {
          echo "<h3>Base Success</h3>";

        }

        if ( !require_once( 'google-api-php-client/src/Google/Client.php' ) ) {
          echo "<h3>Client Fail</h3>";
        } else {
          echo "<h3>Client Success</h3>";

        }


        if ( !require_once ( 'google-api-php-client/src/Google/autoload.php') ) {
          echo "<h3>Autoload Fail</h3>";
        } else {
          echo "<h3>Autoload Success</h3>";

        }



        if ( !include( "google-api-php-client/src/Google/Auth/OAuth2.php" ) ) {
          echo "<h3>0 Fail - google-api-php-client/src/Google/Auth/OAuth2.php</h3>";
          if ( !include( "http://www.ptechinternational.com/ptiMulti/wp-content/themes/magazine-basic/google-api-php-client/src/Google/Auth/OAuth2.php")) {
            echo "<h3>0 Fail 2 </h3>";
          }
        } else {
          echo "<h3>0 Success</h3>";

        }

        //include_once "templates/base.php";
        session_start();

        /************************************************
          ATTENTION: Fill in these values! Make sure
          the redirect URI is to this page, e.g:
          http://localhost:8080/user-example.php
         ************************************************/


        $client_id = '197825410529-mi4jne28mk7m9a3b129ftgujb33d509k.apps.googleusercontent.com';
        $client_secret = 'r51xiasNHJfoVpoToKfVaqXy';
        //$redirect_uri = 'http://www.ptechinternational.com/ptiMulti/hill-condominium/title-2/';
        //$redirect_uri = 'http://www.mediatemanagement.com/pm/add_google_drive_links.php';
        $redirect_uri = 'http://www.mediatemanagement.com/tlc/?page_id=23';


        /************************************************
          Make an API request on behalf of a user. In
          this case we need to have a valid OAuth 2.0
          token for the user, so we need to send them
          through a login flow. To do this we need some
          information from our API console project.



        UNCOMMENT
        ************************************************/

        $client = new Google_Client();
        //echo "<H1>CLIENT " . $client . "</H1>";
        $client->setClientId($client_id);
        $client->setClientSecret($client_secret);
        $client->setRedirectUri($redirect_uri);
        $client->addScope("https://www.googleapis.com/auth/drive");
        //$client->addScope("https://www.googleapis.com/auth/youtube");



        /************************************************
          We are going to create both YouTube and Drive
          services, and query both.
         ************************************************/
        //$yt_service = new Google_Service_YouTube($client);
        $dr_service = new Google_Service_Drive($client);


        //0 1 2 4 20
        $folder_ids = ARRAY(
        28 =>'0Bz2Av5rKd4lLfmxfejhYZmxrNEZHb1NaXzNHaTR4WXNQMGxJSUhreDhqdTVpZnBSb1N3TTQ'
        );


        /************************************************
          Boilerplate auth management - see
          user-example.php for details.
         ************************************************/
        if (isset($_REQUEST['logout'])) {
          unset($_SESSION['access_token']);
        }
        if (isset($_GET['code'])) {
          $client->authenticate($_GET['code']);
          $_SESSION['access_token'] = $client->getAccessToken();
          $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
          header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
        }

        if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
          $client->setAccessToken($_SESSION['access_token']);
        } else {
          $authUrl = $client->createAuthUrl();
          //$client->setAccessToken($_SESSION['access_token']);//?
        }

        /************************************************
          If we're signed in, retrieve channels from YouTube
          and a list of files from Drive.
         ************************************************/
        if ($client->getAccessToken()) {
          $_SESSION['access_token'] = $client->getAccessToken();


        }

    if (isset($authUrl)) {
      echo "<a class='login' href='" . $authUrl . "'>Connect Me!</a>";
    } else {
      echo "<h3>Results Of Drive List:</h3>";

    return $form;
  }
}

?>