<?PHP

class fgpsn_network_documents extends WP_Widget {

	function fgpsn_network_documents() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-network-documents', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows most recent network documents. Automatically filters for property, unit, vendor, contact, etc. where the ID is present, usually in a $_GET variable', 'fgpsn-network-documents' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnnetworkdocuments', __( 'Recent Property Documents', 'fgpsn-network-documents' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );
		$link = empty( $instance[ 'link' ]) ? '' : $instance[ 'link' ];
		$parameters = array(
				'title' 	=> $title,
				'link' 		=> $instance[ 'link' ],
				'hideposttitle' => $instance[ 'hideposttitle' ],
				'separator' => $instance[ 'separator' ],
				'afterexcerpt' => $instance[ 'afterexcerpt' ],
				'afterexcerptlink' => $instance[ 'afterexcerptlink' ],
				'show_type' => 'property_doc',
				'shownum' 	=> (int) $instance[ 'shownum' ],
				'postoffset' => (int) $instance[ 'postoffset' ],
				'reverseorder' => (int) $instance[ 'reverseorder' ],
				'excerpt' 	=> (int) $instance[ 'excerpt' ],
				'excerptlengthwords' => (int) $instance[ 'excerptlengthwords' ],
				'fg_act_document_cat' 	=> (bool) $instance[ 'fg_act_document_cat' ],
				'cats' 		=> esc_attr( $instance[ 'cats' ] ),
				'cusfield' 	=> esc_attr( $instance[ 'cusfield' ] ),
				'w' 		=> (int) $instance[ 'width' ],
				'h' 		=> (int) $instance[ 'height' ],
				'firstimage' => (bool) $instance[ 'firstimage' ],
				'atimage' 	=>(bool) $instance[ 'atimage' ],
				'defimage' 	=> esc_url( $instance[ 'defimage' ] ),
				'showauthor' => (bool) $instance[ 'showauthor' ],
				'showtime' 	=> (bool) $instance[ 'showtime' ],
				'format' 	=> esc_attr( $instance[ 'format' ] ),
				'spot' 		=> esc_attr( $instance[ 'spot' ] ),
			);

		if ( !empty( $title ) &&  !empty( $link ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}
		else if ( !empty( $title ) ) {
			 echo $before_title . $title . $after_title;
		}
        //print recent posts
		dg_fgpsnnetworkdocuments($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['link'] = esc_attr($new_instance['link']);
		$instance['hideposttitle'] = $new_instance['hideposttitle'] ? 1 : 0;
		$instance['separator'] = $new_instance['separator'];
		$instance['afterexcerpt'] = $new_instance['afterexcerpt'];
		$instance['afterexcerptlink'] = $new_instance['afterexcerptlink'] ? 1 : 0;
		$instance['show_type'] = $new_instance['show_type'];

		$instance['shownum'] = isset($new_instance['show-num']) ? (int) abs($new_instance['show-num']) : (int) abs($new_instance['shownum']);
	//	if ($instance['shownum'] > 20) $instance['shownum'] = 20;
		unset($instance['show-num']);

		$instance['postoffset'] = (int) abs($new_instance['postoffset']);
		$instance['reverseorder'] = $new_instance['reverseorder'] ? 1 : 0;

		$instance['excerpt'] = isset($new_instance['excerpt-length']) ? (int) abs($new_instance['excerpt-length']) : (int) abs($new_instance['excerpt']);
		unset($instance['excerpt-length']);

		$instance['excerptlengthwords'] = (int) abs($new_instance['excerptlengthwords']);

		$instance['cats'] = esc_attr($new_instance['cats']);
		$instance['fg_act_document_cat'] = $new_instance['fg_act_document_cat'] ? 1 : 0;

		$instance['cusfield'] = isset($new_instance['cus-field']) ? esc_attr($new_instance['cus-field']) : esc_attr($new_instance['cusfield']);
		unset($instance['cus-field']);

		$instance['width'] = esc_attr($new_instance['width']);
		$instance['height'] = esc_attr($new_instance['height']);
		$instance['firstimage'] = $new_instance['first-image'] ? 1 : 0;
		$instance['atimage'] = $new_instance['atimage'] ? 1 : 0;
		$instance['defimage'] = esc_url($new_instance['def-image']);
		$instance['showauthor'] = $new_instance['showauthor'] ? 1 : 0;
		$instance['showtime'] = $new_instance['showtime'] ? 1 : 0;
		$instance['format'] = esc_attr($new_instance['format']);
 		$instance['spot'] = esc_attr($new_instance['spot']);
 		unset($instance['spot1']);
 		unset($instance['spot2']);
 		unset($instance['spot3']);
//die($new_instance['spot']);
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		if (isset($instance['spot1'])) $instance['spot'] = $instance['spot1'];
		if (isset($instance['show-num'])) $instance['shownum'] = $instance['show-num'];
		if (isset($instance['excerpt-length'])) $instance['excerpt'] = $instance['excerpt-length'];
		if (isset($instance['cus-field'])) $instance['cusfield'] = $instance['cus-field'];

		$instance = wp_parse_args( (array) $instance, dg_fgpsnnetworkdocuments_defaults() );

		$title 		= esc_attr($instance['title']);
		$link 		= esc_attr($instance['link']);
		$hideposttitle = $instance['hideposttitle'];
		$separator 	= $instance['separator'];
		$afterexcerpt = $instance['afterexcerpt'];
		$afterexcerptlink = $instance['afterexcerptlink'];
		$show_type 	= $instance['show_type'];
		$shownum 	= (int) $instance['shownum'];
		$postoffset	= (int) $instance['postoffset'];
		$reverseorder = $instance['reverseorder'];
		$excerpt = (int) $instance['excerpt'];
		$excerptlengthwords = (int) $instance['excerptlengthwords'];
		$cats 		= esc_attr($instance['cats']);
		$fg_act_document_cat 	= (bool) $instance['fg_act_document_cat'];
		$cus_field 	= esc_attr($instance['cusfield']);
		$width 		= esc_attr($instance['width']);
		$height 	= esc_attr($instance['height']);
		$firstimage	= (bool) $instance['firstimage'];
		$atimage 	= (bool) $instance['atimage'];
		$defimage 	= esc_url($instance['defimage']);
		$showauthor	= (bool) $instance['showauthor'];
		$showtime 	= (bool) $instance['showtime'];
		$format 	= esc_attr($instance['format']);
		$spot 		= esc_attr($instance['spot']);
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Title Link:');?>
				<input class="widefat" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" type="text" value="<?php echo $link; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('shownum'); ?>"><?php _e('Number of documents to show:');?>
				<input id="<?php echo $this->get_field_id('shownum'); ?>" name="<?php echo $this->get_field_name('shownum'); ?>" type="text" value="<?php echo $shownum; ?>" size ="3" /><br />
				<small><?php _e('(at most 20)','fgpsn-network-documents'); ?></small>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('postoffset'); ?>"><?php _e('Number of Documents to skip:');?>
				<input id="<?php echo $this->get_field_id('postoffset'); ?>" name="<?php echo $this->get_field_name('postoffset'); ?>" type="text" value="<?php echo $postoffset; ?>" size ="3" /><br />
				<small><?php _e('(e.g. "1" will skip the most recent post)','fgpsn-network-documents'); ?></small>
			</label>
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('reverseorder'); ?>" name="<?php echo $this->get_field_name('reverseorder'); ?>"<?php checked( $reverseorder ); ?> />
			<label for="<?php echo $this->get_field_id('reverseorder'); ?>"><?php _e('Show documents in reverse order?', 'fgpsn-network-documents');?></label>
		</p>

		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('showauthor'); ?>" name="<?php echo $this->get_field_name('showauthor'); ?>"<?php checked( $showauthor ); ?> />
			<label for="<?php echo $this->get_field_id('showauthor'); ?>"><?php _e('Show Author', 'fgpsn-network-documents');?></label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('cats'); ?>"><?php _e('Document Types:', 'fgpsn-network-documents');?>
				<input class="widefat" id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" type="text" value="<?php echo $cats; ?>" /><br />
				<small>(<?php _e('Doc. Type IDs, separated by commas.', 'fgpsn-network-documents');?>)</small>
			</label>
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('fg_act_document_cat'); ?>" name="<?php echo $this->get_field_name('fg_act_document_cat'); ?>"<?php checked( $fg_act_document_cat ); ?> />
			<label for="<?php echo $this->get_field_id('fg_act_document_cat'); ?>"> <?php _e('Get documents of current document type.', 'fgpsn-network-documents');?>
			<small>(<?php _e('Adds a list of related documents when viewing a single document listing.', 'fgpsn-network-documents');?>)</small></label>
		</p>
		<?php
	} //end of form
}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_network_documents");') );
//Register Widget


// Show recent posts function
function dg_fgpsnnetworkdocuments_defaults() {
$defaults = array( 	'title' => __( 'Network Documents', 'fgpsn-network-documents' ),
					'link' => get_bloginfo( 'url' ) . '/blog/',
					'hideposttitle' => 0,
					'separator' => ': ',
					'afterexcerpt' => '...',
					'afterexcerptlink' => 0,
					'show_type' => 'property_doc',
					'postoffset' => 0,
					'limit' => 10,
					'shownum' => 10,
					'reverseorder' => 0,
					'excerpt' => 0,
					'excerptlengthwords' => 0,
					'fg_act_document_cat' => 0,
					'cats' => '',
					'cusfield' => '',
					'width' => '',
					'height' => '',
					'w' => '',
					'h' => '',
					'firstimage' => 0,
					'showauthor' => 0,
					'showtime' => 0,
					'atimage' => 0,
					'defimage' => '',
					'format' => 'm/d/Y',
					'spot' => 'spot1' );
	return $defaults;
}


function dg_fgpsnnetworkdocuments($args = '', $echo = true) {
	global $wpdb;
	$defaults = dg_fgpsnnetworkdocuments_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);

	//one fg_act_document_cat check
	$cut_post_types = get_post(get_the_id());

	$hideposttitle = (bool) $hideposttitle;
	$separator = $separator;
	$afterexcerpt = $afterexcerpt;
	$afterexcerptlink = (bool) $afterexcerptlink;
	$show_type = $show_type;

	$shownum = (int) abs($shownum);
	if(isset($limit) && $shownum == 10) $shownum = (int) $limit;
	$postoffset = (int) abs($postoffset);
	$reverseorder = (int) abs($reverseorder);
	$firstimage = (bool) $firstimage;
	$showauthor = (bool) $showauthor;
	$showtime = (bool) $showtime;

	$spot = esc_attr($spot);

	$atimage = (bool) $atimage;
	$defimage = esc_url($defimage);
	$format = esc_attr($format);
	$time = '';
	$width = (int) $width;
	$height = (int) $height;
	$w = (int) $w;
	$h = (int) $h;
	if ($width > $w) {
		$width = $width; $height = $height;
	} else {
		$width = $w; $height = $h;
	}

	$excerptlength = (int) abs($excerpt);
	$excerptlengthwords = (int) abs($excerptlengthwords);
	$excerpt = '';
	$cats = str_replace(" ", "", esc_attr($cats));
	if (($shownum < 1 ) || ($shownum > 20)) $shownum = 10;
	
	global $wpdb;
	global $current_user;
	global $disp_wos;
	$disp_wos = '';
	get_currentuserinfo();
	$postid = get_the_ID();
				
	$args = array(
				'network_id' => $wpdb->siteid,
				'public'     => null,
				'archived'   => null,
				'mature'     => null,
				'spam'       => null,
				'deleted'    => null,
				'limit'      => 100,
				'offset'     => 0,
				);
							
	$property_ids = wp_get_sites( $args );
	$property_ct = count( $property_ids);
			
	foreach ($property_ids as $k=>$v) {
		foreach ($v as $k1=>$v1) {
			//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
			if ($k1 == 'blog_id') {
				$blog_details = get_blog_details($v1, true);
				$user_query = new WP_User_Query( array( 'blog_id' => $v1 ) );
				// User Loop
				if ( ! empty( $user_query->results ) && $blog_details->blogname != '' ) {
					if ( in_array( $current_user->ID, $user_query->results) ) {
						/* $disp_data .= '<H4>
							<A HREF=?blog_id=' . $blog_details->blog_id . '>' . $blog_details->blogname . '</A></H4>';
							
						*/
						
						$table_prefix = "wp_" . $blog_details->blog_id . "_";
							$get_wos_sql = "SELECT ID,
													post_title,
													post_date,
													post_status,
													post_author,
													post_date,
													post_excerpt
												FROM  " . $table_prefix . "posts
												WHERE post_type = 'maintenance_requests'
												AND post_status = 'Pending'
												OR ID IN
								( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'work_order_status' AND meta_value = 'New' )";
								
						$terms2[$blog_details->blog_id] = $wpdb->get_results( $wpdb->prepare($get_wos_sql), ARRAY_A);


						if ( is_wp_error( $terms2[$blog_details->blog_id] ) ) {
							$error_string = $terms2->get_error_message();
							$disp_wos .= '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
						}
					}
				}
			}
		}	
	}
	$disp_wos .= '<DIV class="aside"><div id="message" class="error"><p>Array? Object? ';
	foreach($terms2 as $k=>$v) {
		$disp_wos .= '<P><B>Property ID' . $k . '</B></P>';
		foreach($v as $k1=>$v1) {	
			$disp_wos .= '<P>Key: ' . $k1 . ', Value: ' . $v1['post_title'] . '</p>';
		}	
	}
	$disp_wos .= '</div></DIV>';
	
	if ($echo)
		echo $disp_wos;
	else
		return $disp_wos;
}


?>
