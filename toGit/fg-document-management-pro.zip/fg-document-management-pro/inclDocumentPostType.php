<?PHP

/******************************************************
 * DG Creating Documents post type and meta boxes: Document type and the actual file.
*******************************************************/



function custom_post_property_doc() {

		$labels = array(
			'name'               => _x( 'Property Documents', 'post type general name' ),
			'singular_name'      => _x( 'Property Document', 'post type singular name' ),
			'add_new'            => _x( 'Add Document', 'property_doc' ),
			'add_new_item'       => __( 'Add New Document' ),
			'edit_item'          => __( 'Edit Document' ),
			'new_item'           => __( 'New Document' ),
			'all_items'          => __( 'All Documents' ),
			'view_item'          => __( 'View Document' ),
			'search_items'       => __( 'Search Documents' ),
			'not_found'          => __( 'No Documents Found' ),
			'not_found_in_trash' => __( 'No Documents found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Property Documents'
		);

		$args = array(
			'labels'        => $labels,
			'description'   => 'Holds our Property Documents',
			'public'        => true,
			'menu_position' => 6,
			'supports'      => array( 'title', 'editor', 'excerpt', 'author', 'revisions', 'comments', 'page-attributes' ),
			'taxonomies'      => array( 'property_document_types'  ),
			'hierarchical' => true,
			'has_archive'   => true
		);

	register_post_type( 'property_doc', $args );
}
add_action( 'init', 'custom_post_property_doc' );

add_action( 'init', 'create_property_document_types' );
function create_property_document_types() {
 $labels = array(
    'name' => _x( 'Document Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Document Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Document Types' ),
    'all_items' => __( 'All Document Types' ),
    'parent_item' => __( 'Parent Document Type' ),
    'parent_item_colon' => __( 'Parent Document Type:' ),
    'edit_item' => __( 'Edit Document Type' ),
    'update_item' => __( 'Update Document Type' ),
    'add_new_item' => __( 'Add New Document Type' ),
    'new_item_name' => __( 'New Document Type Name' ),
  );

  register_taxonomy('property_document_types','property_doc',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}



add_filter('add_meta_boxes', 'hide_meta_boxes_property_docs');

function hide_meta_boxes_property_docs() {

	remove_meta_box('postexcerpt', 'property_doc', 'normal');
	remove_meta_box('trackbacksdiv', 'property_doc', 'normal');
	remove_meta_box('postcustom', 'property_doc', 'normal');
	remove_meta_box('slugdiv', 'property_doc', 'normal');
	//remove_meta_box('postarea', 'property_doc', 'normal');

	//remove_meta_box('commentstatusdiv', 'property_doc', 'normal');
	//remove_meta_box('commentsdiv', 'property_doc', 'normal');
	remove_meta_box('revisionsdiv', 'property_doc', 'normal');

}

//adding metaboxes for files - add document management:

add_action( 'add_meta_boxes', 'property_doc_file' );
function property_doc_file() {
    $screens = array( 'maintenance_requests', 'property_doc' );
    foreach ($screens as $screen) {
		add_meta_box(
			'property_doc_file',
			__( 'Attach Document', 'myplugin_textdomain' ),
			'property_doc_file_content',
			$screen,
			'side',
			'high'
		);
	}
}

function property_doc_file_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'property_doc_file_content_nonce' );
	echo '<label for="property_doc_file">Attach File: </label>';


	$cur_doc_file = get_post_meta(get_the_ID(), 'property_doc_file', true);


	/* Limit to one doc per post. I'm emulating the document management functions in TLC.

	*/

	if (isset($cur_doc_file) && $cur_doc_file != '') {
		if (is_array($cur_doc_file)) {

			$cur_file = $cur_doc_file[url];

		} else {

			$cur_file = $cur_doc_file;

		}
		echo '<A HREF="' . $cur_file . '" target="_blank">View Document</A>
		<BR>Replace Document: <input id="property_doc_file" name="property_doc_file" value="" type="file">';

	} else {

		echo '<input id="property_doc_file" name="property_doc_file" value="" type="file">';

	}

}


add_action( 'save_post', 'property_doc_file_save' );
function property_doc_file_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['property_doc_file_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

/*
	$property_doc_file = $_POST['property_doc_file']['name'];
	update_post_meta( $post_id, 'property_doc_file', $property_doc_file );

*/

	    // Make sure the file array isn't empty
	    if(!empty($_FILES['property_doc_file']['name'])) {
	   // echo '<H1>NOT EMPTY:' . $_FILES['property_doc_file']['name'] . '</H1>';

	        // Setup the array of supported file types. In this case, it's just PDF.
	        $supported_types = array('application/pdf', 'application/vnd.ms-word');

	        // Get the file type of the upload
	        $arr_file_type = wp_check_filetype(basename($_FILES['property_doc_file']['name']));
	        $uploaded_type = $arr_file_type['type'];

	        // Check if the type is supported. If not, throw an error.
	        if(in_array($uploaded_type, $supported_types) || !in_array($uploaded_type, $supported_types)) {

	            // Use the WordPress API to upload the file
	            $upload = wp_upload_bits($_FILES['property_doc_file']['name'], null, file_get_contents($_FILES['property_doc_file']['tmp_name']));

	            if(isset($upload['error']) && $upload['error'] != 0) {
	                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
	            } else {
	                add_post_meta(get_the_ID(), 'property_doc_file', $upload);
	                update_post_meta(get_the_ID(), 'property_doc_file', $upload);
	            } // end if/else

	        } else {
	            wp_die("The file type that you've uploaded is not a PDF.");
	        } // end if/else

	    } // end if

} // end save_custom_meta_data


/*********************************
//adding metaboxes to create a mailing list of users:

add_action( 'add_meta_boxes', 'note_recipients' );
function note_recipients() {
    $screens = array( 'property_doc' );
    add_meta_box(
        'note_recipients',
        __( 'Choose Recipients', 'myplugin_textdomain' ),
        'note_recipients_content',
        'property_doc',
        'normal',
        'high'
    );
}


function note_recipients_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'note_recipients_content_nonce' );
	echo '<script>
jQuery(document).ready(function() {

	var url = "/post.php?post='; echo $_GET['post'] . '&action=' . $_GET['action'] . '";
	jQuery("#cat_kid").hide();
	jQuery("#docs").hide();

	jQuery("#cat_dad select").change( function() {


		if( jQuery(this).val() != "0" ) {
			var id = jQuery(this).val();
			alert(id);
			var data = { "Administrator" : id };
			alert(data);
			jQuery.post( url, data, function(response) {
			alert(response);
				if(response=="0") {
					set_docs(id);
					jQuery("#cat_kid").hide();
				} else {
					jQuery("#cat_kid").html(response);
					jQuery("#cat_kid").show();
				}
			}, "html");
		} else {
			jQuery("#cat_kid").hide();
		}
	});

	jQuery("#cat_kid").on( "change", "select", function(e) {
		var val = jQuery(e.target).val();
		if( val != "0" ) {
			set_docs(val);
		} else {
			jQuery("#docs").hide();
		}

	});




});
</script><label for="note_recipients"></label>';

	global $wp_roles;
     $roles = $wp_roles->get_names();







    echo '<p id="cat_dad"><SELECT id="cat_dad" name="cat_dad"><OPTION> SELECT </OPTION>';
	foreach($roles as $role) {
	  echo '<OPTION>' . $role . '</OPTION>';
 }//end foreach
	echo '</SELECT></P><p id="cat_kid"><SELECT  id="cat_kid" name="cat_kid" MULTIPLE=5 id="note_recipients" name="note_recipients[]" placeholder="Notify Users" >
		<OPTION VALUE = 0> -- Select Users -- </OPTION>';

			$args = array(


			 	'orderby'      => 'ID'
				 );
				$blogusers = get_users($args);
				foreach ($blogusers as $user) {
				   echo '<OPTION VALUE = ' . $user->ID . '>' . $user->user_email . '</OPTION>';
    			}


	echo '</SELECT></p><p id="docs"></p>';




}


add_action( 'save_post', 'note_recipients_save' );
function note_recipients_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['note_recipients_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$note_recipients = $_POST['note_recipients'];

	// Update the post into the database
 // wp_update_post( $my_post );


	update_post_meta( $post_id, 'note_recipients', $note_recipients );
}
*********************************/
?>
