jQuery(document).ready(function() {
  jQuery( '#fg-documents-accordion' ).accordion({
  heightStyle: 'content'
  });
});