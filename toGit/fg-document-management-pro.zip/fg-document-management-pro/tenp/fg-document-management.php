<?php
/*
Plugin Name: Create Document Library
Plugin URI: http://www.2265solutions.com
Description: Add Document Post type with custom taxonomy, display shortcodes, and sidebar widget to display a customizable selection of documents. Premium version includes ability to restrict document access by document type, user role, and/or individually as well as additional display parameters.
Version: 1
Author: Dennis Gannon
Author URI: http://www.2265solutions.com
*/

/*  Copyright 2013  Dennis Gannon  (email : dgannon@2265solutions.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

//include post type and taxonomy
include("fg-inclDocumentPostType.php");
include("network-documents-widget.php");
/*
function update_edit_form() {
	echo ' enctype="multipart/form-data"';
} // end update_edit_form
add_action('post_edit_form_tag', 'update_edit_form');
*/
function fg_single_document( $fg_doc_id ){

	$fg_cur_document = get_post( $fg_doc_id );
	echo '<h1 class="fg-document-title">' . $fg_cur_document->post_title . '</h1>
	<div class="entry-content">' . $fg_cur_document->post_content . '</DIV>';
	$cur_doc_file = get_post_meta($fg_cur_document->ID, 'property_doc_file', true);
	if (is_array($cur_doc_file)) {

		$cur_file = $cur_doc_file[url];

	} else {

		$cur_file = $cur_doc_file;

	}
		$file_name = basename($cur_file);
		$file_size = @filesize($cur_file);

		//format file size
		$length = strlen($file_size);

		if ($length == 8) {

			$start = substr($file_size, 0,2);
			$end = substr($file_size, 2,2);

			$disp_size = $start . "." . $end . "MB";

		} elseif ($length == 7) {

			$start = substr($file_size, 0,1);
			$end = substr($file_size, 1,2);

			$disp_size = $start . "." . $end . "MB";

		} elseif ($length == 6) {


			$end = substr($file_size, 1,2);

			$disp_size = "." . $end . "MB";

		} elseif ($length == 5) {


			$end = substr($file_size, 1,2);

			$disp_size = $end . "kb";

		} elseif ($length == 4) {


			$end = substr($file_size, 1,1);

			$disp_size = $end . "kb";

		} else {

			$disp_size = "N/A";

		}

		$file_extension = strtolower(substr(strrchr($file_name,"."),1));

		switch( $file_extension ) {

		     case "pdf": $file_type="PDF File"; break;
		     case "exe": $file_type="application/octet-stream"; break;
		     case "zip": $file_type="application/zip"; break;
		     case "doc": $file_type="MS Word File"; break;
		     case "xls": $file_type="MS Excel File"; break;
		     case "ppt": $file_type="application/vnd.ms-powerpoint"; break;
		     case "gif": $file_type=".gif Image File"; break;
		     case "png": $file_type=".png Image File"; break;
		     case "jpeg":
		     case "jpg": $file_type=".jpg Image File"; break;
		     case "mp3": $file_type="audio/mpeg"; break;
		     case "wav": $file_type="audio/x-wav"; break;
		     case "mpeg":
		     case "mpg":
		     case "mpe": $file_type="video/mpeg"; break;
		     case "mov": $file_type="video/quicktime"; break;
		     case "avi": $file_type="video/x-msvideo"; break;
			 case "tiff": $file_type=".tiff Image File"; break;
			 case "tif": $file_type=".tiff Image File"; break;

			 default: $file_type="N/A";

		}

		switch( $file_extension ) {
		     case "pdf": $icon_src="images/icon_pdf.png"; break;
		     case "doc": $icon_src="images/icon_msword.png"; break;
		     case "xls": $icon_src="images/icon_xls.png"; break;
		     case "ppt": $icon_src="images/icon_msppt.png"; break;
		     case "gif": $icon_src=".gif Image File"; break;
		     case "png": $icon_src=".png Image File"; break;
		     case "jpg": $icon_src=".jpg Image File"; break;
			 case "tiff": $icon_src="images/icon_tiff.png"; break;
			 case "tif": $icon_src="images/icon_tiff.png"; break;

			 default: $icon_src="";

		}

	echo '<TABLE class="fg-document-meta">
		<TR><TH COLSPAN=2>Document Data</TH></TR>
		<TR><TH><label>File Size:</label></TH><TD>' . $disp_size . '</TD></TR>
		<TR><TH><label>File Type:</label></TH><TD>' . $file_extension . '</TD></TR>
		<TR><TH><label>Download:</label></TH><TD><A HREF="' . $cur_file . '" target="_blank">' . $fg_cur_document->post_title . '</A></TD></TR>
		<TR><TH><label>Edit:</label></TH><TD><A HREF=' . site_url() . '/manage-documents/?gform_post_id=' . $fg_cur_document->ID . '" target="_blank">Edit Document Data</A></TD></TR>
		</TABLE>';

	$cur_location = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	$domain = strstr($cur_location, '?');
	$back_link = str_replace($domain, '', $cur_location);

	echo '<a href="http://' . $back_link . '">Back to document list</A><BR>';


}

//add shortcode for creating a Property Data Page

function get_property_documents( $atts ){

	/* For multi site this function must take doc type information from the root site and replicate it
	 * in each property site as it's viewed
	 * First get the docs from root and insert them locally then run the local functions below
	 */

	global $wpdb;
	global $user;
	//global $switched;
	//switch_to_blog(14);
	//$blog_details = get_blog_details(14, true);
	//switch_to_blog($v->blog_id);

	$args = array(
	'offset'           => 0,
	'post_type'        => 'property_doc',
	'post_status'      => 'publish',
	'suppress_filters' => true );

	$communications = get_posts( $args );

	$property_ct = count( $communications);
	$cur_property =  get_bloginfo();
	$current_user = wp_get_current_user();
	$user_roles = get_userdata( $current_user-ID );
	$cur_role = $user_roles->roles;

	echo '<p><TABLE><TR><TH colspan=4>' . $cur_property . ' Documents</TH></TR>';
	//for each property, set the message and communications as a Metavalue?
	echo '</table></P>';

	//	restore_current_blog();
	//first check if its a single. If so skip displaying list
	$cut_post_types = get_post(get_the_id());
	if (  isset( $_GET['fg_doc_id'] ) ) {
		fg_single_document( $_GET['fg_doc_id'] );
		return false;
	}

	wp_enqueue_script( 'jquery-ui-accordion' );
	$disp_data = "<script type='text/javascript' language='javascript' src='http://datatables.net/release-datatables/media/js/jquery.js'></script><link rel='stylesheet' href='http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css' />

	<script>
	jQuery(document).ready(function() {
	jQuery( '#fg-documents-accordion' ).accordion({
	heightStyle: 'content'
	});
	});
	</script>";

	/* setup attribute distinguish property vs. service vendor using parent categories */
	extract( shortcode_atts( array(
		'document_types' => 0
	), $atts ) );
	$document_types = "{$document_types}";

	$args = array(
		'post_type'        => 'property_doc',
		'taxonomy' => 'property_document_types',
		'include' => $document_types,
		'hide_empty'  		=> 1,
		'show_count'         => 1,
		'hierarchical'  => true,
		'order' => ASC);

	$terms = get_terms("property_document_types", $args);


	 $count = count($terms);
	 //echo '<H2>Query 228: ' . $wpdb->last_query . ', Count: ' . $count . '</H2>';
	 if ( $count > 0 ){
		 /* $disp_data .= "<ul class='no_bullets top'>"; */
		 $disp_data .= "<div id='fg-documents-accordion'>";
		 foreach ( $terms as $term ) {

			//now get terms where ID is parent
			/* $disp_data .= "<li class='level_1'><A HREF='"  . get_bloginfo('url') . "/property_document_types/" . $term->slug . "/'>" . $term->name . " (" . $term->count . ")</A>"; */

			$disp_data .= "<H3>" . $term->name . " <DIV STYLE='display: inline; position: relative; float: right; font-size: 70%; color: blue; padding-right: 20px; padding-top: 7px;'> Total: " . $term->count . "</DIV><DIV STYLE='display: inline; position: relative; float: right; font-size:  70%; color: blue; padding-right: 20px; padding-top: 7px;'> Most Recent:" . get_the_time('D j, Y', $term->ID) . "</DIV>Line 239</H3>";
			$cur_slug = $term->slug;


		 /*trustees query
		 $args2 = array(
			'post_type'        => 'property_doc',
			'meta_key' =>  'set_group_document_access',
			'meta_value' => 'Trustee',
			'property_document_types' => $cur_slug,
			'hide_empty'  		=> 0,
			'hierarchical'  => true,
			'show_count'         => 1
			);
*/
		/*general query*/
				 $args2 = array(
					'post_type'        => 'property_doc',
					'property_document_types' => $cur_slug,
					'hide_empty'  		=> 0,
					'hierarchical'  => true,
					'show_count'         => 1
					);

//echo $disp_data . "<H3>LINE 265 - " . $cur_slug ."</H3>";

$terms2 = get_posts($args2);
//echo "<H3>LINE 265 - </H3>";


		 if ( is_wp_error( $terms2 ) ) {
		    $error_string = $terms2->get_error_message();
		    echo '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
}
		 //$disp_data .= "<H3>LINE 256 - " . $terms2 ."</H3>";
		// echo $disp_data;
		  $count2 = count($terms2);
		  if ( $count2 > 0 ){
			 /* $disp_data .= "<ul class='no_bullets'>"; */

			//get user role - certain roles can edit document data
			if ( in_array('property_manager', $cur_role) ) {
				$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
				<TBODY>";
			} else {
				$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
				<TBODY>";
			 $disp_data .= "</TH></TR></THEAD>
			  <TBODY>";


			  }
			  foreach ( $terms2 as $term2 ) {

				$cur_doc_file = get_post_meta($term2->ID, 'property_doc_file', true);
				if (is_array($cur_doc_file)) {

					$cur_file = $cur_doc_file[url];

				} else {

					$cur_file = $cur_doc_file;

				}
				$disp_data .= "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $term2->ID . "'>" . $term2->post_title . "</A></TD>
				<TD>" . get_the_time('D j, Y', $term2->ID) . "</TD>
				<TD><A HREF='" . $cur_file . "' target='_blank'>View</A>
				<BR><A HREF='https://www.googleapis.com/drive/v2/files/0Bz2Av5rKd4lLaFRXdmY2bHg0bDQ?updateViewedDate=true&alt=media&key=AIzaSyD_tH573SkrKN0pzVY5Yo3wjmEu8al55p4'>View</A>
				<BR><A HREF='" . plugins_url( 'docs3.php', __FILE__ ) ."'>View</A></TD>";
				if ( in_array('property_manager', $cur_role) ) {
					$disp_data .= "<TD><a href='" . site_url() . "/manage-documents/?gform_post_id=" . $term2->ID . "'>Edit</A></TD>";
				} else {
					$disp_data .= "<TD><a href='" . site_url() . "/manage-documents/?gform_post_id=" . $term2->ID . "'>Edit</A></TD>";
				}
				$disp_data .= "</TR>";

			  }
			  $disp_data .= "</TABLE>";
		 }


		/* $disp_data .= "</li>"; */

		 }
		/* $disp_data .= "</ul>"; */
		$disp_data .= "</DIV>";
	 }
	 //echo $disp_data;
	 //$disp_data .= phpinfo();
	return $disp_data;
}
add_shortcode( 'property_documents', 'get_property_documents' );


/*sql functions form mmc*/

function SQLget_property_documents( $atts ){


	/* For multi site this function must take doc type information from the root site and replicate it
	 * in each property site as it's viewed
	 * First get the docs from root and insert them locally then run the local functions below
	 */
	global $db_connection;
	global $yardi_connection;
	global $maint_connection;
	global $cs_connection;
	global $wpdb;
	global $user;
	
	wp_enqueue_script( 'jquery-ui-accordion' );
	$disp_data = "<script type='text/javascript' language='javascript' src='http://datatables.net/release-datatables/media/js/jquery.js'></script><link rel='stylesheet' href='http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css' />

	<script>
	jQuery(document).ready(function() {
	jQuery( '#fg-documents-accordion' ).accordion({
	heightStyle: 'content'
	});
	});
	</script>";
	$disp_data .= "<div id='fg-documents-accordion'>";
	$fetch_types = "SELECT * FROM menu_doc_types ORDER BY doc_type_title ASC";

		$get_types = odbc_exec($db_connection, $fetch_types);
		$ct_id = 10000000000;
		while ($these_types = odbc_fetch_row($get_types)) {
			$type_ID = odbc_result($get_types, 1);
			$type_title = odbc_result($get_types, 2);
			$doc_summary = "SELECT
							COUNT(document_type) AS 'Num of Docs.'
							FROM property_documents
							WHERE property_documents.property_ID = 625

							AND document_type = $type_ID";

			$make_documents_query = odbc_exec($db_connection, $doc_summary);
			$documents_query_results = odbc_fetch_row($make_documents_query);

			$num = odbc_result($make_documents_query, 1);
			$rowcounter = 0;
			if ( $num != 0 ) {
				
				$date = "SELECT TOP 1 posted_date
						FROM property_documents
						WHERE property_documents.property_ID = 625

						AND document_type = $type_ID
						ORDER BY posted_date DESC";

				odbc_free_result($make_documents_query);

				$make_date_query = odbc_exec($db_connection, $date);
				$date_query_results = odbc_fetch_row($make_date_query);
				$ref_date = odbc_result($make_date_query, 1);
				$ref_date = substr($ref_date,0,10);
				
				/*$type_title</SPAN></TD>\n
							<TD ALIGN=center class=\"KnockoutDataTD\">
							<B>$num</B></TD>\n
							<TD ALIGN=center NOWRAP class=\"KnockoutDataTD\"><B>$ref_date</B>
				*/
				
					$disp_data .= "<H3>" . $type_title . " <DIV STYLE='display: inline; position: relative; float: right; font-size: 70%; color: blue; padding-right: 20px; padding-top: 7px;'> Total: " . $num . "</DIV><DIV STYLE='display: inline; position: relative; float: right; font-size:  70%; color: blue; padding-right: 20px; padding-top: 7px;'> Most Recent:" . $ref_date . "</DIV></H3>";
				
				
				$get_properties = "SELECT mmcyardi6.dbo.property.hmy,
								mmcyardi6.dbo.property.saddr1,
								mmcyardi6.dbo.property.scity,
								mmcyardi6.dbo.tenant.hproperty,
								mmcyardi6.dbo.tenant.sfirstname,
								mmcyardi6.dbo.tenant.slastname,
								mmcyardi6.dbo.tenant.hmyperson,
								tlc.dbo.property_documents.document_ID,
								tlc.dbo.property_documents.property_ID,
								tlc.dbo.property_documents.document_type,
								tlc.dbo.property_documents.associated_date,
								tlc.dbo.property_documents.document_path,
								tlc.dbo.property_documents.document_ID,
								tlc.dbo.property_documents.contact_ID,
								tlc.dbo.property_documents.financial_trustees,
								tlc.dbo.property_documents.financial_all,
								tlc.dbo.property_documents.proposal_trustees,
								tlc.dbo.property_documents.proposal_all,
								tlc.dbo.menu_doc_types.doc_type_title,
								tlc.dbo.property_documents.doc_description,
								tlc.dbo.property_documents.pub_access,
								tlc.dbo.property_documents.access_level,
								tlc.dbo.property_documents.posted_date
								FROM tlc.dbo.menu_doc_types, mmcyardi6.dbo.property,
								tlc.dbo.property_documents LEFT JOIN mmcyardi6.dbo.tenant
								ON tlc.dbo.property_documents.contact_ID = mmcyardi6.dbo.tenant.hmyperson
								WHERE tlc.dbo.menu_doc_types.doc_type_ID = tlc.dbo.property_documents.document_type
								AND mmcyardi6.dbo.property.hmy = 625
								AND mmcyardi6.dbo.property.hmy = tlc.dbo.property_documents.property_ID
								AND tlc.dbo.property_documents.document_type = $type_ID
								ORDER BY tlc.dbo.property_documents.posted_date DESC";


				//echo "$selected_property<BR><BR>$get_properties";
				$these_properties = odbc_exec($yardi_connection, $get_properties);
				$t = 0; //for title col
					
				/*start diplay logic*/
				if ( in_array('property_manager', $cur_role) ) {
						$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
						<TBODY>";
					} else {
						$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
						<TBODY>";

				  }	
				
				while(odbc_fetch_row($these_properties)) {

					$property_ID = odbc_result($these_properties, 1);
					$address_1 = odbc_result($these_properties, 2);
					$city = odbc_result($these_properties, 3);
					$doc_ID = odbc_result($these_properties, 13);
					$doc_type = odbc_result($these_properties, 10);
					$doc_date = odbc_result($these_properties, 11);
					$doc_date = substr($doc_date, 0, 10);
					$link_1 = odbc_result($these_properties, 12);
					$f_name = odbc_result($these_properties, 5);
					$l_name = odbc_result($these_properties, 6);
					$contact_ID = odbc_result($these_properties, 14);

					$trustee_release = odbc_result($these_properties, 15);
					$all_release = odbc_result($these_properties, 16);

					$prop_trustee_release = odbc_result($these_properties, 17);
					$prop_all_release = odbc_result($these_properties, 18);
					$doc_type_title = odbc_result($these_properties, 19);
					$doc_desc = odbc_result($these_properties, 20);
					$pub_doc = odbc_result($these_properties, 21);
					$allowed = odbc_result($these_properties, 22);


					$file_name = basename($link_1);
					$file_size = @filesize($link_1);

					$file_extension = strtolower(substr(strrchr($file_name,"."),1));

					 switch( $file_extension ) {
						 case "pdf": $icon_src="../graphics/icon_pdf.png"; break;
						 case "doc": $icon_src="../graphics/icon_msword.png"; break;
						 case "xls": $icon_src="../graphics/icon_xls.png"; break;
						 case "ppt": $icon_src="../graphics/icon_msppt.png"; break;
						 case "gif": $icon_src=".gif Image File"; break;
						 case "png": $icon_src=".png Image File"; break;
						 case "jpg": $icon_src=".jpg Image File"; break;
						 case "tiff": $icon_src="../graphics/icon_tiff.png"; break;
						 case "tif": $icon_src="../graphics/icon_tiff.png"; break;

						 default: $icon_src="";

					}
						
					if ($doc_desc == '') {
						$doc_desc = "N/A";
					} else {
						$doc_desc = urldecode($doc_desc);
						$doc_desc = stripslashes($doc_desc);
					}

					if ($contact_ID == '0') {
						$f_name = "All Tenants";
					}

					if ($allowed == 0) {
						$f_name = "Private";
						$l_name = "";
					} elseif ($allowed == 1) {
						$f_name = "Trustees Only";
						$l_name = "";
					} elseif ($allowed == 2) {
						$f_name = "All Units";
						$l_name = "";

					}

					if (!isset($doc_date) || $doc_date == '1900-01-01' || $doc_date == '') {
						$doc_date = "N/A";
					}
					
					$disp_data .= "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $term2->ID . "'>" . $doc_type_title . "</A></TD>
					<TD>" . get_the_time('D j, Y', $doc_date) . "</TD>
					<TD>Filesize: " . $file_size . "
					<BR><A HREF='http://www.mediatemanagement.com/tlc/wp-content/themes/oxygen-child/docs3.php?doc=" . $doc_ID . "' target='_blank'>View</A>
					<BR><A HREF='https://www.googleapis.com/drive/v2/files/0Bz2Av5rKd4lLaFRXdmY2bHg0bDQ?updateViewedDate=true&alt=media&key=12d46a80303e60c5b5e72847b094d0b0f8edb019'>View</A></TD>";
							
					if ( in_array('property_manager', $cur_role) ) {
						$disp_data .= "<TD><a href='" . site_url() . "/manage-documents/?gform_post_id=" . $doc_id . "'>Edit</A></TD>";
					} else {
						$disp_data .= "<TD><a href='" . site_url() . "/manage-documents/?gform_post_id=" . $doc_id . "'>Edit</A></TD>";
					}
					$disp_data .= "</TR>";
				
				}
				$disp_data .= "</tbody></table>";
				
			}
		$disp_data .= "";
		}
		$disp_data .= "</DIV>";
	 
	 //echo $disp_data;
	return $disp_data;
}
add_shortcode( 'sql_property_documents', 'SQLget_property_documents' );





class dg_recent_documents extends WP_Widget {

	function dg_recent_documents() {
		//Load Language
		load_plugin_textdomain( 'recent-documents', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows most recent documents. Customize by category or related documents.', 'recent-documents' ) );
		//Create widget
		$this->WP_Widget( 'recentdocuments', __( 'Recent Documents', 'recent-documents' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );
		$link = empty( $instance[ 'link' ]) ? '' : $instance[ 'link' ];
		$parameters = array(
				'title' 	=> $title,
				'link' 		=> $instance[ 'link' ],
				'hideposttitle' => $instance[ 'hideposttitle' ],
				'separator' => $instance[ 'separator' ],
				'afterexcerpt' => $instance[ 'afterexcerpt' ],
				'afterexcerptlink' => $instance[ 'afterexcerptlink' ],
				'show_type' => 'property_doc',
				'shownum' 	=> (int) $instance[ 'shownum' ],
				'postoffset' => (int) $instance[ 'postoffset' ],
				'reverseorder' => (int) $instance[ 'reverseorder' ],
				'excerpt' 	=> (int) $instance[ 'excerpt' ],
				'excerptlengthwords' => (int) $instance[ 'excerptlengthwords' ],
				'fg_act_document_cat' 	=> (bool) $instance[ 'fg_act_document_cat' ],
				'cats' 		=> esc_attr( $instance[ 'cats' ] ),
				'cusfield' 	=> esc_attr( $instance[ 'cusfield' ] ),
				'w' 		=> (int) $instance[ 'width' ],
				'h' 		=> (int) $instance[ 'height' ],
				'firstimage' => (bool) $instance[ 'firstimage' ],
				'atimage' 	=>(bool) $instance[ 'atimage' ],
				'defimage' 	=> esc_url( $instance[ 'defimage' ] ),
				'showauthor' => (bool) $instance[ 'showauthor' ],
				'showtime' 	=> (bool) $instance[ 'showtime' ],
				'format' 	=> esc_attr( $instance[ 'format' ] ),
				'spot' 		=> esc_attr( $instance[ 'spot' ] ),
			);

		if ( !empty( $title ) &&  !empty( $link ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}
		else if ( !empty( $title ) ) {
			 echo $before_title . $title . $after_title;
		}
        //print recent posts
		dg_recentdocuments($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['link'] = esc_attr($new_instance['link']);
		$instance['hideposttitle'] = $new_instance['hideposttitle'] ? 1 : 0;
		$instance['separator'] = $new_instance['separator'];
		$instance['afterexcerpt'] = $new_instance['afterexcerpt'];
		$instance['afterexcerptlink'] = $new_instance['afterexcerptlink'] ? 1 : 0;
		$instance['show_type'] = $new_instance['show_type'];

		$instance['shownum'] = isset($new_instance['show-num']) ? (int) abs($new_instance['show-num']) : (int) abs($new_instance['shownum']);
	//	if ($instance['shownum'] > 20) $instance['shownum'] = 20;
		unset($instance['show-num']);

		$instance['postoffset'] = (int) abs($new_instance['postoffset']);
		$instance['reverseorder'] = $new_instance['reverseorder'] ? 1 : 0;

		$instance['excerpt'] = isset($new_instance['excerpt-length']) ? (int) abs($new_instance['excerpt-length']) : (int) abs($new_instance['excerpt']);
		unset($instance['excerpt-length']);

		$instance['excerptlengthwords'] = (int) abs($new_instance['excerptlengthwords']);

		$instance['cats'] = esc_attr($new_instance['cats']);
		$instance['fg_act_document_cat'] = $new_instance['fg_act_document_cat'] ? 1 : 0;

		$instance['cusfield'] = isset($new_instance['cus-field']) ? esc_attr($new_instance['cus-field']) : esc_attr($new_instance['cusfield']);
		unset($instance['cus-field']);

		$instance['width'] = esc_attr($new_instance['width']);
		$instance['height'] = esc_attr($new_instance['height']);
		$instance['firstimage'] = $new_instance['first-image'] ? 1 : 0;
		$instance['atimage'] = $new_instance['atimage'] ? 1 : 0;
		$instance['defimage'] = esc_url($new_instance['def-image']);
		$instance['showauthor'] = $new_instance['showauthor'] ? 1 : 0;
		$instance['showtime'] = $new_instance['showtime'] ? 1 : 0;
		$instance['format'] = esc_attr($new_instance['format']);
 		$instance['spot'] = esc_attr($new_instance['spot']);
 		unset($instance['spot1']);
 		unset($instance['spot2']);
 		unset($instance['spot3']);
//die($new_instance['spot']);
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		if (isset($instance['spot1'])) $instance['spot'] = $instance['spot1'];
		if (isset($instance['show-num'])) $instance['shownum'] = $instance['show-num'];
		if (isset($instance['excerpt-length'])) $instance['excerpt'] = $instance['excerpt-length'];
		if (isset($instance['cus-field'])) $instance['cusfield'] = $instance['cus-field'];

		$instance = wp_parse_args( (array) $instance, dg_recentdocuments_defaults() );

		$title 		= esc_attr($instance['title']);
		$link 		= esc_attr($instance['link']);
		$hideposttitle = $instance['hideposttitle'];
		$separator 	= $instance['separator'];
		$afterexcerpt = $instance['afterexcerpt'];
		$afterexcerptlink = $instance['afterexcerptlink'];
		$show_type 	= $instance['show_type'];
		$shownum 	= (int) $instance['shownum'];
		$postoffset	= (int) $instance['postoffset'];
		$reverseorder = $instance['reverseorder'];
		$excerpt = (int) $instance['excerpt'];
		$excerptlengthwords = (int) $instance['excerptlengthwords'];
		$cats 		= esc_attr($instance['cats']);
		$fg_act_document_cat 	= (bool) $instance['fg_act_document_cat'];
		$cus_field 	= esc_attr($instance['cusfield']);
		$width 		= esc_attr($instance['width']);
		$height 	= esc_attr($instance['height']);
		$firstimage	= (bool) $instance['firstimage'];
		$atimage 	= (bool) $instance['atimage'];
		$defimage 	= esc_url($instance['defimage']);
		$showauthor	= (bool) $instance['showauthor'];
		$showtime 	= (bool) $instance['showtime'];
		$format 	= esc_attr($instance['format']);
		$spot 		= esc_attr($instance['spot']);
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Title Link:');?>
				<input class="widefat" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" type="text" value="<?php echo $link; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('shownum'); ?>"><?php _e('Number of documents to show:');?>
				<input id="<?php echo $this->get_field_id('shownum'); ?>" name="<?php echo $this->get_field_name('shownum'); ?>" type="text" value="<?php echo $shownum; ?>" size ="3" /><br />
				<small><?php _e('(at most 20)','recent-documents'); ?></small>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('postoffset'); ?>"><?php _e('Number of Documents to skip:');?>
				<input id="<?php echo $this->get_field_id('postoffset'); ?>" name="<?php echo $this->get_field_name('postoffset'); ?>" type="text" value="<?php echo $postoffset; ?>" size ="3" /><br />
				<small><?php _e('(e.g. "1" will skip the most recent post)','recent-documents'); ?></small>
			</label>
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('reverseorder'); ?>" name="<?php echo $this->get_field_name('reverseorder'); ?>"<?php checked( $reverseorder ); ?> />
			<label for="<?php echo $this->get_field_id('reverseorder'); ?>"><?php _e('Show documents in reverse order?', 'recent-documents');?></label>
		</p>

		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('showauthor'); ?>" name="<?php echo $this->get_field_name('showauthor'); ?>"<?php checked( $showauthor ); ?> />
			<label for="<?php echo $this->get_field_id('showauthor'); ?>"><?php _e('Show Author', 'recent-documents');?></label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('cats'); ?>"><?php _e('Document Types:', 'recent-documents');?>
				<input class="widefat" id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" type="text" value="<?php echo $cats; ?>" /><br />
				<small>(<?php _e('Doc. Type IDs, separated by commas.', 'recent-documents');?>)</small>
			</label>
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('fg_act_document_cat'); ?>" name="<?php echo $this->get_field_name('fg_act_document_cat'); ?>"<?php checked( $fg_act_document_cat ); ?> />
			<label for="<?php echo $this->get_field_id('fg_act_document_cat'); ?>"> <?php _e('Get documents of current document type.', 'recent-documents');?>
			<small>(<?php _e('Adds a list of related documents when viewing a single document listing.', 'recent-documents');?>)</small></label>
		</p>
		<?php
	} //end of form
}

add_action( 'widgets_init', create_function('', 'return register_widget("dg_recent_documents");') );
//Register Widget

// Show recent posts function
function dg_recentdocuments_defaults() {
$defaults = array( 	'title' => __( 'Recent Documents', 'recent-documents' ),
					'link' => get_bloginfo( 'url' ) . '/blog/',
					'hideposttitle' => 0,
					'separator' => ': ',
					'afterexcerpt' => '...',
					'afterexcerptlink' => 0,
					'show_type' => 'property_doc',
					'postoffset' => 0,
					'limit' => 10,
					'shownum' => 10,
					'reverseorder' => 0,
					'excerpt' => 0,
					'excerptlengthwords' => 0,
					'fg_act_document_cat' => 0,
					'cats' => '',
					'cusfield' => '',
					'width' => '',
					'height' => '',
					'w' => '',
					'h' => '',
					'firstimage' => 0,
					'showauthor' => 0,
					'showtime' => 0,
					'atimage' => 0,
					'defimage' => '',
					'format' => 'm/d/Y',
					'spot' => 'spot1' );
	return $defaults;
}
add_shortcode( 'amrp' , 'dg_recentdocuments_sc');
function dg_recentdocuments_sc( $atts ) {

	$defaults = dg_recentdocuments_defaults();
// 	$defaults['limit'] = $defaults['shownum'];
// 	unset($shownum);
	$args = shortcode_atts($defaults, $atts);
	return dg_recentdocuments( $args, false );

}

function dg_recentdocuments($args = '', $echo = true) {
	global $wpdb;
	$defaults = dg_recentdocuments_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);

	//one fg_act_document_cat check
	$cut_post_types = get_post(get_the_id());
	if ( ( $fg_act_document_cat ) && ($cut_post_types->post_type == 'property_doc') ) {
		fg_relateddocuments( $args, $echo );
		echo $rel_doc_list;
	}

	$hideposttitle = (bool) $hideposttitle;
	$separator = $separator;
	$afterexcerpt = $afterexcerpt;
	$afterexcerptlink = (bool) $afterexcerptlink;
	$show_type = $show_type;

	$shownum = (int) abs($shownum);
	if(isset($limit) && $shownum == 10) $shownum = (int) $limit;
	$postoffset = (int) abs($postoffset);
	$reverseorder = (int) abs($reverseorder);
	$firstimage = (bool) $firstimage;
	$showauthor = (bool) $showauthor;
	$showtime = (bool) $showtime;

	$spot = esc_attr($spot);

	$atimage = (bool) $atimage;
	$defimage = esc_url($defimage);
	$format = esc_attr($format);
	$time = '';
	$width = (int) $width;
	$height = (int) $height;
	$w = (int) $w;
	$h = (int) $h;
	if ($width > $w) {
		$width = $width; $height = $height;
	} else {
		$width = $w; $height = $h;
	}

	$excerptlength = (int) abs($excerpt);
	$excerptlengthwords = (int) abs($excerptlengthwords);
	$excerpt = '';
	$cats = str_replace(" ", "", esc_attr($cats));
	if (($shownum < 1 ) || ($shownum > 20)) $shownum = 10;

	/*$postlist = wp_cache_get('dg_recent_documents'); //Not yet
	if ( false === $postlist ) {
	*/

		$cats = explode(",", $cats);
		$counter = count($cats);

		if (!intval($cats)) $cats='';
		if ($cats[0] == '') {
			$args = "taxonomy=property_document_types&terms=$cats&showposts=$shownum&post_type=property_doc&offset=$postoffset";
		} else {
			$args=array(
				"tax_query" => array(
					array(
						"taxonomy" => "property_document_types",
						"field" => "id",
						"terms" => $cats
					)
				),
		    'post__not_in' => array(get_the_ID()),
		    'post_type' => 'property_doc',
		    'posts_per_page' => $shownum

			);
		}
		//$related_by_cats = new WP_Query($args);

		$posts = get_posts($args); //get posts
		if ($reverseorder) $posts = array_reverse($posts);
		$postlist = '';

		$postlist .= "";


		$postlist .= "<TABLE ID='fg-doc-display'><thead><TR><TH>Date/Title</TH><TH>View</TH></TR></thead><tbody>\n";
		$cur_doc_ID = get_the_id();
		$fg_doc_types = get_the_terms( $cur_doc_ID, 'property_document_types' );

		//get an array of categories to which the current post is attached
		if ( $fg_doc_types && ! is_wp_error( $fg_doc_types ) ) :
			$fg_doc_types_list = array();
			foreach ( $fg_doc_types as $fg_doc_type ) {
				$fg_doc_types_list[] = $fg_doc_type->slug;
			}

		endif;
		foreach ($posts as $post) {

			if ($showtime) { $time = ' '. date($format,strtotime($post->post_date)); }
			$post_title = stripslashes($post->post_title);

			if ($excerptlength || !$excerptlength) {
				$excerpt = $post->post_excerpt;
				//echo "<H1>397 - " . $excerpt . "<H1>";
				$text = $post->post_content;
				//get document link
				$doc_url =  get_post_meta(get_the_ID(), 'property_doc_file', true);
				$text = strip_shortcodes( $text );
				$text = str_replace(']]>', ']]&gt;', $text);
				$text = strip_tags($text);
				$excerpt_length = 100;
				$words = explode(' ', $text, $excerpt_length + 1);
				if ( '' == $excerpt ) {
					if (count($words) > $excerpt_length) {
						array_pop($words);
						$text = implode(' ', $words);
					}
					$excerpt = $text;
				}
				$afterexcerpt_html = '';
				if ($afterexcerptlink) $afterexcerpt_html = '<a href="' . get_permalink($post->ID) . '">' . $afterexcerpt . '</a>';
				else $afterexcerpt_html = $afterexcerpt;
				if ($excerptlengthwords > 0 ) {
					$words = array_splice($words, 0, $excerptlengthwords);
					$excerpt = implode(' ', $words);
				}elseif(strlen($excerpt) > $excerptlength) {
					$excerpt = mb_substr($excerpt, 0, $excerptlength);
				}
				$excerpt = $separator . ($spot == 'spot3' ? '<TD><span class="date">'.$time.'</span></TD> ' : '') . $excerpt . $afterexcerpt_html;
			}


			$image = '';
			$img = '';
			if ($cusfield) {
				$cusfield = esc_attr($cusfield);
				$img = get_post_meta($post->ID, $cusfield, true);
			}

			if (!$img && $firstimage) {
				$match_count = preg_match_all("/<img[^']*?src=\"([^']*?)\"[^']*?>/", $post->post_content, $match_array, PREG_PATTERN_ORDER);
				$img = count($match_array['1']) > 0 ? $match_array[1][0] : false;
			}
			if (!$img && $atimage) {
				$p = array(
					'post_type' => 'attachment',
					'post_mime_type' => 'image',
					'numberposts' => 1,
					'order' => 'ASC',
					'orderby' => 'menu_order ID',
					'post_status' => null,
					'post_parent' => $post->ID
				 );
				$attachments = get_posts($p);
				if ($attachments) {
					$imgsrc = wp_get_attachment_image_src($attachments[0]->ID, 'thumbnail');
					$img = $imgsrc[0];
				}
			 }

			if (!$img && $defimage)
				$img = $defimage;

			if ($img)
				$image = '<a href="' . get_permalink($post->ID) . '" title="'. $post_title .'" >

				<img STYLE="padding-top: -2em; margin: 0em; padding: 0em; width: 95%; max-width: 300px; min-width: 150px;" src="' . $img . '" title="' . $post_title . '" class="recent-posts-thumb" /></a><BR>';


			$postlist .=  '<TR><TD><a href="' . get_bloginfo( 'url' ) . '/property-documents/?fg_doc_id=' . $post->ID . '">';

			$doc_url = get_post_meta($post->ID, 'property_doc_file', true);
			if (is_array($doc_url)) {
				if (!$hideposttitle) $postlist .= $post_title . '</A>';

					if ($showauthor) {
						$fg_user_data = get_userdata($post->post_author);
						$postlist .= '<BR><small>Posted By: ' . $fg_user_data->user_firstname . ' ' . $fg_user_data->user_lastname . '</small>';

					}

				$postlist .= '</TD><TD><A HREF="' . $doc_url[url] . '" title="View" target="_blank">View</A></TD></TR>';
			} else {
				if (!$hideposttitle) $postlist .= $post_title .'</A>';

					if ($showauthor) {
						$fg_user_data = get_userdata($post->post_author);
						$postlist .= '<BR><small>Posted By: ' . $fg_user_data->user_firstname . ' ' . $fg_user_data->user_lastname . '</small>';

					}

				$postlist .= '</TD><TD><A HREF="' . $doc_url . '" title="View" target="_blank">View</A></TD></TR>';
			}

		}// end foreach()
		$postlist .= "</tbody></TABLE>\n";
		/*
		wp_cache_set('dg_recent_documents', $postlist);
	}*/

	if ($echo)
		echo $postlist;
	else
		return $postlist;
}




/*******************************************************************************/
/**Create related documents function instead of trying to blend it into the recent documents func
/*******************************************************************************/


function fg_relateddocuments_defaults() {
$defaults = array( 	'title' => __( 'Recent Documents', 'recent-documents' ),


					'link' => get_bloginfo( 'url' ) . '/blog/',
					'hideposttitle' => 0,
					'separator' => ': ',
					'afterexcerpt' => '...',
					'afterexcerptlink' => 0,
					'show_type' => 'property_doc',
					'postoffset' => 0,
					'limit' => 10,
					'shownum' => 10,
					'reverseorder' => 0,
					'excerpt' => 0,
					'excerptlengthwords' => 0,
					'fg_act_document_cat' => 0,
					'cats' => '',
					'cusfield' => '',
					'width' => '',
					'height' => '',
					'w' => '',
					'h' => '',
					'firstimage' => 0,
					'showauthor' => 0,
					'showtime' => 0,
					'atimage' => 0,
					'defimage' => '',
					'format' => 'm/d/Y',
					'spot' => 'spot1' );
	return $defaults;
}


function fg_relateddocuments($args = '', $echo = false) {
	global $wpdb;
	$defaults = fg_relateddocuments_defaults();
	//$defaults = array('separator' => ': ','show_type' => 'property_doc', 'limit' => 10, 'excerpt' => 0, 'fg_act_document_cat' => 0, 'cats'=>'', 'cusfield' =>'', 'w' => 48, 'h' => 48, 'firstimage' => 0, 'showauthor' => 0, 'showtime' => 0, 'atimage' => 0, 'defimage' => '', 'format' => 'm/d/Y', 'spot' => 'spot1');

	$args = wp_parse_args( $args, $defaults );
	extract($args);

	$hideposttitle = (bool) $hideposttitle;
	$separator = $separator;
	$afterexcerpt = $afterexcerpt;
	$afterexcerptlink = (bool) $afterexcerptlink;
	$show_type = $show_type;

	$shownum = (int) abs($shownum);
	if(isset($limit) && $shownum == 10) $shownum = (int) $limit;
	$postoffset = (int) abs($postoffset);
	$reverseorder = (int) abs($reverseorder);
	$firstimage = (bool) $firstimage;
	$showauthor = (bool) $showauthor;
	$showtime = (bool) $showtime;

	$spot = esc_attr($spot);

	$atimage = (bool) $atimage;
	$defimage = esc_url($defimage);
	$format = esc_attr($format);
	$time = '';
	$width = (int) $width;
	$height = (int) $height;
	$w = (int) $w;
	$h = (int) $h;
	if ($width > $w) {
		$width = $width; $height = $height;
	} else {
		$width = $w; $height = $h;
	}

	$excerptlength = (int) abs($excerpt);
	$excerptlengthwords = (int) abs($excerptlengthwords);
	$excerpt = '';
	$cats = str_replace(" ", "", esc_attr($cats));
	if (($shownum < 1 ) || ($shownum > 20)) $shownum = 10;

	/*$postlist = wp_cache_get('dg_recent_documents'); //Not yet
	if ( false === $postlist ) {
	*/

		if (($fg_act_document_cat) && (is_tax())) {
			$cats = get_query_var('tax');
		}
		if (($fg_act_document_cat) && (is_single())) {
			$cats = '';
			foreach (get_the_terms( get_the_ID(), 'property_document_types' ) as $catt) {
				$cats .= $catt->term_id.' ';
			}
			$cats = str_replace(" ", ",", trim($cats));

		}
		$cats = explode(",", $cats);
		$counter = count($cats);

		if (!intval($cats)) $cats='';
		if ($cats[0] == '') {
			$args = "taxonomy=property_document_types&terms=$cats&showposts=$shownum&post_type=property_doc&offset=$postoffset";
		} else {
			$args=array(
				"tax_query" => array(
					array(
						"taxonomy" => "property_document_types",
						"field" => "id",
						"terms" => $cats
					)
				),
		    'post__not_in' => array(get_the_ID()),
		    'post_type' => 'property_doc',
		    'posts_per_page' => $shownum

			);
		}
		//$related_by_cats = new WP_Query($args);

		$posts = get_posts($args); //get posts
		if ($reverseorder) $posts = array_reverse($posts);
		$rel_doc_list = '';

		$rel_doc_list .= "";


		$cur_doc_ID = get_the_id();
		$fg_doc_types = get_the_terms( $cur_doc_ID, 'property_document_types' );

		//get an array of categories to which the current post is attached
		if ( $fg_doc_types && ! is_wp_error( $fg_doc_types ) ) :
			$fg_doc_types_list = array();
			foreach ( $fg_doc_types as $fg_doc_type ) {
				$fg_doc_types_list[] = $fg_doc_type->slug;
			}

		endif;
		foreach ($posts as $post) {

			if ($showtime) { $time = ' '. date($format,strtotime($post->post_date)); }
			$post_title = stripslashes($post->post_title);
			if ($excerptlength || !$excerptlength) {
				$excerpt = $post->post_excerpt;
				//echo "<H1>397 - " . $excerpt . "<H1>";
				$text = $post->post_content;
				//get document link
				$doc_url =  get_post_meta(get_the_ID(), 'property_doc_file', true);
				$text = strip_shortcodes( $text );
				$text = str_replace(']]>', ']]&gt;', $text);
				$text = strip_tags($text);
				$excerpt_length = 100;
				$words = explode(' ', $text, $excerpt_length + 1);
				if ( '' == $excerpt ) {
					if (count($words) > $excerpt_length) {
						array_pop($words);
						$text = implode(' ', $words);
					}
					$excerpt = $text;
				}
				$afterexcerpt_html = '';
				if ($afterexcerptlink) $afterexcerpt_html = '<a href="' . get_permalink($post->ID) . '">' . $afterexcerpt . '</a>';
				else $afterexcerpt_html = $afterexcerpt;
				if ($excerptlengthwords > 0 ) {
					$words = array_splice($words, 0, $excerptlengthwords);
					$excerpt = implode(' ', $words);
				}elseif(strlen($excerpt) > $excerptlength) {
					$excerpt = mb_substr($excerpt, 0, $excerptlength);
				}
				$excerpt = $separator . ($spot == 'spot3' ? '<TD><span class="date">'.$time.'</span></TD> ' : '') . $excerpt . $afterexcerpt_html;
			}


			$image = '';
			$img = '';
			if ($cusfield) {
				$cusfield = esc_attr($cusfield);
				$img = get_post_meta($post->ID, $cusfield, true);
			}

			if (!$img && $firstimage) {
				$match_count = preg_match_all("/<img[^']*?src=\"([^']*?)\"[^']*?>/", $post->post_content, $match_array, PREG_PATTERN_ORDER);
				$img = count($match_array['1']) > 0 ? $match_array[1][0] : false;
			}
			if (!$img && $atimage) {
				$p = array(
					'post_type' => 'attachment',
					'post_mime_type' => 'image',
					'numberposts' => 1,
					'order' => 'ASC',
					'orderby' => 'menu_order ID',
					'post_status' => null,
					'post_parent' => $post->ID
				 );
				$attachments = get_posts($p);
				if ($attachments) {
					$imgsrc = wp_get_attachment_image_src($attachments[0]->ID, 'thumbnail');
					$img = $imgsrc[0];
				}
			 }

			if (!$img && $defimage)
				$img = $defimage;

			if ($img)
				$image = '<a href="' . get_permalink($post->ID) . '" title="'. $post_title .'" >

				<img STYLE="padding-top: -2em; margin: 0em; padding: 0em; width: 95%; max-width: 300px; min-width: 150px;" src="' . $img . '" title="' . $post_title . '" class="recent-posts-thumb" /></a><BR>';

			if (($fg_act_document_cat) && is_single()) {//this means show only current category of documents

				$rel_doc_list .= "<h3>Related Documents:</H3>";
				$rel_doc_list .= "<TABLE ID='fg-rel-doc-display'><thead><TR><TH>Date/Title</TH><TH>View</TH></TR></thead><tbody>";

				//create array of all taxonomy terms
				$all_terms = wp_get_post_terms( $post->ID, 'property_document_types' );//get the terms for this post

				foreach ($all_terms as $each_term){

					$counter = count($fg_doc_types_list);
					for ($i = 0; $i <= $counter; $i++) {

						if ($fg_doc_types_list[$i] == $each_term->slug) {

							$original_query = $wp_query;
							$wp_query = null;
							$wp_query = new WP_Query( array(
								'post_type' => 'property_doc',
								'tax_query' => array(
									array(
										'taxonomy' => 'property_document_types',
										'field' => 'slug',
										'terms' => $term->slug, //the taxonomy terms I'd like to dynamically query
										'posts_per_page' => '-1'
										 ),
									),
								'orderby' => 'title',
								'order' => 'ASC'
								) );

								$rel_doc_list .=  '<TR><TD><a href="' . get_permalink($post->ID) . '" >';

								if ( have_posts() ):
									while (have_posts() ) : the_post();

										$doc_url = get_post_meta($post->ID, 'property_doc_file', true);
										if (is_array($doc_url)) {
											if (!$hideposttitle) $rel_doc_list .= $post_title .'</A></TD><TD><A HREF="' . $doc_url[url] . '" title="View" target="_blank">View</A>';

					if ($showauthor) {
						$fg_user_data = get_userdata($post->post_author);
						$rel_doc_list .= '<BR><small>Posted By: ' . $fg_user_data->user_firstname . ' ' . $fg_user_data->user_lastname . '</small>';

					}

				$rel_doc_list .= '</TD></TR>';
										} else {
											if (!$hideposttitle) $rel_doc_list .= $post_title .'</A></TD><TD><A HREF="' . $doc_url . '" title="View" target="_blank">View</A>';

					if ($showauthor) {
						$fg_user_data = get_userdata($post->post_author);
						$rel_doc_list .= '<BR><small>Posted By: ' . $fg_user_data->user_firstname . ' ' . $fg_user_data->user_lastname . '</small>';

					}

				$rel_doc_list .= '</TD></TR>';
										}

									endwhile;
									$rel_doc_list .= '</tbody></TABLE><BR><h3>Other Recent Documents:</H3>';
							 		//echo $post_list;
								endif;
							$wp_query = null;
							$wp_query = $original_query;
							wp_reset_postdata();
						}
					}
			 	}

			 }



		}// end foreach()
		/*
		wp_cache_set('dg_recent_documents', $postlist);
	}*/


	if ($echo)
		echo $rel_doc_list;
	else
		return $rel_doc_list;
}



/*

add_action('admin_init', 'hhs_add_meta_boxes', 1);
function hhs_add_meta_boxes() {
	add_meta_box( 'repeatable-fields', 'Set Reminders', 'hhs_repeatable_meta_box_display', 'property_doc', 'normal', 'default');
}
*/
function hhs_repeatable_meta_box_display() {
	global $post;
	//$repeatable_fields = get_post_meta($post->ID, 'repeatable_fields', true);
	//delete_post_meta(get_the_ID(), 'fg_document_reminder');
	$cur_reminders = get_post_meta(get_the_ID(), 'fg_document_reminder');
	//$checker = count($cur_reminders);

	$cur_doc_url = get_post_meta(get_the_ID(), 'property_doc_file', true);
	//$options = hhs_get_sample_options();

	wp_nonce_field( 'hhs_repeatable_meta_box_nonce', 'hhs_repeatable_meta_box_nonce' );
	?>
	<script type="text/javascript">
	jQuery(document).ready(function( $ ){
		$( '#add-row' ).on('click', function() {
			var row = $( '.empty-row.screen-reader-text' ).clone(true);
			row.removeClass( 'empty-row screen-reader-text' );
			row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
			return false;
		});

		$( '.remove-row' ).on('click', function() {
			$(this).parents('tr').remove();
			return false;
		});
	});
	</script>
	<table id="repeatable-fieldset-one" width="100%">
	<thead>
		<TR>
			<TH>Reminder Notes:</TH>
			<TH>Date</TH>
			<TH>Delete</TH>
		</TR>
	</thead>
	<tbody>
		<TR></TR><TH COLSPAN=4><?php
	echo "</TH></TR><TR><TH COLSPAN=4>";
	//var_dump($cur_reminders);
	$meta_title = $cur_reminders['fg_document_reminder'];
	//echo "<H4>Meta Title" . $meta_title . "</H4>";
	foreach ( $cur_reminders as $k=>$v ) {
		//echo "KReally: " . $k . "; V: " . $v . ";<BR>";

		foreach ( $v as $k1=>$v1 ) {
			//echo "K1: " . $k1 . "; V1: " . $v1 . "<BR>";

			if ( is_array( $v1 ) ) {
				//echo "<UL>";
				foreach ( $v1 as $k2=>$v2 ) {
					//echo "<LI>K2: " . $k2 . "; V2: " . $v2 . "</LI>";
					if ( is_array( $v2 ) ) {
						//echo "<UL>";

						foreach ( $v2 as $k3=>$v3 ) {
							//echo "<LI><B>K3: " . $k3 . "; V3: " . $v3 . "</B></LI>";
							$recip_array[] = $v3;
						}
						//echo "</UL>";
					} elseif($k2 == 'fg_document_reminder_date') {
						$reminder_date = $v2;
					}elseif($k2 == 'fg_document_reminder_notes') {
						$reminder_notes = $v2;
					}

				}
				echo "</UL>";
			}
		}
	}
	echo "</TH></TR>";
	$recip_ct = 1;
	if ( $cur_reminders ) :

	$recip_ct = 1;
	$args = array(
		'fields'       => 'all'
	);

	$blogusers = get_users();
	global $wpdb;
	foreach ($blogusers as $user) {
		$user_emails[] = $user->user_email;
	}

	foreach ( $cur_reminders as $cur_reminder ) {
	?>
     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $reminder_notes; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $reminder_date ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
		<TD valign=top>
     	 <SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />
     	  <OPTION value=""> - Select - </OPTION>\n
			<?PHP
				foreach( $user_emails as $k=>$v ) {
					if ( $v != '' ) {
						echo "<OPTION value='" . $v . "'";
							//if ($cur_reminder[fg_document_reminder_cc] == $v) {
							if ( is_array( $recip_array ) && in_array( $v, $recip_array ) ) {
								echo "selected";
							}
						echo ">" .  $v  . "</OPTION>\n";
					}
				}


			echo '</SELECT>';
			?>
     	</TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
	<?php
	$recip_ct++;
	}
	else :
	// show a blank one
	?>

     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
		<TD valign=top>
     	 <SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />

		<OPTION value=""> - Select - </OPTION>\n
		<?PHP
		$args = array(
			'fields'       => 'all'
		);
						$blogusers = get_users( $args );
						foreach ($blogusers as $user) {
							if ( $user->user_email != '' ) {
								echo "<OPTION value='" . $user->user_email . "'>1132 - " .  $user->user_email  . "</OPTION>\n";
							}
						}

					  echo '</SELECT>';
					?>
     	</TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
<?PHP $recip_ct++; ?>
	<?php

	endif; ?>

	<!-- empty hidden one for jQuery -->
	<tr class="empty-row screen-reader-text">

     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminders[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminders[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
 <TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />

					<OPTION value=""> - Select - </OPTION>\n

					<?PHP

					$args = array(
						'fields'       => 'all'
						 );
				$blogusers = get_users( $args );

				foreach ($blogusers as $user) {
					if ( $user->user_email != '' ) {
						echo "<OPTION value='" . $user->user_email . "'>" .  $user->user_email  . "</OPTION>\n";
					}
   				}

          echo '</SELECT>';

		?>
     	</TD>
     	<?PHP $recip_ct++; ?>
		<td><a class="button remove-row" href="#">Remove</a></td>

	</tr>
	</tbody>
	</table>

	<p><a id="add-row" class="button" href="#">Add another</a></p>
	<?php
}

add_action('save_post', 'hhs_repeatable_meta_box_save');
function hhs_repeatable_meta_box_save($post_id) {

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;

	if (!current_user_can('edit_post', $post_id))
		return;

	if ( $_POST['fg_document_reminder_date'] == '' || empty($_POST['fg_document_reminder_date']) ||
	 $_POST['fg_document_reminder_notes'] == '' || empty($_POST['fg_document_reminder_notes']) ||
	 $_POST['fg_document_reminder_cc_'] == '' || empty($_POST['fg_document_reminder_cc_']))
		return;

	$old = get_post_meta($post_id, 'fg_document_reminder', true);
	$new = array();
	$reminder_notes = $_POST['fg_document_reminder_notes'];
	$reminder_dates = $_POST['fg_document_reminder_date'];
	$reminder_url = $_POST['fg_document_reminder_url'];

	$count = count( $reminder_notes ) - 1;
	for ( $i = 0; $i <= $count; $i++ ) {

		$reminder_cc[$i] = $_POST['fg_document_reminder_cc_' . $i];
		//$reminder_cc[$i] = $_POST;
		//echo "<H3>CC array? " . $reminder_cc[$i] . "</H3>";

	}
	$count = count( $reminder_notes ) - 1;
	echo "<H1>1223 - " . $count . "</H1>";
	for ( $i = 0; $i < $count; $i++ ) {
		if ( $reminder_notes[$i] == '' ||
				$reminder_dates[$i] == '' ||

				$reminder_cc[$i] == '' ) {

			break;
		} else {
			$new[$i]['fg_document_reminder_notes'] = stripslashes( strip_tags( $reminder_notes[$i] ) );
			$new[$i]['fg_document_reminder_date'] = $reminder_dates[$i];
			$new[$i]['fg_document_reminder_url'] = $reminder_url[$i];
			$new[$i]['fg_document_reminder_cc'] = $reminder_cc[$i];

			echo "<LI>CC Notes? " . $new[$i]['fg_document_reminder_notes'] . " - " . $reminder_cc[$i] . "</LI>";
			echo "<LI>CC Date? " . $new[$i]['fg_document_reminder_date'] . " - " . $reminder_cc[$i] . "</LI>";
			echo "<LI>CC URL? " . $new[$i]['fg_document_reminder_url'] . " - " . $reminder_cc[$i] . "</LI>";
			echo "<LI>CC Addresses? " . $new[$i]['fg_document_reminder_cc'] . " - " . $reminder_cc[$i] . "</LI>";
		}

	}

	if ( !empty( $new ) && $new != $old ) {
		update_post_meta( $post_id, 'fg_document_reminder', $new );
	} elseif ( empty($new) && $old ) {
		delete_post_meta( $post_id, 'fg_document_reminder', $old );
	}
}


/*cron start */
add_action('after_switch_theme', 'central_cron_activation');
function central_cron_activation() {
	// other options include 'hourly' and 'twicedaily'
	 wp_schedule_event( time(), 'daily', 'central_daily');
}

// this code deactivates the cron when the theme is deactivated
add_action('switch_theme', 'central_cron_deactivation');
function central_cron_deactivation() {
	wp_clear_scheduled_hook('central_daily');
}

// this links the cron we defined above, 'central_daily', to an actual method, 'central_daily_method'
add_action('central_daily', 'central_daily_method');

function central_daily_method() {
	//use this method with acf
	//echo "<H3>Called in fg_dahsboard_reminders!</H3>";
	global $wpdb;
	$sent_reminder = false;
	$sql = "SELECT post_id FROM " . $wpdb->prefix . "postmeta WHERE meta_key = 'attach_reminders'";
	$cur_reminders = $wpdb->get_results($sql, ARRAY_A);

	$this_count =  count($cur_reminders);
	//echo $wpdb->last_query . ";<BR>Return: " . $cur_reminders[0] . ";<BR>Index: " . $cur_reminders[0]['post_id'];
	foreach ($cur_reminders[0] as $key => $value) {
	 $message .= "<P>The following reminders are currently set:";
	 	//if ( $key == 'post_id' ) {
		if( $these_rems = have_rows( 'attach_reminders', $cur_reminders[0]['post_id'] ) ) {
			//$message .=  '<ul class="slides">';
			$reminder_subject = the_title($cur_reminders[0]['post_id']);
			$doc_title = get_the_title( $cur_reminders[0]['post_id'] );
			$message .=  "<DIV><table id='example' class='display' cellspacing='0' width='100%'>
			<thead>
				<tr>
					<th>Reminder Subject</th>
					<th>Date</th>
					<th>Recipients</th>
					<th>View</th>
					<th>Deactivate</th>

				</tr>
			</thead>";
				while( have_rows('attach_reminders', $cur_reminders[0]['post_id'] ) ): the_row();

					// vars
					$dates = get_sub_field('reminder_dates');
					$rem_notes = get_sub_field('reminder_notes');
					$contacts = get_sub_field('reminder_recipients');

					if ( is_array($contacts) ) { foreach ( $contacts as $contact_key=>$contact_value ) {
						//$message .= "Recip: " . $contact_value->ID . "<BR>";
						$recip_name = get_the_title( $contact_value->ID );
						$recip_email = get_post_meta($contact_value->ID, 'client_email', true);

						$message .= "<tr><td>" . $doc_title . "</td>
						<td>" . $dates . "</td>
						<td>" . $recip_name . "<BR>" . $recip_email . "</td>
						<td><A HREF=>View</A></td>
						<td><A HREF=>Close</A></td>";
						 $message .= " <tfoot>
							<tr>
								<th>Reminder Subject</th>
								<th>Date</th>
								<th>Recipients</th>
								<th>View</th>
								<th>Deactivate</th>

							</tr>
						</tfoot>";


						if ( $sent_reminder == false ) {

							$message = $message . $title . $reminders . $closing;
							add_filter( 'wp_mail_content_type', 'set_html_content_type' );
							$admin_email = get_option( 'admin_email', $default );
							$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
							//wp_mail( $recip_email, 'Recip', $message );

							if ( !wp_mail( 'dg_419@hotmail.com', $doc_title, $message, $headers ) ) {
								//echo "<H1>Not dg_419HOTMAIL</H1>";
							}
							remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
							$sent_reminder = false;
						}


						}



						}



					//$message .= '</li>';

				endwhile;

				//$message .= '</ul>';

			} else {
				$message .= "<H3>Not have rows</H3>";
			}
			$message .=  '</TABLE></DIV>';

	 		$message .= $title . $message;
		}
	//}

	//echo the_sub_field('reminder_notes');
	echo $message;

}







function central_daily_methodWKG() {
	//echo "<H1>Called!!!!</H1>";
	global $wpdb;
	$cur_time = strtotime( date( 'Y-m-d' ) );
	$sent_reminder = false;
	$sql = "SELECT * FROM " . $wpdb->prefix . "postmeta WHERE meta_key = 'fg_document_reminder'";
	$cur_reminders = $wpdb->get_results($sql);

	foreach ($cur_reminders[0] as $key => $value) {

	 $message = "<P>The following reminders are currently set:
	 <UL>";
	 	if ( $key == 'post_id' ) {
	 		$doc_title = get_the_title( $value );
	 		$reminder_sub = $doc_title . " reminder";
	 		$title = "<LI>Document Title: " . $doc_title . "</LI>";
		}
		if ( $key == 'meta_value' ) {
	 		$value = unserialize( $value );
			$reminders = "<UL>";
				foreach ( $value as $cur_reminder ) {
					$remind_time = strtotime( $cur_reminder[fg_document_reminder_date] );
					if ( ($cur_time >= $remind_time) && $cur_reminder[fg_document_reminder_notes] != '' ) {
						$reminders .= "<LI>Reminder Notes: " . $cur_reminder[fg_document_reminder_notes] . "</LI>
						</LI>Reminder Date: " . $cur_reminder[fg_document_reminder_date] . "</LI>";
						$sent_reminder = true;
					}
				$reminders .= "<LI>Reminder Recipients: " . $cur_reminder[fg_document_reminder_cc] . "</LI>";
				if ( is_array($cur_reminder[fg_document_reminder_cc]) ) {
					foreach ($cur_reminder[fg_document_reminder_cc] as $k=>$v) {
						$reminders .= "<LI>More Recipients: " . $v . "</LI>";
						$rem_recip[] = $v;
					}

				}
				}
			$closing = "</UL>";
		}
		if ( $sent_reminder == true ) {
			$message = $message . $title . $reminders . $closing;
			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$admin_email = get_option( 'admin_email', $default );
			foreach( $rem_recip as $recip_k=>$recip_v) {
				//wp_mail( $recip_v, $reminder_sub, $message );
			}
			if ( !wp_mail( 'dg_419@hotmail.com', 'Lease Reminders', $message ) ) {
				//echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			//wp_mail( 'lij350@gmail.com', 'Lease Reminders', $message );

			$cur_doc_file = get_post_meta(get_the_ID(), 'property_doc_file', true);

			if (isset($cur_doc_file) && $cur_doc_file != '') {
				if (is_array($cur_doc_file)) {

					$cur_file = $cur_doc_file[url];

				} else {

					$cur_file = $cur_doc_file;

				}
			}
			$attachments = array( $cur_file );
			$message = "<H3>Cur doc file: " . $cur_file . "</H3>";
			$message .= $cur_local_file;
			//echo "<H1>" . $cur_file . "</H1>";
			wp_mail( 'dg_419@hotmail.com', 'Lease Reminders2', $message );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
   			wp_mail('dg_419@hotmail.com', 'subject', $cur_file, $headers, $attachments );

			//wp_mail( 'technologycity@icloud.com', 'Lease Reminders', $message);
			remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$sent_reminder = false;
		}
	}
}

if($_GET['run_daily_method']=='true') {
	central_daily_method();
}


?>
