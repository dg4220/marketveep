=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: www.2265solutions.com/vendor-management-plugin
Tags: vendor management, business listings
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creates a custom post type and taxonomy to list and sort vendors, affiliates, or other service providers by service provided and company name within the service type.

== Description ==
Front Gate Vendor Management plugin is designed as part of a suite of plugins that can turn your Wordpress installation into a powerful property managemnet tool for HOA or condominimum trust officers and residents, property management companies and their managers, as well as serve lodging and hotel industries.

This plugin uses datatables to allow dynamic sorting of vendors within a category, ajax to open and close category sections, and shortcodes for creating vendor listing tables.

This plugin is compatable with Wordpress Multi to allow a user to manage multiple properties.

The premuim version, due for release Sept. 9, 2013, includes keyword search, geographical search, hours of operation filter and more.

== Installation ==

Upload and activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==



== Screenshots ==

1. The Front Gate Vendor Management edit screen is very similar to the Post or Page edit screen. Use the 'Vendor Service Types' to group vendors by service.

2. Use the [property_vendors] shortcode in either a page or a post to create a listing of current vendors.

3. Vendor front-end display.


