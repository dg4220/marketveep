<?PHP
class dgGoogleConnection {

	/*manages the google api connections and services*/
	
	public function googleConnection()
    {

	 		if ( !include( 'google-api-php-client/examples/templates/base.php' ) ) {
				echo "<h3>Base Fail google-api-php-client/examples/templates/base.php</h3>";
			} 
			if ( !include( 'google-api-php-client/src/Google/Client.php' ) ) {
				echo "<h3>Client Fail</h3>";
			}
			if ( !include ( 'google-api-php-client/src/Google/autoload.php') ) {
				echo "<h3>Autoload Fail</h3>";
			} 
			if ( !include( "google-api-php-client/src/Google/Auth/OAuth2.php" ) ) {
				echo "<h3>0 Fail - google-api-php-client/src/Google/Auth/OAuth2.php</h3>";
				if ( !include( "http://themeshoppe.fgpsn.com/wp-content/themes/fgpsn-mobile-app-themes/google-api-php-client/src/Google/Auth/OAuth2.php")) {
					echo "<h3>0 Fail 2 </h3>";
				}
			} 	       

			session_start();

			$client_id = '823965136704-js5jhmp36ivlrrdampupekv40u98ujgs.apps.googleusercontent.com';
			$client_secret = 'XIXJ7DioJQhR9uPRwJUO3MJW';
			//console.developers.google.com
			$redirect_uri = 'http://themeshoppe.fgpsn.com/wp-admin/options-general.php?page=fgpsn-docman-pro-settings';

						/************************************************
						  Make an API request on behalf of a user. In
						  this case we need to have a valid OAuth 2.0
						  token for the user, so we need to send them
						  through a login flow. To do this we need some
						  information from our API console project.

						************************************************/

			$client = new Google_Client();

			//echo "<H1>CLIENT " . $client . "</H1>";
			/*$client->setClientId($this->options['googleclientid']);
			$client->setClientSecret($this->options['googleclientsecret']);
			$client->setRedirectUri($this->options['googleredirecturi']);*/
			$client->setClientId($client_id);
			$client->setClientSecret($client_secret);
			$client->setRedirectUri($redirect_uri);
			$client->addScope("https://www.googleapis.com/auth/drive");
			
			global $dr_service;
			$dr_service = new Google_Service_Drive($client);
						
						/************************************************
						 Boilerplate auth management - see
						 user-example.php for details.
						************************************************/
						if (isset($_REQUEST['logout'])) {
						  unset($_SESSION['access_token']);
						}
						
						if (isset($_GET['code'])) {
						  $client->authenticate($_GET['code']);
						  $_SESSION['access_token'] = $client->getAccessToken();
						  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
						  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
						}

						if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
						  $client->setAccessToken($_SESSION['access_token']);
						} else {
						  $authUrl = $client->createAuthUrl();
						  //$client->setAccessToken($_SESSION['access_token']);//?
						}

					/************************************************
					  If we're signed in, retrieve channels from YouTube
					  and a list of files from Drive.
					 ************************************************/
					if ($client->getAccessToken()) {
					  $_SESSION['access_token'] = $client->getAccessToken();

					}
						

					/*wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 3', $message, $headers );
					wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments );
					wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 5', $message, $headers, $attachments[0] );*/
					remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
					
					if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
						$client->setAccessToken($_SESSION['access_token']);
					} else {
						$authUrl = $client->createAuthUrl();
						 //$client->setAccessToken($_SESSION['access_token']);//?
					}


					if (isset($authUrl)) {
					  echo "<a class='login' href='" . $authUrl . "'>Connect Me!</a>";
					} else {
					  echo "<h3>Results Of Drive List:</h3>";
					 //floder id for mmc->0
					  //$mmc_folder_id = "0Bz2Av5rKd4lLfmZFcVlVTXVVWXF0dUdUbnU5LUhXdG10ajNIOXdMTlJITE9sY2dGamF0UGM";
					  $folder_id = "0Bz2Av5rKd4lLQk1Ib3NTckE1Ymc";
					  //$folder_id = $this->options['googleflderid'];
					 
					}

					//echo '<h1>Google Connection</h1>';
					//var_dump($dr_service);
					return $dr_service;
					//
    }

    public function googleInsert() {

    	
    }

}

class fgDocumentSettingsPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        /*add_submenu_page( 'edit.php?post_type=property_doc',
					'FGPSN Doc Settings',
					'FGPSN Settings',
					'manage_options',
					'fgpsn-docman-pro-settings',
					'fgpsnDocSettingsForm' );*/

        add_options_page(
            'Settings Admin', 
            'FGPSN Doc Settings', 
            'manage_options', 
            'fgpsn-docman-pro-settings', 
            array( $this, 'fgpsnDocSettingsForm' )
        );

    }

    /**
     * Options page callback
     */
    public function fgpsnDocSettingsForm()
    {
        // Set class property
        $this->options = get_option( 'docman-pro-settings-name' );
        ?>
        <div class="wrap">
            <h1>My Settings</h1>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'docman-pro-settings-group' );
                do_settings_sections( 'fgpsn-docman-pro-settings' );
                $my_google_connections = new dgGoogleConnection();
								$my_google_connections->googleConnection();
                submit_button();
            ?>
           
        
        <?php

        //if the options are all set create the connection
        //start the session, create the token or 'Connect Me!' link and continue


        /*if ( !empty($this->options['googleclientid']) && !empty($this->options['googleredirecturi']) &&  !empty($this->options['googleclientsecret']) && !empty($this->options['googleflderid']) ) {*/

		  // }
echo '</div>';
?>  </form>

<?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'docman-pro-settings-group', // Option group
            'docman-pro-settings-name', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'docman-pro-settings-id', // ID
            'Google Drive Settings', // Title
            array( $this, 'print_section_info' ), // Callback
            'fgpsn-docman-pro-settings' // Page
        );  

        add_settings_field(
            'setdocdisplaypage', // ID
            'Select Documents Page', // Title 
            array( $this, 'setdocdisplaypage_callback' ), // Callback
            'fgpsn-docman-pro-settings', // Page
            'docman-pro-settings-id' // Section           
        );      

        add_settings_field(
            'googleclientid', 
            'Client ID', 
            array( $this, 'googleclientid_callback' ), 
            'fgpsn-docman-pro-settings', 
            'docman-pro-settings-id'
        );

        add_settings_field(
            'googleclientsecret', // ID
            'Client Secret', // Title 
            array( $this, 'googleclientsecret_callback' ), // Callback
            'fgpsn-docman-pro-settings', // Page
            'docman-pro-settings-id' // Section           
        );      

        add_settings_field(
            'googleredirecturi', 
            'Redirect URI', 
            array( $this, 'googleredirecturi_callback' ), 
            'fgpsn-docman-pro-settings', 
            'docman-pro-settings-id'
        );

        add_settings_field(
            'googleflderid', 
            'Folder ID', 
            array( $this, 'googleflderid_callback' ), 
            'fgpsn-docman-pro-settings', 
            'docman-pro-settings-id'
        );      
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['setdocdisplaypage'] ) )
            $new_input['setdocdisplaypage'] = absint( $input['setdocdisplaypage'] );

        if( isset( $input['googleclientid'] ) )
            $new_input['googleclientid'] = sanitize_text_field( $input['googleclientid'] );
        
        if( isset( $input['googleclientsecret'] ) )
            $new_input['googleclientsecret'] = sanitize_text_field( $input['googleclientsecret'] );
        if( isset( $input['googleflderid'] ) )
            $new_input['googleflderid'] = sanitize_text_field( $input['googleflderid'] );
        
        if( isset( $input['googleredirecturi'] ) )
            $new_input['googleredirecturi'] = sanitize_text_field( $input['googleredirecturi'] );

        return $new_input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print 'Enter your Google Drive settings below:';
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function setdocdisplaypage_callback()
    {
       echo 'Select a <em>Documents</em> page if you have no template and are using the shortcode to display the library:<br>
					<Select name="docman-pro-settings-name[setdocdisplaypage]" id="" class="">
						<option value=""> - Select your Documents Page - </option>/n';

						$posts = get_posts( array('post_type' => 'page', 'posts_per_page' => -1) );
						foreach ( $posts as $post ) : setup_postdata( $post ); 
							echo '<option value="' . $post->ID . '" ';
							if ( $this->options['setdocdisplaypage'] == $post->ID ) {echo 'selected';}
							echo '>' . $post->post_title . '</option>';
						endforeach; 
						wp_reset_postdata();

						echo '</select>';

    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function googleclientid_callback()
    {
        printf(
            '<input type="text" id="googleclientid" name="docman-pro-settings-name[googleclientid]" value="' . $this->options['googleclientid'] . '" />',
            isset( $this->options['googleclientid'] ) ? esc_attr( $this->options['googleclientid']) : ''
        );
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function googleclientsecret_callback()
    {
        printf(
            '<input type="text" id="googleclientsecret" name="docman-pro-settings-name[googleclientsecret]" value="%s" />',
            isset( $this->options['googleclientsecret'] ) ? esc_attr( $this->options['googleclientsecret']) : ''
        );
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function googleredirecturi_callback()
    {
        printf(
            '<input type="text" id="googleflderid" name="docman-pro-settings-name[googleredirecturi]" value="%s" />',
            isset( $this->options['googleredirecturi'] ) ? esc_attr( $this->options['googleredirecturi']) : ''
        );
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function googleflderid_callback()
    {
        printf(
            '<input type="text" id="googleflderid" name="docman-pro-settings-name[googleflderid]" value="%s" />',
            isset( $this->options['googleflderid'] ) ? esc_attr( $this->options['googleflderid']) : ''
        );
    }

    public function checkGoogleConnect()
    {
      
    }

    








}

if( is_admin() )
  $my_settings_page = new fgDocumentSettingsPage();
  
?>


