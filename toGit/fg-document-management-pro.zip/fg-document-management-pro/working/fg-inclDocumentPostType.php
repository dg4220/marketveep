<?PHP

/******************************************************
 * DG Creating Documents post type and meta boxes: Document type and the actual file.
*******************************************************/



function custom_post_property_doc() {

		$labels = array(
			'name'               => _x( 'Property Documents', 'post type general name' ),
			'singular_name'      => _x( 'Property Document', 'post type singular name' ),
			'add_new'            => _x( 'Add Document', 'property_doc' ),
			'add_new_item'       => __( 'Add New Document' ),
			'edit_item'          => __( 'Edit Document' ),
			'new_item'           => __( 'New Document' ),
			'all_items'          => __( 'All Documents' ),
			'view_item'          => __( 'View Document' ),
			'search_items'       => __( 'Search Documents' ),
			'not_found'          => __( 'No Documents Found' ),
			'not_found_in_trash' => __( 'No Documents found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Property Documents'
		);

		$args = array(
			'labels'        => $labels,
			'description'   => 'Holds our Property Documents',
			'public'        => true,
			'menu_position' => 6,
			'supports'      => array( 'title', 'editor', 'excerpt', 'author', 'revisions', 'comments', 'page-attributes', 'custom-fields' ),
			'taxonomies'      => array( 'property_document_types'  ),
			'hierarchical' => true,
			'has_archive'   => true
		);

	register_post_type( 'property_doc', $args );
}
add_action( 'init', 'custom_post_property_doc' );

add_action( 'init', 'create_property_document_types' );
function create_property_document_types() {
 $labels = array(
    'name' => _x( 'Document Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Document Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Document Types' ),
    'all_items' => __( 'All Document Types' ),
    'parent_item' => __( 'Parent Document Type' ),
    'parent_item_colon' => __( 'Parent Document Type:' ),
    'edit_item' => __( 'Edit Document Type' ),
    'update_item' => __( 'Update Document Type' ),
    'add_new_item' => __( 'Add New Document Type' ),
    'new_item_name' => __( 'New Document Type Name' ),
  );

  register_taxonomy('property_document_types','property_doc',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}


/*Adding settings page for google drive integration*/
// 
/*function wpdocs_register_fgpsn_settings_pageX() {
   add_submenu_page( 'edit.php?post_type=property_doc',
					'FGPSN Doc Settings',
					'FGPSN Settings',
					'manage_options',
					'fgpsn-docman-pro-settings',
					'fgpsnDocSettingsForm' );
}*/

/*function register_mysettingsX() { // whitelist options
  register_setting( 'docman-pro-settings-group', 'setdocdisplaypage' );
  register_setting( 'docman-pro-settings-group', 'googleclientid' );
  register_setting( 'docman-pro-settings-group', 'googleclientsecret' );
  register_setting( 'docman-pro-settings-group', 'googleflderid' );
  register_setting( 'docman-pro-settings-group', 'googleredirecturi' );
}*/

/*function fgpsnDocSettingsFormX(){

	echo '<div class="wrap">
	<form method="post" action="http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '">';

	settings_fields( 'docman-pro-settings-group' );
	do_settings_sections( 'docman-pro-settings-group' );

	echo '<h2>General Document Settings</h2>
		
		Thumbnail Size (if applicable): <input type="text" name="" value="" id="" class=""><br>
		Select a <em>Documents</em> page if you have no template and are using the shortcode to display the library:<br>
		<Select name="setdocdisplaypage" id="" class="">
			<option value=""> - Select your Documents Page - </option>/n';

			$posts = get_posts( array('post_type' => 'page', 'posts_per_page' => -1) );
			foreach ( $posts as $post ) : setup_postdata( $post ); 
				echo '<option value="' . $post->ID . '">' . $post->post_title . '</option>';
			endforeach; 
			wp_reset_postdata();

			echo '</select>

		<h2>Google Drive Settings</h2>
		
		Client ID: <input type="text" name="googleclientid" value="' . esc_attr( get_option('googleclientid') ) . '" id="" class="" size=72><br>
		Client Secret: <input type="text" name="" value="" id="" class=""><br>
		Folder ID: <input type="text" name="" value="" id="" class=""><br>
		Redirect URI: <input type="text" name="" value="" id="" class=""><br>';
		submit_button();
		echo '</form>';

}*/

//check the google connection
add_action( 'add_meta_boxes', 'google_connection_status' );
function google_connection_status() {
     $screens = array( 'property_doc' );
    foreach ($screens as $screen) {
			add_meta_box(
			'google_connection_status',
			__( 'Attach Document', 'myplugin_textdomain' ),
			'google_connection_status_content',
			$screen,
			'side',
			'high'
		);
	}
}

function google_connection_status_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'google_connection_status_content_nonce' );
	echo '<label for="property_doc_file">Status:</label>';

$my_google_connections = new dgGoogleConnection();
$my_google_connections->googleConnection();
}
























add_filter('add_meta_boxes', 'hide_meta_boxes_property_docs');
function hide_meta_boxes_property_docs() {

	remove_meta_box('postexcerpt', 'property_doc', 'normal');
	remove_meta_box('trackbacksdiv', 'property_doc', 'normal');
	//remove_meta_box('postcustom', 'property_doc', 'normal');
	remove_meta_box('slugdiv', 'property_doc', 'normal');
	//remove_meta_box('postarea', 'property_doc', 'normal');

	//remove_meta_box('commentstatusdiv', 'property_doc', 'normal');
	//remove_meta_box('commentsdiv', 'property_doc', 'normal');
	remove_meta_box('revisionsdiv', 'property_doc', 'normal');

}

//adding metaboxes for files - add document management:

add_action( 'add_meta_boxes', 'property_doc_file' );
function property_doc_file() {
     $screens = array( 'property_doc' );
    foreach ($screens as $screen) {
			add_meta_box(
			'property_doc_file',
			__( 'Attach Document', 'myplugin_textdomain' ),
			'property_doc_file_content',
			$screen,
			'side',
			'high'
		);
	}
}

function property_doc_file_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'property_doc_file_content_nonce' );
	echo '<label for="property_doc_file">Attach File: </label>';
get_post_meta();

	$cur_doc_file = get_post_meta($post->ID, 'property_doc_file', true);


	/* Limit to one doc per post. I'm emulating the document management functions in TLC.

	*/

	if (isset($cur_doc_file) && $cur_doc_file != '') {
		if (is_array($cur_doc_file)) {

			$cur_file = $cur_doc_file[url];

		} else {

			$cur_file = $cur_doc_file;

		}
		echo '<A HREF="' . $cur_file . '" target="_blank">View Document</A>
		<BR>Replace Document: <input id="property_doc_file" name="property_doc_file" value="" type="file">';

	} else {

		echo '<input id="property_doc_file" name="property_doc_file" value="" type="file">';

	}

}


add_action( 'save_post', 'property_doc_file_save' );
function property_doc_file_save( $post_id ) {
	//var_dump($_FILES);
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['property_doc_file_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

/*
	$property_doc_file = $_POST['property_doc_file']['name'];
	update_post_meta( $post_id, 'property_doc_file', $property_doc_file );

*/

	    // Make sure the file array isn't empty
	    if(!empty($_FILES['property_doc_file']['name'])) {
	   //echo '<H1>NOT EMPTY:' . $_FILES['property_doc_file']['name'] . '</H1>';

	        // Setup the array of supported file types. In this case, it's just PDF.
	        $supported_types = array('application/pdf', 'application/vnd.ms-word');

	        // Get the file type of the upload
	        $arr_file_type = wp_check_filetype(basename($_FILES['property_doc_file']['name']));
	        $uploaded_type = $arr_file_type['type'];

	        // Check if the type is supported. If not, throw an error.
	        if(in_array($uploaded_type, $supported_types) || !in_array($uploaded_type, $supported_types)) {

	            // Use the WordPress API to upload the file
	            $upload = wp_upload_bits($_FILES['property_doc_file']['name'], null, file_get_contents($_FILES['property_doc_file']['tmp_name']));

	            if(isset($upload['error']) && $upload['error'] != 0) {
	                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
	            } else {
	                add_post_meta(get_the_ID(), 'property_doc_file', $upload);
	                update_post_meta(get_the_ID(), 'property_doc_file', $upload);

	                
	                $this_google_connections = new dgGoogleConnection();
									$this_google_connections->googleConnection();
									global $dr_service;
									$file = new Google_Service_Drive_DriveFile($_FILES['property_doc_file']['name']);
								  $file->setTitle(get_the_title());
								  //$file->setDescription($description);
								  $file->setMimeType($uploaded_type);
								  try {
	                $data = file_get_contents($_FILES['property_doc_file']['name']);
							    $createdFile = $dr_service->files->insert($file, array(
							      'data' => $data,
							      'mimeType' => $uploaded_type,
							      'uploadType' => 'media',
							    ));
							  } catch (Exception $e) {
    print "An error occurred: " . $e->getMessage();
  }



    // Uncomment the following line to print the File ID
  print 'File ID: %s' % $createdFile->getId();
  $google_link = "https://docs.google.com/uc?id=" . $createdFile->getId() . "&export=download";
  print '<BR>Google Link: ' .  $createdFile->getId();








    
//send to google
//move file to googledrove and delete from gravityforms folder
	

	} 

	} // end if

} // end save_custom_meta_data
}

/*************************************************************
 * Adding file to google drive 
 * this is part called from run_form_process after form submission
 Update to include posting comunications attachemnts from wp admin and gforms
 as well as property documents wp admin and gforms
 to google drive when  
 0Bz2Av5rKd4lLQk1Ib3NTckE1Ymc*/
function insertFile( $dr_service,
					$title,
					$description,
					$parentId,
					$mimeType,
					$filename,
					$entry) {

	/*insertFile( 'Property Document',
					'Posted From FGPSN',
					'0Bz2Av5rKd4lLQk1Ib3NTckE1Ymc',
					'application/pdf',
					'/home/fgpsncom/public_html/wp-content/sites/23/gravity_forms/5-fa5b7f09c7955e20873cdc6c14252cea/2016/03/brochure_map.pdf',//$filename,
					$entry);
				
		return $form;
						*/

		


  $file = new Google_Service_Drive_DriveFile($filename);
  $file->setTitle($title);
  $file->setDescription($description);
  $file->setMimeType($mimeType);

  // Set the parent folder.
  if ($parentId != null) {
    $parent = new Google_Service_Drive_ParentReference();
    $parent->setId($parentId);
    $file->setParents(array($parent));
  }

  try {
    $data = file_get_contents($filename);

    $createdFile = $dr_service->files->insert($file, array(
      'data' => $data,
      'mimeType' => $mimeType,
      'uploadType' => 'media',
    ));

    // Uncomment the following line to print the File ID
     print 'File ID: %s' % $createdFile->getId();
    $google_link = "https://docs.google.com/uc?id=" . $createdFile->getId() . "&export=download";
     print '<BR>Google Link: ' .  $createdFile->getId();
	update_post_meta($entry['post_id'], 'property_doc_file', $google_link);
    return $createdFile;
  } catch (Exception $e) {
    print "An error occurred: " . $e->getMessage();
  }
}

 /* Done Adding file to google drive */
 /*************************************************************/
 //http://themetest.fgpsn.com/add-documents/?code=4%2FQeVYbVJt-ASXb0HeDf4FJnS3amcjF-EZiC7X7fls3so#gf_5
/* Send notifications and post doc to google drive */
add_filter( "gform_after_submission_5", "run_form_process", 10, 4 );
function run_form_process( $entry, $lead, $field, $form ) {
	
	global $wpdb;
	print_r( $entry );
	add_filter( 'wp_mail_content_type', 'set_html_content_type' );
	//$admin_email = get_option( 'admin_email', $default );
	$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";

	//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 570', $message );

	$attachments = array( $entry[12] );
	/*if ( !move_uploaded_file( $entry[12],WP_CONTENT_DIR .'\\uploads\\2016\\03\\'.basename($entry[12] ) ) ) {
		foreach($_FILES as $k=>$v) {
			echo "<H4>578 = FAIL! " . $k . ", " . $v . "</H4>";
			foreach($v as $k1=>$v1) {
			echo "<H4>579 = FAIL! K:" . $k1 . ", V: " . $v1 . "</H4>";
		}
		}
		echo "<H4>580 = FAIL! " . $_FILES . "</H4>";
		echo "<H4>581 = FAIL!</H4>";
	}*/
	$property_access = explode( ',', $entry[38] );
	/*foreach($property_access as $k=>$v ) {
		add_post_meta($entry['post_id'], 'selected_properties', $v);
		echo $wpdb->last_query;
	}*/

	$use_filename = str_replace('http://themetest.fgpsn.com/wp-content/uploads/', '', $entry[12]);

	//$attachments = array(WP_CONTENT_DIR .'\\uploads\\'.$use_filename);

	echo '<BR>Second: ' . WP_CONTENT_DIR . '/' . $use_filename;
	//$attachments = WP_CONTENT_DIR . '/' . $use_filename;
	
	//move file to googledrove and delete from gravityforms folder
	
	if ( !require_once( 'google-api-php-client/examples/templates/base.php' ) ) {
		echo "<h3>Base Fail</h3>";
	} 
	if ( !require_once( 'google-api-php-client/src/Google/Client.php' ) ) {
		echo "<h3>Client Fail</h3>";
	}
	if ( !require_once ( 'google-api-php-client/src/Google/autoload.php') ) {
		echo "<h3>Autoload Fail</h3>";
	} 
	if ( !include( "google-api-php-client/src/Google/Auth/OAuth2.php" ) ) {
		echo "<h3>0 Fail - google-api-php-client/src/Google/Auth/OAuth2.php</h3>";
		if ( !include( "http://themetest.fgpsn.com/wp-content/themes/fgpsn-mobile-app-themes/google-api-php-client/src/Google/Auth/OAuth2.php")) {
			echo "<h3>0 Fail 2 </h3>";
		}
	} 

	//include_once "templates/base.php";
	session_start();
		/************************************************
	  ATTENTION: Fill in these values! Make sure
	  the redirect URI is to this page, e.g:
	  http://localhost:8080/user-example.php
	 ************************************************/


	$client_id = '823965136704-js5jhmp36ivlrrdampupekv40u98ujgs.apps.googleusercontent.com';
	$client_secret = 'XIXJ7DioJQhR9uPRwJUO3MJW';
	//this is for theme test only need new credentials for each install
	//console.developers.google.com
	$redirect_uri = 'http://themetest.fgpsn.com/add-documents/';
	//$redirect_uri = 'http://themetest.fgpsn.com/add-google-docs/';
	//$redirect_uri = 'http://themetest.fgpsn.com/?page_id=4437&preview=true';
				 


	/************************************************
	  Make an API request on behalf of a user. In
	  this case we need to have a valid OAuth 2.0
	  token for the user, so we need to send them
	  through a login flow. To do this we need some
	  information from our API console project.

	UNCOMMENT
	************************************************/

	$client = new Google_Client();
	//echo "<H1>CLIENT " . $client . "</H1>";
	$client->setClientId($client_id);
	$client->setClientSecret($client_secret);
	$client->setRedirectUri($redirect_uri);
	$client->addScope("https://www.googleapis.com/auth/drive");
	
	$dr_service = new Google_Service_Drive($client);
		
	/************************************************
	 Boilerplate auth management - see
	 user-example.php for details.
	************************************************/
	if (isset($_REQUEST['logout'])) {
	  unset($_SESSION['access_token']);
	}
	
	if (isset($_GET['code'])) {
	  $client->authenticate($_GET['code']);
	  $_SESSION['access_token'] = $client->getAccessToken();
	  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
	  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
	}

	if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
	  $client->setAccessToken($_SESSION['access_token']);
	} else {
	  $authUrl = $client->createAuthUrl();
	  //$client->setAccessToken($_SESSION['access_token']);//?
	}

	/************************************************
	  If we're signed in, retrieve channels from YouTube
	  and a list of files from Drive.
	 ************************************************/
	if ($client->getAccessToken()) {
	  $_SESSION['access_token'] = $client->getAccessToken();

	}
		

	/*wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 3', $message, $headers );
	wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments );
	wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 5', $message, $headers, $attachments[0] );*/
	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	
	if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
		$client->setAccessToken($_SESSION['access_token']);
	} else {
		$authUrl = $client->createAuthUrl();
		 //$client->setAccessToken($_SESSION['access_token']);//?
	}


	if (isset($authUrl)) {
	  echo "<a class='login' href='" . $authUrl . "'>Connect Me!</a>";
	} else {
	  echo "<h3>Results Of Drive List:</h3>";
	 //floder id for mmc->0
	  //$mmc_folder_id = "0Bz2Av5rKd4lLfmZFcVlVTXVVWXF0dUdUbnU5LUhXdG10ajNIOXdMTlJITE9sY2dGamF0UGM";
	  $folder_id = "0Bz2Av5rKd4lLQk1Ib3NTckE1Ymc";
	  
	  
	  
	  //$filename = WP_CONTENT_DIR .'\\uploads\\vouchers.pdf';
	  $filename = basename( $entry[12] );
	 /*insertFile($dr_service,
				'/home/fgpsncom/public_html/wp-content/sites/23/gravity_forms/5-fa5b7f09c7955e20873cdc6c14252cea/2016/03/brochure_map.pdf',//$filename
				'Upload Test',
				'0Bz2Av5rKd4lLQk1Ib3NTckE1Ymc',//$folder_id
				'application/pdf',
				$entry[12],
				$entry);*/

	 insertFile( $dr_service,
	 				$entry[49],
					'Posted From FGPSN',
					'0Bz2Av5rKd4lLQk1Ib3NTckE1Ymc',
					'application/pdf',
					$entry[12],
					/*'http://themetest.fgpsn.com/wp-content/uploads/sites/23/gravity_forms/5-fa5b7f09c7955e20873cdc6c14252cea/2016/03/GainEfficiencies.pdf',//$filename,*/
					$entry);
				
		return $form;
	}
				
}


add_filter( 'gform_pre_validation_5', 'populate_html' );
add_filter("gform_pre_submission_filter_5", "populate_html");
add_filter( 'gform_pre_render_5', 'populate_html' );
function populate_html($form)
{
	//echo "<H2>518 - populate Form?? " . var_dump($form) . ", " . $field["id"] . "</H2>";
    //this is a 2-page form with the data from page one being displayed in an html field on page 2
    $current_page = GFFormDisplay::get_current_page($form["id"]);
    $html_content = "The information you have submitted is as follows:<br/><ul>";
    if ($current_page == 2)
    {
        foreach($form["fields"] as &$field)
        {
            //gather form data to save into html field (id 3 on my form), exclude page break
            if ( $field["type"] == "page" && $field["id"] == 38 )
            {//that is, never
                //see if this is a complex field (will have inputs)

                 //get the label and then get the posted data for the field (this works for simple fields only - not the field groups like name and address)
                
                 $items[] = array("value" => 0, "text" => "Selected?");

				
             }
             //echo "<H2>537 - populate Form?? " . $form["form_id"] . ", " . $field["id"] . "</H2>";
             if ( $field["id"] == 50 )
            {
				 foreach( rgpost('input_38') as $k=>$v) {

					 $args = array(
								'blog_id'      => $v
							 );

						$property_contacts = get_users( $args );
						foreach ( $property_contacts as $property_contact ) {
							//echo '<span>' . esc_html( $user->user_email ) . '</span>';
							$blog_details = get_blog_details($v);
							$v = $property_contact->display_name . ',' . $property_contact->roles . ',' . $blog_details->blogname;
							$items[] = array("value" => $property_contact->user_email, "text" => $v);
						}

					 $items[] = array("value" => $k, "text" => $v);

					}
				$field["choices"] = $items;

             }
         }
     }

    $html_content .= "</ul>";
    //loop back through form fields to get html field (id 3 on my form) that we are populating with the data gathered above
   foreach($form["fields"] as &$field)
        {
            //get html field
            if ($field["id"] == 46)
            {
                //set the field content to the html
                //$field["content"] = $html_content;
            }
             //get contacts field
            if ($field["id"] == 50)
            {
                //set the field content to the html
                $field["content"] = $field["choices"];
            }
        }

    //return altered form so changes are displayed
    return $form;

 }
/*********************************
//adding metaboxes to create a mailing list of users:

add_action( 'add_meta_boxes', 'note_recipients' );
function note_recipients() {
    $screens = array( 'property_doc' );
    add_meta_box(
        'note_recipients',
        __( 'Choose Recipients', 'myplugin_textdomain' ),
        'note_recipients_content',
        'property_doc',
        'normal',
        'high'
    );
}


function note_recipients_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'note_recipients_content_nonce' );
	echo '<script>
jQuery(document).ready(function() {

	var url = "/post.php?post='; echo $_GET['post'] . '&action=' . $_GET['action'] . '";
	jQuery("#cat_kid").hide();
	jQuery("#docs").hide();

	jQuery("#cat_dad select").change( function() {


		if( jQuery(this).val() != "0" ) {
			var id = jQuery(this).val();
			alert(id);
			var data = { "Administrator" : id };
			alert(data);
			jQuery.post( url, data, function(response) {
			alert(response);
				if(response=="0") {
					set_docs(id);
					jQuery("#cat_kid").hide();
				} else {
					jQuery("#cat_kid").html(response);
					jQuery("#cat_kid").show();
				}
			}, "html");
		} else {
			jQuery("#cat_kid").hide();
		}
	});

	jQuery("#cat_kid").on( "change", "select", function(e) {
		var val = jQuery(e.target).val();
		if( val != "0" ) {
			set_docs(val);
		} else {
			jQuery("#docs").hide();
		}

	});




});
</script><label for="note_recipients"></label>';

	global $wp_roles;
     $roles = $wp_roles->get_names();







    echo '<p id="cat_dad"><SELECT id="cat_dad" name="cat_dad"><OPTION> SELECT </OPTION>';
	foreach($roles as $role) {
	  echo '<OPTION>' . $role . '</OPTION>';
 }//end foreach
	echo '</SELECT></P><p id="cat_kid"><SELECT  id="cat_kid" name="cat_kid" MULTIPLE=5 id="note_recipients" name="note_recipients[]" placeholder="Notify Users" >
		<OPTION VALUE = 0> -- Select Users -- </OPTION>';

			$args = array(


			 	'orderby'      => 'ID'
				 );
				$blogusers = get_users($args);
				foreach ($blogusers as $user) {
				   echo '<OPTION VALUE = ' . $user->ID . '>' . $user->user_email . '</OPTION>';
    			}


	echo '</SELECT></p><p id="docs"></p>';




}


add_action( 'save_post', 'note_recipients_save' );
function note_recipients_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['note_recipients_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$note_recipients = $_POST['note_recipients'];

	// Update the post into the database
 // wp_update_post( $my_post );


	update_post_meta( $post_id, 'note_recipients', $note_recipients );
}
*********************************/
?>
