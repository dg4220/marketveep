<?PHP

class fgpsn_unit_search extends WP_Widget {

	function fgpsn_unit_search() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-unit-search', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( '<p>Searches for FGPSN units based on location, availability, bedrooms, etc..', 'fgpsn-unit-search' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnunitsearch', __( 'Unit Search', 'fgpsn-unit-search' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );

		/*search form goes here*/
		$fg_vendor_filter .= "<table class='fg-vendor-search'>
			<thead><TH>Select a Unit</th>
			<tr>
			<td align='center' valign='middle'>
			<label class='dropdown'><select name='companies' id='companies' onchange='javascript: location=this.value'>
			<option value='0'> - Select - </option>";


		$all_property_vendor_args = array(
			'post_type'=>'unit_data',
			'numberposts'=>-1,
			'orderby'=>'title',
			'order'=>'ASC',
			'post_status'=>'publish',
				'meta_query' => array(
					array(
						'key'     => 'fgpsn_property_unit_available',
						'value'   => 'on',
						'compare' => '=',
					),
				),
		);

		$bg = get_posts($all_property_vendor_args);

		foreach($bg as $b) {

			$fg_vendor_filter .= "<option value='" . $b->guid . "'>" . $b->post_title . "</option>
			";

		} //endforeach
		wp_reset_postdata();
		$fg_vendor_filter .= "</select></label>
			</td>
			</TR></TABLE>";

		//echo $fg_vendor_filter;
	
		$fg_vendor_filter .= "<p>Or use our search feature below to find the place that's righ for you.<table class='catalog_table' width='100%'>
		<thead><TR>
		<TH><form method='get' action='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "'>
		Search for <input type='text' name='q' value='" . $_GET['q']  . "' />
		Within <label class='dropdown'><SELECT name='zip_radius' >
			<OPTION VALUE=10> 10 Miles</OPTION>
			<OPTION VALUE=20> 20 Miles</OPTION>
			<OPTION VALUE=50> 50 Miles</OPTION>
			<OPTION VALUE=100> 100 Miles</OPTION>
		</SELECT></label>
		 <br>of<br> <input type='text' name='zipcode1'  value='";
		 
		 if (!isset($_GET['zipcode1']) || $_GET['zipcode1'] == '') {
		$fg_vendor_filter .= "Zip Code";
		} else {

		$fg_vendor_filter .= $_GET['zipcode1'];

		} 
		
		$fg_vendor_filter .= "'/>

		<input type='submit' value='Search' />
		</form></TH>
		</TR>
		</thead></table>";
		echo $fg_vendor_filter;
		
		
		$args = array( 'hide_empty' => 0 );

		//set up category alnd meta filters
		$terms = get_terms( 'unit_data_types', $args );
		$terms = get_terms( 'unit_data_types', 'orderby=name&hide_empty=0' );
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			$count = count( $terms );
			$i = 0;
			$term_list = '<h3 class="widget-title">Narrow your search</h3><ul>';

			
			foreach ( $terms as $term ) {
				$i++;
				$term_list .= '<li>
				<input type="checkbox" name="unit_data_types" class="' . $term->slug . '" id="' . get_term_link( $term ) . '">
				<a href="' . get_term_link( $term ) . '" title="' . sprintf( __( 'View all units with %s', 'my_localization_domain' ), $term->name ) . '">' . $term->name . '</a></li>';
				if ( $count != $i ) {
					$term_list .= ' &middot; ';
				}
				else {
					$term_list .= '</ul>';
				}
			}
			echo $term_list;
		}
		
		global $wpdb;
		$values = $wpdb->get_col("SELECT meta_value
									FROM $wpdb->postmeta
									WHERE meta_key = 'fgpsn_property_city'
									GROUP BY meta_value" );
		echo "<form method='post' action='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "'>
		<ul>";
		
		foreach( $values as $k=>$v) {
			echo '<li><input type="checkbox" name="unit_data_cities[' . $v . ']" class="' . $v . '" id="' . $v . '">
			' . $v . ' </li>';
		}
		echo "</ul>";

		?>
		  <label for="amount">Number of bedrooms:</label>
		 <div id="slider-range" class="bedroom_slider"></div>
		<p><input type="text" id="bedrooms" style="border: 0; background-color:#f9f1ed;" /></p>
		</p>

		
			
		
		<?php
		echo "<input type='submit' value='Search' />
		</form>";

		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsn_text_alert_defaults() );

		$title 		= esc_attr($instance['title']);
		$api_key 	= $instance['api_key'];
		$auth_token = $instance['auth_token'];
		$from_number 	= $instance['from_number'];

		?>
		<p>
			Thanks!
		</p>

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_unit_search");') );



?>
