<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @since 3.0.0
 */
get_header(); 
global $wpdb;

?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP

$atts = Array( 'vendor_echo' => 1 );
fg_get_property_vendors( $atts );
echo "</DIV>";


?>

	</div><!-- #primary.c6 -->

<?php get_footer(); ?>
