<?PHP
/******************************************************
 * DG Creating Property Logs post type and meta boxes
*******************************************************/
class FGPSN_Property_Log {

	/**
	 * Hook into the appropriate actions when the class is constructed.
	 */
	public function __construct() {

		if ( !post_type_exists( 'property_log' ) ) {
			add_action( 'init', array($this, 'create_property_log') );
		 	add_action( 'init', array($this, 'create_property_log_types') );
			add_action('add_meta_boxes', array($this, 'cs_add_meta_box'));
			add_action('save_post', array($this, 'unit_list_save'));
			add_action('the_content', array($this, 'custom_message'));
			
			//

		}
		/*add_action( 'wp_ajax_nopriv_updateContacts', 'updateContacts_php' );
		add_action( 'wp_ajax_updateContacts', 'updateContacts_php' );*/
	}

	

	public function create_property_log() {
	$labels = array(
			'name'               => _x( 'Property Logs', 'post type general name' ),
			'singular_name'      => _x( 'Log Entry', 'post type singular name' ),
			'add_new'            => _x( 'Create Log Entry', 'property_log' ),
			'add_new_item'       => __( 'Create New Log Entry' ),
			'edit_item'          => __( 'Review Log Entry' ),
			'new_item'           => __( 'New Log Entry' ),
			'all_items'          => __( 'All Log Entrys' ),
			'view_item'          => __( 'View Log Entry' ),
			'search_items'       => __( 'Search Log Entrys' ),
			'not_found'          => __( 'No Log Entrys Found' ),
			'not_found_in_trash' => __( 'No Log Entrys found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Property Logs'
		);
  $args = array(
      'description'   => 'Messaging and Property Property Logs',
			'public'        => true,
			'menu_position' => 5,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes',/*'custom-fields',*/'thumbnail' ),
			'taxonomies'      => array( 'log_types'  ),
			'hierarchical' => true,
			'has_archive'   => true,
      'labels'  => $labels
    );
    register_post_type( 'property_log', $args );

	}
	

	public function create_property_log_types() {
		$labels = array(
	    'name' => _x( 'Log Entry Types', 'taxonomy general name' ),
	    'singular_name' => _x( 'Log Entry Type', 'taxonomy singular name' ),
	    'search_items' =>  __( 'Search Log Entry Types' ),
	    'all_items' => __( 'All Log Entry Types' ),
	    'parent_item' => __( 'Parent Log Entry Type' ),
	    'parent_item_colon' => __( 'Parent Log Entry Type:' ),
	    'edit_item' => __( 'Edit Log Entry Type' ),
	    'update_item' => __( 'Update Log Entry Type' ),
	    'add_new_item' => __( 'Add New Log Entry Type' ),
	    'new_item_name' => __( 'New Log Entry Type Name' ),
	  );

	  register_taxonomy('log_types','property_log',array(
	    'hierarchical'  => true,
	    'labels'    => $labels,
	    'query_vars'    => true

	  ));
	}

	/**
	 * Adds the meta box container.
	 */
	public function cs_add_meta_box($post_type) {
		$post_types = array('post', 'property_log');

		//limit meta box to certain post types
		if (in_array($post_type, $post_types)) {
			add_meta_box('cs-meta',
			'Select Log Recipients',
			array($this, 'fgpsn_selected_contacts_mb'),
			$post_type,
			'normal',
			'high');
		}
	}

	/**
	 * Render Meta Box content.
	 *
	 * @param WP_Post $post The post object.
	 */

	public function fgpsn_selected_contacts_mb($post) {
	  
	  wp_nonce_field( plugin_basename( __FILE__ ), 'unit_list_content_nonce' );
	  
	  //if edititng and entry, get units who have received the log entry
	  $cur_unit_list = get_post_meta( get_the_ID(), 'fgpsn_log_selected_units', true );
	  $cur_groups_list = get_post_meta( get_the_ID(), 'fgpsn_log_selected_groups', true );
	  $cur_string = get_post_meta( get_the_ID(), 'first_string', true );
	  $test_output = get_post_meta( get_the_ID(), 'test_output', true );

	  foreach($cur_unit_list as $k => $v ) {
	    $unit_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
	    $unit_array[] = $v;
	  }
	  foreach($cur_groups_list as $k => $v ) {
	    $group_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
	    $group_array[] = $k;
	  }

	 echo "<FIELDSET>
	 <input type='hidden' ID='fgpsn_log_id' name='fgpsn_log_id' value='" . get_the_ID() . "'>
	  <DIV class='right_half' STYLE='position: relative; display: inline; float: left; width: 48%;'>
	  Select Properties:";

	/*
	* First check if they have assigned properties
	* 
	*/
	$current_user = wp_get_current_user();
	if( !empty(get_user_meta( $current_user->ID, 'fgpsn_assigned_properties') ) ) {
		$args = array(
	    'posts_per_page'  => -1,
	    'post_type'  => 'properties',
	    'post_status' => 'publish',
	    'include'	=> '1',//get array from user meta
	              
	  );

	}
   
	echo  '<SELECT multiple ID="fgpsn_log_selected_properties"  name="fgpsn_log_selected_properties[]" size=5 >
	          <option value="0"> -- Select Properties -- </option>';
	      
	  $getem = get_posts(array('post_type' => 'properties'));
		foreach ( $getem as $property ) {
			
      setup_postdata($property );
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);
	    
	      if ($address_1) {
        echo '<OPTION value="' . $property->ID . '"';

  			if ( $property->ID == $fgpsn_property_id ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $address_1 . " " . $city . "</A><BR>";
  			}

  			echo '>' .  $address_1  . ' ' . $address_2 . ', ' . $city . ', ' . $property->ID . ', ' . 
  			$fgpsn_property_id . '</OPTION>';
  			
      } else {
        echo '<OPTION value="' . $property->ID . '"';
        echo '>' . $property->ID . ', ' . $property->ID . '</OPTION>';
      }
	         
     }
	  echo  '</SELECT>';
	  wp_reset_postdata();
	  echo  "</DIV>";
	  
	  echo "<DIV class='right_half' STYLE='position: relative; display: inline; float: left; width: 48%;'>
	  Select Units:<br>";

	/*
	* First check if they have assigned properties
	* 
	*/
	$current_user = wp_get_current_user();
	if( !empty(get_user_meta( $current_user->ID, 'fgpsn_assigned_properties') ) ) {
		$args = array(
	    'posts_per_page'  => -1,
	    'post_type'  => 'properties',
	    'post_status' => 'publish',
	    'include'	=> '1',//get array from user meta
	              
	  );

	}
   
	echo  '<SELECT multiple ID="fgpsn_log_selected_contacts" name="fgpsn_log_selected_units[]" size=5 >
	          <option value="0"> -- Selected Units -- </option>';
	      
	  $getem = get_posts(array('post_type' => 'unit_data'));
		foreach ( $getem as $property ) {
			
      setup_postdata($property );
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);
	    
	      if ($property->post_title) {
        echo '<OPTION value="' . $property->ID . '"';

  			if ( in_array($property->ID, $unit_array) ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $property->post_title . "</A><BR>";
  			}

  			echo '>' .  $property->post_title . '</OPTION>';
  			
      } 
	         
    }
	  echo  '</SELECT>';
	  wp_reset_postdata();
	  echo  "</DIV>";
	  echo "<DIV class='right_half' STYLE='display: inline; float: left; width: 30%;'>
	    Select Recipient Groups:";

	  $categories = get_terms( 'contact_data_types', array(
	    'orderby'    => 'count',
	    'hide_empty' => 0
	   ) );

	   if ( !empty( $categories ) && !is_wp_error( $categories ) ){
	     echo  "<ul>";
	     foreach ( $categories as $category ) {
	       echo  "<input type='checkbox' name=fgpsn_comm_recip_group[$category->term_id] id=fgpsn_comm_recip_group[]";
	       if ( in_array($category->term_id, $group_array) ) {
	       echo  " checked";
	     }
	       echo  ">" . $category->name . " - " . $category->term_id . "<BR>";

	     }
	     echo  "</ul>";
	  }
	 	echo  "<H4>Properties: " . $unit_string . "</H4>
	     <H4>Groups: " . $group_string . "</H4>
	     <H4>STRING: " . $cur_string . "</H4>
	     <H4>Output: " . $test_output . "</H4>";

	  echo  "</DIV>
	     </FIELDSET>";
	}

	/**
	 * Save the meta when the post is saved.
	 *
	 * @param int $post_id The ID of the post being saved.
	 */
	function unit_list_save( $post_id ) {

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
		return;

		if ( !wp_verify_nonce( $_POST['unit_list_content_nonce'], plugin_basename( __FILE__ ) ) )
		return;

		if ( 'property_log' == $_POST['post_type'] ) {
			if ( !current_user_can( 'edit_page', $post_id ) )
			return;
		} else {
			if ( !current_user_can( 'edit_post', $post_id ) )
			return;
		}


		update_post_meta( $post_id, 'fgpsn_log_selected_properties', $_POST['fgpsn_log_selected_properties'] );
		update_post_meta( $post_id, 'fgpsn_log_selected_units', $_POST['fgpsn_log_selected_units'] );
		

		if ( ! wp_is_post_revision( $post_id ) ){

			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'unit_list_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'unit_list_save');
		}
	}

/*
* For creating a display area for meta data	
*/
	public function custom_message($content) {
		global $post;
		//retrieve the metadata values if they exist
		$data = get_post_meta($post -> ID, '_cs_custom_message', true);
		if (!empty($data)) {
			$custom_message = "<div style='background-color: #FFEBE8;border-color: #C00;padding: 2px;margin:2px;font-weight:bold;text-align:center'>";
			$custom_message .= $data;
			$custom_message .= "</div>";
			$content = $custom_message . $content;
		}

		return $content;
	}

/*
* Adding methods
*
*/
	public function updateContactsMenu_php() {
		
		global $wpdb;
		$getem = get_posts(
								array('post_type' => 'unit_data',
									/*'include' =>  $_POST['form_data'],*/
									'meta_key'   => 'fgpsn_property_id',
									'meta_query' => array(
											array(
												'key'     => 'fgpsn_property_id',
												'value'   => $_POST['form_data'][0],
												'compare' => 'IN',
											),
										),
									)
							);

		$new_contacts_menu = '';
		foreach ( $getem as $unit ) {
			
      setup_postdata($unit );
      $cur_unit_list = get_post_meta( $_POST['form_data'][1], 'fgpsn_log_selected_units', true );
      foreach($cur_unit_list as $k => $v ) {
		    $unit_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
		    $unit_array[] = $v;
		  }
			/* Use the unit title for now.
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);*/
	    
	    if ($unit->post_title) {
        $new_contacts_menu .= '<OPTION value="' . $unit->ID . '"';

  			if ( in_array($unit->ID, $unit_array) ) {
  				$new_contacts_menu .= " selected";
  				$property_link = "<BR><A HREF=?" . $unit->ID  . ">" . $unit->post_title . "</A><BR>";
  			}

  			$new_contacts_menu .= '>' .  $unit->post_title . '</OPTION>';
  			
      } 
	         
    }
    wp_reset_postdata();
	  echo $new_contacts_menu;
	  die();
	}




}//end class



new FGPSN_Property_Log;
?>
