<?php
/*
* Template Name: Network Workorders
* Description goes with each client theme. Must be configured for each new multi site installation.
* This template looks for property_comm post types in the Property Manager's designated site on the network.
* Any comms with the correct property ID (or blog_id) and contact ID meta values will be imported to the local property * blog.
*/

get_header(); 
?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP
	global $wpdb;
	global $switched;
	
	$properties = wp_get_sites();
for( $i=0; $i< count($properties); $i++ ) {
	switch_to_blog( $properties[$i][blog_id] );
	$blog_details = get_blog_details($properties[$i][blog_id], true);
	//switch_to_blog($v->blog_id); 

	$args = array(
	'offset'           => 0,
	'orderby'          => 'post_title',
	'meta_key'         => '',
	'meta_value'       => '',
	'post_type'        => 'property_comm',
	'post_status'      => 'publish',
	'suppress_filters' => true );

	$communications = get_posts( $args );
	//echo '<H4>' . $communications . ' -- Select Properties -- ' . $wpdb->last_query . '</H4>';
	$property_ct = count( $communications);
	//echo '<OPTION> -- Select Properties -- </OPTION>';
	//$comm_opt = array();
	//$blog_details = get_blog_details($k, true);
	$cur_property = $blog_details->blogname;
		
	echo '<p><TABLE><TR><TH>' . $cur_property . ' contacts</TH></TR>';
	//for each property, set the message and communications as a Metavalue?

	foreach ($communications as $communication) {
		//$comm_email = get_post_meta( $communication->ID, 'client_email', true );
		//$comm_unit = get_post_meta( $communication->ID, 'client_unit', true );
		//$comm_cell = get_post_meta( $communication->ID, 'client_cell', true );
		//$comm_all = get_post_meta( $communication->ID );

		$comm_roles = get_the_terms( $communication->ID, 'contact_data_types' );
		//////find custom taxonomy category name
		echo '<TR><TD><B>Contact:</B> ' . $communication->post_title . '</TD></TR>';
		echo '<TR><TD><B>Date:</B>' . $communication->post_title . '</TD></TR>';
		echo '<TR><TD><B>Date:</B>' . $communication->post_content . '</TD></TR>';
		echo '<TR><TF><BR></TF></TR>';

	}
	echo '</table>';
		//unset($communications);


	echo '</P>';
	
}
		restore_current_blog(); 

	?>
	</div><!-- #primary.c8 -->

<?php get_footer(); ?>
