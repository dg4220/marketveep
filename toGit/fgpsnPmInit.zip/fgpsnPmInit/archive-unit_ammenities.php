<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @since 3.0.0
 */
get_header(); 
global $wpdb;

?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP
		
	$property_data = array();
	$property_data['property_title'] = get_option('property_title');
	$property_data['property_type'] = get_option('property_type');
	$property_data['property_manager'] = get_option('property_manager');
	$property_data['number_of_units'] = get_option('number_of_units');

	$property_data['property_state'] = get_option('property_state');
	$property_data['property_addr1'] = get_option('property_addr1');
	$property_data['property_addr2'] = get_option('property_addr2');
	$property_data['property_city'] = get_option('property_city');


	$disp_data = "<script>

	jQuery(document).ready(function() {
	jQuery( '#fg-vendors-accordion' ).accordion({
	heightStyle: 'content'
	});
	});
	</script>

	/service/xml/
<H3><A HREF='http://razor-cloud.com/xml/rest/product/143?pos=8508a7e6ce43e091&test=true'>Property Data</A></H3>
	<div id='fg-vendors-accordion'>

	<H3><A HREF='http://razor-cloud.com/xml/rest/product/143?pos=8508a7e6ce43e091&test=true'>Property Data</A></H3>
	<DIV ID='property_data_div'>

			<DIV ID='property_field_label'><H4>Property Title:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_title'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>
<H3>Property Specifications</H3>
	<DIV ID='property_data_div'>

			<DIV ID='property_field_label'><H4>Property Title:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_title'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>

<H3>Property Vendors</H3>
	<DIV ID='property_data_div'>";


	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);

	    $terms = get_terms("property_vendor_services", $args);
		$count = count($terms);
		if ( $count > 0 ){

			foreach($terms as $term) {
				$disp_data .= "

			<DIV ID='property_field_label'><H4>" .  $term->name . "</H4> </DIV>";

					$all_vendors_args = array(
								'post_type'=>'property_vendor',
								'numberposts'=>-1,
								'orderby'=>'post_title',
								'order'=>'ASC',
								'taxonomy'=>'property_vendor_services',
								'term'=>$term->name
							);

							$vendors = get_posts($all_vendors_args);

		//$property_ . $term->slug = get_option('property_' . $term->slug);
		$property_cur_option = get_option('property_' . $term->slug);

		foreach($vendors as $vendor) :

				$disp_data .= "

			<DIV ID='property_field_content'><H4>" .  $vendor->post_title . " - " . $term->slug . "</H4></DIV>
			<DIV style='clear: both;'></DIV>";


		 endforeach;

		}
	}




$disp_data .= "

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>
</DIV>	";

	echo $disp_data;
		
	?>

	</div><!-- #primary.c6 -->

<?php get_footer(); ?>
