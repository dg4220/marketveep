<?php

/*
Plugin Name: Set Up A Front Gate Property Network Services Management Site
Plugin URI: http://www.fgpsn.com
Description: Incorporates a wide array of custom post types and related functions that turn a wordparess install into a property management application and client portal
Version: 1
Author: Dennis Gannon
Author URI: http://www.fgpsn.com
*/

/*  Copyright 2016-2017  Dennis Gannon  (email : dgannon@fgpsn.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
//First get all required includes for post types, plugins, etc.

/*set restrict site to non registertered visitors
Do this first to avoid header output errors during redirect
*/

//ini_set('display_errors', '1');
add_action( 'get_header', 'site_access_filter' );
function site_access_filter() {

	$siceaccess = get_post_meta( get_the_id(), 'siceaccess', true);
	if ( get_post_meta(get_the_ID(), 'fgpsn_protected_content', true) == 'true' &&  is_user_logged_in() === false ) {
		wp_redirect( 'http://fgpsn.com/login' ); exit;
		
	} else {

		//include( plugin_dir_path( __FILE__ ) . '/style.css' );
	}

}

add_action( 'post_submitbox_misc_actions', 'my_post_submitbox_protect_content1' );

function my_post_submitbox_protect_content1(){

	echo '<div class="misc-pub-section my-options">
	<input type="checkbox" id="fgpsn_protected_content" name="fgpsn_protected_content" value="true"';

	if ( get_post_meta(get_the_ID(), 'fgpsn_protected_content', true) == 'true' ){ echo ' checked'; }
	echo '>
	<label for="fgpsn_protected_content">FGPSN Content</label>
				
	<label for="fgpsn_protected_content_result">Protected?</label><br />
	<input type="text" size="20" id="fgpsn_protected_content_result" name="fgpsn_protected_content_result" value="' . get_post_meta(get_the_ID(), 'fgpsn_protected_content', true) . '"></div>';
				

}


add_action( 'save_post', 'fgpsn_protect_content_save' );
function fgpsn_protect_content_save($post_id)
		{
			//var_dump($_POST);
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
			return;

			if ( 'page' == $_POST['post_type'] ) {
				if ( !current_user_can( 'edit_page', $post_id ) )
				return;
			} else {
				if ( !current_user_can( 'edit_post', $post_id ) )
				return;
			}
			
			//var_dump($_POST);
			/* check if the custom field is submitted (checkboxes that aren't marked, aren't submitted) */
			if(isset($_POST['fgpsn_protected_content'])){
				/* build the feed here */
				update_post_meta($post_id, 'fgpsn_protected_content', $_POST['fgpsn_protected_content']);
				//add_post_meta($postid, 'fgpsn_update_zillow_feed_result', 1, true );
			}
			else{
				/* not marked? delete the value in the database */
				update_post_meta($post_id, 'fgpsn_protected_content', 'false');
			}
		   // var_dump($_POST);
		
		
		}


function my_plugin_init() {
  load_plugin_textdomain( 'fgpsnPmInit', false, 'my-plugin/languages' );
}
add_action('init', 'my_plugin_init');

//include( plugin_dir_path( __FILE__ ) . '/inclCommunicationsPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclUnitPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclContactPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclEmployeePostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclWOPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclPropertySetup.php' );
include( plugin_dir_path( __FILE__ ) . '/inclPropertyPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclCommunicationsPostType.php' );

//include( plugin_dir_path( __FILE__ ) . '/inclPropertyLogPostType.php' );

include( plugin_dir_path( __FILE__ ) . '/ClassPostTypeProperty.php' );
include( plugin_dir_path( __FILE__ ) . '/ClassPostTypeUnit.php' );
include( plugin_dir_path( __FILE__ ) . '/ClassPostTypeContact.php' );
include( plugin_dir_path( __FILE__ ) . '/ClassPostTypePropertyLog.php' );


include( plugin_dir_path( __FILE__ ) . '/inclTimeSheetPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/contentAndNavTrustee.php' );
include( plugin_dir_path( __FILE__ ) . '/contentAndNavMaintEmp.php' );
include( plugin_dir_path( __FILE__ ) . '/pmDashboardInit.php' );
include( plugin_dir_path( __FILE__ ) . '/sms_widget.php' );
include( plugin_dir_path( __FILE__ ) . '/quick_message_widget.php' );
include( plugin_dir_path( __FILE__ ) . '/time_logger_widget.php' );
include( plugin_dir_path( __FILE__ ) . '/unit_search_widget.php' );
include( plugin_dir_path( __FILE__ ) . '/init-activation-hooks.php' );
require( plugin_dir_path(__FILE__) . "sendgrid-php/vendor/autoload.php" );
//include( plugin_dir_path( __FILE__ ) . '/sendgrid-php/sendgrid-php.php' );
//include( plugin_dir_path( __FILE__ ) . '/function-forms.php' );
//include( plugin_dir_path( __FILE__ ) . '/fgpsnRelatedUnitData_widget.php' );

/*  ajax currently being called from outside the class?*/
function getUpdateContactsMenu_php() {
	$update_menu = New FGPSN_Property_Log;
	$update_menu->updateContactsMenu_php();
}
add_action( 'wp_ajax_nopriv_updateContactsMenu', 'getUpdateContactsMenu_php' );
add_action( 'wp_ajax_updateContactsMenu', 'getUpdateContactsMenu_php' );

add_filter('manage_edit-property_log_columns', 'add_edit_property_log_columns');

function add_edit_property_log_columns($property_log_columns) {
    $new_columns['cb'] = '<input type="checkbox" />';
    $new_columns['title'] = _x('Subject', 'column name');
    $new_columns['author'] = __('From');
    $new_columns['log_types'] = __('Log Entry Type');
    $new_columns['date'] = _x('Date', 'column name');

    return $new_columns;
}


add_action('manage_property_log_posts_custom_column', 'manage_property_log_columns', 10, 2);

function manage_property_log_columns($column_name, $id) {
    global $wpdb;
    switch ($column_name) {
    case 'id':
        echo $id;
            break;

    case 'log_types':
        // Get number of images in gallery
        $terms = wp_get_post_terms( $id, 'log_types' );
        foreach($terms as $term) {
        echo 'Communication Type: ' . $term->name;
        }

        break;
    default:
        break;
    } // end switch
}




if (!is_admin()) {
	wp_register_style( 'fgpsnPmInt-style', '/wp-content/plugins/fgpsnPmInit/style.css' );
	//include( plugin_dir_path( __FILE__ ) . '/style.css' );

function theme_name_scripts() {
	wp_enqueue_style( 'fgpsnPmInt-style', 'style.css' );
	//wp_enqueue_script( 'script-name', get_template_directory_uri() . '/js/example.js', array(), '1.0.0', true );
	


}

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );
}

wp_register_style( 'fgpsnDateTime-style', plugin_dir_url( __FILE__ ) . 'js/datetimepicker-master/jquery.datetimepicker.css' );
wp_register_script('fgpsnDateTimeScripts', plugin_dir_url( __FILE__ ) . 'js/datetimepicker-master/build/jquery.datetimepicker.full.min.js', array('jquery'),null,true );
wp_enqueue_script('fgpsndatatables', plugin_dir_url( __FILE__ ) . 'js/jquery.dataTables.min.js', array(), '1.10.4', true );
  wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );

   	
/*

include( plugins_url( 'inclCommunicationsPostType.php', __FILE__ ) );
include( plugins_url( 'inclUnitPostType.php', __FILE__ ) );
include( plugins_url( 'inclContactPostType.php', __FILE__ ) );
include( plugins_url( 'inclVendorPostType.php', __FILE__ ) );
include( plugins_url( 'inclWOPostType.php', __FILE__ ) );
*/

/* Edit backend admin for managing a property only - this is all the back end they need for PM */
 $blog_id = get_current_blog_id();

//get datatables library
 //&&  $blog_id > 500
 if ( $blog_id == 10 || $blog_id == 5 && $blog_id > 500 ) {
	function remove_pm_menu() {
		//remove_menu_page('edit.php?post_type=acf');
		remove_menu_page( 'options-general.php' );
		//remove_menu_page( 'plugins.php' );
	}
	add_action( 'admin_menu', 'remove_pm_menu', 999);
	wp_register_style( 'fgpm_dashboard_css',  get_stylesheet_directory() . 'fgpm_dashboard_css.css');


	function edit_man_admin_menus() {
			global $menu;
			global $submenu;

//echo '<pre>'.print_r($GLOBALS['menu'], true).'</pre>';
echo '<pre>'.print_r($GLOBALS['submenu'], true).'</pre>';
			add_menu_page('Property Data', 'Property Data', 'publish_pages', 'options-general.php?page=property-data-settings', '', '', 1);
			add_menu_page('Service Requests', 'Service Requests', 'publish_pages', 'edit.php?post_type=ai1ec_event', '', '', 4);
			//remove_menu_page('edit.php');
			add_menu_page('Communications', 'Client Communications', 'publish_pages', 'edit.php?post_type=property_comm', '', '', 5);

			//remove_menu_page('index.php');
			//remove_menu_page('options-general.php');

			//remove_menu_page('upload.php');
			//remove_menu_page('edit-comments.php');
			//remove_menu_page('tools.php');
			//remove_menu_page('edit-tags.php?taxonomy=category&post_type=page');

			//remove_menu_page('admin.php', '?page=s2');
			if ( !remove_submenu_page('edit.php?post_type=acf') ) {

			//echo "<H1>How How How?</H1>";
			}

			//remove_menu_page('admin.php', '?page=acf-export');
			remove_menu_page('admin.php', '?page=acf-addons');
			if ( !remove_menu_page('edit.php?post_type=acf') ) {

			//echo "<H1>How2 How2 How2?</H1>";
			} else {
			//echo "<H1>yeah2?</H1>";
			}
			if ( !remove_submenu_page('edit.php?post_type=acf', 'acf-export') ) {

			//echo "<H1>How3</H1>";
			}
			if ( !remove_menu_page('theme_my_login') ) {

			//echo "<H1>How4</H1>";
			} else {
			//echo "<H1>yeah4?</H1>";
			}
			if ( !remove_submenu_page('theme_my_login', 'theme_my_login_email') ) {

			//echo "<H1>How5</H1>";
			}
			if ( !remove_submenu_page('theme_my_login', 'theme_my_login_redirection') ) {

			//echo "<H1>How6</H1>";
			}

			if ( !remove_submenu_page('theme_my_login', 'theme_my_login_user_links') ) {

			//echo "<H1>How7</H1>";
			}

			if ( !remove_submenu_page('theme_my_login', 'theme_my_login_themed_profiles') ) {

			//echo "<H1>How8</H1>";
			}

			/*remove_menu_page('edit.php?post_type=page');
			remove_menu_page('admin.php?page=wpi_main');
			remove_menu_page('themes.php');
			remove_menu_page('plugins.php');
			remove_menu_page('users.php');
			remove_menu_page('admin.php?page=gf_edit_forms');
			remove_menu_page('dmin.php?page=cwp_poll');
			remove_menu_page('edit.php?post_type=acf');
			remove_menu_page('admin.php?page=wpseo_dashboard');
			remove_menu_page('admin.php?page=appointments');
			* */


			//add_menu_page('edit.php?post_type=property_doc');


			//remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=category' );
			//remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=post_tag' );
			//remove_submenu_page( 'admin.php', 'admin.php?page=wpseo_dashboard' );
			//remove_submenu_page( 'admin.php', 'admin.php?page=appointments' );
			//remove_submenu_page( 'admin.php', 'admin.php?page=wpi_main' );
			//remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=property_document_types' );

			$menu[5][0] = 'Property Log'; // Change Posts to Communications
			//$submenu['edit.php?post_type=property_comm'][5][0] = 'All Communications';

			//$menu[6][0] = 'Service Requests'; // Change Posts to Communications
			$submenu['edit.php?post_type=ai1ec_event'][4][0] = 'All Requests';
			$submenu['edit.php?post_type=ai1ec_event'][4][1] = 'New Request';




    function custom_menu_order($menu_ord) {
        if (!$menu_ord) return true;

        return array(

            'options-general.php?page=property-data-settings',
            'edit.php', // Posts
            'edit.php?post_type=ai1ec_event',//maint reqs
            'edit.php?post_type=property_doc', // Links


            'separator2', // Second separator
            'edit.php?post_type=unit_data', // Links
            'edit.php?post_type=contact_data', // Links
            'edit.php?post_type=property_vendor', // Links
            'separator-last', // Last separator
        );

    }
    //add_filter('custom_menu_order', 'custom_menu_order'); // Activate custom_menu_order
    //add_filter('menu_order', 'custom_menu_order');
		}
	
//add_action( 'admin_menu', 'edit_man_admin_menus' );
function edit_admin_menus() {
    global $menu;
    global $submenu;
    //echo '<pre>'.print_r($GLOBALS['submenu'], true).'</pre>';
     
    $menu[5][0] = 'Property Log'; // Change Posts to Recipes
    $submenu['edit.php'][5][0] = 'All Log Entries'; // Change Posts to Recipes
}
add_action( 'admin_menu', 'edit_admin_menus' );


/* create custom property management roles */
function fg_custom_pm_roles () {

	remove_role('property_manager');
	$property_manager_role = add_role(
		'property_manager',
		__( 'Property Manager' ),
		array(
			'read'         => true,  // true allows this capability
			'read_property_comm'   => true,
			'edit_posts'   => true,
			'edit_ai1ec_events'   => true,
			'publish_posts'   => true,
			'publish_pages'   => true,
			'manage_options'   => true,
			'manage_categories'   => true,
			'delete_posts' => false, // Use false to explicitly deny
			/*manager needs a network 'dashboard' that tabs through management functions for all sites.
			For Example post to multiple properies and groups */
		)
	);

	if ( null !== $property_manager_role ) {
		echo 'Yay! PM role created!';
	}

	$property_trustee_role = add_role(
		'property_trustee',
		__( 'Property Trustee' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => true,
			'edit_ai1ec_events'   => true,
			'publish_posts'   => true,
			'publish_pages'   => false,
			'manage_options'   => false,
			'manage_categories'   => true,
			'delete_posts' => false, // Use false to explicitly deny
			/*manager needs a network 'dashboard' that tabs through management functions for all sites.
			For Example post to multiple properies and groups */
		)
	);

	if ( null !== $property_trustee_role ) {
		echo 'Yay! Property Trustee role created!';
	}


	$desk_staff_role = add_role(
		'desk_staff',
		__( 'Desk Staff' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => false,
			'delete_posts' => false, // Use false to explicitly deny
		)
	);

	if ( null !== $desk_staff_role ) {
		echo 'Yay! Desk Staff role created!';
	}


	$maint_staff_role = add_role(
		'maint_staff',
		__( 'Maintenance Staff' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => false,
			'delete_posts' => false, // Use false to explicitly deny
		)
	);

	if ( null !== $maint_staff_role ) {
		echo 'Yay! Maintenance Staff role created!';
	}

	$property_vendor_role = add_role(
		'property_vendor',
		__( 'Property Vendor' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => true,
			'edit_ai1ec_events'   => true,
			'publish_posts'   => true,
			'publish_pages'   => false,
			'manage_options'   => false,
			'manage_categories'   => true,
			'delete_posts' => false, // Use false to explicitly deny
			/*manager needs a network 'dashboard' that tabs through management functions for all sites.
			For Example post to multiple properies and groups */
		)
	);
	
	$editor=get_role('editor');
	//$maint_manager_role=add_role('maint_manager_role','Maintenance Staff',$author->capabilities);
	$maint_manager_role=add_role('maint_manager_role','Maintenance Manager',$editor->capabilities);
	$tenant_role=add_role('tenant_role','Tenant',$editor->capabilities);


}//end func
add_action( 'init', 'fg_custom_pm_roles' );
}




//allow file upload for property documents
function update_edit_this_form() {
	echo ' enctype="multipart/form-data"';
}
add_action('post_edit_form_tag', 'update_edit_this_form');



//add shrotcode for creating a Property Data Page
/*
 * deprecated - creating temple page for the post types
 *
 *
 *
 * and adding the pages to the menu manually using tempAddPage()
 * */
function get_property_data( $atts ){
	
	global $wpbd;
	global $disp_data;
	$disp_data = "";
	//$disp_data = "<H1>ATTS: " . $atts . ", " . $atts[0] . "</H1>";
	
	//return $disp_data;
	//restore_current_blog();
	/* not any more 
	if ( isset( $_GET['property_id'] ) ) {
		switch_to_blog( $_GET['property_id'] );
	}
	*/
	$property_data = array();
	
	$property_data['property_title'] = get_option('blogname');
	$property_data['property_type'] = get_option('property_type');
	$property_data['property_manager'] = get_option('property_manager');//user id
	//contacts all need to be added to pmsuite in order to keep contact post IDs in sync with user ids
	//eg. Cathie is a contact for Hill but not pm suite - how can we find her from her user ID?
	$property_data['number_of_units'] = get_option('number_of_units');

	$property_data['property_state'] = get_option('property_state');
	$property_data['property_addr1'] = get_option('property_addr1');
	$property_data['property_addr2'] = get_option('property_addr2');
	$property_data['property_city'] = get_option('property_city');
	$property_data['property_zip'] = get_option('property_zip');
	
	//check if this is the sidebar widget display
	if ( $atts[0] == 'unit-info' ) {
		//$disp_data .= "<H1>ATTS: " . $atts . ", " . $atts[0] . "</H1>";

		$disp_data .= "<section class='widget'><H3 class='widget-title'>Property Data</H3>
			
			<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Property Title:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_title'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Property Title:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_manager'] . "</SPAN>
		</DIV>
			<H3 class='widget-title'>Property Vendors</H3>
			<DIV ID='property_data_widget_div'>
			Property Title
			Manager:
			Staff:
			Access
			Additional Notes</DIV>
			
			<H3 class='widget-title'>Property Specs</H3>
			<DIV ID='property_data_widget_div'>
			Property Title
			Manager:
			Staff:
			Access
			Additional Notes</DIV>
			</section>";
		
		return $disp_data;
	restore_current_blog();
	} else {
		//$disp_data .= "<H3>ATTS: " . $atts . ", " . $atts[0] . "</H3>";
		$disp_data .= "<section class='widget'>
		<DIV ID='property_data_widget_div'>
		<H3 class='widget-title'>Property Data</H3>
			
			Property Title: " . get_the_title( get_post_meta($atts, 'fgpsn_property_id', true) ) . "<BR>
			Manager: " . $property_data['property_manager'] . "
			Staff:
			Access
			Additional Notes</DIV>
			
			<DIV ID='property_data_widget_div'>
			<H3 class='widget-title'>Property Vendors</H3>
			
			Property Title
			Manager:
			Staff:
			Access
			Additional Notes</DIV>
			
			<DIV ID='property_data_widget_div'>
			<H3 class='widget-title'>Property Specs</H3>
			
			Property Title:
			Manager:
			Staff:
			Access
			Additional Notes</DIV>
			</section>";
			return $disp_data;
	restore_current_blog();
	}
	

	$disp_data .= "<div id='fg-vendors-accordion'>

	<H3>Property Data</H3>
	<DIV ID='property_data_div'>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Property Title:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_title'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Property Title:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_manager'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Property Title:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_type'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Number of Units:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['number_of_units'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Address line 1:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_addr1'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Address line 2:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_addr2'] . "</SPAN>
		</DIV>
			
		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>City:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_city'] . "</SPAN>
		</DIV>

		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>State:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_state'] . "</SPAN>
		</DIV>
		
		<DIV class='property_data_item'>
			<SPAN class='property_data_label'>Zipcode:</SPAN>
			<SPAN class='property_data_value'>" . $property_data['property_zip'] . "</SPAN>
		</DIV>			
			
	</DIV>
	
<H3>Property Specifications</H3>
	
	<DIV ID='property_data_div'>
	</DIV>

<H3>Property Vendors</H3>
	<DIV ID='property_data_div'>";


	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);

	    $terms = get_terms("property_vendor_services", $args);
		$count = count($terms);
		if ( $count > 0 ){

			foreach($terms as $term) {
				$disp_data .= "<DIV class='property_data_item'>
			<SPAN class='property_data_label'>" .  $term->name . ":</SPAN>
			<SPAN class='property_data_value'>";

					$all_vendors_args = array(
								'post_type'=>'property_vendor',
								'numberposts'=>-1,
								'orderby'=>'post_title',
								'order'=>'ASC',
								'taxonomy'=>'property_vendor_services',
								'nopaging' => true,
								'term'=>$term->name
							);

							$vendors = get_posts($all_vendors_args);

		//$property_ . $term->slug = get_option('property_' . $term->slug);
		$property_cur_option = get_option('property_' . $term->slug);

		foreach($vendors as $vendor) :

				$disp_data .= $vendor->post_title . " - " . $term->slug . "";


		 endforeach;
$disp_data .= "</span></DIV>";
		}
		
	}
	$disp_data .= "</DIV>";

	$disp_data .= "<H3>Property Location</H3>
		<DIV ID='property_data_div'>
				<iframe width='384' height='315' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=" . $property_data['property_addr1'] . ",+" . $property_data['property_city'] . ",+" . $property_data['property_state'] . "&amp;output=embed'></iframe>
				
				<br /><small><a href='https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=" . $property_data['property_addr1'] . ",+" . $property_data['property_city'] . ",+" . $property_data['property_state'] . "&amp;t=m&amp;z=14&amp;iwloc=A' style='color:#0000FF;text-align:left'>View Larger Map</a></small>
		</DIV>
		</DIV>";




	//echo $disp_data;
	return $disp_data;
	restore_current_blog();
}
add_shortcode( 'property_data', 'get_property_data' );


//add shrotcode for creating a Property Data Page
/*
 * deprecated - creating temple page for the post types
 *
 *
 *
 * and adding the pages to the menu manually using tempAddPage()
 * */
function edit_property_data( $atts ){
	global $wpbd;
	global $disp_data;
	/*
	 extract( shortcode_atts( array(
		'unit_data' => 0
	), $atts ) );
	*/
	switch_to_blog(5);
	$property_data = array();
	$property_data['property_title'] = get_option('property_title');
	$property_data['property_type'] = get_option('property_type');
	$property_data['property_manager'] = get_option('property_manager');
	$property_data['number_of_units'] = get_option('number_of_units');

	$property_data['property_state'] = get_option('property_state');
	$property_data['property_addr1'] = get_option('property_addr1');
	$property_data['property_addr2'] = get_option('property_addr2');
	$property_data['property_city'] = get_option('property_city');


	$disp_data = "<FORM><DIV ID='property_data_div'>

			<DIV ID='property_field_label'><H4>Property Title:</H4> </DIV>
			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_title'] . "'></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='management_form_fieldset'>
				<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

				<DIV ID='property_field_content'>
				<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_manager'] . "'></DIV>
				<DIV style='clear: both;'></DIV>
			</DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_type'] . "'></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['number_of_units'] . "'></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_addr1'] . "'></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_addr2'] . "'></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_city'] . "'></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'>
			<INPUT TYPE='text' NAME='' VALUE ='" . $property_data['property_state'] . "'></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>
<H3>Property Specifications</H3>
	<DIV ID='property_data_div'>

			<DIV ID='property_field_label'><H4>Property Title:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_title'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>

<H3>Property Vendors</H3>
	<DIV ID='property_data_div'>";


	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);

	    $terms = get_terms("property_vendor_services", $args);
		$count = count($terms);
		if ( $count > 0 ){

			foreach($terms as $term) {
				$disp_data .= "

			<DIV ID='property_field_label'><H4>" .  $term->name . "</H4> </DIV>";

					$all_vendors_args = array(
								'post_type'=>'property_vendor',
								'numberposts'=>-1,
								'orderby'=>'post_title',
								'order'=>'ASC',
								'taxonomy'=>'property_vendor_services',
								'nopaging' => true,
								'term'=>$term->name
							);

							$vendors = get_posts($all_vendors_args);

		//$property_ . $term->slug = get_option('property_' . $term->slug);
		$property_cur_option = get_option('property_' . $term->slug);

		foreach($vendors as $vendor) :

				$disp_data .= "

			<DIV ID='property_field_content'><H4>" .  $vendor->post_title . " - " . $term->slug . "</H4></DIV>
			<DIV style='clear: both;'></DIV>";


		 endforeach;

		}
	}




$disp_data .= "<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>";

$disp_data .= "<TABLE class='fg-vendor-meta'>
			<TR><TH COLSPAN=3>Location and Hours</TH></TR>

			<TR>

				<TD colspan=3>
				<iframe width='384' height='315' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=" . $property_data['property_addr1'] . ",+" . $property_data['property_city'] . ",+" . $property_data['property_state'] . "&amp;output=embed'></iframe>
				
				<br /><small><a href='https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=" . $property_data['property_addr1'] . ",+" . $property_data['property_city'] . ",+" . $property_data['property_state'] . "&amp;t=m&amp;z=14&amp;iwloc=A' style='color:#0000FF;text-align:left'>View Larger Map</a></small>
				</TD>
				</TR>
			</TABLE>
			
			
</DIV>
<DIV style='clear: both;'></DIV>";
	//echo $disp_data;
	restore_current_blog();
	return $disp_data;
}
add_shortcode( 'property_data_edit', 'edit_property_data' );


function get_property_contacts( $atts ){
	global $current_user;

	$cur_property =  get_bloginfo();
	$current_user = wp_get_current_user();
	$user_roles = get_userdata( $current_user-ID );
	$cur_role = $user_roles->roles;
	$contact_types = get_terms('contact_data_types');

	$directory_display = "";

		foreach ( $contact_types as $contact_type ) {

			$contact_list = "";
			$args = array(
				'tax_query' => array(
					array(
						"taxonomy" => "contact_data_types",
						"field" => "id",
						"terms" => $contact_type->term_id
					)
				),
				'posts_per_page'  => -1,
				'numberposts'     => -1,
				'post_type'       => 'contact_data',
				'post_status'     => 'publish',
				'nopaging' => true,
				'suppress_filters' => true );
			$posts = get_posts($args);
			$directory_display .= "<DIV><H3>" . $contact_type->name . "s</H3>
			<TABLE ID='property_data_div'>
				<thead><TR><TH>Name</TH><TH>Unit</TH><TH>Phone</TH><TH>Email:</TH></THEAD>
				<TBODY>";

			if(is_array($posts)) :  foreach($posts as $post) :

				$contact_first_name = get_post_meta($post->ID, 'contact_first_name', true);
				$contact_last_name = get_post_meta($post->ID, 'contact_last_name', true);
				$emp_phone = get_post_meta($post->ID, 'emp_phone', true);
				$emp_email = get_post_meta($post->ID, 'emp_email', true);

				$client_phone = get_post_meta($post->ID, 'client_phone', true);
				$client_email = get_post_meta($post->ID, 'client_email', true);
				$client_unit = get_post_meta($post->ID, 'contact_unit_number', true);


				$directory_display .= "<TR><TD><a href='" . site_url() . "/add-contacts/?gform_post_id=" . $post->ID . "'>" . $contact_first_name . " " . $contact_last_name . "</A></TD>
				<TD>" . $client_unit . "</TD>
				<TD>" . $client_phone . "</TD>
				<TD><a href='" . site_url() . "/addedit-communications/?select_recipients=" . $post->ID . "'>" . $client_email . "</A></TD>
				</TR>";

			endforeach; endif;

			$directory_display .= "</TBODY></Table>";

     	}

	return $directory_display;
}
add_shortcode( 'property_contacts', 'get_property_contacts' );

/*shortcode for communications*/

function get_property_comms( $atts ){
	global $current_user;

	$cur_property =  get_bloginfo();
	$current_user = wp_get_current_user();
	$user_roles = get_userdata( $current_user-ID );
	$cur_role = $user_roles->roles;
	$contact_types = get_terms('contact_data_types');

	$directory_display = "";

		foreach ( $contact_types as $contact_type ) {

			$contact_list = "";
			$args = array(
				'tax_query' => array(
					array(
						"taxonomy" => "contact_data_types",
						"field" => "id",
						"terms" => $contact_type->term_id
					)
				),
				'posts_per_page'  => -1,
				'numberposts'     => -1,
				'post_type'       => 'contact_data',
				'post_status'     => 'publish',
				'nopaging' => true,
				'suppress_filters' => true );
			$posts = get_posts($args);
			$directory_display .= "<DIV><H3>" . $contact_type->name . "s</H3>
			<TABLE ID='property_data_div'>
				<thead><TR><TH>Name</TH><TH>Unit</TH><TH>Phone</TH><TH>Email:</TH></THEAD>
				<TBODY>";

			if(is_array($posts)) :  foreach($posts as $post) :

				$contact_first_name = get_post_meta($post->ID, 'contact_first_name', true);
				$contact_last_name = get_post_meta($post->ID, 'contact_last_name', true);
				$emp_phone = get_post_meta($post->ID, 'emp_phone', true);
				$emp_email = get_post_meta($post->ID, 'emp_email', true);

				$client_phone = get_post_meta($post->ID, 'client_phone', true);
				$client_email = get_post_meta($post->ID, 'client_email', true);
				$client_unit = get_post_meta($post->ID, 'contact_unit_number', true);


				$directory_display .= "<TR><TD><a href='" . site_url() . "/add-contacts/?gform_post_id=" . $post->ID . "'>" . $contact_first_name . " " . $contact_last_name . "</A></TD>
				<TD>" . $client_unit . "</TD>
				<TD>" . $client_phone . "</TD>
				<TD><a href='?select_recipients=" . $post->ID . "'>" . $client_email . "</A></TD>
				</TR>";

			endforeach; endif;

			$directory_display .= "</TBODY></Table>";

     	}

	return $directory_display;
}
add_shortcode( 'property_communications', 'get_property_comms' );

/**/

function get_unit_data( $atts ){
	global $wpdb;
	global $cur_unit_info;
	//global $disp_unit_data;
	//first check if its a single. If so skip displaying list
	if ( isset( $_GET['fg_unit_id'] ) || isset( $_GET['unit_number'] ) ) {

		$unit_id = $_GET['fg_unit_id'];
		if ( $unit_id != 0 || $unit_id != '') {

			$args=array(
			  'post_id' => $unit_id,
			  'post_type' => 'unit_data',
			  'post_status' => 'publish',
			'nopaging' => true,
			  'showposts' => 1
				);

			$my_posts = get_posts($args);
			//echo $wpdb->last_query;
			if( $my_posts ) {
				$unit_id = $my_posts[0]->ID;
				echo "<H3>" . $my_posts[0]->post_title . ", " . $my_posts->post_title . "</H3>";
			}

		}
		fg_single_unit( $unit_id );
		return $unit_data;;
	}
	if ( $atts[0] == 'unit-info' ) {
		
		$access_notes = get_post_meta($atts[1], 'fgpsn_property_unit_access_notes', true);
		
		//$table_prefix = "wp_" . $_GET['property_id'] . "_";
		//$table_prefix = "wp_2_";
		global $table_prefix;
		global $cur_unit_info;
		$get_comms = "SELECT " . $table_prefix . "postmeta.meta_key,
							" . $table_prefix . "postmeta.meta_value,
							" . $table_prefix . "postmeta.post_id
							FROM " . $table_prefix . "postmeta
							WHERE " . $table_prefix . "postmeta.post_id IN
							(SELECT ID FROM " . $table_prefix . "posts
								WHERE post_type = 'unit_data'
								AND post_status = 'publish')
								AND " . $table_prefix . "postmeta.post_id = " . $_GET['post_id'] . 
								" AND " . $table_prefix . "postmeta.meta_key
									IN ('unit_rent_amt',
										'unit_sqft',
										'unit_sqft_cst',
										'unit_rent_amt_year',
										'unit_rent_effective_date',
										'unit_option_start',
										'unit_option_end',
										'unit_option_notification',
										'unit_cpi_date',
										'unit_cpi_amt',
										'unit_owner_id')";

						$get_comms1 = "SELECT " . $table_prefix . "postmeta.meta_key,
								" . $table_prefix . "postmeta.meta_value,
								" . $table_prefix . "postmeta.post_id
								FROM " . $table_prefix . "postmeta
								WHERE " . $table_prefix . "postmeta.post_id IN
								(SELECT ID FROM " . $table_prefix . "posts
									WHERE post_type = 'unit_data'
									AND post_status = 'publish')
									AND " . $table_prefix . "postmeta.post_id = " . $_GET['post_id'];

						$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);
						//echo "<H4>Array NOT! " . $wpdb->last_query . "</H4>";
						if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
							 
							foreach ($cur_comms as $k=>$v) {
								foreach ($v as $k1=>$v1) {
									
									if ($k1 == 'unit_owner_id') {
										$unit_owner_id = $v1;
									}
									$cur_unit_info .= "<DIV><label>" . $k1 . "</label>" . $v1 . "</DIV>";
								}
							}	
						}
					if ( $cur_unit_info == '' ) {
						$cur_unit_info .= "<p>There are no recent communications for this Unit.</p>";
						$cur_unit_info .= "<p>There are no recent W.O. requests for this Unit.</p>";
						$cur_unit_info .= "<p>There are no documents attached this Unit.</p>";
					}
					$cur_unit_info = "<section id='unit-details' class='widget'>
					<H3 class='widget-title'>Additional Unit Details</H3>
					<DIV style='color: blue;'>*Access Notes:<BR>"
			. $access_notes . "</DIV>"
								. $cur_unit_info . 
								"</section>";
					return $cur_unit_info;
		
	}

	/* setup attribute distinguish property vs. service vendor using parent categories */

	extract( shortcode_atts( array(
		'unit_data' => 0
	), $atts ) );

	$unit_args = array(
	'posts_per_page'   => 10,
	'offset'           => 0,
	'category'         => '',
	'orderby'          => 'post_date',
	'order'            => 'DESC',
	'include'          => '',
	'exclude'          => '',
	'meta_key'         => '',
	'meta_value'       => '',
	'post_type'        => 'unit_data',
	'post_mime_type'   => '',
	'post_parent'      => '',
	'post_status'      => 'publish',
	'nopaging' => true,
	'suppress_filters' => true );
$myposts = get_posts( $unit_args );

//$value = get_metadata_by_mid( 'user', 1161 );
$unit_data = "";
$printthis = "<TABLE><TR><TH>" . $value . " - Unit</TH><TH>Owner</TH><TH>Occupants</TH><TH>% Ownership</TH></TR>";
foreach ( $myposts as $post ) : setup_postdata( $post );

	$permalink = get_permalink( $post->ID );
	$unit_owner = get_post_meta( $post->ID, 'unit_owner_id', true);
	$unit_owner1 = get_user_by('id', $unit_owner);
	//$printthis .= "<H3>3 unit_owner1: " . $unit_owner1->user_email . "</H3>";
	//echo "<H3>1 unit_owner: " . $unit_owner . "</H3>";
	$unit_owner = get_post( $unit_owner );
	//$printthis .= "<H3>2 unit_owner: " . $unit_owner->post_title . "</H3>";

	$unit_owner->user_email;


	$printthis .= "<TR>
					<TH><a href='?fg_unit_id=" . $post->ID . "'>" . $post->post_title . "</A></TH>
					<TH><a href='" . site_url() . "/add-contacts/?gform_post_id=" . $unit_owner->ID . "'>" . $unit_owner->post_title . "</A></TH>
					<TH>" . $unit_occupant->post_title . "</TH>
					<TH>% Ownership</TH></TR>";


endforeach;
echo $printthis . "</TABLE>";
wp_reset_postdata();


	return $unit_data;
}
add_shortcode( 'unit_data', 'get_unit_data' );


//add_filter( 'cpt_default_content', 'my_editor_content', 10, 2 );

function my_editor_content( $content, $post ) {

    switch( $post->post_type ) {
        case 'unit_data':
            $content = '<P>The Unit Data page can be used to display any of the data from the Units edit screen in the admin area. This page, like anyother, can be made in whole or in part private so that only the resident, owner, or other permitted user can view it.</P>';
        break;

    }

    return $content;
}
//add_filter( 'default_content', 'cpt_default_content' );
//end menu set up


/* document post type functionality is now in the plugin
most-recent-documents-mod */
//include("inclDocumentPostType.php");

/* property post type functionality is now in the Settings page
under Property Setup */

/* add communication emails to post publish */
add_action( 'add_meta_boxes', 'fg_email_posts' );
//add_action( 'save_post', 'fg_email_posts_save' );

function fg_email_posts() {

	add_meta_box(
		'fg_email_posts',
		__( 'Contact List', 'myplugin_textdomain' ),
		'fg_email_posts_content',
		'post',
		'normal',
		'high'
	);

}

function fg_email_posts_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'fg_email_posts_content_nonce' );
	echo '<FIELDSET>';

		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'occupant'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_occupant_id">Property Occupants: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_occupant_id" name="unit_occupant_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;


		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'owner'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_owner_id">Property Owners: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_owner_id" name="unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;


		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'trustee'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_owner_id">Property Trustees: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_owner_id" name="unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;



		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'employee'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_owner_id">Property Staff: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_owner_id" name="unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;


          echo '</FIELDSET>';



}

//force post type to use my template


//add_filter( 'template_include', 'contacts_page_template', 999 );

function contacts_page_template( $template ) {

	if ( is_post_type_archive()  ) {
		echo "<H1>IN! is archive</H1>";
		$new_template = plugins_url( 'archive-property_vendor.php', __FILE__ );
		load_template( $new_template );
		echo "<H1>Template is! " . $new_template . " is archive</H1>";
		if ( '' != $new_template ) {
			//return $new_template ;
		}
	} else {
		echo "<H1>What gives? " . $post->ID . "</H1>";

	}

	//return $template;
}

/*
$plugginFile = __FILE__;
$themeDir = get_theme_root() . '/' . get_current_theme();
$customThemeFile = 'myTheme.php';

register_activation_hook($plugginFile, 'myActivation');
register_deactivation_hook($plugginFile, 'myDeactivation');

if ( !function_exists('myActivation') )
{
    function myActivation()
    {
        global $themeDir;
        global $customThemeFile;
        $themeDir = get_template_directory();
        $pluginDir = plugin_dir_path( __FILE__ );
       echo $themeDir . '/archive-property_vendor.php<BR>' ;
       echo $pluginDir . 'archive-property_vendor.php';
        copy( $pluginDir . 'archive-property_vendor.php', $themeDir . '/archive-property_vendor.php' ) or die('cant open file');

copy( $pluginDir . 'archive-maintenance_requests.php', $themeDir . '/archive-maintenance_requests.php' ) or die('cant open file');
copy( $pluginDir . 'archive-property_comm.php', $themeDir . '/archive-property_comm.php' ) or die('cant open file');
copy( $pluginDir . 'archive-property_doc.php', $themeDir . '/archive-property_doc.php' ) or die('cant open file');
copy( $pluginDir . 'archive-contact_data.php', $themeDir . '/archive-contact_data.php' ) or die('cant open file');

    }
}
*/



add_filter("gform_predefined_choices", "add_predefined_choice");
function add_predefined_choice($choices){

	global $wpdb;
	global $current_user;
	get_currentuserinfo();

	$args = array(
				'network_id' => $wpdb->siteid,
				'public'     => null,
				'archived'   => null,
				'mature'     => null,
				'spam'       => null,
				'deleted'    => null,
				'limit'      => 100,
				'offset'     => 0,
				);
				
	$property_ids = wp_get_sites( $args );
	$property_ct = count( $property_ids);
	
   $choices["Contacts"] = array();
   $choices["Network Contacts"] = array();
   //$choices["Network Properties"] = array();
   $choices["User Groups"] = array();
   $choices["Document Types"] = array();
   $choices["Units"] = array();
   $choices["Vendors"] = array();
   $choices["Vendor Services"] = array();
   $choices["Service Type"] = array();
   $choices["Vendor Contacts"] = array();
   $choices["Assigned Properties"] = array();
   $choices["Roles"] = array();//the formal user role rather than contact type above
   //use for site access permissions - use groups for content access
   $choices["List Units"] = array();




	$taxonomy     = 'events_categories';
	$orderby      = 'name'; 
	$show_count   = 0;      // 1 for yes, 0 for no
	$pad_counts   = 0;      // 1 for yes, 0 for no
	$hierarchical = 1;      // 1 for yes, 0 for no
	$title        = '';


	$args = array(
	  'taxonomy'     => 'events_categories',
	  'type'      => 'ai1ec_event',
		'show_counts'	=> 0,
	  'hierarchical' => 1,
	  
	  'hide_empty'   => 0
	);
	
	$these_cats = get_categories( $args ); 
	
	foreach($these_cats as $this_cat) {
		$choices["Service Type"][] = $this_cat->cat_name . '|' . $this_cat->category_nicename;	
	}
	/***************************************************/

	global $wpdb;
	global $current_user;
	
	get_currentuserinfo();

		$args = array(
					'network_id' => $wpdb->siteid,
					'public'     => null,
					'archived'   => null,
					'mature'     => null,
					'spam'       => null,
					'deleted'    => null,
					'limit'      => 100,
					'offset'     => 0,
					);
							
		$property_ids = wp_get_sites( $args );
		$property_ct = count( $property_ids);
			
		foreach ($property_ids as $k=>$v) {
			foreach ($v as $k1=>$v1) {
				//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
//echo '<LI>Array1: ' . $blog_details->blog_id . ' => ' . $blog_details->blogname . '</LI>';
					$choices["Assigned Properties"][] = $blog_details->blogname . '|' . $blog_details->blog_id;
				}
			}
		}
			
/*************************************************************/
	$blogusers = get_users( array( 'fields' => array( 'display_name', 'role', 'ID' ) ) );
     //Array of stdClass objects.
     foreach ( $blogusers as $user ) {
     	//echo '<span>' . esc_html( $user->display_name ) . '</span>';
     	if ( $user->role == 'property_vendor' || $user->role != 'property_vendor' ) {
			$choices["Vendor Contacts"][] = $user->display_name . ' | ' . $user->ID . '-' . $user->role;
		}
   	}
/*******************************************************************/
   $contacts = get_posts( array( 'post_type' => 'contact_data', 'post_status' => 'publish',
							'nopaging' => true ) );
   // Array of stdClass objects.
   foreach ( $contacts as $contact ) {
      	$choices["Contacts"][] = $contact->post_title . ' | ' . $contact->ID;
   }


/********************************************************************/
/*see MMC version for list of network blogs/sites/properties*/
			$args = array(
			'post_type' => 'properties',
			'post_status' => 'publish'	
		
		);

		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :
         while ($my_query->have_posts()) : $my_query->the_post();

              $address_1 = get_post_meta(get_the_ID(), 'address_1', true);
              $address_2 = get_post_meta(get_the_ID(), 'address_2', true);
              $city = get_post_meta(get_the_ID(), 'city', true);

              $choices["Network Properties"][] = $address_1 . ', ' . $city . ' | ' . get_the_ID();

          endwhile;
		endif;
		$args = array( 'post_type' => 'contact_data', 'post_status'=> 'publish',
							'nopaging' => true );

		$myposts = get_posts( $args );
		//echo "<H4>SQL?: " . $wpdb->last_query . "</H4>";
		foreach ( $myposts as $post ) : setup_postdata( $post );

			$contact_user_id = get_post_meta($post->ID, 'unit_owner_id', true);
			$choices["Network Contacts"][] = $post->post_title . ' | ' . $post->ID;
				
		endforeach; 
		wp_reset_postdata();

	
	restore_current_blog();
/*******************************************************************/
   // Array of stdClass objects.

	
	$taxonomy = 'contact_data_types';
	$term_args=array(
	  'hide_empty' => false,
	  'orderby' => 'name',
	  'order' => 'ASC'
	);
	$user_tax = get_terms($taxonomy,$term_args);
	foreach ( $user_tax as $user ) {

     	$choices["User Groups"][] = $user->name . ' | ' . $user->term_id;
   	}
/*********************************************************************/
	$taxonomy = 'property_document_types';
	$term_args=array(
	  'hide_empty' => false,
	  'orderby' => 'name',
	  'order' => 'ASC'
	);
	$user_tax = get_terms($taxonomy,$term_args);
	foreach ( $user_tax as $user ) {

     	$choices["Document Types"] [] = $user->name . ' | ' . $user->term_id;
   	}
/*************************************************************************/
	$post_args=array(
	  'post_type' => 'unit_data',
	  'post_status' => 'publish',
		'nopaging' => true,
	  'order' => 'ASC'
	);
	$unit_posts = get_posts($post_args);
	foreach ( $unit_posts as $post ) {
	$title = $post->post_title;
	$this_id = $post->ID;

		$choices["Units"][] = $title . ' | ' . $this_id;
		//$choices["Units"][] = $wpdb->last_query;
	}
/**************************************************************************/
	$vendors = get_posts( array( 'post_type' => 'property_vendor', 'post_status' => 'publish',
							'nopaging' => true ) );
		// Array of stdClass objects.
		foreach ( $vendors as $vendor ) {
			$choices["Vendors"][] = $vendor->post_title . ' | ' . $vendor->ID;
   		}
/*****************************************************************************/
	$taxonomy = 'property_vendor_services';
	$term_args=array(
	  'hide_empty' => false,
	  'orderby' => 'name',
	  'order' => 'ASC'
	);
	$vendor_tax = get_terms($taxonomy,$term_args);
	foreach ( $vendor_tax as $service ) {

     	$choices["Vendor Services"] [] = $service->name . ' | ' . $service->term_id;
   	}

/*******************************************************************************/
	//get roles
	global $wp_roles;

	if ( ! isset( $wp_roles ) ) {
		$wp_roles = new WP_Roles();
		$roles = $wp_roles->get_names();
	}
		foreach ($wp_roles as $role_name => $role_value) {
		//$choices["Roles"] [] = $role_name . ' | ' . $role_value;
			if ($role_name == 'roles') {
				foreach( $role_value as $k=>$v ) {
					//$choices["Roles"] [] = $v . ' | ' . $k;
					//if ( $v == 'role_names' ) {
						foreach( $v as $k1=>$v1 ) {
							if ( $k1 == 'name' ) {
								$choices["Roles"][] =  $v1 . ' | ' . $k;
							}
						}
						
					//}
				}

			}
	  	}

/*****************************************************************/
//display units list
	$units = get_posts( array( 'post_type' => 'unit_data', 'post_status' => 'publish',
							'nopaging' => true ) );
		// Array of stdClass objects.
		foreach ( $units as $unit ) {
			$choices["List Units"][] = $unit->post_title . ' | ' . $unit->ID;
   		}
  
  
   return $choices;
}

//additional gform processing

//add_filter( "gform_after_submission", "run_form_processes", 10, 4 );

function run_form_processes( $entry, $lead, $field, $form ){
	global $user;
	global $wpdb;
		
	
	
 	/*************************************************/
 	//if document post notification is set
    if( $entry['form_id'] == 112 ) {//changed from form 2 contact form for testing
		$message = print_r($entry, true);
		$message .= "<P>Additional Emails:<BR>";
		$new_vendor_service = $entry[46];

		if ( !empty( $entry[46] ) ) {
			if ( wp_insert_term(
			  		$entry[46], // the term
					'property_vendor_services', // the taxonomy
					 array(
						'description'=> '',
						'parent'=> 42
					 )

					)
				)

			{
				$message .= "<H1>GOOD</H1>";
				add_predefined_choice($choices);//reset gforms menu options
			} else {
				$message .= "<H1>NOT GOOD</H1>";
			}

  		//mail('dg_419@hotmail.com', 'Getting the Gravity Form 2', $message);
 		}


 	//add contact as a user if not already present
	global $wp_roles;

	$all_roles = $wp_roles->roles;
	$user_id = username_exists( $entry[2] );
	if ( email_exists($entry[6]) == false ) {

         $message = "<P>Add user and contact data:<BR>";
         $message .= print_r($entry, true);

         $post = array(
		 	        'post_status'  => 'publish' ,
		 	        'post_title'  => $entry[1] . ' ' . $entry[4],
		 	        'post_type'  => 'contact_data' ,
		 	    );

		 	    // insert the post
	    $post_id = wp_insert_post( $post );




		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		//$user_id = wp_create_user( $entry[1], $random_password, $entry[5] );


		$userdata = array(
		    'user_login'  =>  $entry[1],
		    'user_email'    =>  $entry[5],
		    'user_pass'   =>  $random_password,
		    'role' => 'property_trustee'
		);
		$user_id = wp_insert_user( $userdata );

		//$updatethis = update_user_meta( $user_id, 'role', 'property_trustee' );



		if ( $updatethis === false ) {
		$message .= "<H4>Bad Role: " . $updatethis . ", " . $user_id . "</H4>";
		} else {
		$message .= "<H4>GOOD Role: " . $updatethis . ", " . $user_id . "</H4>";
		}


		//get_editable_roles();
		$message .= "<H4>Roles: " . $all_roles . "</H4>";
		foreach($all_roles as $role => $name) {
		$message .= "<H5>Role Key: " . $role . "; Role Value: " . $name[0] . "</H4>";
		foreach($name as $k => $v) {
				$message .= "<UL><H5>Role Key: " . $k . "; Role Value: " . $v . "</H4></UL>";
				if ($v == 'Trustee') {
				//$updatethis = update_user_meta( $user_id, 'role', $v );

				}
		}
		}

		//set user role based on contact type - entry[9]
		//if entry[9] == 3 user role is 'trustee' for example
		switch( $entry[9] ) {
			case 4:
				//update_user_meta( $user_id, 'role', 'fg_prop_occupant' );
				break;

			case 3:
				//update_user_meta( $user_id, 'role', 'fg_prop_owner' );
				break;


			case 2:
				//update_user_meta( $user_id, 'role', 'fg_prop_trustee' );
				break;



		}

		update_user_meta( $user_id, 'contact_data_id', $post_id );
		update_user_meta( $user_id, 'contact_first_name', $entry[1] );
		update_user_meta( $user_id, 'contact_last_name', $entry[4] );
		update_user_meta( $user_id, 'client_phone', $entry[2] );
		update_user_meta( $user_id, 'client_email', $entry[5] );
		update_user_meta( $user_id, 'client_cell', $entry[3] );
		/*
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );
		*/

		}



 	}


 	/*************************************************/
 	//if document post notification is set
     if( $entry['form_id'] == 3 ) {
         $message = print_r($entry, true);
         $message .= "<P>Additional Emails:<BR>";

         //group recipients
         $recip_group_ids = explode( ",", $entry[4] );
         //use group ids to get individual ids and merge arrays below
         for($i=0; $i < count($recip_group_ids); $i++) {
				$message .= "<H2>Group Ids Look: " . $recip_group_ids[$i] . "</H2>";
				$args = array(
				'post_type' => 'contact_data',
				'tax_query' => array(
					array(
					'taxonomy' => 'contact_data_types',
					'field' => 'term_id',
					'value' => $recip_group_ids[$i]
					 )
				  )
				);
				$query = new WP_Query( $args );

				if ( $query->have_posts() ) {
					$message .= "<ul>";
					while ( $query->have_posts() ) {
						$query->the_post();
						$message .= "<li>Title" . the_title() . "</li>";
					}
					$message .= "</ul>";
				} else {
					$message .= "<H3>" . $wpdb->last_query . "</H3>";
				}
				/* Restore original Post Data */
				wp_reset_postdata();
		}


         $recip_contact_ids = explode( ",", $entry[5] );
         $type_test = gettype($entry[4]);
         $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
         ";
         $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
         ";
         add_filter( 'wp_mail_content_type', 'set_html_content_type' );
         for($i=0; $i < count($recip_contact_ids); $i++) {
         $message .= "<P>K: " . $i . ", V: " . $recip_contact_ids[$i];
         	//$recip_email = get_userdata($recip_contact_ids[$i]);
         	$recip_email = get_user_by('id', $recip_contact_ids[$i]);
         	$recip_subject = $entry[1];
         	$recip_message = $entry[2];
         	$recip_message = wordwrap($recip_message, 70);

 			
 			$admin_email = get_option( 'admin_email', $default );
 			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
 			//wp_mail( $recip_email, 'Recip', $message );


			if ( isset( $entry[6.1] ) && $entry[6.1] != '' ) {
				//if ( !wp_mail( $recip_email->user_email, $recip_subject, //$recip_message, $headers ) ) {
					$message .= '<H1>Not dg_419HOTMAIL</H1>';
				//}
 			} else {

 			$recip_subject .= 'NO NOTICE' . $recip_subject;
 			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
								$message .= '<H1>Later dg_419HOTMAIL</H1>';
				}
				*/
 			}

 			
         	$message .= '<P>Email to: ' . $recip_email->user_email;

         	foreach($v  as $k1=>$v1) {
         	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
         	}
         }
		remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
 		$message = wordwrap($message, 70);
 		 // Send
  		//mail('dg_419@hotmail.com', 'Getting the Gravity Form 3', $message);
 	}


    //if client communications form
    //also add as 
    if( $entry['form_id'] == 6 || $entry['form_id'] == 16 ) {
		
		//$recip_array empty($recip_array);
		unset($recip_array);
		add_filter( 'wp_mail_content_type', 'set_html_content_type' );
		$admin_email = get_option( 'admin_email', $default );
		$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
						
        $message = print_r($entry, true);
        $message .= "<H2>Entry</H2><UL>";
        $attachments = array( $entry[12] );
				 move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
				 $use_filename = str_replace('/wp-content/uploads/', '', $entry[12]);
				 
				 
				$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
		foreach ($entry as $k=>$v) {
			if ( !is_array($v) ) {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
			} else {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
				$message .= "<H3>Nested</H3><UL>";
				foreach ( $v as $k1=>$v1 ) {
					$message .= "<li>Level 2: " . $k1 . ", " . $v1 . "</li>";
				}
				$message .= "</ul>";
			}


			if ( $k == 38 && !isset( $recip_array ) )
            {
				$recip_array = array();
				$message .= "<P>Property Emails:<BR>";
				$selected_properties = explode(',', $v);
				 foreach( $selected_properties as $k=>$v) {
					 
					 $message .= "<U><h3>Emails Array:" . $k . ", " . $v . "<h3></U>";
					  $args = array(
								'blog_id'      => $v
							 );
						$property_contacts = get_users( $args );
						
		
		$message .= '<LI><H4>' . $v . '</H4></LI>';

		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 1', $message, $headers, $attachments[0] );
		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 2', $message, $headers, $attachments );
		//wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
		foreach ( $property_contacts as $property_contact ) {
			if( esc_html( $property_contact->user_email ) != '' ) {
				$recip_array[] = esc_html( $property_contact->user_email );
				$message .= '<h4>' . esc_html( $property_contact->user_email ) . '</h4>';
			}
			
		}	
					//wp_mail( $property_contact->user_email, 'Recip 2', $message );
					//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 0', $recip_message, $headers, $attachments );
								
		
							/*
							$blog_details = get_blog_details($v);
							$v = $property_contact->display_name . ',' . $property_contact->roles . ',' . $blog_details->blogname;
							$items[] = array("value" => $property_contact->user_email, "text" => $v);
							*/
								 
							 
					 //$items[] = array("value" => $k, "text" => $v);
					 
					}
				//$field["choices"] = $items;
				
             }
		
		
			if ( $k == 45 ) { 
				
				if (is_array($v) ) {
					$selected_contacts = explode(',', $v);
					$message .= "<P>Field 45 Array:" . $v . "<BR>";
					foreach ( $selected_contacts as $k1=>$v1 ) {	
						$message .= '<h4>CONTACTS!: ' . $k1 . ' - ' . $v1 . '</h4>';
					}
				} else {
					$message .= '<h4>CONTACTS STRING!: ' . $v . '</h4>';
				}
			}
        
        
		}
        
        

        //$recip_ids = explode( ",", $entry[45] );
        
        //$recip_emails = explode( ",", $entry[45] );
        $recip_emails = explode( ",", $recip_array );
        //$type_test = gettype($entry[45]);
        $message .= "<P>Emails Array:" . $recip_emails . ", ?<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
         //for($i=0; $i < count($recip_emails); $i++) {
         $recip_array = array_unique($recip_array);
        
		for($i=0; $i < count($recip_array); $i++) {
			$message .= "<P>K: " . $i . ", V: " . $recip_array[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	//$recip_id = get_user_by('id', $recip_ids[$i]);
        	//$recip_email = get_post_meta( $recip_ids[$i], 'client_email', true );
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			
        	$message .= '<P>Email to: ' . $recip_array[$i];
        	//wp_mail( $recip_email, $recip_subject, $recip_message, $headers, $attachments );
        	$recip_subject .= 'Emails loop: ';
        	wp_mail( 'dg_419@hotmail.com', 'Emails loop: ' . $i . ' - ' . $recip_array[$i], $message, $headers, $attachments );
        	//wp_mail( 'dg_419@hotmail.com', 'Emails loop 2: ', $message, $headers, $attachments );

        	foreach($v  as $k1=>$v1) {
        	//$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        	
        	
        }

		$message = wordwrap($message, 70);
		 // Send
		$attachments = array( $entry[12] );
		 move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
		 $use_filename = str_replace('/wp-content/uploads/', '', $entry[12]);
		 
		 
		 
		$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
		$message .= '<P><H1>Recip Array! ' . $recip_array . 'First! ' . $recip_array[0] . '</H1>' . $attachments[0];
		// wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 3', $message, $headers, $attachments[0] );
		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments );

		//wp_mail( 'dg_419@hotmail.com', $recip_subject, $recip_message, $headers, $attachments );
		//wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
 		
 		remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	}


 	/*************************************************/
 	//add contacts and users magazine basic
     if( $entry['form_id'] == 9 ) {

		global $wp_roles;
		$all_roles = $wp_roles->roles;
		$user_id = username_exists( $entry[1] );
		if ( email_exists($entry[5]) == false ) {

			 $message = "<P>Add user and contact data:<BR>";
			 $message .= print_r($entry, true);

			 $post = array(
		 	        'post_status'  => 'publish' ,
		 	        'post_title'  => $entry[1] . ' ' . $entry[4],
		 	        'post_type'  => 'contact_data' ,
		 	    );

		 	    // insert the post
				$post_id = wp_insert_post( $post );
				$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
			//$user_id = wp_create_user( $entry[1], $random_password, $entry[5] );


			$userdata = array(
				'user_login'  =>  $entry[1],
				'user_email'    =>  $entry[5],
				'user_pass'   =>  $random_password,
				'role' => 'property_trustee'
			);
			$user_id = wp_insert_user( $userdata );

			//$updatethis = update_user_meta( $user_id, 'role', 'property_trustee' );



			if ( $updatethis === false ) {
			$message .= "<H4>Bad Role: " . $updatethis . ", " . $user_id . "</H4>";
			} else {
			$message .= "<H4>GOOD Role: " . $updatethis . ", " . $user_id . "</H4>";
			}


			//get_editable_roles();
			$message .= "<H4>Roles: " . $all_roles . "</H4>";
			foreach($all_roles as $role => $name) {
			$message .= "<H5>Role Key: " . $role . "; Role Value: " . $name[0] . "</H4>";
			foreach($name as $k => $v) {
				$message .= "<UL><H5>Role Key: " . $k . "; Role Value: " . $v . "</H4></UL>";
				if ($v == 'Trustee') {
				//$updatethis = update_user_meta( $user_id, 'role', $v );

				}
		}
		}

		//set user role based on contact type - entry[9]
		//if entry[9] == 3 user role is 'trustee' for example
		switch( $entry[9] ) {
			case 4:
				//update_user_meta( $user_id, 'role', 'fg_prop_occupant' );
				break;

			case 3:
				//update_user_meta( $user_id, 'role', 'fg_prop_owner' );
				break;


			case 2:
				//update_user_meta( $user_id, 'role', 'fg_prop_trustee' );
				break;



		}

		update_user_meta( $user_id, 'contact_data_id', $post_id );
		update_user_meta( $user_id, 'contact_first_name', $entry[1] );
		update_user_meta( $user_id, 'contact_last_name', $entry[4] );
		update_user_meta( $user_id, 'client_phone', $entry[2] );
		update_user_meta( $user_id, 'client_email', $entry[5] );
		update_user_meta( $user_id, 'client_cell', $entry[3] );
		/*
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );
		*/

			} else {
			$really = email_exists($entry[5]);
			$message .= "<H4>No Roles: " . $entry[5] . ", Really: " . $really . "</H4>";
			$return_email_fail;
			return false;
			}
         //update_post_meta($post_id, 'contact_first_name', $entry[1]);
         //update_post_meta($post_id, 'contact_first_name', $entry[4]);

	//set contact type
	wp_set_post_terms( $post_id, $entry[9], 'contact_data_types', $append );
	update_post_meta( $post_id, 'contact_first_name', $entry[1] );
	update_post_meta( $post_id, 'contact_last_name', $entry[4] );
	update_post_meta( $post_id, 'client_phone', $entry[2] );
	update_post_meta( $post_id, 'client_email', $entry[5] );
	update_post_meta( $post_id, 'client_cell', $entry[3] );
	/*
	update_post_meta( $client_addr1, 'client_addr1', $client_addr1 );
	update_post_meta( $client_addr2, 'client_addr2', $client_addr2 );
	update_post_meta( $client_city, 'client_city', $client_city );
	update_post_meta( $client_zip, 'client_zip', $client_zip );
	*/
	// Send
  		//mail('dg_419@hotmail.com', 'Getting the Gravity Form 9', $message);
 	}
	/***************************************************************/

 	//Enter work order and send notifications
     if( $entry['form_id'] == 22 ) {
		
       $message = print_r($entry, true);
       foreach($entry as $k=>$v) {
		   $message .= "<P>Form Data:<UL>";
		   $message .= "<li>Key: " . $k . "; Value: " . $v . "<li>";
	   }
        $message .= "</UL><P>Additional Emails:<BR>";
        if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
        if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

        $recip_ids = explode( ",", $entry[14] );
        $type_test = gettype($entry[14]);
        $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
        for($i=0; $i < count($recip_ids); $i++) {
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	$recip_email = get_user_by('id', $recip_ids[$i]);
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$admin_email = get_option( 'admin_email', $default );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			//wp_mail( $recip_email, 'Recip', $message );

			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
				echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			*/
			
        	$message .= '<P>Email to: ' . $recip_email->user_email;

        	foreach($v  as $k1=>$v1) {
        	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        }

		$message = wordwrap($message, 70);
		 // Send
 		//mail('dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message);
 		remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
 	}
 	
 	/***************************************************************/

 	//Testing Event plugin as WO request
 	//don't forget add as maintenance_requests
     if( $entry['form_id'] == 23 ) {
	
		//send emails as neccessary       
       $message = '';
       //$message .= print_r($entry, true);
       $message .= "<P>Form Data:<UL>";
       foreach($entry as $k=>$v) {
		   $message .= "<li>Key: " . $k . "; Value: " . $v . "<li>";
	   }
        $message .= "</UL><P>Additional Emails:<BR>";
        if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
        if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

        $recip_ids = explode( ",", $entry[14] );
        $type_test = gettype($entry[14]);
        $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
        for($i=0; $i < count($recip_ids); $i++) {
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	$recip_email = get_user_by('id', $recip_ids[$i]);
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$admin_email = get_option( 'admin_email', $default );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			//wp_mail( $recip_email, 'Recip', $message );

			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
				echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			*/
			
        	$message .= '<P>Email to: ' . $recip_email->user_email;

        	foreach($v  as $k1=>$v1) {
        	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        }

		$message = wordwrap($message, 70);
		 // Send
 		//mail('dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message, $headers);
 		remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
 		
 		//add as maintenance_requests paot type
		$post = array(
		 	        'post_status'  => 'publish' ,
		 	        'post_title'  => $entry[1] . ' ' . $entry[4],
		 	        'post_content'  => $message,
		 	        'post_type'  => 'maintenance_requests',
		 	    );
		
		//wp_insert_post( $post );
 	}
	
	/***************************************************************/
 	//add contacts and users from pm suite
     if( $entry['form_id'] == 26 ) {

		global $wp_roles;
		$all_roles = $wp_roles->roles;
		$user_id = username_exists( $entry[1] );
		if ( email_exists($entry[6]) == false ) {

			 $message = "<P>Add user and contact data:<BR>";
			 $message .= print_r($entry, true);

			 $post = array(
		 	        'post_status'  => 'publish' ,
		 	        'post_title'  => $entry[1] . ' ' . $entry[4],
		 	        'post_type'  => 'contact_data' ,
		 	    );

		 	    // insert the post
				$post_id = wp_insert_post( $post );
				$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
			//$user_id = wp_create_user( $entry[1], $random_password, $entry[5] );


			$userdata = array(
				'user_login'  =>  $entry[1],
				'user_email'    =>  $entry[5],
				'user_pass'   =>  $random_password,
				'role' => 'property_trustee'
			);
			$user_id = wp_insert_user( $userdata );

			//$updatethis = update_user_meta( $user_id, 'role', 'property_trustee' );



			if ( $updatethis === false ) {
			$message .= "<H4>Bad Role: " . $updatethis . ", " . $user_id . "</H4>";
			} else {
			$message .= "<H4>GOOD Role: " . $updatethis . ", " . $user_id . "</H4>";
			}


			//get_editable_roles();
			$message .= "<H4>Roles: " . $all_roles . "</H4>";
			foreach($all_roles as $role => $name) {
			$message .= "<H5>Role Key: " . $role . "; Role Value: " . $name[0] . "</H4>";
			foreach($name as $k => $v) {
				$message .= "<UL><H5>Role Key: " . $k . "; Role Value: " . $v . "</H4></UL>";
				if ($v == 'Trustee') {
				//$updatethis = update_user_meta( $user_id, 'role', $v );

				}
		}
		}

		//set user role based on contact type - entry[9]
		//if entry[9] == 3 user role is 'trustee' for example
		switch( $entry[9] ) {
			case 4:
				//update_user_meta( $user_id, 'role', 'fg_prop_occupant' );
				break;

			case 3:
				//update_user_meta( $user_id, 'role', 'fg_prop_owner' );
				break;


			case 2:
				//update_user_meta( $user_id, 'role', 'fg_prop_trustee' );
				break;



		}

		update_user_meta( $user_id, 'contact_data_id', $post_id );
		update_user_meta( $user_id, 'contact_first_name', $entry[1] );
		update_user_meta( $user_id, 'contact_last_name', $entry[4] );
		update_user_meta( $user_id, 'client_phone', $entry[2] );
		update_user_meta( $user_id, 'client_email', $entry[5] );
		update_user_meta( $user_id, 'client_cell', $entry[3] );
		/*
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );
		*/

			} else {
			$really = email_exists($entry[5]);
			$message .= "<H4>No Roles: " . $entry[5] . ", Really: " . $really . "</H4>";
			$return_email_fail;
			return false;
			}
         //update_post_meta($post_id, 'contact_first_name', $entry[1]);
         //update_post_meta($post_id, 'contact_first_name', $entry[4]);

	//set contact type
	wp_set_post_terms( $post_id, $entry[9], 'contact_data_types', $append );
	update_post_meta( $post_id, 'contact_first_name', $entry[1] );
	update_post_meta( $post_id, 'contact_last_name', $entry[4] );
	update_post_meta( $post_id, 'client_phone', $entry[2] );
	update_post_meta( $post_id, 'client_email', $entry[5] );
	update_post_meta( $post_id, 'client_cell', $entry[3] );
	/*
	update_post_meta( $client_addr1, 'client_addr1', $client_addr1 );
	update_post_meta( $client_addr2, 'client_addr2', $client_addr2 );
	update_post_meta( $client_city, 'client_city', $client_city );
	update_post_meta( $client_zip, 'client_zip', $client_zip );
	*/
	// Send
  		//mail('dg_419@hotmail.com', 'Getting the Gravity Form 9', $message);
 	}
	
 	/*************************************************/
 	
     if( $entry['form_id'] == 30 ) {//network document management form

		/*$property_url = $entry[7];
		$property_path = str_replace($_SERVER['HTTP_HOST'], '', $property_url);
		getAssignedProperties();
		$cur_properties = implode( ',', $assigned_properties );
		$cur_properties = trim( $assigned_properties, ',' );
			
		$query_blogs = "SELECT path FROM wp_blogs WHERE blog_id IN (" . $cur_properties . ")";
		$cur_blogs = $wpdb->get_results( $query_units, ARRAY_A);
		*/
	
	$message .= "<H2>Entry</H2><UL>";
    if ( is_array($entry) ) {
		
		foreach ($entry as $k=>$v) {
			if ( !is_array($v) ) {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
			} else {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
				$message .= "<H3>Nested</H3><UL>";
				foreach ( $v as $k1=>$v1 ) {
					$message .= "<li>Level 2: " . $k1 . ", " . $v1 . "</li>";
				}
				$message .= "</ul>";
			}
			
			if ( $k == 38 )
            {
				$message .= "<P>Additional Emails:<BR>";
				$selected_properties = explode(',', $v);
				 foreach( $selected_properties as $k=>$v) {
					 
					 $message .= "<h3>Emails Array:" . $k . ", " . $v . "<h3>";
					  $args = array(
								'blog_id'      => $v
							 );
						$property_contacts = get_users( $args );
						
						$admin_email = get_option( 'admin_email', $default );
						$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			$attachments = array( $entry[12] );
		 move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
		 $use_filename = str_replace('/wp-content/uploads/', '', $entry[12]);
		 
		 
		$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
		//$message .= '<P>' . $attachments[0];

		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 1', $message, $headers, $attachments[0] );
		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 2', $message, $headers, $attachments );
		//wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
						foreach ( $property_contacts as $property_contact ) {
							$message .= '<h4>' . esc_html( $property_contact->user_email ) . '</h4>';
							if ( esc_html( $property_contact->user_email ) == 'dg_419@hotmail.com' 
								|| esc_html( $property_contact->user_email ) == 'd_gannon@ptechinternational.com'
								|| esc_html( $property_contact->user_email ) == 'dgannon@2265solutions.com') {
								//wp_mail( $property_contact->user_email, 'Recip 2', $message );
								//wp_mail( $property_contact->user_email, 'Recip with attachemnts', $recip_message, $headers, $attachments );
								
							}
							/*
							$blog_details = get_blog_details($v);
							$v = $property_contact->display_name . ',' . $property_contact->roles . ',' . $blog_details->blogname;
							$items[] = array("value" => $property_contact->user_email, "text" => $v);
							*/
						}			 
							 
					 //$items[] = array("value" => $k, "text" => $v);
					 
					}
				//$field["choices"] = $items;
				
             }
             
             
		}
		$message .= "</ul>";
		
		
        
		
	}
       
		
			
		
	}
	
	if ( $entry['form_id'] == 13 ) {
		 $message .= "<H2>Entry</H2><UL>";
    if ( is_array($entry) ) {
		
		foreach ($entry as $k=>$v) {
			if ( !is_array($v) ) {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
			} else {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
				$message .= "<H3>Nested</H3><UL>";
				foreach ( $v as $k1=>$v1 ) {
					$message .= "<li>Level 2: " . $k1 . ", " . $v1 . "</li>";
				}
				$message .= "</ul>";
			}
			
			if ( $k == 38 )
            {
				$message .= "<P>Additional Emails:<BR>";
				$selected_properties = explode(',', $v);
				 foreach( $selected_properties as $k=>$v) {
					 
					 $message .= "<h3>Emails Array:" . $k . ", " . $v . "<h3>";
					  $args = array(
								'blog_id'      => $v
							 );
						$property_contacts = get_users( $args );
						add_filter( 'wp_mail_content_type', 'set_html_content_type' );
						$admin_email = get_option( 'admin_email', $default );
						$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			$attachments = array( $entry[12] );
		 move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
		 $use_filename = str_replace('/wp-content/uploads/', '', $entry[12]);
		 
		 
		$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
		//$message .= '<P>' . $attachments[0];

		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 1', $message, $headers, $attachments[0] );
		//wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 2', $message, $headers, $attachments );
		//wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
						foreach ( $property_contacts as $property_contact ) {
							$message .= '<h4>' . esc_html( $property_contact->user_email ) . '</h4>';
							if ( esc_html( $property_contact->user_email ) == 'dg_419@hotmail.com' 
								|| esc_html( $property_contact->user_email ) == 'd_gannon@ptechinternational.com'
								|| esc_html( $property_contact->user_email ) == 'dgannon@2265solutions.com') {
								//wp_mail( $property_contact->user_email, 'Recip 2', $message );
								//wp_mail( $property_contact->user_email, 'Recip with attachemnts', $recip_message, $headers, $attachments );
								
							}
							/*
							$blog_details = get_blog_details($v);
							$v = $property_contact->display_name . ',' . $property_contact->roles . ',' . $blog_details->blogname;
							$items[] = array("value" => $property_contact->user_email, "text" => $v);
							*/
						}			 
					remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
					 //$items[] = array("value" => $k, "text" => $v);
					 
					}
				//$field["choices"] = $items;
				
             }
             
             
		}
		$message .= "</ul>";
		
		
        
		
	}
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
        if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

        $recip_ids = explode( ",", $entry[14] );
        $type_test = gettype($entry[14]);
        $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
        add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
        $admin_email = get_option( 'admin_email', $default );
		$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
        for($i=0; $i < count($recip_ids); $i++) {
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	$recip_id = get_user_by('id', $recip_ids[$i]);
        	$recip_email = get_post_meta( $recip_ids[$i], 'client_email', true );
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			$admin_email = get_option( 'admin_email', $default );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			//wp_mail( $recip_email, 'Recip', $message );

			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
				echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			*/
			
        	$message .= '<P>Email to: ' . $recip_email;
        	//wp_mail( $recip_email, $recip_subject, $recip_message, $headers, $attachments );

        	foreach($v  as $k1=>$v1) {
        	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        	
        }

		$message = wordwrap($message, 70);
		 // Send
		$attachments = array( $entry[12] );
		 move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
		 $use_filename = str_replace('/wp-content/uploads/', '', $entry[12]);
		 
		 
		$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
		$message .= '<P>' . $attachments[0];

		//wp_mail( 'dg_419@hotmail.com', $recip_subject, $recip_message, $headers, $attachments );
		//wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
 		
 		remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	}
}
add_filter('gform_validation_9', 'validate_user');

function validate_user($validation_result) {
    // 2 - Get the form object from the validation result
    $form = $validation_result["form"];

    // 3 - Get the current page being validated
    $current_page = rgpost('gform_source_page_number_' . $form['id']) ? rgpost('gform_source_page_number_' . $form['id']) : 1;
foreach($form['fields'] as &$field){
if ( email_exists($field['client_email']) ) {

		$field['failed_validation'] = true;
        $field['validation_message'] = 'The email address you registered is already in use.';
}
}

    // 14 - Assign our modified $form object back to the validation result
    $validation_result['form'] = $form;

    // 15 - Return the validation result
    return $validation_result;

}


function my_pre_save_post( $post_id )
{
    // check if this is to be a new post
    if( $post_id == '758' )
    {
		$cur_post = get_post(758);
    	// Create a new post
	    $post = array(
	        'ID' => 758,
	        'post_status'  => 'publish' ,
	        'post_title'  => $cur_post->post_title,
	        'post_type'  => 'property_doc' ,
	    );

	    // insert the post
	    $post_id = wp_insert_post( $post );

	    // update $_POST['return']
	    $_POST['return'] = add_query_arg( array('post_id' => 758), $_POST['return'] );

    // return the new ID
        return $post_id;
    }


    return $post_id;
}

//add_filter('acf/pre_save_post' , 'my_pre_save_post' );

function my_wp_nav_menu_args( $args = '' ) {

	global $current_user;
	$cur_user_data = get_userdata($current_user->ID);

	if( $cur_user_data !== false ) {
		//echo "<h1>Roles: " . $cur_user_data . "</h1>";
		if ( in_array('administrator', $cur_user_data->roles) ) {
			
			$args['menu'] = 'Maintenance Field Menu';
			
		} elseif ( in_array('property_manager', $cur_user_data->roles) ) {
			$args['menu'] = 'Trustee Menu';
			
		} elseif ( in_array('maint_staff', $cur_user_data->roles) ) {
			$args['menu'] = 'Trustee Menu';

			
		} elseif ( in_array('desk_staff', $cur_user_data->roles) ) {
			$args['menu'] = 'Desk Staff';
			
		}
	} 
 return $args;

}
//add_filter( 'wp_nav_menu_args', 'my_wp_nav_menu_args' );

function switchMenus() {
	
	global $current_user;
	$cur_user_data = get_userdata($current_user->ID);

	if( $cur_user_data !== false ) {
		//echo "<h1>Roles: " . $cur_user_data . "</h1>";
		if ( in_array('administrator', $cur_user_data->roles) ) {
			
			$check_default = wp_get_nav_menu_object( 'Maintenance Field Menu' );
			$locations = get_theme_mod('nav_menu_locations');
			$locations['secondary'] = $check_default;
			set_theme_mod( 'nav_menu_locations', $locations );
			
		} elseif ( in_array('property_manager', $cur_user_data->roles) ) {
			$menus = get_registered_nav_menus();

			//$check_default = wp_get_nav_menu_object( 'PSN Default' );
			$check_default = wp_get_nav_menu_object( 'Trustee Menu' );
			$locations = get_theme_mod('nav_menu_locations');
			$locations['secondary'] = $check_default;
			set_theme_mod( 'nav_menu_locations', $locations );
			
		} elseif ( in_array('maint_staff', $cur_user_data->roles) ) {
			$menus = get_registered_nav_menus();

			$check_default = wp_get_nav_menu_object( 'Trustee Menu' );
			$locations = get_theme_mod('nav_menu_locations');
			$locations['secondary'] = $check_default;
			set_theme_mod( 'nav_menu_locations', $locations );

			/*
			$check_default = wp_get_nav_menu_object( 'Maintenance Field Menu' );
			$locations = get_theme_mod('nav_menu_locations');
			$locations['primary'] = $check_default;
			set_theme_mod( 'nav_menu_locations', $locations );
			*/
			
		} elseif ( in_array('desk_staff', $cur_user_data->roles) ) {
			$menus = get_registered_nav_menus();

			$check_default = wp_get_nav_menu_object( 'Desk Staff' );
			$locations = get_theme_mod('nav_menu_locations');
			$locations['secondary'] = $check_default;
			set_theme_mod( 'nav_menu_locations', $locations );

			/*
			$check_default = wp_get_nav_menu_object( 'Maintenance Field Menu' );
			$locations = get_theme_mod('nav_menu_locations');
			$locations['primary'] = $check_default;
			set_theme_mod( 'nav_menu_locations', $locations );
			*/
			
		}
	}
	/*
	 * 
	 * $thisct = count($locations);
		echo "<H3>thisct: " . $thisct . "</H3>";
		foreach($locations as $k=>$v) {
			echo "<H3>ine 1864 Nav Location: " . $k . "</H3>";
		}
		echo "<H3>Locations: " . $locations . "</H3>";
	 * $locations = get_theme_mod('nav_menu_locations');
		$locations['location-name'] = $foo.  //$foo is term_id of menu
		set_theme_mod('nav_menu_locations', $locations);
	 * 
	 * 
	 */

}

//add_action( 'wp_loaded', 'switchMenus' );

function getAssignedProperties(){

		global $wpdb;
		global $current_user;
		global $assigned_properties;
		get_currentuserinfo();
		$postid = get_the_ID();
				
		$args = array(
					'network_id' => $wpdb->siteid,
					'public'     => null,
					'archived'   => null,
					'mature'     => null,
					'spam'       => null,
					'deleted'    => null,
					'limit'      => 100,
					'offset'     => 0,
					);
							
		$property_ids = wp_get_sites( $args );
		$property_ct = count( $property_ids);
			
		foreach ($property_ids as $k=>$v) {
			foreach ($v as $k1=>$v1) {
				//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
					$user_query = new WP_User_Query( array( 'blog_id' => $v1 ) );
					// User Loop
					if ( ! empty( $user_query->results ) && $blog_details->blogname != '' ) {
						if ( in_array( $current_user->ID, $user_query->results) ) {
							$assigned_properties[] = $v1;
						}
					}
				}
			}	
		}
	
	return $assigned_properties;
}


/* gets all communications/post types across network limited to sites to which the user is assigned
 */
function assignedPropertyComms( $comm_type ) {
	
	if ( isset( $_GET['show_comm'] ) && $_GET['show_comm'] != '' ) {
		$display_comm = update_post_meta($_GET['pid'], 'cpm_dashboard_view', $_GET['show_comm'] );
		$show_cur_comm = false;
		unset($_GET['show_comm']);
		unset($_GET['pid']);
	}

	global $wpdb;
	global $current_user;
	global $disp_data;
	get_currentuserinfo();

	$args = array(
				'network_id' => $wpdb->siteid,
				'public'     => null,
				'archived'   => null,
				'mature'     => null,
				'spam'       => null,
				'deleted'    => null,
				'limit'      => 100,
				'offset'     => 0,
				'nopaging'	=> true
				);
				
	$property_ids = wp_get_sites( $args );
	$property_ct = count( $property_ids);
	//echo "<H1>Comm Type: " . $comm_type . "</H1>";

     
            global $wpdb;
            $wo_count = $wpdb->get_var( ' SELECT count("post_id") 
              FROM $wpdb->postmeta
              WHERE $wpdb->postmeta.meta_key = "fgpsn_wo_selected_properties" 
              AND $wpdb->postmeta.meta_value IS NOT NULL ' );


	if( $comm_type == 'unit_data' ) {
		$disp_data = ' <!-- Small boxes (Stat box) -->
      <div class="row">
        <!-- <div class="col-lg-3 col-xs-6"> -->
        <div class="col-lg-4">
          <!-- small box -->
           <div class="small-box bg-red">
            <div class="inner">
             <h3  id="fgpsn-maint-dash-panel-1"><?php echo $wo_count; ?></h3>

              <p>Requests Awaiting Approval</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-4">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
             <h3>' . $wo_count . '</h3>
             <p>Maintenance Requests</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <!-- ./col -->
        <div class="col-lg-4">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>44</h3>

              <p>User Registrations</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="display-wo"></div>
        <!-- ./col -->
        
      </div>
      <!-- /.row -->
      <!-- Main row -->';

      $disp_data = '<H3>Unit Data</H3>
		
		   <TABLE id="fgpsn_unit_summary_table" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Property</th>
					<th>Unit</th>
					<th>Owner</th>
					<th>Details</th>
				</tr>
			</thead>
						<TBODY>';
			
		
			$table_prefix = "wp_" . $v1 . "_";
			
			$args = array( 'post_type' => 'unit_data',
							'post_status' => 'publish',
							'nopaging' => true );

			$myposts = get_posts( $args );
			
			foreach ( $myposts as $post ) : setup_postdata( $post );
					$contact_id = get_post_meta($post->ID, 'unit_owner_id', true);
					$property_title = get_the_title( get_post_meta($post->ID, 'fgpsn_property_id', true) );
					
					
					
					/* if there's no title match to address */
					if ($property_title == '' ) {
						$use_title = '';
						get_post_meta($post->ID, 'fgpsn_property_id', true);
						$query = "";
						get_post_meta('fgpsn_property_street_address_1', true);
					}
					
					
					
					
					$disp_data .= "<tr><td>" . $property_title . " - " . get_post_meta($post->ID, 'fgpsn_property_id', true) . "</td>
						<td>" . $post->post_title . "</td>
						<td>" . $contact_id . "</td>
						<td><A HREF='" . get_the_permalink($post->ID) . "'>View</A></td>";
					

					$disp_data .= "</TR>";

			 endforeach;
			wp_reset_postdata();
		
		$disp_data .= "</tbody>
	<tfoot>
				<tr>
					<th>Property</th>
					<th>Unit</th>
					<th>Owner</th>
					<th>Details</th>
				</tr>
			</foot>
		</table>";
		
	} elseif( $comm_type == 'events' ) {
		
		$disp_data = "<H3>New Resident Requests</H3>
		<P>This page displays 'Maintenance requests' from clients. They have not yet been dispatched to the maintenance department. You can 'Reply', 'Send to Maintenance', or 'Dismiss' each item. Once a message is sent to the maintenance department you can still track it from the <a href=\"\">Pending W.O.'s</a> page.
				</P>
		
		   <TABLE id=\"example\" class=\"display\" cellspacing=\"0\" ><thead>
				<tr>
					<th>Property</th>
					<th>Location/<br>Contact</th>
					<th>Subject</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</thead>
						<TBODY>";
		
		foreach ($property_ids as $k=>$v) {
			//$blog_details = get_blog_details($k, true);
			foreach ($v as $k1=>$v1) {
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
					switch_to_blog($v1);
				}
			}
		
			$table_prefix = "wp_" . $blog_details->blog_id . "_";
			/*the from id is the author id pm
			 - get from ids where meta_key = 'select_recipients' or 'recipient_groups'
			 so
			 */
			
			//$checer = 10;
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'ai1ec_events'
						AND post_status = 'pending'
						AND ID
						IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'cpm_dashboard_view'
								AND meta_value <> '' AND meta_value <> 0 )";
								
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'ai1ec_event'
						AND post_status = 'pending'
						ORDER BY post_date DESC";


			$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);
			
			if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
				//$disp_data .= "<H4>Array 2!</H4>";
				 $disp_data .= '';
				foreach ($cur_comms as $k=>$v) {
					//$disp_data .= "<H4>Array Row 1999: " . $k . " - " . $v . "</H4>";
					foreach ($v as $kv=>$vV) {

						if ($kv == 'post_author') {
							$pc_from_info = get_userdata( $vV );
							$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
							$pc_from_email = $pc_from_info->user_email;
						}
						if ($kv == 'post_date') {
							$pc_from_date = $vV;
						}
						if ($kv == 'post_title') {
							$pc_from_subject = $vV;
						}
						if ($kv == 'ID') {
							$pc_original_id = $vV;
							$recipients = get_post_meta($vV, 'select_recipients', true);
							//$comm_link = get_permalink($vV);
						}
						if ($kv == 'guid') {
							$pc_link = $vV;
							$comm_link = $vV;
						}

					}
					$disp_data .= "<tr><td>" . $blog_details->blogname . "</td>
					<td>" . $pc_from_name . "<BR>
						" . $recipients . "</td>
						<td>" . $pc_from_subject . "</td>
						<td>" . $pc_from_date . "</td>
						<td><A HREF='?property_id=" . $blog_details->blog_id . "&wo_id=" . $pc_original_id . "'>Open</A>
						<BR>
						<A HREF='?property_id=" . $blog_details->blog_id . "&wo_id=" . $pc_original_id . "'>Send to Maint.</A>
						</td>";

						//$href_url = get_admin_url() . 'index.php';

						$disp_data .= "</TR>";

				}
			}
			restore_current_blog();
		}
		
		$disp_data .= "</tbody></table>";
	} elseif( $comm_type == 'property_comm' ) {
		//echo "<H1>Comm Type: " . $comm_type . "</H1>";
		$disp_data = '<H3>Network Communications</H3>
		
		   <TABLE id="example" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Property</th>
					<th>Location/<br>Contact</th>
					<th>Subject</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</thead>
						<TBODY>
		';
		
		foreach ($property_ids as $k=>$v) {
			//$blog_details = get_blog_details($k, true);
			foreach ($v as $k1=>$v1) {
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
					switch_to_blog($v1);
				}
			}
		
			$table_prefix = "wp_" . $blog_details->blog_id . "_";
			/*the from id is the author id pm
			 - get from ids where meta_key = 'select_recipients' or 'recipient_groups'
			 so
			 */
			
			//$checer = 10;
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'property_comm'
						AND post_status = 'publish'
						AND ID
						IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'cpm_dashboard_view'
								AND meta_value <> '' AND meta_value <> 0 )";
								
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'property_comm'
						AND post_status = 'publish'
						ORDER BY post_date DESC";


			$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);
			
			if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
				//$disp_data .= "<H4>Array 2!</H4>";
				 $disp_data .= '';
				foreach ($cur_comms as $k=>$v) {
					//$disp_data .= "<H4>Array Row 1999: " . $k . " - " . $v . "</H4>";
					foreach ($v as $kv=>$vV) {

						if ($kv == 'post_author') {
							$pc_from_info = get_userdata( $vV );
							$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
							$pc_from_email = $pc_from_info->user_email;
						}
						if ($kv == 'post_date') {
							$pc_from_date = $vV;
						}
						if ($kv == 'post_title') {
							$pc_from_subject = $vV;
						}
						if ($kv == 'ID') {
							$pc_original_id = $vV;
							$recipients = get_post_meta($vV, 'select_recipients', true);
							//$comm_link = get_permalink($vV);
						}
						if ($kv == 'guid') {
							$pc_link = $vV;
							$comm_link = $vV;
						}

					}
					$disp_data .= "<tr><td>" . $blog_details->blogname . "</td>
					<td>" . $pc_from_name . "<BR>
						" . $recipients . "</td>
						<td>" . $pc_from_subject . "</td>
						<td>" . $pc_from_date . "</td>
						<td><A HREF='?property_id=" . $blog_details->blog_id . "&wo_id=" . $pc_original_id . "'>Open</A></td>";

						$href_url = get_admin_url() . 'index.php';

						$disp_data .= "</TR>";

				}
			}
			restore_current_blog();
		}
		$disp_data .= "</tbody></table>";
		restore_current_blog();
	
		} elseif( $comm_type == 'maintenance_requests' ) {
		
			
		
		} elseif( $comm_type == 'network_docs' ) {
		
		
			$disp_data = '<H3>Network Documents</H3>
		
		   <TABLE id="example" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Property</th>
					<th>Location/<br>Contact</th>
					<th>Subject</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</thead>
						<TBODY>
		';
		
		foreach ($property_ids as $k=>$v) {
			//$blog_details = get_blog_details($k, true);
			foreach ($v as $k1=>$v1) {
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
					switch_to_blog($v1);
				}
			}
		
			$table_prefix = "wp_" . $blog_details->blog_id . "_";
			/*the from id is the author id pm
			 - get from ids where meta_key = 'select_recipients' or 'recipient_groups'
			 so
			 */
			
			//$checer = 10;
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'ai1ec_events'
						AND post_status = 'publish'
						AND ID
						IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'cpm_dashboard_view'
								AND meta_value <> '' AND meta_value <> 0 )";
								
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'ai1ec_event'
						AND post_status = 'publish'
						AND ID
						NOT IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'ai1ec_start_time'
								AND meta_value IS NOT NULL )
						ORDER BY post_date DESC";


			$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);
			//$disp_data .= "<H4>Query!" . $wpdb->last_query . "</H4>";
			if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
				//$disp_data .= "<H4>Array 2!</H4>";
				 $disp_data .= '';
				foreach ($cur_comms as $k=>$v) {
					//$disp_data .= "<H4>Array Row 1999: " . $k . " - " . $v . "</H4>";
					foreach ($v as $kv=>$vV) {

						if ($kv == 'post_author') {
							$pc_from_info = get_userdata( $vV );
							$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
							$pc_from_email = $pc_from_info->user_email;
						}
						if ($kv == 'post_date') {
							$pc_from_date = $vV;
						}
						if ($kv == 'post_title') {
							$pc_from_subject = $vV;
						}
						if ($kv == 'ID') {
							$pc_original_id = $vV;
							$recipients = get_post_meta($vV, 'select_recipients', true);
							//$comm_link = get_permalink($vV);
						}
						if ($kv == 'guid') {
							$pc_link = $vV;
							$comm_link = $vV;
						}

					}
					$disp_data .= "<tr><td>" . $blog_details->blogname . "</td>
					<td>" . $pc_from_name . "<BR>
						" . $recipients . "</td>
						<td>" . $pc_from_subject . "</td>
						<td>" . $pc_from_date . "</td>
						<td><A HREF='?property_id=" . $blog_details->blog_id . "&wo_id=" . $pc_original_id . "'>Open</A>
						<BR>
						<A HREF='?property_id=" . $blog_details->blog_id . "&wo_id=" . $pc_original_id . "'>Send to Maint.</A>
						<BR>
						<A HREF='" . network_home_url() . "?gform_id=23'>Open</A></td>";

						$href_url = get_admin_url() . 'index.php';

						$disp_data .= "</TR>";

				}
			}
			
		}
		restore_current_blog();
		$disp_data .= "</tbody></table>";		
		
		} else {
		/* list properties and assignments based on Property CPT
		 * Add site for properties in MultiSite seperately
		 */
		 
		$disp_data .= "<H3>Properties List</H3>";
		$disp_table = false;
		/*
		$args = array(
					'network_id' => $wpdb->siteid,
					'public'     => null,
					'archived'   => null,
					'mature'     => null,
					'spam'       => null,
					'deleted'    => null,
					'limit'      => 100,
					'offset'     => 0,
					);
							
		$property_ids = wp_get_sites( $args );
		$property_ct = count( $property_ids);
			
		foreach ($property_ids as $k=>$v) {
			foreach ($v as $k1=>$v1) {
				//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
					$user_query = new WP_User_Query( array( 'blog_id' => $v1 ) );
					// User Loop
					if ( ! empty( $user_query->results ) && $blog_details->blogname != '' ) {
						if ( in_array( $current_user->ID, $user_query->results) ) {
							$disp_data .= '<H4>
								<A HREF=?blog_id=' . $blog_details->blog_id . '>' . $blog_details->blogname . '</A></H4>';
						}
					}
				}
			}	
		}
		*/
		$args = array(
			'post_type' => 'properties',
			'post_status' => 'publish',
				'nopaging'	=> true	
		
		);

		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :
         while ($my_query->have_posts()) : $my_query->the_post();

              $address_1 = get_post_meta(get_the_ID(), 'fgpsn_property_address_1', true);
              $address_2 = get_post_meta(get_the_ID(), 'fgpsn_property_address_2', true);
              $city = get_post_meta(get_the_ID(), 'fgpsn_property_city', true);

              $disp_data .= '<H4>
								<A HREF=' . get_permalink( get_the_ID() ) . '>' . $address_1 . ', ' . $city . '</A></H4>';
			

          endwhile;
		endif;
		//$disp_data .= '</DIV>';
		
	}
	if ($disp_table === false ) {
		restore_current_blog(); 
		//$disp_data .= "</DIV>";
		return $disp_data;
	} else {
		restore_current_blog(); 
		//echo $disp_data;
		//$disp_data .= "</DIV>";
		return $disp_data;
	}
}

/* employee directory
 */
function employeeData( $comm_type ) {
	
	global $wpdb;
	global $current_user;
	global $table_prefix;
	global $disp_data;
	get_currentuserinfo();
	$blog_details = get_blog_details();
	$disp_data = '<TABLE id="employee_summary_table" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Name</th>
					<th>Department</th>
					<th>Title</th>
					
					<th>Open</th>
				</tr>
			</thead>
					<tbody>';
					
	$emp_list = get_posts( array('post_type' => 'employee_data',
							'nopaging' => true) );
	foreach ( $emp_list as $post ) : setup_postdata( $post ); 
		
		$title = get_post_meta( $post->ID, 'fgpsn_employee_title', true );
		$department = get_post_meta( $post->ID, 'fgpsn_employee_department', true );
		$disp_data .= "<tr><td>" . $post->post_title . "</td>
				<td>" . $department . "</td>
					<td>" . $title . "</td>
					<td><A HREF='" . get_the_permalink($post->ID) . "'>Open</A></td>";

					$disp_data .= "</TR>";
					
	endforeach;
	wp_reset_postdata();
	$disp_data .= "</tbody>
	<tfoot>
				<tr>
					<th>Name</th>
					<th>Department</th>
					<th>Title</th>
					
					<th>Open</th>
				</tr>
			</foot>
		</table>";
	
    //echo $disp_data;
    return $disp_data;
}




class fgpsn_work_order_details_widgetNA extends WP_Widget {

	function fgpsn_work_order_details_widget() {
		//Load Language
		load_plugin_textdomain( 'work-order-details', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows work order details, relevant unit data, vendors amybe also.', 'work-order-details' ) );
		//Create widget
		$this->WP_Widget( 'workorderdetails', __( 'W.O. Details', 'work-order-details' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		//extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );
		$link = empty( $instance[ 'link' ]) ? '' : $instance[ 'link' ];
		

		if ( !empty( $title ) &&  !empty( $link ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}
		else if ( !empty( $title ) ) {
			 echo $before_title . $title . $after_title;
		}
        //print recent posts
		//echo "<H4>HERE</H4>";
		echo $after_widget;

  } //end of widget()

	
}

//add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_work_order_details_widget");') );
//Register Widget


class fgpsn_assigned_properties extends WP_Widget {

	function fgpsn_assigned_properties() {

		//Load Language
		load_plugin_textdomain( 'fgpsn-assigned-properties', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Linked list of assigned properties.', 'recent-documents' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnassignedproperties', __( 'Assigned Properties', 'fgpsn-assigned-properties' ), $widget_ops );
		
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );
		$link = empty( $instance[ 'link' ]) ? '' : $instance[ 'link' ];
		$parameters = array(
				'title' 	=> $title,
				'link' 		=> $instance[ 'link' ],
				'hideposttitle' => $instance[ 'hideposttitle' ],
				'separator' => $instance[ 'separator' ],
				'afterexcerpt' => $instance[ 'afterexcerpt' ],
				'afterexcerptlink' => $instance[ 'afterexcerptlink' ],
				'show_type' => 'property_doc',
				'shownum' 	=> (int) $instance[ 'shownum' ],
				'postoffset' => (int) $instance[ 'postoffset' ],
				'reverseorder' => (int) $instance[ 'reverseorder' ],
				'excerpt' 	=> (int) $instance[ 'excerpt' ],
				'excerptlengthwords' => (int) $instance[ 'excerptlengthwords' ],
				'fg_act_document_cat' 	=> (bool) $instance[ 'fg_act_document_cat' ],
				'cats' 		=> esc_attr( $instance[ 'cats' ] ),
				'cusfield' 	=> esc_attr( $instance[ 'cusfield' ] ),
				'w' 		=> (int) $instance[ 'width' ],
				'h' 		=> (int) $instance[ 'height' ],
				'firstimage' => (bool) $instance[ 'firstimage' ],
				'atimage' 	=>(bool) $instance[ 'atimage' ],
				'defimage' 	=> esc_url( $instance[ 'defimage' ] ),
				'showauthor' => (bool) $instance[ 'showauthor' ],
				'showtime' 	=> (bool) $instance[ 'showtime' ],
				'format' 	=> esc_attr( $instance[ 'format' ] ),
				'spot' 		=> esc_attr( $instance[ 'spot' ] ),
			);
		
		
		global $wpdb;
		global $current_user;
		get_currentuserinfo();
		$postid = get_the_ID();
		
		/* eliminate this move these functions into sidebars for flexibility
		if ( $postid == 520 ) {//id of the unit data page
			if ( $_GET['post_id'] != '' && get_post_type( $_GET['post_id'] ) == 'unit_data' ) {
				
				//should be activating sidebars or widgets here I think
				echo $before_title . 'Violations History' . $after_title;
				echo '<DIV></DIV>';
				echo $before_title . 'Recent Payments' . $after_title;
				echo '<DIV></DIV>';
				echo $before_title . 'Recent Work Orders' . $after_title;
				echo '<DIV></DIV>';
				//echo '<H3>Cur Post' . get_post_type($_GET['post_id']) . '</H3>';
			}		
		}
		
		if ( $postid == 523 ) {//id of the unit data page
			if ( $_GET['property_id'] != '' ) {
				
				//should be activating sidebars or widgets here I think
				echo $before_title . 'Property Violations' . $after_title;
				echo '<DIV></DIV>';
				echo $before_title . 'Property Work Orders' . $after_title;
				echo '<DIV></DIV>';
				//echo '<H3>Cur Post' . get_post_type($_GET['post_id']) . '</H3>';
			}		
		}	
		*/

		if ( !empty( $title ) &&  !empty( $link ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}
		else if ( !empty( $title ) ) {
			 echo $before_title . $title . $after_title;
		}
        
        
        /* old for multisite property assignments 
		
		$args = array(
					'network_id' => $wpdb->siteid,
					'public'     => null,
					'archived'   => null,
					'mature'     => null,
					'spam'       => null,
					'deleted'    => null,
					'limit'      => 100,
					'offset'     => 0,
				'nopaging'	=> true
					);
					
		$property_ids = wp_get_sites( $args );
		$property_ct = count( $property_ids);
		
		foreach ($property_ids as $k=>$v) {
			foreach ($v as $k1=>$v1) {
				//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
					$user_query = new WP_User_Query( array( 'blog_id' => $v1 ) );
					// User Loop
					if ( ! empty( $user_query->results ) && $blog_details->blogname != '' ) {
						if ( in_array( $current_user->ID, $user_query->results) ) {
							echo '<A HREF="/property-data/?blog_id=' . $v1 . '"><LI>' . $blog_details->blogname . '</LI></A>';
						}
					}
				}
			}
	
		}
		*/
		$post_args = Array('post_type' => 'properties');
	
		$recent_wos = get_posts($post_args);
		$postlist = '';
		foreach ( $recent_wos as $recent_wo ) :
		  setup_postdata( $recent_wos );
			
			$postlist .= '<h4><a href="' . get_the_permalink( $recent_wo->ID ) . '">' .  get_the_title( $recent_wo->ID ) . '</a></h4>';
		endforeach; 
		wp_reset_postdata();
		echo $postlist;
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['link'] = esc_attr($new_instance['link']);
		$instance['hideposttitle'] = $new_instance['hideposttitle'] ? 1 : 0;
		$instance['separator'] = $new_instance['separator'];
		$instance['afterexcerpt'] = $new_instance['afterexcerpt'];
		$instance['afterexcerptlink'] = $new_instance['afterexcerptlink'] ? 1 : 0;
		$instance['show_type'] = $new_instance['show_type'];

		$instance['shownum'] = isset($new_instance['show-num']) ? (int) abs($new_instance['show-num']) : (int) abs($new_instance['shownum']);
	//	if ($instance['shownum'] > 20) $instance['shownum'] = 20;
		unset($instance['show-num']);

		$instance['postoffset'] = (int) abs($new_instance['postoffset']);
		$instance['reverseorder'] = $new_instance['reverseorder'] ? 1 : 0;

		$instance['excerpt'] = isset($new_instance['excerpt-length']) ? (int) abs($new_instance['excerpt-length']) : (int) abs($new_instance['excerpt']);
		unset($instance['excerpt-length']);

		$instance['excerptlengthwords'] = (int) abs($new_instance['excerptlengthwords']);

		$instance['cats'] = esc_attr($new_instance['cats']);
		$instance['fg_act_document_cat'] = $new_instance['fg_act_document_cat'] ? 1 : 0;

		$instance['cusfield'] = isset($new_instance['cus-field']) ? esc_attr($new_instance['cus-field']) : esc_attr($new_instance['cusfield']);
		unset($instance['cus-field']);

		$instance['width'] = esc_attr($new_instance['width']);
		$instance['height'] = esc_attr($new_instance['height']);
		$instance['firstimage'] = $new_instance['first-image'] ? 1 : 0;
		$instance['atimage'] = $new_instance['atimage'] ? 1 : 0;
		$instance['defimage'] = esc_url($new_instance['def-image']);
		$instance['showauthor'] = $new_instance['showauthor'] ? 1 : 0;
		$instance['showtime'] = $new_instance['showtime'] ? 1 : 0;
		$instance['format'] = esc_attr($new_instance['format']);
 		$instance['spot'] = esc_attr($new_instance['spot']);
 		unset($instance['spot1']);
 		unset($instance['spot2']);
 		unset($instance['spot3']);
//die($new_instance['spot']);
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		if (isset($instance['spot1'])) $instance['spot'] = $instance['spot1'];
		if (isset($instance['show-num'])) $instance['shownum'] = $instance['show-num'];
		if (isset($instance['excerpt-length'])) $instance['excerpt'] = $instance['excerpt-length'];
		if (isset($instance['cus-field'])) $instance['cusfield'] = $instance['cus-field'];

		$instance = wp_parse_args( (array) $instance, fgpsn_assigned_properties_defaults() );

		$title 		= esc_attr($instance['title']);
		$link 		= esc_attr($instance['link']);
		$hideposttitle = $instance['hideposttitle'];
		$separator 	= $instance['separator'];
		$afterexcerpt = $instance['afterexcerpt'];
		$afterexcerptlink = $instance['afterexcerptlink'];
		$show_type 	= $instance['show_type'];
		$shownum 	= (int) $instance['shownum'];
		$postoffset	= (int) $instance['postoffset'];
		$reverseorder = $instance['reverseorder'];
		$excerpt = (int) $instance['excerpt'];
		$excerptlengthwords = (int) $instance['excerptlengthwords'];
		$cats 		= esc_attr($instance['cats']);
		$fg_act_document_cat 	= (bool) $instance['fg_act_document_cat'];
		$cus_field 	= esc_attr($instance['cusfield']);
		$width 		= esc_attr($instance['width']);
		$height 	= esc_attr($instance['height']);
		$firstimage	= (bool) $instance['firstimage'];
		$atimage 	= (bool) $instance['atimage'];
		$defimage 	= esc_url($instance['defimage']);
		$showauthor	= (bool) $instance['showauthor'];
		$showtime 	= (bool) $instance['showtime'];
		$format 	= esc_attr($instance['format']);
		$spot 		= esc_attr($instance['spot']);
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Title Link:');?>
				<input class="widefat" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" type="text" value="<?php echo $link; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('shownum'); ?>"><?php _e('Number of documents to show:');?>
				<input id="<?php echo $this->get_field_id('shownum'); ?>" name="<?php echo $this->get_field_name('shownum'); ?>" type="text" value="<?php echo $shownum; ?>" size ="3" /><br />
				<small><?php _e('(at most 20)','recent-documents'); ?></small>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('postoffset'); ?>"><?php _e('Number of Documents to skip:');?>
				<input id="<?php echo $this->get_field_id('postoffset'); ?>" name="<?php echo $this->get_field_name('postoffset'); ?>" type="text" value="<?php echo $postoffset; ?>" size ="3" /><br />
				<small><?php _e('(e.g. "1" will skip the most recent post)','recent-documents'); ?></small>
			</label>
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('reverseorder'); ?>" name="<?php echo $this->get_field_name('reverseorder'); ?>"<?php checked( $reverseorder ); ?> />
			<label for="<?php echo $this->get_field_id('reverseorder'); ?>"><?php _e('Show documents in reverse order?', 'recent-documents');?></label>
		</p>

		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('showauthor'); ?>" name="<?php echo $this->get_field_name('showauthor'); ?>"<?php checked( $showauthor ); ?> />
			<label for="<?php echo $this->get_field_id('showauthor'); ?>"><?php _e('Show Author', 'recent-documents');?></label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('cats'); ?>"><?php _e('Document Types:', 'recent-documents');?>
				<input class="widefat" id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" type="text" value="<?php echo $cats; ?>" /><br />
				<small>(<?php _e('Doc. Type IDs, separated by commas.', 'recent-documents');?>)</small>
			</label>
		</p>
		<p>
			<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('fg_act_document_cat'); ?>" name="<?php echo $this->get_field_name('fg_act_document_cat'); ?>"<?php checked( $fg_act_document_cat ); ?> />
			<label for="<?php echo $this->get_field_id('fg_act_document_cat'); ?>"> <?php _e('Get documents of current document type.', 'recent-documents');?>
			<small>(<?php _e('Adds a list of related documents when viewing a single document listing.', 'recent-documents');?>)</small></label>
		</p>
		<?php
	} //end of form
}


// Show recent posts function
function fgpsn_assigned_properties_defaults() {
$defaults = array( 	'title' => __( 'Recent Documents', 'recent-documents' ),


					'link' => get_bloginfo( 'url' ) . '/blog/',
					'hideposttitle' => 0,
					'separator' => ': ',
					'afterexcerpt' => '...',
					'afterexcerptlink' => 0,
					'show_type' => 'property_doc',
					'postoffset' => 0,
					'limit' => 10,
					'shownum' => 10,
					'reverseorder' => 0,
					'excerpt' => 0,
					'excerptlengthwords' => 0,
					'fg_act_document_cat' => 0,
					'cats' => '',
					'cusfield' => '',
					'width' => '',
					'height' => '',
					'w' => '',
					'h' => '',
					'firstimage' => 0,
					'showauthor' => 0,
					'showtime' => 0,
					'atimage' => 0,
					'defimage' => '',
					'format' => 'm/d/Y',
					'spot' => 'spot1' );
	return $defaults;
}
add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_assigned_properties");') );

//Register Widget

class fgpsnRecentWos extends WP_Widget {

	function fgpsnRecentWos() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-recent-wos', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Show recent workorders filtered by property, user, unit, etc..', 'fgpsn-recent-wos' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnrecentwos', __( 'Recent Work Orders', 'fgpsn-recent-wos' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );


		$parameters = array(
				'title' 	=> $title,
				'api_key' 	=> $instance[ 'api_key'],
				'auth_token' 	=> $instance[ 'auth_token'],
				'from_number' 	=> $instance[ 'from_number'],
			);

		if ( !empty( $title ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}

        //print recent posts
		fgpsnGetRecentWos($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['api_key'] = $new_instance['api_key'];
		$instance['auth_token'] = $new_instance['auth_token'];
		$instance['from_number'] = $new_instance['from_number'];
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsnRecentWosDefaults() );

		$title 		= esc_attr($instance['title']);
		$api_key 	= $instance['api_key'];
		$auth_token = $instance['auth_token'];
		$from_number 	= $instance['from_number'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsnRecentWos");') );


function fgpsnGetRecentWos($args = '', $echo = true) {

	global $wpdb;
	$echo = true;
	$defaults = fgpsnRecentWosDefaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);

	$post_args = Array('post_type' => 'maintenance_requests',
						'posts_per_page'   => 5);
	
	$recent_wos = get_posts($post_args);
	$postlist = '';
	foreach ( $recent_wos as $recent_wo ) :
	  setup_postdata( $recent_wos );
		
		$postlist .= '<DIV>Desc: <a href="' . get_the_permalink( $recent_wo->ID ) . '">' .  get_the_title( $recent_wo->ID ) . '</a></DIV>';
		$postlist .= '<div>Request Date: ' . $recent_wo->post_date . '<BR>
		Request For: ' . get_the_title(get_post_meta($recent_wo->ID, 'fgpsn_wo_selected_properties', true)) . '</div>';
	endforeach; 
	wp_reset_postdata();

	if ($echo)
		echo $postlist;
	else
		return $postlist;
}



function fgpsnRecentWosDefaults() {
	$defaults = array( 	'title' => __( 'Recent W.O.', 'fgpsn-recent-wos' ),
				'api_key' 	=> 'AC73f31202e64ac545fcf2b96d0a3a7b73',
				'auth_token' 	=> 'a7da0165d7ed912c85460a01c7c38454',
				'from_number' 	=> '+16172717634', );
	return $defaults;
}


/***************************************************************************/
//register pm sidebars

	
function maint_default_sidebar() {
    register_sidebar( array(
        'name' => __( 'Maintenace Default', 'oxygen-child' ),
        'id' => 'maintenance-default-1',
        'description' => __( 'Widgets in this area will be shown for maintenance staff.', 'oxygen-child' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
        'before_title' => '<h3 class="maintenance-default-1-title">',
        'after_title' => '</h3>'
    ) );
}
//add_action( 'widgets_init', 'maint_default_sidebar' );

function maint_single_wo_sidebar() {
    register_sidebar( array(
        'name' => __( 'Situational Data', 'oxygen-child' ),
        'id' => 'maintenance-default-2',
        'description' => __( 'Displays widgets related to the current, open WO.', 'oxygen-child' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
        'before_title' => '<h3 class="maintenance-default-1-title">',
        'after_title' => '</h3>'
    ) );
}
//add_action( 'widgets_init', 'maint_single_wo_sidebar' );


function unit_info_sidebar() {
    register_sidebar( array(
        'name' => __( 'Unit Data', 'oxygen-child' ),
        'id' => 'unit-info',
        'description' => __( 'Eemployee sidebar to hold widgets with unit data for WOs, communication history etc..', 'oxygen-child' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
        'before_title' => '<h3 class="maintenance-default-1-title">',
        'after_title' => '</h3>'
    ) );
    
    register_sidebar( array(
        'name' => __( 'Situational Data', 'oxygen-child' ),
        'id' => 'maintenance-default-2',
        'description' => __( 'Displays widgets related to the current, open WO.', 'oxygen-child' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
        'before_title' => '<h3 class="maintenance-default-1-title">',
        'after_title' => '</h3>'
    ) );
    
    register_sidebar( array(
        'name' => __( 'Maintenace Default', 'oxygen-child' ),
        'id' => 'maintenance-default-1',
        'description' => __( 'Widgets in this area will be shown for maintenance staff.', 'oxygen-child' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
        'before_title' => '<h3 class="maintenance-default-1-title">',
        'after_title' => '</h3>'
    ) );
}
add_action( 'widgets_init', 'unit_info_sidebar' );

//get network documents
function get_network_documents( $blog_id ){

	/* For multi site this function must take doc type information from the root site and replicate it
	 * in each property site as it's viewed
	 * First get the docs from root and insert them locally then run the local functions below
	 */

	global $wpdb;
	global $user;
	global $switched;
	global $disp_data;
	switch_to_blog($blog_id);
	$blog_details = get_blog_details($blog_id, true);
	//switch_to_blog($v->blog_id);

	$args = array(
	'offset'           => 0,
	'post_type'        => 'property_doc',
	'post_status'      => 'publish',
	'nopaging' => true,
	'suppress_filters' => true );

	$communications = get_posts( $args );

	$property_ct = count( $communications);
	$cur_property =  get_bloginfo();
	$current_user = wp_get_current_user();
	$user_roles = get_userdata( $current_user-ID );
	$cur_role = $user_roles->roles;

	$disp_data = "";

	$disp_data .= '<p><TABLE><TR><TH colspan=4>' . $cur_property . ' Documents</TH></TR>';
	//for each property, set the message and communications as a Metavalue?
	$disp_data .= '</table></P>';

	//	restore_current_blog();
	//first check if its a single. If so skip displaying list

	//wp_enqueue_script( 'jquery-ui-accordion' ); moved to theme/funtions

	/* setup attribute distinguish property vs. service vendor using parent categories */
	extract( shortcode_atts( array(
		'document_types' => 0
	), $atts ) );
	$document_types = "{$document_types}";

	$args = array(
		'post_type'        => 'property_doc',
		'taxonomy' => 'property_document_types',
		'include' => $document_types,
		'hide_empty'  		=> 1,
		'show_count'         => 1,
		'hierarchical'  => true,
				'nopaging'	=> true,
		'order' => ASC);

	$terms = get_terms("property_document_types", $args);


	 $count = count($terms);
	 //echo '<H2>Query 228: ' . $wpdb->last_query . ', Count: ' . $count . '</H2>';
	 if ( $count > 0 ){
		 /* $disp_data .= "<ul class='no_bullets top'>"; */
		 $disp_data .= "<div id='fg-documents-accordion'>";
		 foreach ( $terms as $term ) {

			//now get terms where ID is parent
			/* $disp_data .= "<li class='level_1'><A HREF='"  . get_bloginfo('url') . "/property_document_types/" . $term->slug . "/'>" . $term->name . " (" . $term->count . ")</A>"; */

			$disp_data .= "<H3>" . $term->name . " <DIV STYLE='display: inline; position: relative; float: right; font-size: 70%; color: blue; padding-right: 20px; padding-top: 7px;'> Total: " . $term->count . "</DIV><DIV STYLE='display: inline; position: relative; float: right; font-size:  70%; color: blue; padding-right: 20px; padding-top: 7px;'> Most Recent:" . get_the_time('D j, Y', $term->ID) . "</DIV></H3>";
			$cur_slug = $term->slug;


		 /*trustees query
		 $args2 = array(
			'post_type'        => 'property_doc',
			'meta_key' =>  'set_group_document_access',
			'meta_value' => 'Trustee',
			'property_document_types' => $cur_slug,
			'hide_empty'  		=> 0,
			'hierarchical'  => true,
			'show_count'         => 1
			);
*/
		/*general query*/
				 $args2 = array(
					'post_type'        => 'property_doc',
					'property_document_types' => $cur_slug,
					'hide_empty'  		=> 0,
					'hierarchical'  => true,
					'nopaging' => true,
					'show_count'         => 1
					);

			//echo $disp_data . "<H3>LINE 265 - " . $cur_slug ."</H3>";

			$terms2 = get_posts($args2);
			//echo "<H3>LINE 265 - </H3>";


		 if ( is_wp_error( $terms2 ) ) {
		    $error_string = $terms2->get_error_message();
		    echo '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
}
		 //$disp_data .= "<H3>LINE 256 - " . $terms2 ."</H3>";
		// echo $disp_data;
		  $count2 = count($terms2);
		  if ( $count2 > 0 ){
			 /* $disp_data .= "<ul class='no_bullets'>"; */

			//get user role - certain roles can edit document data
			if ( in_array('property_manager', $cur_role) ) {
				$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
				<TBODY>";
			} else {
				$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
				<TBODY>";
			 // $disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: //100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View - ";

				foreach($cur_role as $k=>$v) {
			   //$disp_data .= $k . " -> " . $v . "<BR>";
			  }

			  //$disp_data .= $cur_role . "</TH></TR></THEAD>
			 // <TBODY>";
			 $disp_data .= $cur_role . "</TH></TR></THEAD>
			  <TBODY>";


			  }
			  foreach ( $terms2 as $term2 ) {

				$cur_doc_file = get_post_meta($term2->ID, 'property_doc_file', true);
				if (is_array($cur_doc_file)) {

					$cur_file = $cur_doc_file[url];

				} else {

					$cur_file = $cur_doc_file;

				}
				$disp_data .= "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $term2->ID . "'>" . $term2->post_title . "</A></TD>
				<TD>" . get_the_time('D j, Y', $term2->ID) . "</TD>
				<TD><A HREF='" . $cur_file . "' target='_blank'>View</A></TD>";
				if ( in_array('property_manager', $cur_role) ) {
					$disp_data .= "<TD><a href='" . site_url() . "/manage-documents/?gform_post_id=" . $term2->ID . "'>Edit</A></TD>";
				} else {
					$disp_data .= "<TD><a href='" . site_url() . "/manage-documents/?gform_post_id=" . $term2->ID . "'>Edit</A></TD>";
				}
				$disp_data .= "</TR>";

			  }
			  $disp_data .= "</TABLE>";
		 }


		/* $disp_data .= "</li>"; */

		 }
		/* $disp_data .= "</ul>"; */
		$disp_data .= "</DIV>";
	 }
	 //echo $disp_data;
	return $disp_data;
}



//include( plugin_dir_path( __FILE__ ) . '/style.css' );



/*shortcode for demo intro page template*/

function fgpsnDemoIntro( $atts ){
	global  $disp_data;

	$disp_data = "<div class='demo-intro-box'>
						
						<div class='demo-intro-box-item'>
							<a ahref='". get_permalink() . "'<h3>Work Manage Orders</h3>
							<h4>Create a New Request</h4>
							<p>Start from scratch and follow a maintenance request through the whole distribution process.
							</p>
							<h4>View Current Work Orders</h4>
							<p>View a summary sample work orders. Search and sort work orders by date, priority, unit, staff . . . View request details as well as assign and schedule tasks.
							</p>
						</div>

						<div class='demo-intro-box-item'>
							<h3>Manage Units</h3>
							<h4>View Unit Details</h4>
							<p>Update 'public' unit information like images, descriptions. You can also manage private owner and unit information such as schedules and billing, legal and financial documents, violation letters and more.
							</p>
							<h4>Rent or Sell a Unit</h4>
							<p>Easily update a unit's status and list on Trulio, Postlets, Zillow and more. The unit is also listed on the Available Units page and in the Property Classified Ads.
							</p>
						</div>

						<div style='clear: both;'></div>
						
						<div class='demo-intro-box-item'>
							<h3>Vendor Services</h3>
							<h4>View Vendor Details</h4>
							<p>Vendor lists can made available to residents or limited to staff access. Search vendors by service type and location, assign resident work orders dorectly to vendors, or allow residents to request services directly.
							</p>
							<h4>Create a Vendor Network</h4>
							<p>You can allow residents to add their own preferred vendors and allow other residents to request their services. Vendors can be added to the property Classified area as well.
							</p>
						</div>
						
						<div class='demo-intro-box-item'>
							<h3>Access Anytime, Anywhere</h3>
							<h4>View Vendor Details</h4>
							<p>Vendor lists can made available to residents or limited to staff access. Search vendors by service type and location, assign resident work orders dorectly to vendors, or allow residents to request services directly.
							</p>
							<h4>Create a Vendor Network</h4>
							<p>You can allow residents to add their own preferred vendors and allow other residents to request their services. Vendors can be added to the property Classified area as well.
							</p>
						</div>
						<div style='clear: both;'></div>

					</div>";
	return $disp_data;
	//echo "<h1>Oh Here we 1200!</h1>";

}
add_shortcode( 'fgpsn_demo_intro', 'fgpsnDemoIntro' );


/*shortcode for demo intro page template*/

function fgpsnWoDemo( $atts ){
	global  $disp_data;

	wp_enqueue_script ( 'jquery-ui-tabs');
	gravity_form_enqueue_scripts( 1, true );

	$disp_data = '<link rel="stylesheet" href="http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/style.css">';
  ?>
 <script>
  jQuery(function() {
  	
    jQuery( "#tabs" ).tabs();
   
  });
  </script>
  
  <?php
// echo gravity_form(1);
   $echo_form = gravity_form( 1, false, false, false, '', false );
	$disp_data .= "<div id='tabs'>
  <ul>
    <li><a href='#tabs-1'>Nunc tincidunt</a></li>
    <li><a href='#tabs-2'>Proin dolor</a></li>
    <li><a href='#tabs-3'>Aenean lacinia</a></li>
  </ul>
  <div id='tabs-1'>
    <p>Proin elit arcu, rutrum commodo, vehicula tempus, commodo a, risus. Curabitur nec arcu. Donec sollicitudin mi sit amet mauris. Nam elementum quam ullamcorper ante. Etiam aliquet massa et lorem. Mauris dapibus lacus auctor risus. Aenean tempor ullamcorper leo. Vivamus sed magna quis ligula eleifend adipiscing. Duis orci. Aliquam sodales tortor vitae ipsum. Aliquam nulla. Duis aliquam molestie erat. Ut et mauris vel pede varius sollicitudin. Sed ut dolor nec orci tincidunt interdum. Phasellus ipsum. Nunc tristique tempus lectus.</p>
  </div>
  <div id='tabs-2'>
    <p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
  </div>
  <div id='tabs-3'><p>" . $echo_form . "</p></div>
</div>";
	return $disp_data;
	//echo "<h1>Oh Here we 1200!</h1>";

}
add_shortcode( 'fgpsn_wo_demo', 'fgpsnWoDemo' );


function encodeBootstrapJsCss() {

  //echo '<H1>Ecque Called!</h1>';
  /*wp_register_script("fgpsn-dashboard-script", "http://fgpsn.com/wp-content/themes/fgpsn-pm-admin-bootstrap/dist/js/pages/dashboard.js", true);

   wp_enqueue_script("fgpsn-dashboard-script", true);*/
  wp_register_style( "fgpsn-bootstrapcdn-style", "http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" );
   wp_enqueue_style("fgpsn-bootstrapcdn-style");

  wp_register_script( "fgpsn-bootstrapcdn", "http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js", null, '', true );
  wp_enqueue_script("fgpsn-bootstrapcdn", true);

  wp_register_style( "fgpsn-fontawesome-style", "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css");
  wp_enqueue_style("fgpsn-fontawesome-style");

  /*wp_register_style( "fgpsn-whysiyg5-style", "http://fgpsn.com/bootstrap/AdminLTE-master/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css");

  wp_enqueue_style("fgpsn-whysiyg5-style");
*/
  /* wp_register_script("fgpsn-wysihtml5-script", "http://fgpsn.com/bootstrap/AdminLTE-master/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js", null, '', true);

   wp_enqueue_script("fgpsn-wysihtml5-script", true);*/

   wp_register_script('fgpsnmoment', plugin_dir_url( __FILE__ ) . 'js/moment.min.js', true );
  wp_enqueue_script('fgpsnmoment', true);


  wp_register_style( "fgpsncalendarstyle", plugin_dir_url( __FILE__ ) . "js/fullcalendar-master/dist/fullcalendar.css");//, '', true
  wp_enqueue_style( 'fgpsncalendarstyle' );
  

 wp_register_script('fgpsncalendar', plugin_dir_url( __FILE__ ) . 'js/fullcalendar-master/dist/fullcalendar.js', true );
 wp_enqueue_script( 'fgpsncalendar', true );

 /*
 wp_register_script('fgpsn-jquery', get_template_directory_uri() . '/plugins/jQuery/jQuery-2.2.0.min.js', true );
wp_enqueue_script( 'fgpsn-jquery', true );*/
wp_register_script('fgpsn-jquery-ui-core', 'https://code.jquery.com/ui/1.11.4/jquery-ui.min.js', true );
wp_enqueue_script( 'fgpsn-jquery-ui-core', true );



/*wp_register_script('fgpsn-slimscroll', get_template_directory_uri() . '/plugins/slimScroll/jquery.slimscroll.min.js', true );
wp_enqueue_script( 'fgpsn-slimscroll', true );


wp_register_script("fgpsn-app", get_template_directory_uri() . "/dist/js/app.min.js", true);

   wp_enqueue_script("fgpsn-app", true);*/

   wp_register_script("fgpsn-wysihtml5-script", "http://fgpsn.com/bootstrap/AdminLTE-master/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js", true);


   wp_enqueue_script("fgpsn-wysihtml5-script", true);

   
    wp_register_script("fgpsn-angularapp", "https://ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular.min.js", true);
    //wp_enqueue_script("fgpsn-angularapp", true);
  
}
add_action('wp_enqueue_scripts', 'encodeBootstrapJsCss');
?>
