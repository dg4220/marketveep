<?PHP

/******************************************************
 * DG Creating Contacts post type and meta boxes: Contacts and metaoxes dependent on other coustom post types or taxonomies.
*******************************************************/

/* Create the post and Taxonomies */
function custom_post_employee_data() {

		$labels = array(
			'name'               => _x( 'Employees', 'post type general name' ),
			'singular_name'      => _x( 'Employee', 'post type singular name' ),
			'add_new'            => _x( 'Add Employee', 'employee_data' ),
			'add_new_item'       => __( 'Add New Employee' ),
			'edit_item'          => __( 'Edit Employee Data' ),
			'new_item'           => __( 'New Employee' ),
			'all_items'          => __( 'All Employees' ),
			'view_item'          => __( 'View Employee' ),
			'search_items'       => __( 'Search Employees' ),
			'not_found'          => __( 'No Employees Found' ),
			'not_found_in_trash' => __( 'No Employees found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Employee'
		);

		$args = array(
			'labels'        => $labels,
			'description'   => 'Holds Employee Data',
			'public'        => true,
			'menu_position' => 6,
			'supports'      => array( 'author', 'revisions', 'page-attributes', 'thumbnail', 'post_formats', 'custom-fields'),
			'taxonomies'      => array( 'employee_titles' ),
			'hierarchical' => true,
			'has_archive'   => true
		);

	register_post_type( 'employee_data', $args );
}
add_action( 'init', 'custom_post_employee_data' );
//wp_insert_term( 'post-format-directory', 'post_format' );
add_theme_support( 'post-formats', array( 'post-format-directory', 'directory' ) );

/* add employee types taxonomy */
function create_employee_data_types() {
 $labels = array(
    'name' => _x( 'Employee Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Employee Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Employee Types' ),
    'all_items' => __( 'All Employee Types' ),
    'parent_item' => __( 'Parent Employee Type' ),
    'parent_item_colon' => __( 'Parent Employee Type:' ),
    'edit_item' => __( 'Edit Employee Type' ),
    'update_item' => __( 'Update Employee Type' ),
    'add_new_item' => __( 'Add New Employee Type' ),
    'new_item_name' => __( 'New Employee Type Name' ),
  );

  register_taxonomy('employee_data_types','employee_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_employee_data_types' );


/* add Employee types taxonomy - use to create a two tier hierarchy Departments>Titles*/
function create_employee_titles() {
 $labels = array(
    'name' => _x( 'Employee Titles', 'taxonomy general name' ),
    'singular_name' => _x( 'Employee Title', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Titles' ),
    'all_items' => __( 'All Titles' ),
    'parent_item' => __( 'Department' ),
    'parent_item_colon' => __( 'Department Name:' ),
    'edit_item' => __( 'Edit Title' ),
    'update_item' => __( 'Update Title' ),
    'add_new_item' => __( 'Add New Title' ),
    'new_item_name' => __( 'New Title' ),
  );

  register_taxonomy('employee_titles','employee_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_employee_titles' );


/******************************************************************************
*Begin adding employee type specific meta boxes
******************************************************************************/


/* Below is for Employee Specific Information */


add_action( 'add_meta_boxes', 'employee_data' );
add_action( 'save_post', 'employee_data_save' );

function employee_data() {

	add_meta_box(
		'employee_data',
		__( 'Employee Data', 'myplugin_textdomain' ),
		'employee_data_content',
		'employee_data',
		'normal',
		'high'
	);

}

function employee_data_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'employee_data_content_nonce' );
	echo '<FIELDSET><LI><label for="fgpsn_employee_department">Department</label>';

	$fgpsn_employee_department = get_post_meta(get_the_ID(), 'fgpsn_employee_department', true);
	echo '<input id="fgpsn_employee_department" name="fgpsn_employee_department" value="' . $fgpsn_employee_department . '" type="text"></LI>';


	echo '<LI><label for="fgpsn_employee_title_role">Title</label>';

	$fgpsn_employee_title_role = get_post_meta(get_the_ID(), 'fgpsn_employee_title_role', true);
	echo '<input id="fgpsn_employee_title_role" name="fgpsn_employee_title_role" value="' . $fgpsn_employee_title_role . '" type="text"></LI>';

	echo '<LI><label for="fgpsn_employee_phone">Phone</label>';

	$fgpsn_employee_phone = get_post_meta(get_the_ID(), 'fgpsn_employee_phone', true);
	echo '<input id="fgpsn_employee_phone" name="fgpsn_employee_phone" value="' . $fgpsn_employee_phone . '" type="text">

	<label for="fgpsn_employee_email">Email: </label>';

	$fgpsn_employee_email = get_post_meta(get_the_ID(), 'fgpsn_employee_email', true);
	echo '<input id="fgpsn_employee_email" name="fgpsn_employee_email" value="' . $fgpsn_employee_email . '" type="text">

	<label for="fgpsn_employee_cell">Cell: </label>';

	$fgpsn_employee_cell_phone = get_post_meta(get_the_ID(), 'fgpsn_employee_cell_phone', true);
	echo '<input id="fgpsn_employee_cell_phone" name="fgpsn_employee_cell_phone" value="' . $fgpsn_employee_cell_phone . '" type="text">';
	
	
	
	$fgpsn_employee_co_prop = get_post_meta(get_the_ID(), 'fgpsn_employee_co_prop', true);
	echo '</FIELDSET>
	<FIELDSET><H3>Company Property/Equipment Distributed</H3>
	<label for="fgpsn_employee_cell">Cell: </label><input id="fgpsn_employee_co_prop" name="fgpsn_employee_co_prop[]" value="" type="checkbox"> ';
	
	echo '</LI>

	</FIELDSET>';

}

function employee_data_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['employee_data_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	
	// Update the post into the database
	// wp_update_post( $my_post );


	update_post_meta( $post_id, 'fgpsn_employee_department', $_POST['fgpsn_employee_department'] );
	update_post_meta( $post_id, 'fgpsn_employee_title_role', $_POST['fgpsn_employee_title_role'] );
	update_post_meta( $post_id, 'fgpsn_employee_phone', $_POST['fgpsn_employee_phone'] );
	update_post_meta( $post_id, 'fgpsn_employee_email', $_POST['fgpsn_employee_email'] );
	update_post_meta( $post_id, 'fgpsn_employee_cell', $_POST['fgpsn_employee_cell_phone'] );



/*
	if ( !$user_id && email_exists($fgpsn_employee_email) == false ) {

		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $contact_first_name, $random_password, $fgpsn_employee_email );

		update_user_meta( $user_id, 'contact_data_id', $contact_data_id );
		update_user_meta( $user_id, 'contact_first_name', $contact_first_name );
		update_user_meta( $user_id, 'contact_last_name', $contact_last_name );
		update_user_meta( $user_id, 'client_phone', $client_phone );
		update_user_meta( $user_id, 'client_email', $client_email );
		update_user_meta( $user_id, 'client_cell', $client_cell );
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );


	} else {

		update_user_meta( $user_id, 'contact_data_id', $contact_data_id );
		update_user_meta( $user_id, 'contact_last_name', $contact_last_name );
		update_user_meta( $user_id, 'client_phone', $client_phone );
		update_user_meta( $user_id, 'client_email', $client_email );
		update_user_meta( $user_id, 'client_cell', $client_cell );

		$random_password = __('User already exists.  Password inherited.');
	
	}

*/
}


function getEmpTemplate( $employee_id ) {

	global $current_user;
	global $cur_emp_data;
	$user_roles = get_userdata( $employee_id );
	$all_meta_for_user = get_user_meta( $employee_id );
	 //print_r( $all_meta_for_user );
	// echo '<BR><BR>';
	// the_meta();


    $employee_name = get_the_title($employee_id);
	$address_1 = get_post_meta( $employee_id, 'fgpsn_contact_address_1', true);
	$city = get_post_meta( $employee_id, 'fgpsn_contact_city', true);
	$state = get_post_meta( $employee_id, 'fgpsn_contact_state', true);
	$contact_phone = get_post_meta( $employee_id, 'fgpsn_contact_phone', true);
	$contact_email = get_post_meta( $employee_id, 'fgpsn_contact_email', true);
		
	$department = get_post_meta( $employee_id, 'fgpsn_employee_department', true);
	$title = get_post_meta( $employee_id, 'fgpsn_employee_title_role', true);
				
	$emp_phone = get_post_meta( $employee_id, 'fgpsn_employee_phone', true);
	$emp_email = get_post_meta( $employee_id, 'fgpsn_employee_email', true);
				
	$cur_emp_data = '<h2>Employee Datasheet: ' . $employee_name . '</h2>';
	$cur_emp_data .= '<TABLE class="fg-vendor-meta">
			<TR><TH COLSPAN=2><h3>Employee Data</h3></TH></TR>
			
			<Th>Contact Information:</TH>
				<TD>Name: ' . $employee_name . '<BR>
				Address: ' . $address_1 . ', ' . $city . ' ' . $state . '<BR>
				Phone: ' . $contact_phone . '<BR>
				Email' . $contact_email . '</TD></TR>
				
				<TR><TH valign=top align=right><label>Employment Data:</label></TH>
				<TD>Department: ' . $department . '<BR>
					Title: ' . $title . '<BR>
					Company Phone:' . $emp_phone . '<BR>
					Company Email: ' . $emp_email[0] . '</TD></TR>

				<TR><TH valign=top align=right><label>Company Property:</label></TH>
				<TD>Department: ' . $department . '<BR>
					Title: ' . $title . '<BR>
					Company Phone:' . $emp_phone . '<BR>
					Company Email: ' . $emp_email[0] . '</TD></TR>
					
				
					
				<TR><TH valign=top align=right><label>Current Assignments:</label></TH>
				<td>';
				
		$args = array(
					'post_type' => 'maintenance_requests',
					'meta_query' => array(
						array(
							'key' => 'fgpsn_wo_participating_staff_approval',
							'value' => $employee_id,
						)
					)
				 );
				$wolist = get_posts( $args );
				global $wpdb;
				
				foreach( $wolist as $wo) {
					setup_postdata( $wo );
					$property_title = get_the_title(get_post_meta( $wo->ID, 'fgpsn_wo_selected_properties', true));
					$unit_no = get_the_title(get_post_meta( $wo->ID, 'fgpsn_wo_selected_units', true));	
					$unit_owner_id = get_post_meta( $wo->ID, 'unit_owner_id', true);
					$room = get_post_meta( $wo->ID, 'fgpsn_wo_room_location', true); 
					$cur_emp_data .= '<P>Property: ' . $property_title . '<BR>
					Unit: ' . $unit_no . '<BR>
					Issue: <A HREF="' . get_permalink($wo->ID) . '">' . $wo->post_title . '</A><BR>
					Location:' . get_the_title( get_post_meta( $wo->ID, 'fgpsn_wo_selected_units', true ) ) . '</p>';
				}
				wp_reset_postdata();
								
				$cur_emp_data .= '</TD></TR></TABLE>
				
				<p>Click the button to get your coordinates.</p>
				<button onclick="getLocation()">Try It</button>

				<p id="demo"></p><script>

				function initMap() {
				  var myLatLng = {lat: -25.363, lng: 131.044};

				  var map = new google.maps.Map(document.getElementById("map"), {
				    zoom: 4,
				    center: myLatLng
				  });

				  var marker = new google.maps.Marker({
				    position: myLatLng,
				    map: map,
				    title: "Employee Location"
				  });
				}

				   
			var x = document.getElementById("demo");

			function getLocation() {
			    if (navigator.geolocation) {
			        navigator.geolocation.getCurrentPosition(initMap);
			    } else { 
			        x.innerHTML = "Geolocation is not supported by this browser.";
			    }
			}

			function showPosition(position) {
			    x.innerHTML = "Latitude: " + position.coords.latitude + 
			    "<br>Longitude: " + position.coords.longitude
			    + "<iframe src=\'https://www.google.com/maps/place/10+Oxford+St,+Augusta,+ME+04330/@44.3263624,-69.7773674\' width=\'600\' height=\'450\' frameborder=\'0\' style=\'border:0\' allowfullscreen></iframe>";

			    myLatLng = {lat: position.coords.latitude, lng: position.coords.longitude};
			    alert(myLatLng);
			    
			    var map = new google.maps.Map(document.getElementById(\'demo\'), {
						    center: myLatLng
						  });

			    var marker = new google.maps.Marker({
					    position: myLatLng,
					    map: map,
					    title: \'Hello World!\'
					  });
			}

			</script>

			<div id="mapholder"></div>

			 <style>
			      
			      #map {
			        height: 100%;
			      }
			      
			    </style>
			 
			    <div id="map"></div>
			    <script>

			function initMap(position) {
			  var myLatLng = {lat: position.coords.latitude, lng: position.coords.longitude};

			  var map = new google.maps.Map(document.getElementById(\'map\'), {
			    zoom: 8,
			    center: myLatLng
			  });

			  var marker = new google.maps.Marker({
			    position: myLatLng,
			    map: map,
			    title: \'Hello World!\'
			  });
			}


			    </script>';
   return $cur_emp_data;

}
?>
