<?php
/**
 * Template Name: Template Manage Contacts
 *
 * Allow users to update their profiles from Frontend.
 *
 */

get_header(); ?>

	<div id="primary" <?php mb_primary_attr(); ?> role="main">
		<?php

contact_first_name_content( $post );
//echo $disp_data;
		?>
	</div><!-- #primary.c8 -->

<?php get_footer(); ?>
