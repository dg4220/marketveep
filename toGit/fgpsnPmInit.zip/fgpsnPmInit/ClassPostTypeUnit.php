<?PHP
/******************************************************
 * DG Creating Property Logs post type and meta boxes
*******************************************************/
class FGPSN_Unit extends FGPSN_Property {

	/**
	 * Hook into the appropriate actions when the class is constructed.
	 */
	public function __construct() {

		
	}

	/*add public unility methods*/

	/*getting a property menu from a passed value or 'all' properties */
	public function fgpsn_unit_menu($unit_array) {
	  
	  //should also be able to take a passed value of property IDs  
		/*
		* First check if they have assigned properties
		* 
		*/
		$current_user = wp_get_current_user();
		if( !empty(get_user_meta( $current_user->ID, 'fgpsn_assigned_properties') ) ) {
			$args = array(
		    'posts_per_page'  => -1,
		    'post_type'  => 'properties',
		    'post_status' => 'publish',
		    'include'	=> '1',//get array from user meta
		              
		  );

		}
	   
		echo  '<SELECT multiple ID="unit_selection_menu" name="fgpsn_log_selected_units[]" size=5 >
	          <option value="0"> -- Selected Units -- </option>';
	      
	  $getem = get_posts(array('post_type' => 'unit_data'));
		foreach ( $getem as $property ) {
			
      setup_postdata($property );
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);
	    
	      if ($property->post_title) {
        echo '<OPTION value="' . $property->ID . '"';

  			if ( in_array($property->ID, $unit_array) ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $property->post_title . "</A><BR>";
  			}

  			echo '>' .  $property->post_title . '</OPTION>';
  			
      } 
	         
    }
	  echo  '</SELECT>';
	  wp_reset_postdata();	  
	 
	}
	

}//end class

new FGPSN_Unit;
?>
