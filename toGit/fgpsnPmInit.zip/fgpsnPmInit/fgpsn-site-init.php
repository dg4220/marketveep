<?php
/*
Plugin Name: Set Up A Front Gate Property Network Services Site
Plugin URI: http://www.ptechinternational.com
Description: Incorporates a wide array of custom post types and related functions that turn a wordparess install into a property management application and client portal
Version: 1
Author: Dennis Gannon
Author URI: http://www.ptechinternational.com
*/

/*  Copyright 2014  Dennis Gannon  (email : dgannon@2265solutions.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/



/* First get all required includes for post types, plugins, etc. 
include( plugin_dir_path( __FILE__ ) . '/inclCommunicationsPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclUnitPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclContactPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclVendorPostType.php' );
include( plugin_dir_path( __FILE__ ) . '/inclWOPostType.php' );


include( plugins_url( 'inclCommunicationsPostType.php', __FILE__ ) );
include( plugins_url( 'inclUnitPostType.php', __FILE__ ) );
include( plugins_url( 'inclContactPostType.php', __FILE__ ) );
include( plugins_url( 'inclVendorPostType.php', __FILE__ ) );
include( plugins_url( 'inclWOPostType.php', __FILE__ ) );
*/


/* Edit backend admin for managing a property only - this is all the back end they need for PM */
 $blog_id = get_current_blog_id();
 if ( $blog_id == 10 || !$blog_id == 10 ) {
	function remove_pm_menu() {
		//remove_menu_page('edit.php?post_type=acf');
		remove_menu_page( 'options-general.php' );
		remove_menu_page( 'plugins.php' );
	}
	add_action( 'admin_menu', 'remove_pm_menu', 999);
		//wp_register_style( 'fgpm_dashboard_css',  get_stylesheet_directory() . 'fgpm_dashboard_css.css');
		
		function edit_man_admin_menus() {
			global $menu;
			global $submenu;

			add_menu_page('Property Data', 'Property Data', 'publish_pages', 'options-general.php?page=property-data-settings', '', '', 1);
			add_menu_page('Service Requests', 'Service Requests', 'publish_pages', 'edit.php?post_type=ai1ec_event', '', '', 4);
			remove_menu_page('edit.php');
			add_menu_page('Communications', 'Client Communications', 'publish_pages', 'edit.php?post_type=property_comm', '', '', 5);

			//remove_menu_page('index.php');
			//remove_menu_page('options-general.php');
			
			remove_menu_page('upload.php');
			remove_menu_page('edit-comments.php');
			remove_menu_page('tools.php');
			remove_menu_page('admin.php', '?page=s2');
			remove_menu_page('edit.php?post_type=acf');
			remove_menu_page('edit.php?post_type=page');
			remove_menu_page('admin.php?page=wpi_main');
			remove_menu_page('themes.php');
			//remove_menu_page('plugins.php');
			remove_menu_page('users.php');
			remove_menu_page('admin.php?page=gf_edit_forms');
			remove_menu_page('dmin.php?page=cwp_poll');
			remove_menu_page('edit.php?post_type=acf');
			remove_menu_page('admin.php?page=wpseo_dashboard');
			remove_menu_page('admin.php?page=appointments');
			
			
			//add_menu_page('edit.php?post_type=property_doc');
			

			remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=category' );
			remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=post_tag' );
			remove_submenu_page( 'admin.php', 'admin.php?page=wpseo_dashboard' );
			remove_submenu_page( 'admin.php', 'admin.php?page=appointments' );
			remove_submenu_page( 'admin.php', 'admin.php?page=wpi_main' );
			//remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=property_document_types' );

			$menu[5][0] = 'Communications'; // Change Posts to Communications
			//$submenu['edit.php?post_type=property_comm'][5][0] = 'All Communications';

			//$menu[6][0] = 'Service Requests'; // Change Posts to Communications
			$submenu['edit.php?post_type=ai1ec_event'][4][0] = 'All Requests';
			$submenu['edit.php?post_type=ai1ec_event'][4][1] = 'New Request';




}
add_action( 'admin_menu', 'edit_man_admin_menus' );	 
	 
 }

//to allow file uploads
function update_edit_form() {
	echo ' enctype="multipart/form-data"';
}
add_action('post_edit_form_tag', 'update_edit_form');

//include("inclPropertyDataOptionsPage.php");


//create property setup tabs for admin
add_action('admin_menu', 'frontGate_property_settings_menu');

function frontGate_property_settings_menu() {
	add_options_page('Property Setup', 'Property Setup', 'manage_options', 'property-data-settings', 'property_settings_page');
}

/*********************************************************************************/
//property setting in the
function property_settings_page() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}

	?>

	<div class="wrap">

		    <?php screen_icon(); ?>
		    <h2>Settings</h2>
		    <form method="post" action="options.php">
		        <?php
	                    // This prints out all hidden setting fields
			    settings_fields('property_data_options');
			    do_settings_sections('property-data-settings');
			?>
		        <?php submit_button(); ?>
		    </form>
	</div>


	<?PHP

}//end property_settings_page function

add_action('admin_init', 'property_admin_init');

function property_admin_init(){
	register_setting( 'property_data_options', 'property_options', 'property_options_validate' );
	add_settings_section('property_main', 'Property Data', 'property_settings_section_text', 'property-data-settings');
	add_settings_field('property_title', 'Property Text Input', 'property_setting_string', 'property-data-settings', 'property_main');
}

function property_settings_section_text() {

	echo '<p>Set up your persistent Property Data here</p>';

}

function property_setting_string($prop_id) {

	$states_util = array('AL'=>"Alabama",
                'AK'=>"Alaska",
                'AZ'=>"Arizona",
                'AR'=>"Arkansas",
                'CA'=>"California",
                'CO'=>"Colorado",
                'CT'=>"Connecticut",
                'DE'=>"Delaware",
                'DC'=>"District Of Columbia",
                'FL'=>"Florida",
                'GA'=>"Georgia",
                'HI'=>"Hawaii",
                'ID'=>"Idaho",
                'IL'=>"Illinois",
                'IN'=>"Indiana",
                'IA'=>"Iowa",
                'KS'=>"Kansas",
                'KY'=>"Kentucky",
                'LA'=>"Louisiana",
                'ME'=>"Maine",
                'MD'=>"Maryland",
                'MA'=>"Massachusetts",
                'MI'=>"Michigan",
                'MN'=>"Minnesota",
                'MS'=>"Mississippi",
                'MO'=>"Missouri",
                'MT'=>"Montana",
                'NE'=>"Nebraska",
                'NV'=>"Nevada",
                'NH'=>"New Hampshire",
                'NJ'=>"New Jersey",
                'NM'=>"New Mexico",
                'NY'=>"New York",
                'NC'=>"North Carolina",
                'ND'=>"North Dakota",
                'OH'=>"Ohio",
                'OK'=>"Oklahoma",
                'OR'=>"Oregon",
                'PA'=>"Pennsylvania",
                'RI'=>"Rhode Island",
                'SC'=>"South Carolina",
                'SD'=>"South Dakota",
                'TN'=>"Tennessee",
                'TX'=>"Texas",
                'UT'=>"Utah",
                'VT'=>"Vermont",
                'VA'=>"Virginia",
                'WA'=>"Washington",
                'WV'=>"West Virginia",
                'WI'=>"Wisconsin",
                'WY'=>"Wyoming");
		/*********************************************************************/
		//start tlc


	$property_addr1 = get_option('property_addr1');
	$property_addr2 = get_option('property_addr2');
	$property_city = get_option('property_city');
	$property_state = get_option('property_state');
	$property_zip = get_option('property_zip');
	$property_type = get_option('property_type');
	$property_title = get_option('property_title');
	$cur_property_manager = get_option('property_manager');
	$number_of_units = get_option('number_of_units');

	$property_addr1 = get_post_meta('fgpsn_property_address_1');
	$property_addr2 = get_post_meta('fgpsn_property_address_2');
	$property_city = get_post_meta('fgpsn_property_city');
	$property_state = get_post_meta('fgpsn_property_state');
	$property_zip = get_post_meta('fgpsn_property_zip');
	$property_type = get_post_meta('fgpsn_property_type');
	$property_title = get_post_meta('fgpsn_property_title');
	$cur_property_manager = get_post_meta('fgpsn_property_manager');
	$number_of_units = get_post_meta('fgpsn_number_of_units');


	echo "<STYLE>
        .tabs input[type=radio] {
            position: absolute;
            top: -9999px;
            left: -9999px;
        }
        .tabs {

          float: left;
          list-style: none;
          position: relative;
          padding: 0;
          margin: 75px auto;
        }
        .tabs li{
          float: left;
        }
        .tabs label {
            display: inline;
            float: left;
            padding: 10px 20px;
            border-radius: 2px 2px 0 0;

           // font-size: 18px;
           // font-weight: normal;

            background: rgba(255,255,255,0.2);
            cursor: pointer;
            position: relative;

            top: 3px;

        }
        .tabs label:hover {
          background: rgba(255,255,255,0.5);
          top: 0;
        }

        [id^=tab]:checked + label {
          background: #08C;
          color: white;
          top: 0;
        }

        [id^=tab]:checked ~ [id^=tab-content] {
            display: block;
        }
        .tab-content{
          z-index: 2;
          display: none;
          text-align: left;
          width: 100%;
          //font-size: 20px;
          line-height: 140%;
          padding-top: 10px;
          //background: #08C;
          padding: 15px;

          position: absolute;
          top: 53px;
          left: 0;
          box-sizing: border-box;

      }



  </STYLE><DIV><ul class='tabs'><li>
             <input type='radio' checked name='tabs' id='tab1'>
             <label for='tab1'>Here Data</label>
             <div id='tab-content1' class='tab-content animated fadeIn'>

	<TABLE>
		<TR><TH colspan=3>Property Data:</TH></TR>


			<TR><TH colspan=2><INPUT TYPE='button' VALUE = 'Export to Excel' ></TD></TR>


		<TR><TH>Property Web Status:</TH>
			<TD><A HREF='view_property.php?set_access=1&selected_property=108'>Access Allowed</A></TD>
			</TR>

		<TR><TH>Property Title:</TH>

			<TD><input id='property_title' name='property_data_options[property_title]' size='40' type='text' value='{$property_title}' /></TD>

		</TR>
		<TR>
			<TH>Address 1</TH>
			<TD><input id='property_addr1' name='property_data_options[property_addr1]' size='40' type='text' value='{$property_addr1}' /></TD>
		</TR>
		<TR>
		<TH>Address 2*</TH>
		<TD><input id='property_addr2' name='property_data_options[property_addr2]' size='40' type='text' value='{$property_addr2}' /></TD></TR>

		<TR>
			<TH>City*</TH>
			<TD ><input id='property_city' name='property_data_options[property_city]' size='40' type='text' value='{$property_city}' /></TD>
		</TR>
			<TH>State/Province*</TH><TD><SELECT id='property_state' name='property_data_options[property_state]' />";

				$this_count = count($states_util);

				echo "<OPTION value=''> - Here -" . $this_count . " </OPTION>\n";

				foreach ($states_util as $key => $value) {

						echo "<OPTION value='" . $key . "'";
						if ($property_state == $key) {
							echo " selected";
						}

						echo ">" . $value . "</OPTION>\n";

				}
			echo "</SELECT></TD></TR>

		<TR>

			<Th>Zip Code:</TH>
			<TD ><input id='property_zip' name='property_data_options[property_zip]' size='5' type='text' value='{$property_zip}' /></TD>

		</TR>

		<TR>
			<TH>Property Type:</TH>
			<TD><SELECT id='property_type' name='property_data_options[property_type]' />

			<OPTION value=''> - Select - </OPTION>\n
			<OPTION value='Condominium'";

			if ($property_type == 'Condominium') {
				echo " selected";
			}

			echo "> Condominium </OPTION>\n
			<OPTION value='Rental Property'";

			if ($property_type == 'Rental Property') {
				echo " selected";
			}


			echo "> Rental Property </OPTION>\n
			<OPTION value='Commercial'";

			if ($property_type == 'Commercial') {
				echo " selected";
			}


			echo "> Commercial </OPTION>\n
			<OPTION value='HOA'";

			if ($property_type == 'HOA') {
				echo " selected";
			}


			echo "> HOA </OPTION>\n
			<OPTION value='Retirement Community'";

			if ($property_type == 'Retirement Community') {
				echo " selected";
			}


			echo "> Retirement Community </OPTION>\n

		</SELECT></TD>

	</TR>
	<TR>

		<TH>Property Manager: </TH>
		<TD ><SELECT id='property_manager' name='property_data_options[property_manager]' />
				<OPTION VALUE=''> - Select - </OPTION>";

		$prop_managers = new WP_User_Query( array( 'role' => 'property_manager' ) );
		if ( ! empty( $prop_managers->results ) ) {
			foreach ( $prop_managers->results as $prop_manager ) {

				echo "<OPTION VALUE='" . $prop_manager->ID . "'";


					if ($cur_property_manager == $prop_manager->ID) {

						$manager_email = $prop_manager->user_email;
						$manager_phone = $prop_manager->client_phone;
						echo " selected";

					}


			echo ">" .  $prop_manager->display_name . " Title: " . $check_role . "</OPTION>";
			}


		echo "</SELECT>

		<BR>
				Cell: " .  $manager_phone . "<BR>
			   Phone: (617) 316-3313<BR>
			   Fax: (617) 316-3363<BR>
		   Email: " .  $manager_email;

		} else {
		   			echo '<OPTION VALUE="">No users found.</Option>';
		}


		  echo "</TD></TR>

	<TR>
		<TH>Assigned Staff: </TH>
		<TD ><SELECT id='desk_staff' name='property_data_options[desk_staff][]' multiple=multiple />
				<OPTION VALUE=''> - Select - </OPTION>";

	$args = array(
       'post_type' => 'contact_data',
       'tax_query' => array(
                   array(
                       'taxonomy' => 'contact_data_types',
                       'field' => 'slug',
                       'terms' => 'desk-staff'
                    )
                )
        );
        $posts = get_posts($args);


		if(is_array($posts)) :  foreach($posts as $post) :

			echo "<OPTION VALUE='" . $post->ID . "'";


			if ($cur_property_manager == $post->ID) {

				$emp_phone = get_post_meta($cur_property_manager, 'emp_phone', true);
				$emp_email = get_post_meta($cur_property_manager, 'emp_email', true);
				echo " selected";

			}


			echo ">" .  $post->post_title . "</OPTION>";

		endforeach; endif;

		echo "</SELECT></TD></TR>

		<TR><TD>Dennis Gannon</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email: N/A
							<BR><A HREF=''>Edit</A></TD></TR>

		<TR ><TD>Tom McMullin</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email:
							<BR><A HREF=''>Edit</A></TD></TR>

		<TR ><TD>cliff snider</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email:
							<BR><A HREF=''>Edit</A></TD></TR>

		<TR ><TD>Stephen Furqueron</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email:
							<BR><A HREF=''>Edit</A></TD></TR>


			<TR><TH>Superintendent:</TH>

					<TD >Adam Barbour (<A HREF=''>Edit</A>)<BR>Phone: (617) 592-2349<BR></TD></TR>
					<TR><TH COLSPAN=2>Superintendent Notes:</TH></TR>
					<TR><TD COLSPAN=2>
				Please call Adam Barbour for any emergency calls. Cell phone (617)592-2349.<BR>(<A HREF=''>Edit</A>)</TD>

				</TR>

				<TR ><TH COLSPAN=2>Additional Notes:</TH></TR>

				<TR ><TD COLSPAN=2  >
				Property has one elevator in lobby.  Certificate of Inspection expires February 1, 2014 and car identification is 1-P-2605.<BR>(<A HREF=''>Edit</A>)</TD></TR>

				<TR ><TH COLSPAN=2>Trustees</TH></TR>";

	$args = array(
		 'posts_per_page' => -1,
		 'orderby' => 'rand',
		 'post_type' => 'contact_data',
		 'contact_data_types' => 'trustee',
		 'post_status' => 'publish'
	);
	$show_trustees = get_posts( $args );

	if(is_array($show_trustees)) :  foreach($show_trustees as $show_trustee) :

	echo "<TR><TD>" . $show_trustee->post_title . "</TD><TD>Contact Information:<BR></TD></TR>";

	endforeach; endif;


	echo "<TR>

		<TH>Number of Units</TH>
		<TD><input id='number_of_units' name='property_data_options[number_of_units]' size='3' type='text' value='{$number_of_units}' /></TD>

		</TR>

	</TABLE></div>
           </li>

           <li>
             <input type='radio' name='tabs' id='tab2'>
             <label for='tab2'>Property Vendors</label>
             <div id='tab-content2' class='tab-content animated fadeIn'>";

	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);


	echo "<TABLE><TR><TH COLSPAN=2>Add New Specification Type: <INPUT TYPE=text NAME=property_data_options[fg_property_spec_type]></TH></TR>";


	$terms = get_terms("property_vendor_services", $args);
	$count = count($terms);
	if ( $count > 0 ){

		foreach($terms as $term) {
			echo "<TR><TH>" .  $term->name . "</TH>";

			$cur_term = $term->slug;

			$all_vendors_args = array(
						'post_type'=>'property_vendor',
						'numberposts'=>-1,
						'orderby'=>'post_title',
						'order'=>'ASC',
						'taxonomy'=>'property_vendor_services',
						'term'=>$term->name
					);

					$vendors = get_posts($all_vendors_args);

		$check_cur = get_option($cur_term);

		?>
		<TD><select name="property_data_options['<?php echo $cur_term; ?>']" id="property_data_options['<?php echo $cur_term; ?>']">
		<option value="0"> - Select - </option>
		<?php foreach($vendors as $vendor) : ?>

		<option value="<?php echo $vendor->ID; ?>"><?php echo $vendor->post_title; ?> Slug: <?php echo $check_cur; ?></option>


		<?php endforeach; ?>
		</select></TD></TR>

		<?PHP }

		
	echo "</TABLE></DIV></LI>";

	 } else {
		 echo "</TABLE></DIV></LI>"; 
	 }
         echo "<li>
             <input type='radio' name='tabs' id='tab3'>
             <label for='tab3'>Property Specifications</label>
             <div id='tab-content3' class='tab-content animated fadeIn'>";

	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 0);


	$terms = get_terms("property_specifications", $args);
	 $count = count($terms);
	 if ( $count > 0 ){

	echo "<TABLE>";

		foreach($terms as $term) {
			echo "<TR><TH>" .  $term->name . "</TH>";

			$specification = get_post_meta($ID, $term->slug, TRUE);

			$spec_content = get_option('property_' . $term->slug);

			echo "<TD>" .  $specification . "</TD><TD><input id='property_" . $term->slug . "' name='property_data_options[property_" . $term->slug . "]' size='3' type='text' value='{$spec_content}' /></TD></TR>";


		}
		echo "</TABLE></div>";

	}

	echo "</div>
           </li>";


echo "</ul></DIV>";


}

function property_options_validate($input) {

	$stopper = "<H1>Line 1309</H1>";
	//return $stopper;
		//adds a new specification type
		if ( !empty( $_POST['property_data_options']['fg_property_spec_type'] ) ) {

			if ( wp_insert_term(
			  $_POST['property_data_options']['fg_property_spec_type'], // the term
			  'property_vendor_services', // the taxonomy
			  array(
				'description'=> '',

				'parent'=> 42
			  )
			) ) {

				echo "<H1>GOOD</H1>";


			} else {

			echo "<H1>NOT GOOD</H1>";
			}
		}
	/*
	need to have an option for each vendor service type

	foreach vendor service { update_option( 'vendor-service-slug') }


	*/


	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);

	$terms = get_terms("property_vendor_services", $args);
	$count = count($terms);
	if ( $count > 0 ){
		echo "<H1>Line 1349</H1>";
		foreach($terms as $term) {
			echo "<TR><TH>LINE 1349 " .  $term->name . "</TH>";

			$all_vendors_args = array(
						'post_type'=>'property_vendor',
						'numberposts'=>-1,
						'orderby'=>'post_title',
						'order'=>'ASC',
						'taxonomy'=>'property_vendor_services',
						'term'=>$term->name
					);

					$vendors = get_posts($all_vendors_args);


			$cur_option = $_POST['property_data_options'][$term->slug];
			echo "<TR><TH>" .  $cur_option . "</TH>";
			update_option($term->slug, $cur_option);


	 	}

	}







/**********************************************************************************/
	$property_title = $_POST['property_data_options']['property_title'];
	update_option('property_title', $property_title);

	$property_type = $_POST['property_data_options']['property_type'];
	update_option('property_type', $property_type);

	$property_manager = $_POST['property_data_options']['property_manager'];
	echo "<H1>Line 1293  - " . $property_manager . "</H1>";
	update_option('property_manager', $property_manager);

	$number_of_units = $_POST['property_data_options']['number_of_units'];
	update_option('number_of_units', $number_of_units);

	$property_state = $_POST['property_data_options']['property_state'];
	update_option('property_state', $property_state);

	$property_addr1 = $_POST['property_data_options']['property_addr1'];
	update_option('property_addr1', $property_addr1);

	$property_addr2 = $_POST['property_data_options']['property_addr2'];
	update_option('property_addr2', $property_addr2);

	$property_city = $_POST['property_data_options']['property_city'];
	update_option('property_city', $property_city);

	$property_zip = $_POST['property_data_options']['property_zip'];
	update_option('property_zip', $property_zip);


/*
		$args = array(
			'hide_empty'  		=> 0,
			'show_count'         => 1,
			'hierarchical'  => true,
		    'parent'      => 0);


		$terms = get_terms("property_vendor_services", $args);
		 $count = count($terms);
		 if ( $count > 0 ){
			foreach($terms as $term) {
				$property_ . $term->slug = $_POST['property_data_options']['property_' . $term->slug];
				update_option('property_' . $term->slug, $property_ . $term->slug);
			}

	 }
*/


	$property_title = get_option('property_title');
	$property_title = trim($property_title);
	if(!preg_match('/^[a-z0-9]{32}$/i', $property_title)) {
	$property_title = '';
	}
	//return $property_title;

}

//add shrotcode for creating a Property Data Page
/*
 * deprecated - creating temple page for the post types
 * 
 * 
 * 
 * and adding the pages to the menu manually using tempAddPage()
 * */
function get_property_data( $atts ){

	$property_data = array();
	$property_data['property_title'] = get_option('property_title');
	$property_data['property_type'] = get_option('property_type');
	$property_data['property_manager'] = get_option('property_manager');
	$property_data['number_of_units'] = get_option('number_of_units');

	$property_data['property_state'] = get_option('property_state');
	$property_data['property_addr1'] = get_option('property_addr1');
	$property_data['property_addr2'] = get_option('property_addr2');
	$property_data['property_city'] = get_option('property_city');


	$disp_data = "<script>

	jQuery(document).ready(function() {
	jQuery( '#fg-vendors-accordion' ).accordion({
	heightStyle: 'content'
	});
	});
	</script>

	/service/xml/
<H3><A HREF='http://razor-cloud.com/xml/rest/product/143?pos=8508a7e6ce43e091&test=true'>Property Data</A></H3>
	<div id='fg-vendors-accordion'>

	<H3><A HREF='http://razor-cloud.com/xml/rest/product/143?pos=8508a7e6ce43e091&test=true'>Property Data</A></H3>
	<DIV ID='property_data_div'>

			<DIV ID='property_field_label'><H4>Property Title:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_title'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>
<H3>Property Specifications</H3>
	<DIV ID='property_data_div'>

			<DIV ID='property_field_label'><H4>Property Title:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_title'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>

<H3>Property Vendors</H3>
	<DIV ID='property_data_div'>";


	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);

	    $terms = get_terms("property_vendor_services", $args);
		$count = count($terms);
		if ( $count > 0 ){

			foreach($terms as $term) {
				$disp_data .= "

			<DIV ID='property_field_label'><H4>" .  $term->name . "</H4> </DIV>";

					$all_vendors_args = array(
								'post_type'=>'property_vendor',
								'numberposts'=>-1,
								'orderby'=>'post_title',
								'order'=>'ASC',
								'taxonomy'=>'property_vendor_services',
								'term'=>$term->name
							);

							$vendors = get_posts($all_vendors_args);

		//$property_ . $term->slug = get_option('property_' . $term->slug);
		$property_cur_option = get_option('property_' . $term->slug);

		foreach($vendors as $vendor) :

				$disp_data .= "

			<DIV ID='property_field_content'><H4>" .  $vendor->post_title . " - " . $term->slug . "</H4></DIV>
			<DIV style='clear: both;'></DIV>";


		 endforeach;

		}
	}




$disp_data .= "

			<DIV ID='property_field_label'><H4>Property Manager:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_manager'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Property Type:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_type'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Number of Units:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['number_of_units'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 1:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>Address line 2:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr2'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>City:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_city'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>

			<DIV ID='property_field_label'><H4>State:</H4> </DIV>

			<DIV ID='property_field_content'><H4>" . $property_data['property_addr1'] . "</H4></DIV>
			<DIV style='clear: both;'></DIV>
</DIV>
</DIV>	";

	return $disp_data;
}
add_shortcode( 'property_data', 'get_property_data' );

function get_property_contacts( $atts ){


		$contact_types = get_terms('contact_data_types');
		$directory_display = "";
		foreach ( $contact_types as $contact_type ) {

			$contact_list = "";
			$args = array(
				'tax_query' => array(
					array(
						"taxonomy" => "contact_data_types",
						"field" => "id",
						"terms" => $contact_type->term_id
					)
				),
				'posts_per_page'  => -1,
				'numberposts'     => -1,
				'post_type'       => 'contact_data',
				'post_status'     => 'publish',
				'suppress_filters' => true );
			$posts = get_posts($args);
			$directory_display .= "<DIV><H3>" . $contact_type->name . "s</H3>
			<TABLE ID='property_data_div'>
				<thead><TR><TH>Name</TH><TH>Unit</TH><TH>Phone</TH><TH>Email:</TH></THEAD>
				<TBODY>";

			if(is_array($posts)) :  foreach($posts as $post) :

				$contact_first_name = get_post_meta($post->ID, 'contact_first_name', true);
				$contact_last_name = get_post_meta($post->ID, 'contact_last_name', true);
				$emp_phone = get_post_meta($post->ID, 'emp_phone', true);
				$emp_email = get_post_meta($post->ID, 'emp_email', true);

				$client_phone = get_post_meta($post->ID, 'client_phone', true);
				$client_email = get_post_meta($post->ID, 'client_email', true);
				$client_unit = get_post_meta($post->ID, 'contact_unit_number', true);


				$directory_display .= "<TR><TD>" . $contact_first_name . " " . $contact_last_name . "</TD>
				<TD>" . $client_unit . "</TD>
				<TD>" . $client_phone . "</TD>
				<TD>" . $client_email . "</TD>
				</TR>";

			endforeach; endif;

			$directory_display .= "</TBODY></Table>";

     	}

	return $directory_display;
}
add_shortcode( 'property_contacts', 'get_property_contacts' );
//end depricated short codes

//start menu set up

function tempAddPage() {
	global $wpdb;
	/*first see if the page exists*/
	$fixed_page_args = array(
		'post_type'        => 'page',
		'post_mime_type'   => '',
		'post_parent'      => 0,
		'post_status'      => 'private',
		'suppress_filters' => true );

	//$fixed_pages = get_posts($fixed_page_args);
	foreach ( $fixed_pages as $post ) {
		/*echo "<H1>Published: " . $post->post_title . "</H1>
		<H3>If it is publihsed, make if private</H3>";*/
		 $set_fixed_page_status = array(
		      'ID' => $post->ID,
		      'post_status' => 'publish'
		  );

 		//wp_update_post( $set_fixed_page_status );
	}

	$menu_exists = wp_get_nav_menu_object( 'PSN Default' );

	// If it doesn't exist, let's create it.
	if( !$menu_exists){
		
		$menu_id = wp_create_nav_menu( 'PSN Default' );
		
		$menu_url = get_site_url() . '/contact_data/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Contact Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));
			
		$menu_url = get_site_url() . '/property_data/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Property Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));
			
		$menu_url = get_site_url() . '/unit_data/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Unit Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));			

		$menu_url = get_site_url() . '/property_vendor/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Vendor Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));
			
		$menu_url = get_site_url() . '/property_comm/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Property Communications'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));
			
		$menu_url = get_site_url() . '/property_doc/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Property Documents'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/maintenance_requests/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Maintenance Requests'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));			

		echo "<H3>1147 - " . $wpdb->last_query . "</H3>";
		} else {
		if (!is_admin()) {
		global $wpdb;

		$tablename = $wpdb->prefix.'terms'; // use always table prefix
		$menu_name = 'Top Navigation'; // menu name
		$menu_id = $wpdb->get_results(
			"
			SELECT term_id
			FROM ".$tablename." 
			WHERE name= '".$menu_name."'
			"
		);

		// results in array 
		foreach($menu_id as $menu):
			//echo "<H1>" .  $menu->term_id . "</H1>";
			$this_id = $menu->term_id;
		endforeach; 

		/* Set up default menu items
		$cont_us_page = get_page_by_path( 'contact-us' );
		$cont_us_page = get_permalink( $cont_us_page );

		$prop_vend_page = get_page_by_path( 'property-vendors' );
		$prop_vend_page = get_permalink( $prop_vend_page );
		
		$prop_data_page = get_page_by_path( 'property-data' );
		$prop_data_page = get_permalink( $prop_data_page );
		
		$prop_docs_page = get_page_by_path( 'property-documents' );
		$prop_docs_page = get_permalink( $prop_docs_page );

		$unit_data_page = get_page_by_path( 'unit-data' );
		$unit_data_page = get_permalink( $unit_data_page );

		$contacts_page = get_page_by_path( 'property-vendors' );
		$contacts_page = get_permalink( $contacts_page );



	$menu_items = wp_get_nav_menu_items($menu_exists->term_id);
	
		foreach ( $menu_items as $key => $menu_item ) {
			$menu_item_title[] = $menu_item->title;
		}


		if (!in_array('Property Vendors', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Property Vendors'),
				'menu-item-url' => home_url( '/' . $prop_vend_page . '/' ),
				'menu-item-status' => 'publish'));
				
		 }
		if (!in_array('Contact Us', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Contact Us'),
				'menu-item-url' => home_url( '/' . $cont_us_page . '/'  ),
				'menu-item-status' => 'publish'));
		  
		 }
		 
		 if (!in_array('Property Data', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Property Data'),
				'menu-item-url' => home_url( '/' . $prop_data_page . '/' ),
				'menu-item-status' => 'publish'));
				
		 }
		if (!in_array('Property Documents', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Property Documents'),
				'menu-item-url' => home_url( '/' . $prop_docs_page . '/'  ),
				'menu-item-status' => 'publish'));
		  
		 }

			if (!in_array('Unit Data', $menu_item_title)) {
				wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Unit Data'),
				'menu-item-url' => home_url( '/' . $unit_data_page . '/' ),
				'menu-item-status' => 'publish'));
				
			}
			if (!in_array('Contacts', $menu_item_title)) {
				wp_update_nav_menu_item($menu_exists->term_id, 0, array(
					'menu-item-title' =>  __('Contacts'),
					'menu-item-url' => home_url( '/' . $contacts_page . '/'  ),
					'menu-item-status' => 'publish'));
				  
			}
			* * */
		}

	}

}

add_action('admin_init', 'tempAddPage');

//set default content for some pages

//add_filter( 'cpt_default_cantent', 'my_editor_content', 10, 2 );

function my_editor_content( $content, $post ) {

    switch( $post->post_type ) {
        case 'unit_data':
            $content = '<P>The Unit Data page can be used to display any of the data from the Units edit screen in the admin area. This page, like anyother, can be made in whole or in part private so that only the resident, owner, or other permitted user can view it.</P>';
        break;
       
    }

    return $content;
}
//add_filter( 'default_content', 'cpt_default_content' );
//end menu set up


/* document post type functionality is now in the plugin
most-recent-documents-mod */
//include("inclDocumentPostType.php");

/* property post type functionality is now in the Settings page
under Property Setup */

/* add communication emails to post publish */
add_action( 'add_meta_boxes', 'fg_email_posts' );
add_action( 'save_post', 'fg_email_posts_save' );

function fg_email_posts() {

	add_meta_box(
		'fg_email_posts',
		__( 'Contact List', 'myplugin_textdomain' ),
		'fg_email_posts_content',
		'post',
		'normal',
		'high'
	);

}

function fg_email_posts_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'fg_email_posts_content_nonce' );
	echo '<FIELDSET>';

		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'occupant'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_occupant_id">Property Occupants: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_occupant_id" name="unit_occupant_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;


		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'owner'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_owner_id">Property Owners: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_owner_id" name="unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;


		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'trustee'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_owner_id">Property Trustees: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_owner_id" name="unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;



		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
                    array(
                        'taxonomy' => 'contact_data_types',
                        'field' => 'slug',
                        'terms' => 'employee'
                    )
                )
        );

     $my_query = new WP_Query( $args );
     if($my_query->have_posts()) :

     	echo '<P style="position: relative; display: inline; float: left;"><label for="unit_owner_id">Property Staff: </label><BR>

     	<SELECT MULTIPLE SIZE=10 id="unit_owner_id" name="unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              /* store and retrieve contact_data post ID in the post_meta unit_owner_id */

              $contact_id = get_the_ID();
              $contact_first_name = get_post_meta(get_the_ID(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'contact_last_name', true);


              echo '<OPTION value="' . $contact_id . '">' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';



          endwhile;
          echo '</SELECT></P>';
          endif;


          echo '</FIELDSET>';



}



function fg_email_posts_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fg_email_posts_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$emp_department = $_POST['emp_department'];
	$emp_title = $_POST['emp_title'];
	$emp_phone = $_POST['emp_phone'];
	$emp_email = $_POST['emp_email'];
	$emp_cell = $_POST['emp_cell'];


	// Update the post into the database
	// wp_update_post( $my_post );


	update_post_meta( $post_id, 'emp_department', $emp_department );
	update_post_meta( $post_id, 'emp_title', $emp_title );
	update_post_meta( $post_id, 'emp_phone', $emp_phone );
	update_post_meta( $post_id, 'emp_email', $emp_email );
	update_post_meta( $post_id, 'emp_cell', $emp_cell );
}



	global $current_user;
	get_currentuserinfo();

	$test_var = implode (', ', $current_user->roles);

	if ($test_var == 'property_manager') {



	}



 if ($test_var == 'editor' && is_admin() ) {

	function edit_admin_menus() {
		global $menu;
		global $submenu;

	$role = get_role( 'editor' );

    // This only works, because it accesses the class instance.
    // would allow the author to edit others' posts for current theme only
    $role->add_cap( 'manage_options' );
		add_menu_page('Property Data', 'Property Data', 'publish_pages', 'options-general.php?page=property-data-settings', '', '', 1);
		remove_menu_page('index.php');
		remove_menu_page('options-general.php');
		remove_menu_page('upload.php');
		remove_menu_page('edit-comments.php');
		remove_menu_page('tools.php');
		remove_menu_page('admin.php', '?page=s2');
		remove_submenu_page('edit.php?post_type=acf');
		$menu[5][0] = 'Communications'; // Change Posts to Communications
		$menu[6][0] = 'Communications'; // Change Posts to Communications
		$submenu['edit.php'][5][0] = 'All Communications';


	}
	add_action( 'admin_menu', 'edit_admin_menus' );
 }


function implement_ajax() {
if(isset($_POST['main_catid']))
			{

/* gets the terms - I need to send the terms and get the documents
		$args = array(
			'post_type'        => 'property_doc',
			'taxonomy' => 'property_document_types',
			'include' => $document_types,
			'hide_empty'  		=> 1,
			'show_count'         => 1,
			'hierarchical'  => true,
			'order' => ASC);

			$terms = get_terms("property_document_types", $args);

			$count = count($terms);




			$option .= '<TABLE name="sub_cat" id="sub_cat"><THEAD><TR><TH>1741 Title</TH><TH>Date</TH><TH>View</TH></TR></THEAD>
			  <TBODY>';
		 	foreach ( $terms as $term ) {
				$option .= "<TR><TD>" . $term->name . "</TD>
				<TD>Most Recent:" . get_the_time('D j, Y', $terms->ID) . "</TD>
				<TD><A HREF='"  . get_bloginfo('url') . "/property_document_types/" . $term->slug . "/'>" . $term->name . " (" . $term->count . ")</A></TD>
				</TR>";


				$option .= "<TR><TD><a href='" . get_permalink($term2->ID) . "'>" . $term->slug . "</A></TD>

								<TD><A HREF='" . $cur_file . "' target='_blank'>View</A></TD></TR>
								<TR><TD colspan=2><TABLE name='sub_cat' id='sub_cat'><THEAD><TR><TH>62 Title</TH><TH>Date</TH><TH>View</TH></TR></THEAD>
							  <TBODY>
</TBODY></TABLE></TD></TR>";




		 	}

 		$option  .= '</TBODY></TABLE>';
 		echo $option;
			$categories=  get_categories('child_of='.$_POST['main_catid'].'&hide_empty=0');
			$option .= '<table id="example"><thead><TR><th>Title<th>';
			  foreach ($categories as $cat) {
				$option .= '<th id="cat_id_'.$cat->term_id.'">ID';
				$option .= $cat->cat_name;
				$option .= ' ('.$cat->category_count.')';
				$option .= '</th>';
			  }
			  //echo $option . '<tr></table>';
			die();


	end working ajax cats -
	about to begin ajax docs */

	/* BEGIN AJAX DOCS!!!!!!!!!!!!!!!!! */


			//$original_query = $wp_query;
			$wp_query = null;
			$wp_query = new WP_Query( array(
				'post_type' => 'property_doc',
				'include' => $_POST['main_catid'],
				'tax_query' => array(
					array(
						'taxonomy' => 'property_document_types',
						'field' => 'id',
						'terms' => $_POST['main_catid'] //the taxonomy terms I'd like to dynamically query

						 ),
					),
				'orderby' => 'title',
				'order' => 'ASC'
				) );

				echo '<TABLE name="sub_cat" id="sub_cat"><THEAD><TR><TH>' . $_POST[main_catid] . '1788 Title</TH><TH>Date</TH><TH>View</TH></TR></THEAD>
			  <TBODY>';

				if ( $wp_query->have_posts() ) {

					while ( $wp_query->have_posts() ) :  $wp_query->the_post();
						echo '<TR><TD><a href="' . get_permalink( $post->ID) . '" >';
						$doc_url = get_post_meta($post->ID, 'property_doc_file', true);
						if (is_array($doc_url)) {
							if (!$hideposttitle) echo $post->title .'THETITLE</A></TD><TD>THE DATE</TD><TD><A HREF="' . $doc_url[url] . '" title="View" target="_blank">View</A></TD></TR>';
						} else {
							if (!$hideposttitle) echo $post->title .'THETITLE</A></TD><TD>THE DATE</TD></A></TD><TD><A HREF="' . $doc_url . '" title="View" target="_blank">View</A></TD></TR>';
						}

					endwhile;

			 		//echo $post_list;
				} else {

echo "<H1>1809</H1>";


				}//endif;

				echo '</TBODY></TABLE>';
 				//echo $option;






	} // end if
}
add_action('wp_ajax_my_special_ajax_call', 'implement_ajax');
add_action('wp_ajax_nopriv_my_special_ajax_call', 'implement_ajax');//for users that are not logged in.

if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h2 class="widgettitle">',
		'after_title' => '</h2>',
	));
}


// update the '51' to the ID of your form
function populate_posts($form){

    foreach($form['fields'] as &$field){

        if($field['type'] != 'select' || strpos($field['cssClass'], 'populate-posts') === false)
            continue;

        // you can add additional parameters here to alter the posts that are retreieved
        // more info: http://codex.wordpress.org/Template_Tags/get_posts
        $posts = get_posts('post_type=contact_data');

        // update 'Select a Post' to whatever you'd like the instructive option to be
        $choices = array(array('text' => 'Select a Post', 'value' => ' '));

        foreach($posts as $post){
            $choices[] = array('text' => $post->post_title, 'value' => $post->post_title);
        }

        $field['choices'] = $choices;

    }

    return $form;
}
add_filter('gform_pre_render_4', 'populate_posts');

add_filter( 'tiny_mce_before_init', 'my_custom_tinymce' );

function my_custom_tinymce( $init ) {
	$init['theme_advanced_buttons2_add_before'] = 'styleselect';
	$init['theme_advanced_styles'] = 'Button=button,Callout Box=mission';
	return $init;
}


add_action("gform_after_submission_7", "after_submission", 10, 2);
function fg_save_user_profile( $post_id ) {

	/*
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['contact_first_name_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	*/

	$contact_first_name = $_POST['contact_first_name'];
	$contact_last_name = $_POST['contact_last_name'];
	$client_phone = $_POST['client_phone'];
	$client_email = $_POST['client_email'];
	$client_cell = $_POST['client_cell'];
	$client_addr1 = $_POST['client_addr1'];
	$client_addr2 = $_POST['client_addr2'];
	$client_city = $_POST['client_city'];
	$client_zip = $_POST['client_zip'];


	$post_title = $contact_first_name . " " . $contact_last_name;

	$user_id = username_exists( $contact_first_name );
	if ( !$user_id && email_exists($client_email) == false ) {

		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $contact_first_name, $random_password, $client_email );

		update_user_meta( $user_id, 'contact_data_id', $contact_data_id );
		update_user_meta( $user_id, 'contact_first_name', $contact_first_name );
		update_user_meta( $user_id, 'contact_last_name', $contact_last_name );
		update_user_meta( $user_id, 'client_phone', $client_phone );
		update_user_meta( $user_id, 'client_email', $client_email );
		update_user_meta( $user_id, 'client_cell', $client_cell );
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );


	} else {
/*
		update_user_meta( $user_id, 'contact_data_id', $contact_data_id );
		update_user_meta( $user_id, 'contact_last_name', $contact_last_name );
		update_user_meta( $user_id, 'client_phone', $client_phone );
		update_user_meta( $user_id, 'client_email', $client_email );
		update_user_meta( $user_id, 'client_cell', $client_cell );

		$random_password = __('User already exists.  Password inherited.');
	*/
	}

	// Update the post into the database
	// wp_update_post( $my_post );


	update_post_meta( $post_id, 'contact_first_name', $contact_first_name );
	update_post_meta( $post_id, 'contact_last_name', $contact_last_name );
	update_post_meta( $post_id, 'client_phone', $client_phone );
	update_post_meta( $post_id, 'client_email', $client_email );
	update_post_meta( $post_id, 'client_cell', $client_cell );
	update_post_meta( $client_addr1, 'client_addr1', $client_addr1 );
	update_post_meta( $client_addr2, 'client_addr2', $client_addr2 );
	update_post_meta( $client_city, 'client_city', $client_city );
	update_post_meta( $client_zip, 'client_zip', $client_zip );



	//get user id where user_meta_key = contact_data_id and user_meta_value = $post_id
	$args = array(
		'meta_key'     => 'contact_data_id',
		'meta_value'   => $post_id,

	 );

	$blogusers = get_users($args);
	foreach ($blogusers as $user) {
		echo '<li>' . $user->user_email . '</li>';
    }

	if ( ! wp_is_post_revision( $post_id ) ){

		$my_post = array();
		$my_post['ID'] = $post_id;
		$my_post['post_title'] = $post_title;

		// unhook this function so it doesn't loop infinitely
		remove_action('save_post', 'contact_first_name_save');

		// update the post, which calls save_post again
		wp_update_post( $my_post );

		// re-hook this function
		add_action('save_post', 'contact_first_name_save');

	}

}


/************************************************************************/
/* gform functions */
add_filter("gform_field_value_contact_first_name", "update_contact_first_name");
function update_contact_first_name($value){

    global $current_user;
    get_currentuserinfo();

    $user_fname = $current_user->user_firstname;
	return $user_fname;
}

add_filter("gform_field_value_contact_last_name", "update_contact_last_name");
function update_contact_last_name($value){

    global $current_user;
    get_currentuserinfo();

    $user_lname = $current_user->user_lastname;
	return $user_lname;
}
add_filter("gform_field_value_client_phone", "update_client_phone");
function update_client_phone($value){

    global $current_user;
    get_currentuserinfo();

    $client_phone = $client_cell = get_user_meta($current_user->ID, 'client_phone', true);
	return $client_phone;
}
add_filter("gform_field_value_client_cell", "update_client_cell");
function update_client_cell($value){

    global $current_user;
    get_currentuserinfo();

    $client_cell = get_user_meta($current_user->ID, 'client_cell', true);
	return $client_cell;
}

add_filter("gform_field_value_fg_contact_mail_addr1", "update_fg_contact_mail_addr1");
function update_fg_contact_mail_addr1($value){

    global $current_user;
    get_currentuserinfo();

    $fg_contact_mail_addr1 = get_user_meta($current_user->ID, 'fg_contact_mail_addr1', true);
	return $fg_contact_mail_addr1;
}

add_filter("gform_field_value_fg_contact_mail_addr2", "update_fg_contact_mail_addr2");
function update_fg_contact_mail_addr2($value){

    global $current_user;
    get_currentuserinfo();

    $fg_contact_mail_addr2 = get_user_meta($current_user->ID, 'fg_contact_mail_addr2', true);
	return $fg_contact_mail_addr2;
}

add_filter("gform_field_value_fg_contact_mail_addr2", "update_fg_contact_mail_city");
function update_fg_contact_mail_city($value){

    global $current_user;
    get_currentuserinfo();

    $fg_contact_mail_addr2 = get_user_meta($current_user->ID, 'fg_contact_mail_city', true);
	return $fg_contact_mail_city;
}



/* create custom property management roles */
function fg_custom_pm_roles () {

	//remove_role('property_manager');
	$property_manager_role = add_role(
		'property_manager',
		__( 'Property Manager' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => true,
			'edit_ai1ec_events'   => true,
			'publish_posts'   => true,
			'publish_pages'   => true,
			'manage_options'   => true,
			'manage_categories'   => true,
			'delete_posts' => false, // Use false to explicitly deny
			/*manager needs a network 'dashboard' that tabs through management functions for all sites.
			For Example post to multiple properies and groups */
		)
	);

	if ( null !== $property_manager_role ) {
		echo 'Yay! PM role created!';
	}


	$desk_staff_role = add_role(
		'desk_staff',
		__( 'Desk Staff' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => false,
			'delete_posts' => false, // Use false to explicitly deny
		)
	);

	if ( null !== $desk_staff_role ) {
		echo 'Yay! Desk Staff role created!';
	}


	$maint_staff_role = add_role(
		'maint_staff',
		__( 'Maintenance Staff' ),
		array(
			'read'         => true,  // true allows this capability
			'edit_posts'   => false,
			'delete_posts' => false, // Use false to explicitly deny
		)
	);

	if ( null !== $maint_staff_role ) {
		echo 'Yay! Maintenance Staff role created!';
	}

	$editor=get_role('editor');
	$tenant_role=add_role('tenant_role','Tenant',$editor->capabilities);




 	//$tenant_role->add_cap('new_capability');



}//end func
add_action( 'init', 'fg_custom_pm_roles' );
// remove unwanted dashboard widgets for relevant users


function quickDoc() {

	echo '<div class="p_section halfable" id="section_description">
			<h3 class="property_color">Description</h3>';
			wp_editor( $post->post_content, 'post_content' );
	echo '<p><b>Short Description</b> (appears in search results)</p>
			<textarea name="post_excerpt" rows="5">';
			echo $post->post_excerpt;

	echo '</textarea>
		</div>';
}


function fg_dashboard_pending_wo() {

	$args = "
	'posts_per_page'   => 5,
	'offset'           => 0,
	'orderby'          => 'post_date',
	'post_type'        => 'maintenance_requests',
	'suppress_filters' => true";
	$latest_wos = get_posts();
	foreach ( $latest_wos as $work_order ) : setup_postdata( $work_order ); ?>
	<li>
		<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
	</li>
<?php endforeach; 
wp_reset_postdata();
}
add_action( 'wp_dashboard_setup', 'fg_pm_dashboard' );

function fg_pm_dashboard() {
    $user = wp_get_current_user();
    $chk_pm_role = $user->roles;

    if ( in_array( 'property_manager',$chk_pm_role ) ) {
        remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_primary', 'dashboard', 'normal' );
        //remove_meta_box( 'dashboard_quick_press', 'dashboard', 'normal' );


		/*
		 * wp_add_dashboard_widget(
                 'property_settings_dashboard_widget',         // Widget slug.
                 'Property Settings',         // Title.
                 'property_settings_page' // Display function.
        );
        */
   		//property_admin_init();
		wp_add_dashboard_widget(
                 'property_documents_dashboard_widget',         // Widget slug.
                 'Property Documents',         // Title.
                 'quickDoc' // Display function.
        );
       wp_add_dashboard_widget(
				'dashboard_communications_widget',
				'Communications',
				'fg_dashboard_quick_press');

       wp_add_dashboard_widget(
				'dashboard_wo_widget',
				'Pending Work Orders',
				'fg_dashboard_pending_wo');

    }
}
add_action( 'wp_dashboard_setup', 'fg_pm_dashboard' );

function add_sumtips_admin_bar_link() {
	global $wp_admin_bar;

	$wp_admin_bar->remove_node('wp-logo');
	$wp_admin_bar->remove_node('my-sites');
	$wp_admin_bar->add_menu( array(
	'id' => 'assigned-properties',
	'title' => __( 'Properties List'),
	'href' => __('my-sites.php'),
	) );
}
add_action('admin_bar_menu', 'add_sumtips_admin_bar_link',25);


/**
 * Repeatable Custom Fields in a Metabox
 * Author: Helen Hou-Sandi
 *
 * From a bespoke system, so currently not modular - will fix soon
 * Note that this particular metadata is saved as one multidimensional array (serialized)
 */

function hhs_get_sample_options() {
	$options = array (
		'Option 1' => 'option1',
		'Option 2' => 'option2',
		'Option 3' => 'option3',
		'Option 4' => 'option4',
	);

	return $options;
}

add_action('admin_init', 'hhs_add_meta_boxes', 1);
function hhs_add_meta_boxes() {
	add_meta_box( 'repeatable-fields', 'Repeatable Fields', 'hhs_repeatable_meta_box_display', 'property_doc', 'normal', 'default');
}

function hhs_repeatable_meta_box_display() {
	global $post;
	//$repeatable_fields = get_post_meta($post->ID, 'repeatable_fields', true);
	$cur_reminders = get_post_meta(get_the_ID(), 'fg_document_reminder', true);
	//$options = hhs_get_sample_options();

	wp_nonce_field( 'hhs_repeatable_meta_box_nonce', 'hhs_repeatable_meta_box_nonce' );
	?>
	<script type="text/javascript">
	jQuery(document).ready(function( $ ){
		$( '#add-row' ).on('click', function() {
			var row = $( '.empty-row.screen-reader-text' ).clone(true);
			row.removeClass( 'empty-row screen-reader-text' );
			row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
			return false;
		});

		$( '.remove-row' ).on('click', function() {
			$(this).parents('tr').remove();
			return false;
		});
	});
	</script>

	<table id="repeatable-fieldset-one" width="100%">
	<thead>
		<TR>
			<TH>Reminder Notes:</TH>
			<TH>Date</TH>
			<TH>Delete</TH>
		</TR>
	</thead>
	<tbody>
	<?php

	if ( $cur_reminders ) :

	foreach ( $cur_reminders as $cur_reminder ) {
	?>
     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date"></TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
	<?php
	}
	else :
	// show a blank one
	?>
     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date"></TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>

	<?php endif; ?>

	<!-- empty hidden one for jQuery -->
	<tr class="empty-row screen-reader-text">
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminders[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminders[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date"></TD>
		<td><a class="button remove-row" href="#">Remove</a></td>

	</tr>
	</tbody>
	</table>

	<p><a id="add-row" class="button" href="#">Add another</a></p>
	<?php
}

add_action('save_post', 'hhs_repeatable_meta_box_save');
function hhs_repeatable_meta_box_save($post_id) {
/*echo "<H1>Called</H1>";
echo "<H1>Called 2754 " . $_POST . "</H1>";
foreach($_POST as $key=>$value) {

	echo "<LI>" . $key . " - " . $value . "</LI>";

}
*/
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;

	if (!current_user_can('edit_post', $post_id))
		return;

	$old = get_post_meta($post_id, 'fg_document_reminder', true);
	$new = array();
	//$options = hhs_get_sample_options();
	$reminder_notes = $_POST['fg_document_reminder_notes'];
	$reminder_dates = $_POST['fg_document_reminder_date'];
	//$urls = $_POST['url'];

	$count = count( $reminder_notes );

	for ( $i = 0; $i < $count; $i++ ) {
		if ( $reminder_notes[$i] != '' ) {
			$new[$i]['fg_document_reminder_notes'] = stripslashes( strip_tags( $reminder_notes[$i] ) );
		}
		if ( $reminder_dates[$i] != '' ) {
			$new[$i]['fg_document_reminder_date'] = $reminder_dates[$i];
		}
	}

	if ( !empty( $new ) && $new != $old ) {
		update_post_meta( $post_id, 'fg_document_reminder', $new );
	} elseif ( empty($new) && $old ) {
		delete_post_meta( $post_id, 'fg_document_reminder', $old );
	}
}



/*cron start */
add_action('after_switch_theme', 'central_cron_activation');
function central_cron_activation() {
	// other options include 'hourly' and 'twicedaily'
	 wp_schedule_event( time(), 'daily', 'central_daily');
}

// this code deactivates the cron when the theme is deactivated
add_action('switch_theme', 'central_cron_deactivation');
function central_cron_deactivation() {
	wp_clear_scheduled_hook('central_daily');
}

// this links the cron we defined above, 'central_daily', to an actual method, 'central_daily_method'
add_action('central_daily', 'central_daily_method');
function central_daily_method() {
	global $wpdb;
	$cur_time = strtotime( date( 'Y-m-d' ) );
	$sent_reminder = false;
	$sql = "SELECT * FROM wp_5_postmeta WHERE meta_key = 'fg_document_reminder'";
	$cur_reminders = $wpdb->get_results($sql, ARRAY_A);

	foreach ($cur_reminders[0] as $key => $value) {
	 $message = "<P>The following reminders are currently set:
	 <UL>";
	 	if ( $key == 'post_id' ) {
	 		$doc_title = get_the_title( $value );
	 		$title = "<LI>Document Title: " . $doc_title . "</LI>";
		}
		if ( $key == 'meta_value' ) {
	 		$value = unserialize( $value );
			$reminders = "<UL>";
				foreach ( $value as $cur_reminder ) {
					$remind_time = strtotime( $cur_reminder[fg_document_reminder_date] );
					if ( $cur_time >= $remind_time ) {
						$reminders .= "<LI>Reminder Notes: " . $cur_reminder[fg_document_reminder_notes] . "</LI>
						</LI>Reminder Date: " . $cur_reminder[fg_document_reminder_date] . "</LI>";
						$sent_reminder = true;
					}
				}
			$closing = "</UL>";
		}
		if ( $sent_reminder == true ) {
			$message = $message . $title . $reminders . $closing;
			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			wp_mail( 'dg_419@hotmail.com', 'Lease Reminders', $message);
			remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$sent_reminder = false;
		}
	}
}

function set_html_content_type() {
	return 'text/html';
}
if($_GET['run_daily_method']=='true') {
	central_daily_method();
}




?>
