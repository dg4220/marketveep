<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @since 3.0.0
 */
get_header(); 
global $wpdb;

?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP
		
	$args = array(
	'offset'           => 0,
	'orderby'          => 'post_title',
	'meta_key'         => '',
	'meta_value'       => '',
	'post_type'        => 'property_comm',
	'post_status'      => 'publish',
	'suppress_filters' => true );

	$communications = get_posts( $args );
	global $wpdb;
	global $table_prefix;
	
	?>
	<script type="text/javascript" charset="utf-8">

$(document).ready(function() {
    $('#example<?PHP echo  $properties[$i][blog_id]; ?>').dataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": ({
			url "prop_comm_ssp.php?tablePrefix=<?PHP echo  $table_prefix; ?>",
			datatype: "jsonp"
		})
		
		
    } );
} );
</script>

<?PHP
echo "<DIV><table id='example" . $properties[$i][blog_id] . "' class='display' cellspacing='0' width='100%'>
        <thead>
            <tr>
                <th>From</th>
                <th>Date</th>
                <th>Subject</th>
                <th>View</th>
                <th>Close</th>
                
            </tr>
        </thead>";
        
        
	$get_comms = "SELECT post_author, post_date, ID, post_title FROM " . $table_prefix . "posts
	WHERE post_type = 'property_comm' AND post_status = 'publish'";
	$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);

	if (is_array($cur_comms)) {
		//echo "<H4>Array!</H4>";
		foreach ($cur_comms as $k=>$v) {
			//echo "<H4>Array Row: " . $k . " - " . $v . "</H4>";
			foreach ($v as $kv=>$vV) {
				
				if ($kv == 'post_author') {
					$pc_from_info = get_userdata( $vV );
					$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
					$pc_from_email = $pc_from_info->user_email;
				}
				if ($kv == 'post_date') {
					$pc_from_date = $vV;
				}
				if ($kv == 'post_title') {
					$pc_from_subject = $vV;
				}
				if ($kv == 'ID') {
					$pc_original_id = $vV;
				}
				
			}
			echo "<tr><td>" . $pc_from_name . "<BR>" . $vV . "</td>
				<td>" . $pc_from_subject . "</td>
				<td>" . $pc_from_date . "</td>
				<td><A HREF=''>View</A></td>
				<td><A HREF=>Close</A></td>";
			
		}
	} else {
		$this_var = gettype($cur_comms);
		echo "<H4>Is: " . $this_var . "</H4>";
	}
	echo "<tfoot>
            <tr>
                <th>From</th>
                <th>Date</th>
                <th>Subject</th>
                <th>View</th>
                <th>Close</th>
                
            </tr>
        </tfoot>
    </table>
    </DIV>";
	
		
	?>

	</div><!-- #primary.c6 -->

<?php get_footer(); ?>
