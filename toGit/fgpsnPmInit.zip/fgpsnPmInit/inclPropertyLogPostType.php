<?PHP
//wp_enqueue_script( 'jquery' );fgpsn_comm_selected_units
/******************************************************
 * DG Creating Property Logs post type and meta boxes.
 * Include this in the designated PM site theme ONLY
 * The include allows posting messages to all sites in a network
 * Use inclCommPostTypeClient.php to allow property sites to post messages only to thier property
 * and designated residents, employees, management, vendors, etc.
*******************************************************/
function create_property_log() {
	$labels = array(
			'name'               => _x( 'Property Logs', 'post type general name' ),
			'singular_name'      => _x( 'Log Entry', 'post type singular name' ),
			'add_new'            => _x( 'Create Log Entry', 'property_log' ),
			'add_new_item'       => __( 'Create New Log Entry' ),
			'edit_item'          => __( 'Review Log Entry' ),
			'new_item'           => __( 'New Log Entry' ),
			'all_items'          => __( 'All Log Entrys' ),
			'view_item'          => __( 'View Log Entry' ),
			'search_items'       => __( 'Search Log Entrys' ),
			'not_found'          => __( 'No Log Entrys Found' ),
			'not_found_in_trash' => __( 'No Log Entrys found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Property Logs'
		);
    $args = array(
      'description'   => 'Messaging and Property Property Logs',
			'public'        => true,
			'menu_position' => 5,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes','custom-fields','thumbnail' ),
			'taxonomies'      => array( 'log_types'  ),
			'hierarchical' => true,
			'has_archive'   => true,
      'labels'  => $labels
    );
    register_post_type( 'property_log', $args );
}
add_action( 'init', 'create_property_log' );

/* add contact types taxonomy */
function create_property_log_types() {
 $labels = array(
    'name' => _x( 'Log Entry Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Log Entry Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Log Entry Types' ),
    'all_items' => __( 'All Log Entry Types' ),
    'parent_item' => __( 'Parent Log Entry Type' ),
    'parent_item_colon' => __( 'Parent Log Entry Type:' ),
    'edit_item' => __( 'Edit Log Entry Type' ),
    'update_item' => __( 'Update Log Entry Type' ),
    'add_new_item' => __( 'Add New Log Entry Type' ),
    'new_item_name' => __( 'New Log Entry Type Name' ),
  );

  register_taxonomy('log_types','property_log',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_property_log_types' );

/*add_action( 'add_meta_boxes', 'selected_tenant_hmy' );
function selected_tenant_hmy() {

	$screens = array( 'property_log' );
    foreach ($screens as $screen) {
		add_meta_box(
			'selected_tenant_hmy',
			__( 'Selected Recipients', 'myplugin_textdomain' ),
			'selected_tenant_hmy_content',
			$screen,
			'normal',
			'high'
		);
	}
}

function selected_tenant_hmy_content(){
	wp_nonce_field( plugin_basename( __FILE__ ), 'selected_tenant_hmy_content_nonce' );
	echo "<FIELDSET><DIV>
	
	Selected Tenants: <br>";
	echo get_post_meta(get_the_ID(), 'selected_tenant_hmy', true );
	echo "</DIV></FIELDSET>";

}*/

add_action( 'add_meta_boxes', 'unit_list' );
function unit_list() {

	$screens = array( 'property_log' );
    foreach ($screens as $screen) {
		add_meta_box(
			'unit_list',
			__( 'Select Properties', 'myplugin_textdomain' ),
			'unit_list_content',
			$screen,
			'normal',
			'high'
		);
	}
}


function unit_list_content( $post ) {

	global $wpdb;

	wp_nonce_field( plugin_basename( __FILE__ ), 'unit_list_content_nonce' );
	$cur_unit_list = get_post_meta( get_the_ID(), 'fgpsn_log_selected_units', true );
	$cur_groups_list = get_post_meta( get_the_ID(), 'fgpsn_log_selected_groups', true );
	$cur_string = get_post_meta( get_the_ID(), 'first_string', true );
	$test_output = get_post_meta( get_the_ID(), 'test_output', true );

	   foreach($cur_unit_list as $k => $v ) {
		   $prop_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
		   $prop_array[] = $v;
	   }
	   foreach($cur_groups_list as $k => $v ) {
		   $group_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
		   $group_array[] = $k;
	   }
	echo "<FIELDSET><DIV>
	<DIV class='right_half' STYLE='display: inine; float: left; width: 45%;'>
	Select Properties:";
		
	$meta_key = 'fgpsn_property_id';  // The meta_key of the Custom Field
		$sql = "
		   SELECT p.*,m.meta_value,
		   p.*,m.post_id
		   FROM $wpdb->posts p
		   LEFT JOIN $wpdb->postmeta m ON (p.ID = m.post_id)
		   WHERE p.post_type = 'unit_data'
		      AND p.post_status = 'publish'
		      AND m.meta_key = '$meta_key'
		   ORDER BY m.meta_value, p.post_date DESC
		";

		global $wpdb;
		$rows = $wpdb->get_results($sql);
		if ($rows) {
			echo '<SELECT multiple name="fgpsn_log_selected_units[]" size=5 >
					<option value="0"> -- N/AAA -- </option>';
		   foreach ($rows as $post) {
		      setup_postdata($post);
		      if ($post->meta_value != $current_value) {

		      	echo '<option value="' . $post->ID . '"';
					 
					 if ( in_array( $post->ID, $oocids ) ) {
						 echo ' selected';
					 } elseif($post->ID == $oocids) {
					 	echo ' selected';
					 }
					 
					 echo '>' . $post->post_title . ", "  . get_post_meta($post->ID, 'fgpsn_contact_first_name', true) . '</option>';

		      }
		     
		   }
		    echo '</SELECT>';
		}


	echo "</DIV>
	<DIV class='right_half' STYLE='display: inine; float: left; width: 45%;'>
		Select Recipient Groups:";

	$categories = get_terms( 'contact_data_types', array(
		'orderby'    => 'count',
		'hide_empty' => 0
	 ) );

	 if ( !empty( $categories ) && !is_wp_error( $categories ) ){
     echo "<ul>";
     foreach ( $categories as $category ) {
       echo "<input type='checkbox' name=fgpsn_comm_recip_group[$category->term_id] id=fgpsn_comm_recip_group[]";
       if ( in_array($category->term_id, $group_array) ) {
		   echo " checked";
	   }
       echo ">" . $category->name . " - " . $category->term_id . "<BR>";

     }
     echo "</ul>";
	}
 echo "<H4>Properties: " . $prop_string . "</H4>
	   <H4>Groups: " . $group_string . "</H4>
	   <H4>STRING: " . $cur_string . "</H4>
	   <H4>Output: " . $test_output . "</H4>";
	echo "</DIV>
	   </FIELDSET>";

	 
	
}


//add_action( 'save_post', 'unit_list_save' );
function unit_list_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['unit_list_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$fgpsn_comm_selected_properties = $_POST['fgpsn_comm_selected_properties'];
	$selected_groups = $_POST['fgpsn_comm_recip_group'];
	$first_string = '<H1>SP: ' . $fgpsn_comm_selected_properties . ' - ' . $selected_groups[0] . '</H1>';

	/*need to get users/contacts for selected 'properties' and in the selected groups
	 * if there's no group is selected send to all active users? or require group selection?
	 */
	$test_output =  "";
	foreach ( $fgpsn_comm_selected_properties as $k=>$v ) {
		global $switched;
		switch_to_blog($v); //switched to 1 & 2 but only 1 working

		//Get latest Post

		$args = array(
		'offset'           => 0,
		'category'         => $selected_groups,
		'orderby'          => 'post_title',
		'meta_key'         => '',
		'meta_value'       => '',
		'post_type'        => 'contact_data',
		'post_status'      => 'publish',
		'suppress_filters' => true );

		$recipients = get_posts( $args );
		//echo '<H1>' . $property_ids . ' -- Select Properties -- ' . $wpdb->last_query . '</H1>';
		$property_ct = count( $property_ids);
		//echo '<OPTION> -- Select Properties -- </OPTION>';
		$recip_opt = array();
		$blog_details = get_blog_details($k, true);
		$cur_property = $blog_details->blogname;
		echo "<H3>" . $cur_property . "</H3>";
		foreach ($recipients as $recipient) {
			$recip_email = get_post_meta($recipient->ID, 'client_email', true);
			$recip_opt = 'Recipient: ' . $recipient->post_title;
			echo "<H3>" . $recip_opt . " - " . $recip_email . "</H3>";
		}
		//$new_comm = wp_insert_post( $_POST, $wp_error );
				$my_post = array(
				  'post_title'    => 'My post',
				  'post_content'  => 'This is my post.',
				  'post_status'   => 'publish',
				  'post_author'   => 1
				);

				// Insert the post into the database
				//$new_comm = wp_insert_post( $my_post );

		 echo "<H3>Line 198 Insert Result: " . $new_comm . " - Post array: " . $_POST . " - WP Error: " . $fgpsn_comm_selected_properties[0] . "</H3>";
		 $post_item = '';
		 foreach( $_POST as $pk=>$pv ) {
			 //$post_item .= 'Key: ' . $pk . '; Value: ' . $pv . '<BR>';
		 }
		 $test_output .= "<H3>Line 198 Insert Result: " . $new_comm . " - Post Items: " . $post_item . " - WP Error: " . $wp_error . "</H3>";
	}




	/*need to add communicatons log to main PM site to track recipients across network*/

	update_post_meta( $post_id, 'fgpsn_comm_selected_properties', $fgpsn_comm_selected_properties );
	update_post_meta( $post_id, 'selected_groups', $selected_groups );
	update_post_meta( $post_id, 'first_string', $first_string );
	update_post_meta( $post_id, 'test_output', $test_output );

	if ( ! wp_is_post_revision( $post_id ) ){

		// unhook this function so it doesn't loop infinitely
		remove_action('save_post', 'unit_list_save');

		// update the post, which calls save_post again
		wp_update_post( $my_post );

		// re-hook this function
		add_action('save_post', 'unit_list_save');
	}

}


add_action('admin_init', 'fglog_add_meta_boxes', 1);
function fglog_add_meta_boxes() {
	add_meta_box( 'repeatable-fields',
				'Set Reminders',
				'fglog_repeatable_meta_box_display',
				'property_log',
				'normal',
				'default');
}

function fglog_repeatable_meta_box_display() {
	global $post;
	//$repeatable_fields = get_post_meta($post->ID, 'repeatable_fields', true);
	$cur_reminders = get_post_meta(get_the_ID(), 'fg_document_reminder', true);
	$cur_doc_url = get_post_meta(get_the_ID(), 'property_doc_file', true);
	//$options = fglog_get_sample_options();

	wp_nonce_field( 'fglog_repeatable_meta_box_nonce', 'fglog_repeatable_meta_box_nonce' );
	?>
	<FIELDSET><div><script type="text/javascript">
	jQuery(document).ready(function( $ ){
		jQuery( '#add-row' ).on('click', function() {
			var row = $( '.empty-row.screen-reader-text' ).clone(true);
			row.removeClass( 'empty-row screen-reader-text' );
			row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
			return false;
		});

		jQuery( '.remove-row' ).on('click', function() {
			$(this).parents('tr').remove();
			return false;
		});
	});
	</script>
	<table id="repeatable-fieldset-one" width="100%">
	<thead>
		<TR>
			<TH>Reminder Notes:</TH>
			<TH>Date</TH>
			<TH>Delete</TH>
		</TR>
	</thead>
	<tbody>
	<?php

	if ( $cur_reminders ) :

	$recip_ct = 1;
	foreach ( $cur_reminders as $cur_reminder ) {
	?>
     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
		<TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />


					<OPTION value=""> - Select - </OPTION>\n

					<?PHP

					$args = array(
						'fields'       => 'all'
						 );
				$blogusers = get_users( $args );
				foreach ($blogusers as $user) {
					if ( $user->user_email != '' ) {
						echo "<OPTION value='" . $user->user_email . "'";

									if ($cur_reminder[fg_document_reminder_cc] == $user->user_email) {
										echo "selected";
									}


						echo ">" .  $user->user_email  . "</OPTION>\n";
					}
   				}

          echo '</SELECT>';
		?>
     	</TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
	<?php
	$recip_ct++;
	}
	else :
	// show a blank one
	?>

     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
		<TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />

					<OPTION value=""> - Select - </OPTION>\n
					<?PHP
					$args = array(
						'fields'       => 'all'
						 );
							$blogusers = get_users( $args );
							foreach ($blogusers as $user) {
								if ( $user->user_email != '' ) {
									echo "<OPTION value='" . $user->user_email . "'>" .  $user->user_email  . "</OPTION>\n";
								}
							}

					  echo '</SELECT>';
					?>
     	</TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
<?PHP $recip_ct++; ?>
	<?php

	endif; ?>

	<!-- empty hidden one for jQuery -->
	<tr class="empty-row screen-reader-text">

     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminders[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminders[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
 <TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />

					<OPTION value=""> - Select - </OPTION>\n

					<?PHP

					$args = array(
						'fields'       => 'all'
						 );
				$blogusers = get_users( $args );
				foreach ($blogusers as $user) {
					if ( $user->user_email != '' ) {
						echo "<OPTION value='" . $user->user_email . "'>" .  $user->user_email  . "</OPTION>\n";
					}
   				}

          echo '</SELECT>';

		?>
     	</TD>
     	<?PHP $recip_ct++; ?>
		<td><a class="button remove-row" href="#">Remove</a></td>

	</tr>
	</tbody>
	</table>

	<p><a id="add-row" class="button" href="#">Add another</a></p></DIV></FIELDSET>
	<?php
}

//add_action('save_post', 'fglog_repeatable_meta_box_save');
function fglog_repeatable_meta_box_save($post_id) {

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;

	if (!current_user_can('edit_post', $post_id))
		return;

	$old = get_post_meta($post_id, 'fg_document_reminder', true);
	$new = array();
	$reminder_notes = $_POST['fg_document_reminder_notes'];
	$reminder_dates = $_POST['fg_document_reminder_date'];
	$reminder_url = $_POST['fg_document_reminder_url'];

	$count = count( $reminder_notes );
	for ( $i = 1; $i <= $count; $i++ ) {

		$reminder_cc[$i] = $_POST['fg_document_reminder_cc_' . $i];
		//echo "<H3>CC array? " . $reminder_cc[$i] . "</H3>";
		//foreach($reminder_cc[$i] as $k=>$v) {
			//echo "<LI>CC Items? " . $k . " - " . $v . "</LI>";

		//}

	}
	for ( $i = 0; $i < $count; $i++ ) {
		if ( $reminder_notes[$i] != '' ) {
			$new[$i]['fg_document_reminder_notes'] = stripslashes( strip_tags( $reminder_notes[$i] ) );
		}
		if ( $reminder_dates[$i] != '' ) {
			$new[$i]['fg_document_reminder_date'] = $reminder_dates[$i];
		}
		if ( $reminder_url[$i] != '' ) {
			$new[$i]['fg_document_reminder_url'] = $reminder_url[$i];
		}
		if ( $reminder_cc[$i] != '' ) {
			$new[$i]['fg_document_reminder_cc'] = $reminder_cc[$i];
		}


	}

	if ( !empty( $new ) && $new != $old ) {
		update_post_meta( $post_id, 'fg_document_reminder', $new );
	} elseif ( empty($new) && $old ) {
		delete_post_meta( $post_id, 'fg_document_reminder', $old );
	}
}


//custom admin table for Property Logs

function change_property_log_pt_columns( $cols ) {
  $cols = array(
    'cb'       => '<input type="checkbox" />',
    'post_title'     => __( 'Subject', 'trans' ),
    'post_author'     => __( 'From', 'trans' )
  );
  return $cols;
}
add_filter( "manage_property_log_posts_columns", "change_property_log_pt_columns" );

function custom_log_columns( $column, $post_id ) {

  $contact_first_name = get_post_meta($post_id, 'recipient_contact_first_name', true);
  $contact_last_name = get_post_meta($post_id, 'recipient_contact_last_name', true);
  $contact_phone = get_post_meta($unit_occupant_ids, 'client_phone', true);
  $contact_cell = get_post_meta($unit_occupant_ids, 'client_cell', true);
  $contact_email = get_post_meta($unit_occupant_ids, 'client_email', true);

  $unit_cpt_cols[unit_sqft_cst] = 12 * ( number_format( $unit_cpt_cols[unit_sqft_cst], 2, '.', '' ) );

  switch ( $column ) {
    case "unit_monthly_rent":
      echo $unit_cpt_cols[unit_rent_amt_month] . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;

   case "unit_sqft":
      echo $unit_cpt_cols[unit_sqft] . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;
    case "unit_cst_sqft":
      echo $unit_cpt_cols[unit_sqft_cst];
      break;

    case "unit_number":
    $unit_number = get_post_meta(get_the_ID(), 'unit_number', true);
      echo $unit_number . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;

    case "unit_title":
    $unit_title = get_the_title(get_the_ID());
      echo $unit_title . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;

    case "occupant":
      echo $contact_first_name . " " . $contact_last_name;
      echo "<BR>Phone: " . $contact_phone;
      echo "<BR>Cell: " . $contact_cell;
      echo "<BR>Email: " . $contact_email;
      break;

     default:
      //echo "<H1>Default: " . $column . " - " . $post_id . "</H1>";
      break;
  }
}

add_action( "manage_property_log_posts_custom_column", "custom_log_columns", 10, 2 );

// Make these columns sortable
function sortable_log_columns() {
  return array(
    /*'unit_monthly_rent'      => 'unit_monthly_rent',
    'unit_sqft' => 'unit_sqft',
    'unit_cst_sqft' => 'unit_cst_sqft',
    'unit_number' => 'unit_number',
    'occupant'     => 'occupant'
    */
    'date' => 'date',
    'log_types' => 'log_types'
    
  );
}

add_filter( "manage_edit-property_log_sortable_columns", "sortable_log_columns" );

/****************************************************************************************/


//set up the Property Logs archive/search shortcode

function get_archived_property_logs( $atts ){

	global $user;
	global $wpdb;
		/* set up search forms */

	$archive_results = "<table class='catalog_table' width='100%'>
		<thead><TR>
		<TH><form method='get' action='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "'>
		Search for <input type='text' name='q' value='" . $_GET['q']  . "' />
		Within

		<input type='submit' value='Search' />
		</form></TH>
		</TR>
		</thead></table>";
	$fg_vend_search_query = (empty($_GET['q'])) ? 'Nada.' : urldecode($_GET['q']);

	$results = new WP_Query();
	if( ! empty($_GET['q']) ) {
		$query_args = array(
			'post_type'=>'property_log',
			'number_posts'=>-1,
			's'=>$_GET['q'],
		);

		$results = new WP_Query($query_args);
	}


	if($results->have_posts()) {

		while ( $results->have_posts() ) : $results->the_post();

			//$subject = get_post_meta(get_the_id(), 'emp_phone', true);

			$archive_results .= "<TABLE><TR><TD><a href='http://www.ptechinternational.com/ptiMulti/hill-condominium/addedit-Property Logs/?gform_post_id=" . get_the_id() . "'>" . get_the_title() . "</A></TD>
			<TD>" . get_the_date() . "</TD>
			<TD>" . $client_phone . "</TD>
			<TD><a href='http://www.ptechinternational.com/ptiMulti/hill-condominium/addedit-Property Logs/?select_recipients=" . get_the_id() . "'>" . $client_email . "</A></TD>
			</TR></TABLE>";

		endwhile;


	} else {

		$month = date( 'M' );
		$year = date( 'Y' );
		$query = new WP_Query( 'year=' . $year . '&w=' . $week );

	}
	echo $archive_results;
	fg_dashboard_prop_comms();
}
add_shortcode( 'Property Logs_archives', 'get_archived_property_logs' );

// Add to admin_init function
add_filter('manage_edit-property_log_columns', 'add_edit_property_log_columns');

function add_edit_property_log_columns($property_log_columns) {
    $new_columns['cb'] = '<input type="checkbox" />';
    $new_columns['title'] = _x('Subject', 'column name');
    $new_columns['author'] = __('From');
    $new_columns['log_types'] = __('Log Entry Type');
    $new_columns['date'] = _x('Date', 'column name');

    return $new_columns;
}


add_action('manage_property_log_posts_custom_column', 'manage_property_log_columns', 10, 2);

function manage_property_log_columns($column_name, $id) {
    global $wpdb;
    switch ($column_name) {
    case 'id':
        echo $id;
            break;

    case 'log_types':
        // Get number of images in gallery
        $terms = wp_get_post_terms( $id, 'log_types' );
        foreach($terms as $term) {
        echo 'Communication Type: ' . $term->name;
        }

        break;
    default:
        break;
    } // end switch
}


//transfer Property Logs by switch post type


?>
