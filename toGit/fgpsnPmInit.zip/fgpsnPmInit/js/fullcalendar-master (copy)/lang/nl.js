
$.fullCalendar.lang("nl", {
	buttonText: {
		month: "Maand",
		week: "Week",
		day: "Dag",
		list: "Agenda"
	},
	allDayText: "Hele dag",
	eventLimitText: "extra"
});
