
$.fullCalendar.lang("zh-tw", {
	buttonText: {
		month: "月",
		week: "週",
		day: "天",
		list: "待辦事項"
	},
	allDayText: "全天",
	eventLimitText: "更多"
});
