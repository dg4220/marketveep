propertyFilter = function () {

    var countryClass = '.fgpsn_wo_selected_properties',
        countrySelector = '.fgpsn_wo_selected_properties > div > select',
        dealerClass  = '.fgpsn_wo_selected_units > div > select';
    checker = jQuery(dealerClass);
    
    jQuery(countryClass).change(function(){
    alert('Inner ' + checker);
        var countrySelect = jQuery(countrySelector),
            country = countrySelect.val(),
            dealerSelect = countrySelect.parents('form').find(dealerClass);
            
        if(country != "default") {
            alert('Inner 2 ' + country);
           jQuery.ajax({
                type: 'POST',
                url: 'http://watertree.fgpsn.com/wp-admin/admin-ajax.php',
                data: { dealerCountry : country, action: 'getUnitList' },
                success: function(data){
                    dealerSelect.empty();
                    var options = jQuery.parseJSON(data);
                    alert('Inner 3' + options);
                    for(i=0;i<options.length;i++){
                        dealerSelect.append('<option>ssss'+options[i].text+'</option>');
                    }
                    dealerSelect.removeAttr('disabled');
                }
            });

        }

    });

}

 propertyFilter();

    

