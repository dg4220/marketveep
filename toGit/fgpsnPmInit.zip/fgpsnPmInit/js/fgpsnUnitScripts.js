/*


This is for the unit search widget
Thanks the Sam


 alert(jQuery("#access").height());
jQuery(document).ready(function () { 

jQuery("div#header").height( 30 ).css({
    cursor: "auto",
    backgroundColor: "blue",
    height: "30",
    border: "0",
    padding: "0",
    margin: "0"
  });
});
    alert(jQuery("#access").height());
*/
    
jQuery(document).ready(function () { 

      jQuery(".property-beds-filter").change(function () {
        var className = jQuery(this).attr('class');
        var idName = '.' + jQuery(this).attr('id');
        var classStatus = jQuery(this).prop('selected');

        var bedsFilter = jQuery('.property-beds-filter').val();
        var cityFilter = jQuery('.property-city-filter').val();

        var bedsmessage = jQuery('.property-beds-filter  option:selected').text();
        var citymessage = jQuery('.property-city-filter  option:selected').text();
        
        var newBedsFilter = JSON.stringify(bedsFilter);
        newBedsFilter = newBedsFilter.replace(',', ' .');
        newBedsFilter = newBedsFilter.replace('[', '');
        newBedsFilter = newBedsFilter.replace(']', '');
        newBedsFilter = '.' + newBedsFilter.replace(/"/g, '');
        
        var newcityFilter = JSON.stringify(cityFilter);
        newcityFilter = newcityFilter.replace(',', '.');
        newcityFilter = newcityFilter.replace('[', '');
        newcityFilter = newcityFilter.replace(']', '');
        newcityFilter = '.' + newcityFilter.replace(/"/g, '');
        
          
        //jQuery('.fgpsn-unit-archive-display').css('display', 'none');
        jQuery('.fgpsn-unit-archive-display').css('display', 'none');
        
        if ( cityFilter===null) { 
          //alert(typeof(newBedsFilter) + ': ' + newBedsFilter);
          //alert(jQuery(newBedsFilter));
          jQuery(newBedsFilter).css('display', 'block');
        } else {
  
          var showcombined = newBedsFilter + newcityFilter;
          //alert(jQuery(showcombined).css('display'));
          jQuery(showcombined).css('display', 'block'); 
          
        }

        
        var resetDisplay = function () {
        var filterResults;
        filterResults = 0;
        jQuery('.fgpsn-unit-archive-display').each(function( index ) {
            
            
            if (jQuery( this ).css('display') === 'block')  {
              filterResults = 1;
            } 
          });
          //alert(filterResults);
          return filterResults;
        }

        var yesorno = resetDisplay();
        //alert('checker ' + yesorno);
        
        //alert(citymessage.length);
        var doublechecker = citymessage.length;
        var otherchecker = bedsmessage.length;
        jQuery('.filter-message').empty();
        //alert('checker ' + doublechecker + ': ' + otherchecker + ': ' + filterResults);
        if ( otherchecker > 0 && doublechecker > 0 ){ 
          
                  if ( yesorno === 0 ) {
            var filterMessage = 'There are no available <b>' + bedsmessage + '</b> units in ' + citymessage + '</b>.';
          } else {
                    var filterMessage = 'Viewing available <b>' + bedsmessage + '</b> units in <b>' + citymessage + '</b>.';
                  }
                } else if( otherchecker > 0 && doublechecker == 0 ){
                  if ( yesorno === 0 ) {
            var filterMessage = 'There are no available <b>' + bedsmessage + '</b> units in any locations.';
          } else {
            var filterMessage = 'Viewing available <b>' + bedsmessage + '</b> units in all locations.';
          }
                } else if( otherchecker == 0 && doublechecker > 0 ){
                  if ( yesorno === 0 ) {
            var filterMessage = 'There are no available units in <b>' + citymessage + '</b>.';
          } else {
            var filterMessage = 'Viewing available units in <b>' + citymessage + '</b>.';
          }
                }
               filterMessage = filterMessage + '<div class="clear-filter-button">Clear Filters</div>';

                jQuery('.filter-message').append(filterMessage);
        
      });


      jQuery(".property-city-filter").change(function () {

        var bedsFilter = jQuery('.property-beds-filter').val();
        var cityFilter = jQuery('.property-city-filter').val();

        var bedsmessage = jQuery('.property-beds-filter  option:selected').text();
        var citymessage = jQuery('.property-city-filter  option:selected').text();
        
        var newBedsFilter = JSON.stringify(bedsFilter);
        newBedsFilter = newBedsFilter.replace(',', ' .');
        newBedsFilter = newBedsFilter.replace('[', '');
        newBedsFilter = newBedsFilter.replace(']', '');
        newBedsFilter = '.' + newBedsFilter.replace(/"/g, '');
        
        var newcityFilter = JSON.stringify(cityFilter);
        newcityFilter = newcityFilter.replace(',', '.');
        newcityFilter = newcityFilter.replace('[', '');
        newcityFilter = newcityFilter.replace(']', '');
        newcityFilter = '.' + newcityFilter.replace(/"/g, '');
          
        //jQuery('.fgpsn-unit-archive-display').css('display', 'none');
        jQuery('.fgpsn-unit-archive-display').css('display', 'none');
        
        if ( bedsFilter===null) { 
          //alert(typeof(newBedsFilter) + ': ' + newBedsFilter);
          //alert(jQuery(newBedsFilter));
          jQuery(newcityFilter).css('display', 'block');
        } else {
  
          var showcombined = newBedsFilter + newcityFilter;
          //alert(jQuery(showcombined));
          jQuery(showcombined).css('display', 'block'); 
          
        }       
        
        var resetDisplay = function () {
        var filterResults;
        filterResults = 0;
        jQuery('.fgpsn-unit-archive-display').each(function( index ) {
            
            
            if (jQuery( this ).css('display') === 'block')  {
              filterResults = 1;
            } 
          });
          //alert(filterResults);
          return filterResults;
        }

        var yesorno = resetDisplay();
        //alert('checker ' + yesorno);
        //alert(citymessage.length);
        var doublechecker = citymessage.length;
        var otherchecker = bedsmessage.length;
        jQuery('.filter-message').empty();
        //alert('checker ' + doublechecker + ': ' + otherchecker + ': ' + filterResults);
        if ( otherchecker > 0 && doublechecker > 0 ){ 
          
                  if ( yesorno === 0 ) {
            var filterMessage = 'There are no available <b>' + bedsmessage + '</b> units in <b>' + citymessage + '</b>.';
          } else {
                    var filterMessage = 'Viewing available <b>' + bedsmessage + '</b> units in <b>' + citymessage + '</b>.';
                  }
                } else if( otherchecker > 0 && doublechecker == 0 ){
                  if ( yesorno === 0 ) {
            var filterMessage = 'There are no available <b>' + bedsmessage + '</b> units in any locations.';
          } else {
            var filterMessage = 'Viewing available <b>' + bedsmessage + '</b> units in all locations.';
          }
                } else if( otherchecker == 0 && doublechecker > 0 ){
                  if ( yesorno === 0 ) {
            var filterMessage = 'There are no available units in <b>' + citymessage + '</b>.';
          } else {
            var filterMessage = 'Viewing available units in <b>' + citymessage + '</b>.';
          }
                }
               filterMessage = filterMessage + '<div class="clear-filter-button">Clear Filters</div>';



            jQuery('.filter-message').append(filterMessage);
                
           });
    



    jQuery('.filter-message').click(function() {
        jQuery('.property-beds-filter').val('');
        jQuery('.property-city-filter').val('');
        jQuery('.fgpsn-unit-archive-display').css('display', 'block');
        jQuery('.filter-message').empty();
        filterMessage = 'Currently viewing all available units.<div class="clear-filter-button">Clear Filters</div>';
              jQuery('.filter-message').append(filterMessage);

        });



    jQuery('.show-location-map').on('change', function () {
       var divstart = jQuery('.show-location-map').val();
       var divstatus = jQuery('.unit-archive-location-map-' + divstart).css('display');
      
      if( jQuery('.unit-archive-location-map-' + divstart).css('display') === 'none' ) {
         jQuery('.unit-archive-location-map-' + divstart).css('display', 'block');
       } else if( jQuery('.unit-archive-location-map-' + divstart).css('display') === 'block' ) {
         jQuery('.unit-archive-location-map-' + divstart).css('display', 'none');
      }

    
    });


// inpage navigation for property and unit data - displayed in sidebar.php

jQuery('.fgpsn-prop-nav').click(function () {
       var status = jQuery(this).attr('id');

var n = status.lastIndexOf("-");
var new_status = status.substring(0, n);
var use_val = status.substring(n+1, status.length);

       
        if (new_status == 'fgpsn-property-specs') {
          var useFunc = 'getPropSpecTemplate';
          var appendage = 'Specification Sheet'
        }
        if (new_status == 'fgpsn-property-data') {
          var appendage = 'Data Sheet'
          var useFunc = 'getUnitTemplatePriv';
        }
        if (new_status == 'fgpsn-property-vendors') {
          var appendage = 'Property Vendors'
          var useFunc = 'getPropVendorList';
        }
        if (new_status == 'fgpsn-property-contacts') {
          var appendage = 'Unit and Property Contacts'
          var useFunc = 'fgpsnTenantSummaryTable';
        }
        if (new_status == 'fgpsn-property-docs') {
          var appendage = 'Property Documents'
          var useFunc = 'getPropertyDocuments';
        }
        if (new_status == 'fgpsn-property-wo-history') {
          var appendage = 'Property Maintenance History'
          var useFunc = 'getWoHistTemplate';
        }





        
         //alert(useFunc + ',  ' + use_val);
                jQuery.ajax({
                type: 'POST',
                url: 'http://themetest.fgpsn.com/wp-admin/admin-ajax.php',
                data: { useID: use_val, action: useFunc },
                dataType: 'text',
                success: function(data){
                    propertyMenu = data.slice(0, -1);//mystery 0 trailing this! 
                    jQuery('#main > h1').replaceWith( '<h1 class="page-title">Unit Profile - <span style="font-weight=.8;">' + appendage + '</span></h1>');                   
                    jQuery('.fgpsn-property-data-display').replaceWith(propertyMenu);
                    
                    jQuery('.fgpsn-prop-nav').css('backgroundColor', '');//726E85
                    jQuery('#'+status).css('backgroundColor', '#627a76');
                    //jQuery('#'+status).css('backgroundColor', 'red');

              
                },

            });
    
    });

  });
