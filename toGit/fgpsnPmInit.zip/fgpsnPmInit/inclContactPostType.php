<?PHP

/******************************************************
 * DG Creating Contacts post type and meta boxes: Contacts and metaoxes dependent on other coustom post types or taxonomies.
*******************************************************/

/* Create the post and Taxonomies */
function custom_post_contact_data() {

		$labels = array(
			'name'               => _x( 'Contacts', 'post type general name' ),
			'singular_name'      => _x( 'Contact', 'post type singular name' ),
			'add_new'            => _x( 'Add Contact', 'contact_data' ),
			'add_new_item'       => __( 'Add New Contact' ),
			'edit_item'          => __( 'Edit Contact' ),
			'new_item'           => __( 'New Contact' ),
			'all_items'          => __( 'All Contacts' ),
			'view_item'          => __( 'View Contact' ),
			'search_items'       => __( 'Search Contacts' ),
			'not_found'          => __( 'No Contacts Found' ),
			'not_found_in_trash' => __( 'No Contacts found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Contacts'
		);

		$args = array(
			'labels'        => $labels,
			'description'   => 'Holds our Contact Data',
			'public'        => true,
			'menu_position' => 6,
			'supports'      => array( 'author', 'revisions', 'page-attributes', 'thumbnail', 'post_formats', 'comments', 'custom-fields'),
			'taxonomies'      => array( 'contact_data_types', 'post_tag', 'employee_titles' ),
			'hierarchical' => true,
			'has_archive'   => true
		);

	register_post_type( 'contact_data', $args );
}
add_action( 'init', 'custom_post_contact_data' );
//wp_insert_term( 'post-format-directory', 'post_format' );
add_theme_support( 'post-formats', array( 'post-format-directory', 'directory' ) );

/* add contact types taxonomy */
function create_contact_data_types() {
	
	$labels = array(
    'name' => _x( 'Contact Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Contact Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Contact Types' ),
    'all_items' => __( 'All Contact Types' ),
    'parent_item' => __( 'Parent Contact Type' ),
    'parent_item_colon' => __( 'Parent Contact Type:' ),
    'edit_item' => __( 'Edit Contact Type' ),
    'update_item' => __( 'Update Contact Type' ),
    'add_new_item' => __( 'Add New Contact Type' ),
    'new_item_name' => __( 'New Contact Type Name' ),
  );

  register_taxonomy('contact_data_types','contact_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_contact_data_types' );


/* add Vendor Services taxonomy - use to create a two tier hierarchy Prop/CS>Services 
function create_vendor_services() {
 $labels = array(
    'name' => _x( 'Vendor Services', 'taxonomy general name' ),
    'singular_name' => _x( 'Vendor Service', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Services' ),
    'all_items' => __( 'All Services' ),
    'parent_item' => __( 'Vendor Type' ),
    'parent_item_colon' => __( 'Vendor Type:' ),
    'edit_item' => __( 'Edit Service' ),
    'update_item' => __( 'Update Service' ),
    'add_new_item' => __( 'Add New Service' ),
    'new_item_name' => __( 'New Service' ),
  );

  register_taxonomy('vendor_services','contact_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_vendor_services' );
*/

/******************************************************************************
Adding meta boxes.
Get their property information from the Property Post Type.
Set up the meta data keys here then reference them via GF in the front end.
******************************************************************************/

/* First set up name, address, phone, etc. */
/* The first meta box is for all contact types

 $screens = array( 'post', 'page' );
    foreach ($screens as $screen) {
        add_meta_box(
            'myplugin_sectionid',
            __( 'My Post Section Title', 'myplugin_textdomain' ),
            'myplugin_inner_custom_box',
            $screen
        );

        */

add_action( 'add_meta_boxes', 'contact_first_name' );
function contact_first_name() {

	$screens = array( 'contact_data', 'employee_data' );
    foreach ($screens as $screen) {
		add_meta_box(
			'contact_first_name',
			__( 'Contact Information', 'myplugin_textdomain' ),
			'contact_first_name_content',
			$screen,
			'normal',
			'high'
		);
	}
}



function contact_first_name_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'contact_first_name_content_nonce' );

	$fgpsn_contact_first_name = get_post_meta(get_the_ID(), 'fgpsn_contact_first_name', true);
	$fgpsn_contact_last_name = get_post_meta(get_the_ID(), 'fgpsn_contact_last_name', true);
	$fgpsn_contact_title_role = get_post_meta(get_the_ID(), 'fgpsn_contact_title_role', true);

	$fgpsn_contact_phone = get_post_meta(get_the_ID(), 'fgpsn_contact_phone', true);
	$fgpsn_contact_email = get_post_meta(get_the_ID(), 'fgpsn_contact_email', true);
	$fgpsn_contact_cell_phone = get_post_meta(get_the_ID(), 'fgpsn_contact_cell_phone', true);
	$fgpsn_contact_address_1 = get_post_meta(get_the_ID(), 'fgpsn_contact_address_1', true);
	$fgpsn_contact_address_2 = get_post_meta(get_the_ID(), 'fgpsn_contact_address_2', true);
	$fgpsn_contact_city = get_post_meta(get_the_ID(), 'fgpsn_contact_city', true);
	$fgpsn_contact_state = get_post_meta(get_the_ID(), 'fgpsn_contact_state', true);
	$fgpsn_contact_zip = get_post_meta(get_the_ID(), 'fgpsn_contact_zip', true);
	$fgpsn_property_hmy = get_post_meta(get_the_ID(), 'fgpsn_property_hmy', true);
//$fgpsn_contact_property_id = get_post_meta(get_the_ID(), 'fgpsn_contact_property_id', true);
	
	echo '<FIELDSET>
	<H3>Title: '. get_the_title($post->ID) .'</H3>
	<H3>Title: '. the_title() .'</H3>
	<H3>Title: '. $post->ID .'</H3>

	<P><label for="fgpsn_contact_first_name">First Name</label>
	<input id="fgpsn_contact_first_name" name="fgpsn_contact_first_name" value="' . $fgpsn_contact_first_name . '" type="text"></P>

	<P><label for="fgpsn_contact_last_name">Last Name</label>

	<input id="fgpsn_contact_last_name" name="fgpsn_contact_last_name" value="' . $fgpsn_contact_last_name . '" type="text"></P>
	
	<P><label for="fgpsn_contact_contact_title_role">Title*</label>
		<SELECT id="fgpsn_contact_title_role" name="fgpsn_contact_title_role" />';



			echo "<OPTION value=''> - Here - " . $this_count . " </OPTION>\n";

			global $wp_roles;

	if ( ! isset( $wp_roles ) ) {
		$wp_roles = new WP_Roles();
		$roles = $wp_roles->get_names();
	}
		foreach ($wp_roles as $role_name => $role_value) {
		//$choices["Roles"] [] = $role_name . ' | ' . $role_value;
			if ($role_name == 'roles') {
				foreach( $role_value as $k=>$v ) {
					//$choices["Roles"] [] = $v . ' | ' . $k;
					//if ( $v == 'role_names' ) {
						foreach( $v as $k1=>$v1 ) {
							if ( $k1 == 'name' ) {
								
								echo "<OPTION value='" . $v1 . $k . $k1 ."'>" . $v1 . " </OPTION>\n";
							}
						}
						
					//}
				}

			}
	  	}
			echo '</SELECT>

		<P>
		
		

	<P><label for="fgpsn_contact_phone">Phone</label>

	<input id="fgpsn_contact_phone" name="fgpsn_contact_phone" value="' . $fgpsn_contact_phone . '" type="text">

	<label for="fgpsn_contact_email">Email: </label>

	<input id="fgpsn_contact_email" name="fgpsn_contact_email" value="' . $fgpsn_contact_email . '" type="text">

	<label for="fgpsn_contact_cell_phone">Cell: </label>

	<input id="fgpsn_contact_cell_phone" name="fgpsn_contact_cell_phone" value="' . $fgpsn_contact_cell_phone . '" type="text">
	</P>

	</FIELDSET>

	<FIELDSET>

	<P><label for="fgpsn_contact_address_1">Address 1: </label>
		<input id="fgpsn_contact_address_1" name="fgpsn_contact_address_1" size="40" type="text" value="' . $fgpsn_contact_address_1 . '" />

		<P><label for="fgpsn_contact_address_2">Address 2: </label>
		<input id="fgpsn_contact_address_2" name="fgpsn_contact_address_2" size="40" type="text" value="' . $fgpsn_contact_address_2 . '" />

		<P><label for="fgpsn_contact_city">City: </label>
		<input id="fgpsn_contact_city" name="fgpsn_contact_city" size="40" type="text" value="' . $fgpsn_contact_city . '" />

		<P><label for="fgpsn_contact_state">State/Province*</label>
		<SELECT id="fgpsn_contact_state" name="fgpsn_contact_state" />';

			$this_count = count($states_util);

			echo "<OPTION value=''> - Here -" . $this_count . " </OPTION>\n";

			foreach ($states_util as $key => $value) {

				echo "<OPTION value='" . $key . "'>" . $value . "</OPTION>\n";

			}
			echo '</SELECT>

		<P><label for="fgpsn_contact_zip">Zip Code:</label>
		<input id="fgpsn_contact_zip" name="fgpsn_contact_zip" size="40" type="text" value="' . $fgpsn_contact_zip . '" />

	</FIELDSET>';

}


add_action( 'save_post', 'contact_first_name_save' );
function contact_first_name_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['contact_first_name_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$fgpsn_contact_first_name = $_POST['fgpsn_contact_first_name'];
	$fgpsn_contact_last_name = $_POST['fgpsn_contact_last_name'];
	$fgpsn_contact_phone = $_POST['fgpsn_contact_phone'];
	$fgpsn_contact_cell_phone = $_POST['fgpsn_contact_cell_phone'];
	$fgpsn_contact_email = $_POST['fgpsn_contact_email'];
	$fgpsn_contact_address_1 = $_POST['fgpsn_contact_address_1'];
	$fgpsn_contact_address_2 = $_POST['fgpsn_contact_address_2'];
	$fgpsn_contact_city = $_POST['fgpsn_contact_city'];
	$fgpsn_contact_zip = $_POST['fgpsn_contact_zip'];
	$fgpsn_property_hmy = $_POST['fgpsn_property_hmy'];

	//$fgpsn_contact_property_id = $_POST['fgpsn_contact_property_id'];

	$post_title = $fgpsn_contact_first_name . " " . $fgpsn_contact_last_name;

	$user_id = username_exists( $fgpsn_contact_first_name );
	if ( !$user_id && email_exists($fgpsn_contact_email) == false ) {

		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $fgpsn_contact_first_name, $random_password, $fgpsn_contact_email );

		update_user_meta( $user_id, 'fgpsn_contact_data_id', $fgpsn_contact_data_id );
		update_user_meta( $user_id, 'fgpsn_contact_first_name', $fgpsn_contact_last_name );
		update_user_meta( $user_id, 'fgpsn_contact_last_name', $fgpsn_contact_last_name );
		update_user_meta( $user_id, 'fgpsn_contact_phone', $fgpsn_contact_phone );
		update_user_meta( $user_id, 'fgpsn_contact_email', $fgpsn_contact_email );
		update_user_meta( $user_id, 'fgpsn_contact_cell_phone', $fgpsn_contact_cell_phone );
		update_user_meta( $user_id, 'fgpsn_contact_addr1', $fgpsn_contact_address_1 );
		update_user_meta( $user_id, 'fgpsn_contact_addr2', $fgpsn_contact_address_2 );
		update_user_meta( $user_id, 'fgpsn_contact_city', $fgpsn_contact_city );
		update_user_meta( $user_id, 'fgpsn_contact_zip', $fgpsn_contact_zip );
		update_user_meta( $user_id, 'fgpsn_property_hmy', $fgpsn_property_hmy );
		//update_user_meta( $user_id, 'fgpsn_contact_property_id', $fgpsn_contact_property_id );


	} else {
/*
		update_user_meta( $user_id, 'contact_data_id', $contact_data_id );
		update_user_meta( $user_id, 'contact_last_name', $contact_last_name );
		update_user_meta( $user_id, 'client_phone', $client_phone );
		update_user_meta( $user_id, 'client_email', $client_email );
		update_user_meta( $user_id, 'client_cell', $client_cell );

		$random_password = __('User already exists.  Password inherited.');
	*/
	}

	// Update the post into the database
	// wp_update_post( $my_post );


		update_post_meta( $post_id, 'fgpsn_contact_data_id', $fgpsn_contact_data_id );
		update_post_meta( $post_id, 'fgpsn_contact_first_name', $fgpsn_contact_first_name );
		update_post_meta( $post_id, 'fgpsn_contact_last_name', $fgpsn_contact_last_name );
		update_post_meta( $post_id, 'fgpsn_contact_phone', $fgpsn_contact_phone );
		update_post_meta( $post_id, 'fgpsn_contact_email', $fgpsn_contact_email );
		update_post_meta( $post_id, 'fgpsn_contact_cell_phone', $fgpsn_contact_cell_phone );
		update_post_meta( $post_id, 'fgpsn_contact_address_1', $fgpsn_contact_address_1 );
		update_post_meta( $post_id, 'fgpsn_contact_address_2', $fgpsn_contact_address_2 );
		update_post_meta( $post_id, 'fgpsn_contact_city', $fgpsn_contact_city );
		update_post_meta( $post_id, 'fgpsn_contact_zip', $fgpsn_contact_zip );
		update_post_meta( $post_id, 'fgpsn_property_hmy', $fgpsn_property_hmy );
		
	//update_post_meta( $post_id, 'fgpsn_contact_property_id', $fgpsn_contact_property_id );


	//get user id where user_meta_key = contact_data_id and user_meta_value = $post_id
	$args = array(
		'meta_key'     => 'contact_data_id',
		'meta_value'   => $post_id,

	 );

	$blogusers = get_users($args);
	foreach ($blogusers as $user) {
		echo '<li>' . $user->user_email . '</li>';
    }

	if ( ! wp_is_post_revision( $post_id ) ){

		$my_post = array();
		$my_post['ID'] = $post_id;
		$my_post['post_title'] = $post_title;

		// unhook this function so it doesn't loop infinitely
		remove_action('save_post', 'contact_first_name_save');

		// update the post, which calls save_post again
		wp_update_post( $my_post );

		// re-hook this function
		add_action('save_post', 'contact_first_name_save');

	}

}

/******************************************************************************
*Begin adding contact type specific meta boxes
******************************************************************************/




/* Below is for Client Specific Information */


add_action( 'add_meta_boxes', 'client_data' );
add_action( 'save_post', 'client_data_save' );

function client_data() {

	/*$terms = get_the_terms( $post->ID, 'contact_data_types' );

	if ( $terms && ! is_wp_error( $terms ) ) :

		//check that they are employees before adding the metaboxes
		$draught_links = array();
		foreach ( $terms as $term ) {
			$contact_terms[] = $term->name;
			if ($term->name == 'Clients' || $term->name == 'Owner' || $term->name == 'Occupant' || $term->name == 'Trustee' || $term->name == 'Tenant') {

				add_meta_box(
					'client_data',
					__( 'Client Property Data', 'myplugin_textdomain' ),
					'client_data_content',
					'contact_data',
					'normal',
					'high'
				);

			}
		}//end foreach

	 endif;*/
	 add_meta_box(
					'client_data',
					__( 'Client Property Data', 'myplugin_textdomain' ),
					'client_data_content',
					'contact_data',
					'normal',
					'high'
				);

}

function client_data_content( $post ) {

	$original_id = get_the_ID();
	wp_nonce_field( plugin_basename( __FILE__ ), 'client_data_content_nonce' );
	
	$fgpsn_contact_address_1 = get_post_meta(get_the_ID(), 'fgpsn_contact_address_1', true);
	$fgpsn_client_property_id = get_post_meta(get_the_ID(), 'fgpsn_client_property_id', true);
	//getting the property ID
	global $wpdb;
	$args = array(
        'post_type' => 'properties',
        'nopaging'	=> 'true',
        'meta_query' => array(
                    array(
                        'key' => 'fgpsn_property_address_1',
                        'value' => $fgpsn_contact_address_1
                        
                    )
                )
        );
	
     /*$my_query = new WP_Query( $args );
    if ( $my_query->have_posts() ) : while ( $my_query->have_posts() ) : $my_query->the_post();
         //$fgpsn_client_property_id = get_the_ID();
     endwhile;
	 wp_reset_postdata();
	 endif;
	 */
	
	$fgpsn_client_property_address_1 = get_post_meta($fgpsn_client_property_id, 'fgpsn_property_address_1', true);
	$fgpsn_client_property_address_2 = get_post_meta($fgpsn_client_property_id, 'fgpsn_property_address_2', true);
	$fgpsn_client_property_city = get_post_meta($fgpsn_client_property_id, 'fgpsn_property_city', true);
	$fgpsn_client_property_state = get_post_meta($fgpsn_client_property_id, 'fgpsn_property_state', true);
	$fgpsn_client_property_zip = get_post_meta($fgpsn_client_property_id, 'fgpsn_property_zip', true);
	
	echo '<P><label for="fgpsn_client_property_id">Client Properties</label>';
	//the_meta();
	echo '<SELECT id="fgpsn_client_property_id" name="fgpsn_client_property_id" disabled>
		<OPTION> -- Select Unit -- </OPTION>';
	

	$args = array( 'post_type' => 'properties',
					'post_status'=> 'publish',
					'nopaging' => 'true' );

	$properties = get_posts( $args );
	foreach ( $properties as $property ) : setup_postdata( $property );
		$addr1 = get_post_meta( $property->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $property->ID, 'fgpsn_property_city', true);
		$property_name = $addr1 . ', ' .  $city;
		
		echo '<OPTION VALUE="' . $property->ID . '"';
		if ( $property->ID == $fgpsn_client_property_id) {

			echo ' SELECTED';

		}
		echo '>' . $property_name . ', ' . $fgpsn_client_property_id . '</OPTION>';
	endforeach; 
	wp_reset_postdata();

	echo '</SELECT>';

	echo '<P><label for="client_city">City</label>
	<input id="client_city" name="client_city" value="' . $fgpsn_client_property_city . '" type="text" disabled>

	<label for="client_state">State: </label>
	<input id="client_state" name="client_state" value="' . $fgpsn_client_property_state . '" type="text" disabled>

	<label for="client_zip">Zip: </label>
	<input id="client_zip" name="client_zip" value="' . $fgpsn_client_property_zip . '" type="text" disabled></LI>';





echo '<P><label for="fgpsn_contact_unit_id">Client Unit</label>';
	$themevalues = get_post_meta($original_id);
	$cur_unit =  $themevalues;
	foreach ( $themevalues['fgpsn_contact_unit_id'] as $k=>$v ){
		$trythis = unserialize($v);
		foreach ( $trythis as $k1=>$v1 ){
			echo '<h1>k1 ' . $k1 . ' - ' . $v1 . '</h1>';
		}
		
	}
	echo '<h3>HERE ' . $cur_unit . '</h3>';
	echo '<SELECT multiple id="fgpsn_contact_unit_id" name="fgpsn_contact_unit_id[]" SIZE=5 HEIGHT=5>
		<OPTION> -- Select Unit -- </OPTION>';
	

	$args = array( 'post_type' => 'unit_data',
					'post_status'=> 'publish',
					'nopaging' => 'true' );

	$units = get_posts( $args );
	foreach ( $units as $unit ) : setup_postdata( $unit );
		$addr1 = get_post_meta( $unit->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $unit->ID, 'fgpsn_property_city', true);
		$property_name = $addr1 . ', ' .  $city;
		
		echo '<OPTION VALUE="' . $unit->ID . '"';
		if ( $unit->ID == $trythis || in_array($unit->ID, $trythis)) {

			echo ' SELECTED';

		}
		echo '>' . $unit->post_title . ', ' . $trythis . ' || ' . $original_id . '</OPTION>';
	endforeach; 
	wp_reset_postdata();
echo '</SELECT>';
	
	echo '</FIELDSET>';






/*


get meta_value from unit_data where meta key = fgpsn_property_unit_occupant_id

contact post_id = get_post_meta( , fgpsn_property_unit_occupant_id, true);

*/



















}



function client_data_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['client_data_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	//$fgpsn_client_property_id = $_POST['fgpsn_client_property_id'];
	


	// Update the post into the database
	// wp_update_post( $my_post );

	//echo '<H3>Post ID: ' . $post_id . '<br>fgpsn_client_property_id: ' . $_POST['fgpsn_client_property_id'] . '</h3>';
//update_post_meta( $post_id, 'fgpsn_client_property_id', $_POST['fgpsn_client_property_id'] );
	if (update_post_meta( $post_id, 'fgpsn_client_property_id', $_POST['fgpsn_client_property_id'] ) ) {
		
	} else {

	}
	update_post_meta( $post_id, 'fgpsn_contact_property_id', $_POST['fgpsn_contact_property_id'] );
	
	update_user_meta( $user_id, 'fgpsn_client_property_id', $_POST['fgpsn_client_property_id'] );
	update_user_meta( $user_id, 'fgpsn_contact_property_id', $_POST['fgpsn_client_property_id'] );


	//for the unit datafgpsn_property_unit_occupant_id
	//global $wpdb;

	//first get all the occupanats of the current unint and remove this from the array

	$oocids = get_post_meta($post_id, 'fgpsn_property_unit_occupant_id', true);




	foreach($_POST['fgpsn_contact_unit_id'] as $k2=>$v2) {
		//echo $k2 . ', ' . $v2 . ', ' . $post_id . '<br>';
		$didit = update_post_meta($v2, 'fgpsn_property_unit_occupant_id', $post_id);
	}

//echo $_POST['fgpsn_contact_unit_id'] . $post_id . $didit;
}

/*shortcode for Employee Directory*/

function fgpsnEmployeeSummaryTable( $atts ){
	global  $disp_data;
	/*wp_enqueue_script('fgpsndatatablemin','http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery-1.11.1.min.js', array(),  true );
	 * */
   /*wp_enqueue_script('fgpsndatatables', 'http://www.apexpropertymanagement-me.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );
   wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );*/
   
	$fgpsn_table_display_script .=  "<script>
		jQuery(document).ready(function() {
			jQuery('#employee_summary_table').dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );
		} );

	</SCRIPT>";


	employeeData();
	return $disp_data . $fgpsn_table_display_script;
	//echo $disp_data;
}
add_shortcode( 'fgpsn_employee_summary_table', 'fgpsnEmployeeSummaryTable' );

/* shortcode for tenant directory */
function fgpsnTenantSummaryTable( $atts ){
	global  $disp_data;
	/*wp_enqueue_script('fgpsndatatablemin','http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery-1.11.1.min.js', array(),  true );
	 * */
  /* wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );
   wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );*/
   
	$fgpsn_table_display_script .=  "<script>
		jQuery(document).ready(function() {
			jQuery('#tenant_summary_table').dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );
		} );

	</SCRIPT>";


	tenantDataTable( $property_id );
	return $disp_data . $fgpsn_table_display_script;
	//echo $disp_data;
}
add_shortcode( 'fgpsn_tenant_summary_table', 'fgpsnTenantSummaryTable' );

function fgpsnTenantSummaryTable_fn( $atts ){
	global  $disp_data;
	/*wp_enqueue_script('fgpsndatatablemin','http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery-1.11.1.min.js', array(),  true );
	 * */
  /* wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );
   wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );*/
   
	global $wpdb;
	global $current_user;
	global $table_prefix;
	global $disp_data;
	get_currentuserinfo();


	/* wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );
   wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );*/


$disp_data = "<link rel='stylesheet' id='fgpsn-temp'  href='//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css' type='text/css' media='all' />";

$disp_data .= "<script type='text/javascript' src='cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js'></script>
<script>
		jQuery(document).ready(function() {
			jQuery('#tenant_summary_table').dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );
		} );

	</SCRIPT>";
	//$blog_details = get_blog_details();
	$disp_data .= '<div class="fgpsn-property-data-display"><TABLE  id="wo_summary_table" class="display" cellspacing="0"  ><thead>
				<tr>
					<th>Name</th>
					<th>Address</th>
					<th>Contact Data</th>
					
					<th>Open</th>
				</tr>
			</thead>
					<tbody>';
	
	if ( isset( $prop_id ) && $prop_id != '' ) {
		$emp_list = get_posts( array('post_type' => 'contact_data',
							'post_status' => 'publish',
							'meta_query' => array(
								array(
									'key'     => 'fgpsn_client_property_id',
									'value'   => $prop_id ,
									'compare' => '=',
								),
							),

							'nopaging' => true) );

	} else {
	$emp_list = get_posts( array('post_type' => 'contact_data',
							'post_status' => 'publish',
							'nopaging' => true) );
	}
	foreach ( $emp_list as $post ) : setup_postdata( $post ); 
		
		$fgpsn_client_property_id = get_post_meta( $post->ID, 'fgpsn_client_property_id', true );
		$tenant_ids = get_post_meta( $fgpsn_client_property_id, 'fgpsn_property_unit_occupant_id', true);
	
	/*
		$args = array(
	'post_type'  => '',
	'meta_key'   => 'fgpsn_property_id',
	'orderby'    => 'title',
	'order'      => 'ASC',
	'post_status'      => 'publish',
	'meta_query' => array(
			array(
				'key'     => 'fgpsn_property_id',
				'value'   => $fgpsn_client_property_id,
				'compare' => '=',
			),
		),
	);
	$units = new WP_Query( $args );
	$items[] = array("text" => " -- Selected Units -- ", "value" => "");
	while( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_ID(), "text" => get_the_title());
	}


	*/

	if( $fgpsn_client_property_id != '' ) {
		$disp_data .= "<tr><td>" . $post->post_title . "</td>
				<td>" . get_the_title( $fgpsn_client_property_id ) . "</td>
					<td>Phone: " . get_post_meta( $post->ID, 'fgpsn_contact_phone', true ) . "
					<br>
					Email: " . get_post_meta( $post->ID, 'fgpsn_contact_email', true ) . "
					<br>
					Cell: " . get_post_meta( $post->ID, 'fgpsn_contact_cell_phone', true ) . "
					</td>
					<td><A HREF='" . get_the_permalink($post->ID) . "'>View</A>";

if( $cur_role != ''){if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
	$disp_data .= "<A HREF=/add-contacts/?gform_post_id='" . $post->ID . "'>Edit</A>";
}
}
					$disp_data .= "</td>";

					$disp_data .= "</TR>";
	}
					
	endforeach;
	wp_reset_postdata();
	$disp_data .= "</tbody>
	<tfoot>
				<tr>
					<th>Name</th>
					<th>Address</th>
					<th>Contact Data</th>
					
					<th>Open</th>
				</tr>
			</foot>
		</table></div>";
	
    //echo $disp_data;
    //return $disp_data;
	echo $disp_data;
	//echo $disp_data;
}
add_action('wp_ajax_fgpsnTenantSummaryTable', 'fgpsnTenantSummaryTable_fn');
add_action('wp_ajax_nopriv_fgpsnTenantSummaryTable', 'fgpsnTenantSummaryTable_fn');

/* employee directory
 */
function tenantDataTable( $prop_id ) {
	
	global $wpdb;
	global $current_user;
	global $table_prefix;
	global $disp_data;
	get_currentuserinfo();


	 /*wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );
   wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );*/

	//$blog_details = get_blog_details();
	$disp_data = '<div class="fgpsn-property-data-display">CCCC<TABLE id="tenant_summary_table" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Name</th>
					<th>Address</th>
					<th>Contact Data</th>
					
					<th>Open</th>
				</tr>
			</thead>
					<tbody>';
	
	if ( isset( $prop_id ) && $prop_id != '' ) {
		$emp_list = get_posts( array('post_type' => 'contact_data',
							'post_status' => 'publish',
							'meta_query' => array(
								array(
									'key'     => 'fgpsn_client_property_id',
									'value'   => $prop_id ,
									'compare' => '=',
								),
							),

							'nopaging' => true) );

	} else {
	$emp_list = get_posts( array('post_type' => 'contact_data',
							'post_status' => 'publish',
							'nopaging' => true) );
	}
	foreach ( $emp_list as $post ) : setup_postdata( $post ); 
		
		$fgpsn_client_property_id = get_post_meta( $post->ID, 'fgpsn_client_property_id', true );
		$tenant_ids = get_post_meta( $fgpsn_client_property_id, 'fgpsn_property_unit_occupant_id', true);
	
	/*
		$args = array(
	'post_type'  => '',
	'meta_key'   => 'fgpsn_property_id',
	'orderby'    => 'title',
	'order'      => 'ASC',
	'post_status'      => 'publish',
	'meta_query' => array(
			array(
				'key'     => 'fgpsn_property_id',
				'value'   => $fgpsn_client_property_id,
				'compare' => '=',
			),
		),
	);
	$units = new WP_Query( $args );
	$items[] = array("text" => " -- Selected Units -- ", "value" => "");
	while( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_ID(), "text" => get_the_title());
	}


	*/

	if( $fgpsn_client_property_id != '' ) {
		$disp_data .= "<tr><td>" . $post->post_title . "</td>
				<td>" . get_the_title( $fgpsn_client_property_id ) . "</td>
					<td>Phone: " . get_post_meta( $post->ID, 'fgpsn_contact_phone', true ) . "
					<br>
					Email: " . get_post_meta( $post->ID, 'fgpsn_contact_email', true ) . "
					<br>
					Cell: " . get_post_meta( $post->ID, 'fgpsn_contact_cell_phone', true ) . "
					</td>
					<td><A HREF='" . get_the_permalink($post->ID) . "'>View</A>";

if( $cur_role != ''){if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
	$disp_data .= "<A HREF=/add-contacts/?gform_post_id='" . $post->ID . "'>Edit</A>";
}
}
					$disp_data .= "</td>";

					$disp_data .= "</TR>";
	}
					
	endforeach;
	wp_reset_postdata();
	$disp_data .= "</tbody>
	<tfoot>
				<tr>
					<th>Name</th>
					<th>Address</th>
					<th>Contact Data</th>
					
					<th>Open</th>
				</tr>
			</foot>
		</table></div>";
	
    //echo $disp_data;
    return $disp_data;
}


/*Manage custom post type columns*/

//add_filter('manage_edit-contact_data_columns', 'add_edit_contact_data_columns');

function add_edit_contact_data_columns($contact_data_columns) {
    
    $new_columns['id'] = '<input type="checkbox" />';
    
    $new_columns['title'] = _x( 'Display Name' );
    $new_columns['contact_data'] = _x( 'Contact Info.' );
    $new_columns['fgpsn_contact_last_name'] = _x( 'Name' );
    $new_columns['fgpsn_client_property_id'] =  __('Property', 'column name');

    return $new_columns;
}



//add_action('manage_contact_data_posts_custom_column', 'manage_contact_data_columns', 10, 2);
function manage_contact_data_columns($column_name, $id) {
  

    switch ($column_name) {
		case 'id':
			echo $column_name;
				break;

		case 'title':
			echo $title;
				break;
			
		case 'fgpsn_contact_last_name':
			// tenants
			$contact_fn = get_post_meta( $id, 'fgpsn_contact_first_name', true );
			$contact_ln = get_post_meta( $id, 'fgpsn_contact_last_name', true );
			echo $contact_ln . ', ' . $contact_fn;
			
			break;

		case 'contact_data':
			// tenants
			
			echo '<b>Email:</b> ' . get_post_meta( $id, 'fgpsn_contact_email', true ) . '<br>';
			echo '<b>Cell:</b> ' . get_post_meta( $id, 'fgpsn_contact_cell_phone', true ) . '<br>';
			echo '<b>Phone:</b> ' . get_post_meta( $id, 'fgpsn_contact_phone', true ) . '<br>';
			
			break;

			// unit
			/* need to find the post id in the meta_key fgpsn_property_unit_occupant_id
			for post type unit_data
			*/

		case 'fgpsn_client_property_id':

			$fgpsn_client_property_id = get_post_meta( $id, 'fgpsn_client_property_id', true );
			echo get_the_title($fgpsn_client_property_id) . ' ' . $fgpsn_client_property_id;
			
			break;




		default:
			break;
    } // end switch
}

/*Make columns sortable*/
add_filter( 'manage_edit-contact_data_sortable_columns', 'bs_contact_data_table_sorting' );
function bs_contact_data_table_sorting( $columns ) {
  $columns['fgpsn_contact_last_name'] = 'fgpsn_contact_last_name';
  $columns['fgpsn_client_property_id'] = 'fgpsn_client_property_id';
  return $columns;
}

/*Set sorting parameters
THIS NEEDS TO BE SET INDIVIDUALLY FOR EACH SORTABLE COLUMN DESCRIBED ABOVE*/
add_filter( 'request', 'bs_name_column_orderby' );
function bs_name_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'fgpsn_contact_last_name' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'fgpsn_contact_last_name',
            'orderby' => 'meta_value'
        ) );
    }

    return $vars;
}


add_filter( 'request', 'bs_property_column_orderby' );
function bs_property_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'fgpsn_client_property_id' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'fgpsn_client_property_id',
            'orderby' => 'meta_value'
        ) );
    }

    return $vars;
}



















//add_action('quick_edit_custom_box',  'shiba_add_quick_edit1', 10, 2);
 
function shiba_add_quick_edit1($column_name, $post_type,  $id) {
    if ($column_name != 'fgpsn_client_property_id') return;
    ?>
    <fieldset class="inline-edit-col-left">
    <div class="inline-edit-col">
        <span class="title">Widget Set</span>
        <input type="hidden" name="shiba_widget_set_noncename" id="shiba_widget_set_noncename" value="" />
        <?php $fgpsn_client_property_id = get_post_meta(get_the_ID(), 'fgpsn_client_property_id', true);
    echo "<h3>CN " . get_the_ID() . "</h3>";// Get all widget sets
            $widget_sets = get_posts( array( 'post_type' => 'widget_set',
                            'numberposts' => -1,
                            'post_status' => 'publish') );
        ?>
        <select name='post_widget_set' id='post_widget_set'>
            <option class='widget-option' value='0'>None</option>
            <?php 
            foreach ($widget_sets as $widget_set) {
                echo "<option class='widget-option' value='{$widget_set->ID}'>{$widget_set->post_title}</option>\n";
            }
                ?>
        </select>
    </div>
    </fieldset>
    <?php
}



// Add to our admin_init function
//add_action('quick_edit_custom_box',  'fgpsn_add_quick_edit', 10, 2);
 
function fgpsn_add_quick_edit( $column_name, $post_type ) {
    if ($column_name != 'fgpsn_client_property_id') return;

    $fgpsn_client_property_id = get_post_meta(get_the_ID(), 'fgpsn_client_property_id', true);
    echo "<h3>CN " . $id . "</h3>";
    ?>
    <div class="inline-edit-col">
        <input type="hidden" name="fgpsn_widget_set_noncename" id="fgpsn_widget_set_noncename" value="" />
        <?php 
        
       echo '<SELECT id="fgpsn_client_property_id" name="fgpsn_client_property_id" >
		<OPTION> -- Select Unit -- </OPTION>';
	

	$args = array( 'post_type' => 'properties',
					'post_status'=> 'publish',
					'nopaging' => 'true' );

	$properties = get_posts( $args );
	foreach ( $properties as $property ) : setup_postdata( $property );
		$addr1 = get_post_meta( $property->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $property->ID, 'fgpsn_property_city', true);
		$property_name = $addr1 . ', ' .  $city;
		
		echo '<OPTION VALUE="' . $property->ID . '"';
		if ( $property->ID == $fgpsn_client_property_id) {

			echo ' SELECTED';

		}
		echo '>' . $property_name . ', ' . $fgpsn_client_property_id . '</OPTION>';
		wp_reset_postdata();
	endforeach; 
	

	echo '</SELECT>';






        ?>
    </div>
    
    <?php
}



// Add to our admin_init function
//add_action('save_post', 'fgpsn_save_quick_edit_data');
 
function fgpsn_save_quick_edit_data($post_id) {
	
    // verify if this is an auto save routine. If it is our form has not been submitted, so we dont want
    // to do anything
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
        return $post_id;    
    // Check permissions
    if ( 'page' == $_POST['post_type'] ) {
        if ( !current_user_can( 'edit_page', $post_id ) )
            return $post_id;
    } else {
        if ( !current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    }   
    // OK, we're authenticated: we need to find and save the data
    $post = get_post($post_id);
    if (isset($_POST['fgpsn_client_property_id']) && ($post->post_type != 'revision')) {
        $fgpsn_property_id_set_id = esc_attr($_POST['fgpsn_client_property_id']);
        if ($fgpsn_property_id_set_id)
            update_post_meta( $post_id, 'fgpsn_client_property_id', $fgpsn_property_id_set_id);     
        else
            delete_post_meta( $post_id, 'fgpsn_client_property_id');     
    
			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'fgpsn_save_quick_edit_data');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'fgpsn_save_quick_edit_data');
    
    }       
    return $fgpsn_property_id_set_id;  

}


?>
