<?PHP

class fgpsn_related_unit_data extends WP_Widget {

	function fgpsn_related_unit_data() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-related-unit-data', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows unit data relative to the current post or page. Such as contacts, vendors, or warranties alongside a work order.', 'fgpsn-related-unit-data' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnrelatedunitdata', __( 'Related Unit Data', 'fgpsn-related-unit-data' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );


		$parameters = array(
				'title' 	=> $title,
				'fgpsn_wo_vendors' 	=> $instance[ 'fgpsn_wo_vendors'],
				'fgpsn_wo_show_map' 	=> $instance[ 'fgpsn_show_wo_map'],
				'fgpsn_wo_contacts' 	=> $instance[ 'fgpsn_wo_contacts'],
			);

		if ( !empty( $title ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}

        //print recent posts
		fgpsn_get_related_unit_data($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['fgpsn_wo_vendors'] = $new_instance['fgpsn_wo_vendors'];
		$instance['fgpsn_wo_show_map'] = $new_instance['fgpsn_wo_show_map'];
		$instance['fgpsn_wo_contacts'] = $new_instance['fgpsn_wo_contacts'];
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsn_related_unit_data_defaults() );

		$title 		= esc_attr($instance['title']);
		$fgpsn_wo_vendors 	= $instance['fgpsn_wo_vendors'];
		$fgpsn_wo_show_map = $instance['fgpsn_wo_vendors'];
		$fgpsn_wo_contacts 	= $instance['fgpsn_wo_contacts'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>"
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('fgpsn_wo_vendors'); ?>"><?php _e('Show Vendors');?>
				<input class="widefat" id="<?php echo $this->get_field_id('api_key'); ?>" name="<?php echo $this->get_field_name('fgpsn_wo_vendors'); ?>" type="checkbox" value="1"><?php echo $fgpsn_wo_vendors; ?>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('fgpsn_wo_show_map'); ?>"><?php _e('Show On Map');?>
				<input class="widefat" id="<?php echo $this->get_field_id('fgpsn_wo_show_map'); ?>" name="<?php echo $this->get_field_name('fgpsn_wo_show_map'); ?>" type="checkbox" value="1"><?php echo $fgpsn_wo_show_map; ?>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('fgpsn_wo_contacts'); ?>"><?php _e('Show Vendors');?>
				<input class="widefat" id="<?php echo $this->get_field_id('fgpsn_wo_contacts'); ?>" name="<?php echo $this->get_field_name('fgpsn_wo_contacts'); ?>" type="checkbox" value="1"><?php echo $fgpsn_wo_contacts; ?>
			</label>
		</p>

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_related_unit_data");') );


function fgpsn_get_related_unit_data($args = '', $echo = true) {

	global $wpdb;
	global $fgpsn_array_of_wo_ids;
	global $disp_data_wo_sidebar;
	echo $disp_data_wo_sidebar;
	$defaults = fgpsn_related_unit_data_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);


   

    echo '<div><TABLE id="wo_summary_table_sidebarccc" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Lable</th>
					<th>Data</th>
					
				</tr>
			</thead>
						<TBODY>';
    //echo '<table>IDs ' . $fgpsn_array_of_wo_ids . '</H2>';
    if(is_array($fgpsn_array_of_wo_ids)) {
    	 foreach( $fgpsn_array_of_wo_ids as $k=>$v ) {
    	 	echo '<tr><td>ID ' . $k . '</td><td>V: ' . $v . '</td></tr>';
    	 }
    }

	echo "</tbody><tfoot>
				<tr>
					<th>Label</th>
					<th>Data</th>
					
				</tr>
			</foot></table>";
    //first get contacts related to wo units and wos
    //start by doing this for singles

    $filtered_messages = get_posts( array( 'post_type' => 'unit_data' ) );
    // The Query
$the_query = new WP_Query( array( 'post_type' => 'maintenance_requests' ) );

// The Loop
if ( $the_query->have_posts() ) {
	echo '<ul>';
	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		echo '<li>' . get_the_title() . '</li>';
	}
	echo '</ul>';
} else {
	// no posts found
}
/* Restore original Post Data */
wp_reset_postdata();



}
function fgpsn_related_unit_data_defaults() {

	$defaults = array( 	'title' => __( 'Related Unit Data', 'fgpsn-related-unit-data' ),
				'fgpsn_wo_vendors' 	=> '1',
				'fgpsn_wo_show_map' 	=> '1',
				'fgpsn_wo_contacts' 	=> '1', );
	return $defaults;
}

?>
