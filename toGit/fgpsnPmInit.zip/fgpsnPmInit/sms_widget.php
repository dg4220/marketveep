<?PHP

class fgpsn_text_alerts extends WP_Widget {

	function fgpsn_text_alerts() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-text-alerts', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows recent text messages from select numbers.', 'fgpsn-text-alerts' ) );
		//Create widget
		$this->WP_Widget( 'fgpsntextalerts', __( 'Text Alerts', 'fgpsn-text-alerts' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		$before_widget = '<div class="direct-chat-messages">';
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );


		$parameters = array(
				'title' 	=> $title,
				'api_key' 	=> $instance[ 'api_key'],
				'auth_token' 	=> $instance[ 'auth_token'],
				'from_number' 	=> $instance[ 'from_number'],
			);

		if ( !empty( $title ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}

        //print recent posts
		fgpsn_get_text_alerts($parameters);
		$after_widget = '</div>';
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['api_key'] = $new_instance['api_key'];
		$instance['auth_token'] = $new_instance['auth_token'];
		$instance['from_number'] = $new_instance['from_number'];
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsn_text_alert_defaults() );

		$title 		= esc_attr($instance['title']);
		$api_key 	= $instance['api_key'];
		$auth_token = $instance['auth_token'];
		$from_number 	= $instance['from_number'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('api_key'); ?>"><?php _e('API Key:');?>
				<input class="widefat" id="<?php echo $this->get_field_id('api_key'); ?>" name="<?php echo $this->get_field_name('api_key'); ?>" type="text" value="<?php echo $api_key; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('auth_token'); ?>"><?php _e('Token');?>
				<input id="<?php echo $this->get_field_id('auth_token'); ?>" name="<?php echo $this->get_field_name('auth_token'); ?>" type="text" value="<?php echo $auth_token; ?>"  />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('from_number'); ?>"><?php _e('From Number');?>
				<input id="<?php echo $this->get_field_id('from_number'); ?>" name="<?php echo $this->get_field_name('from_number'); ?>" type="text" value="<?php echo $postoffset; ?>" />
			</label>
		</p>

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_text_alerts");') );


function fgpsn_get_text_alerts($args = '', $echo = true) {

	global $wpdb;
	$defaults = fgpsn_text_alert_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);

	if ( !include_once( plugin_dir_path( __FILE__ ) . '/twilio-php-master/Services/Twilio.php' ) )
	{

	echo "<H3>Why Not! - " .plugin_dir_path( __FILE__ ) . '/twilio-php-master/Services/Twilio.php - </H3>';

	}


	$sid = "";
	$token = "";
	$client = new Services_Twilio($sid, $token);

	$http = new Services_Twilio_TinyHttp(
		        'https://api.twilio.com',
		        array('curlopts' => array(CURLOPT_SSL_VERIFYPEER => false))
		    );

    $client = new Services_Twilio('AC73f31202e64ac545fcf2b96d0a3a7b73', 'a7da0165d7ed912c85460a01c7c38454', '2010-04-01', $http);

	$filtered_messages = $client->account->messages->getIterator(
        0, 1, array("To" => "+16174335875"));//16174335875
       
        

    $postlist = '<FORM NAME="replytosms" action="' . network_home_url() . '?property_id=' . $_REQUEST['property_id'] . '" style="position:relative; height: 18em;">';

    $postlist .= '';

    foreach($filtered_messages as $message) {
		
		$clip = substr($message->body, 0, 60 );
		$clip1 = substr( $message->body, 61, 500 );
		
		$smsfrom = str_replace( '+', '', $message->from );

		$smssenders = get_users(array('meta_key' => 'contact_phone', 'meta_value' => $smsfrom, 'meta_compare' => 'like' ));

		$use_query = "SELECT user_id FROM fgpsn_usermeta
						WHERE (meta_key = 'client_phone'
						AND meta_value = '" . $smsfrom . "')
						OR(meta_key = 'contact_phone'
						AND meta_value = '" . $smsfrom . "')
						;";
		$use_ids = $wpdb->get_results($use_query, OBJECT);
		foreach( $use_ids as $use_id ) {
			$smssender = get_user_meta($use_id->user_id, 'nickname', true);
		}
		if ( !$smssender ){
			$postlist .= '<div class="direct-chat-msg"><div class="direct-chat-info clearfix"><span class="direct-chat-name pull-left">Unknown Sender: ' . $smssender;

             $postlist .= '</span><span class="direct-chat-timestamp pull-right">23 Jan 2:00 pm</span></div>';
		} else {

		$postlist .= '<div class="sms-message-details">
    					From: ' . $smssender;
		}
		$postlist .= ' <INPUT class="sms-message-details" TYPE="radio" NAME="message_id" VALUE="';
		$postlist .= $message->sid . '"></div>';

		$postlist .= '<div class="direct-chat-text">';
    	$postlist .= $clip;
    	if ($clip1 != '') {
			$postlist .= '<a class="read-more-show hide" href="#"> . . . Continue</a><span class="read-more-content"> ';
			$postlist .= $clip1;
			$postlist .= '<br><a class="read-more-hide hide" href="#">Show Less</a></span>';
		}
    	
    	$postlist .= '';
		$postlist .= '</div>';

	}


	$postlist .= 'This area can be configured with Twilio texting service. You can reply directly using any device. There is no need to use a text message application. <div class="sms-message-form">
	<INPUT TYPE="text" NAME="message_reply" style="width: 98%;"
	VALUE="Reply to selected message">

		<input type=hidden name=sendsms value=true>
		<input type=hidden name=smsfrom value="6174335875">
		<input type="Submit" name="submit" value="Send">';

		$postlist .= '</div>
	</FORM>';

	if ($echo)
		echo $postlist;
	else
		return $postlist;
}



function fgpsn_text_alert_defaults() {
	$defaults = array( 	'title' => __( 'Text Alerts', 'fgpsn-text-alerts' ),
				'api_key' 	=> 'AC73f31202e64ac545fcf2b96d0a3a7b73',
				'auth_token' 	=> 'a7da0165d7ed912c85460a01c7c38454',
				'from_number' 	=> '+16172717634', );
	return $defaults;
}


function fgpsn_send_text_alerts( $smsfrom, $smsmessage, $message_id ) {

	global $wpdb;
	if ( !include_once( plugin_dir_path( __FILE__ ) . '/twilio/twilio-php/Services/Twilio.php' ) )
	{

	echo "<H3>Why Not! - " .plugin_dir_path( __FILE__ ) . 'twilio/twilio-php/Services/Twilio.php - </H3>';

	}

	$sid = "AC73f31202e64ac545fcf2b96d0a3a7b73";
	$token = "{{ a7da0165d7ed912c85460a01c7c38454 }}";
	$client = new Services_Twilio($sid, $token);

   $http = new Services_Twilio_TinyHttp(
		        'https://api.twilio.com',
		        array('curlopts' => array(CURLOPT_SSL_VERIFYPEER => false))
		    );

    $client = new Services_Twilio('AC73f31202e64ac545fcf2b96d0a3a7b73', 'a7da0165d7ed912c85460a01c7c38454', '2010-04-01', $http);

    //$message = $client->account->messages->get($message_id);

	$smsfrom = '+1' . $smsfrom;
	$smsto = '+1' . $smsto;
	$smsto = '+16172717634';
	$sms = $client->account->sms_messages->create($smsfrom, $smsto, $smsmessage, array());
	//echo "<H1>Reply to: " . $message->body . ", " . $message_id . "</H1>";

	echo $sms->sid;

	if ($echo)
		echo $postlist;
	else
		return $postlist;
}

if ( isset($_POST[sendsms]) || isset($_REQUESST[sendsms]) || isset($_GET[sendsms]) ) {

	fgpsn_send_text_alerts($_GET['smsfrom'], $_GET['message_reply'], $_GET['message_id'] );
}

?>
