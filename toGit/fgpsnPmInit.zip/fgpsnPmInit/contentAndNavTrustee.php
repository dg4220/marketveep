<?PHP
//set up default pages and menu

function tempAddPage() {
	global $wpdb;
	/*first see if the page exists
	once the pages are added set the menu below*/


	$fixed_page_args = array(
		'post_type'        => 'page',
		'post_mime_type'   => '',
		'post_parent'      => 0,
		'post_status'      => 'publish',
		'suppress_filters' => true );

	$fixed_pages = get_posts($fixed_page_args);
	foreach ( $fixed_pages as $post ) {

		$cur_titles[] = $post->post_title;

	}
	//echo "<H2>In the array, no  problem " . $cur_titles;

	$itsreally = count($cur_titles);
	if ( $itsreally == 1 && $cur_titles[0] == 'Sample Page' ) {
	echo " is full of: " . $itsreally . ", '$cur_titles[0]' ";
	}

	//echo "</H2>";
	
	/*******************************************************/
	/* Start creating 'temp' start up pages */
	
	if ( $itsreally == 1 && $cur_titles[0] == 'Sample Page' ) {

		//register menus
		$trustee_menu_id = wp_get_nav_menu_object( 'Trustee Menu' );
		if ( !$trustee_menu_id ) {
			$trustee_menu_id = wp_create_nav_menu( 'Trustee Menu' );
			register_nav_menus( array(
					'fgpsn-trustee-menu' => 'Trustee Menu'
				) );
		}

		$psn_menu_id = wp_get_nav_menu_object( 'PSN Default' );
		if ( !$psn_menu_id ) {
			$psn_menu_id = wp_create_nav_menu( 'PSN Default' );
			register_nav_menus( array(
					'fgpsn-init-menu' => 'PSN Default'
				) );
		}

		if ( in_array( 'Edit Property Data', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
			/*no longer uses shortcode but will use a template
			as described in */
			$my_post = array(
					  'post_title'    => 'Edit Property Data',
					  'post_status'   => 'publish',
					  'post_type'   => 'page',
					  'post_author'   => 1
					);

			// Insert the post into the database
			$new_page_id = wp_insert_post( $my_post );
			$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
			update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

			//add to appropriate menus
			$menu_url = get_page_link($new_page_id);
			$edit_prop_data_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
					'menu-item-title' =>  __('Edit Property Data'),
					'menu-item-url' => $menu_url,
					'menu-item-status' => 'publish'));

			wp_reset_postdata();

		}

		/*sub menu*/
			if ( !in_array( 'Add Contacts', $cur_titles ) ) {

				//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
				$my_post = array(
					  'post_title'    => 'Add Contacts',
					  'post_status'   => 'publish',
					  'post_type'   => 'page',
					  'post_content'   => '[gravityform id="9" name="Add/Edit Property Contacts" title="false" description="false" ajax="true"]',
					  'post_author'   => 1
				);

				// Insert the post into the database
				$new_page_id = wp_insert_post( $my_post );
				//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
				//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

				//add to appropriate menus  -
				$menu_url = get_page_link($new_page_id);
				//echo $menu_url . "<BR><BR>";
				$add_contacts_menu_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
						'menu-item-title' =>  __('Add Contacts'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $edit_prop_data_id,
						'menu-item-position' => 0,
						'menu-item-status' => 'publish'));
					//echo $add_contacts_menu_id . "<BR><BR>";
				wp_reset_postdata();

			}

			if ( !in_array( 'Write Communications', $cur_titles ) ) {

				//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
				$my_post = array(
					  'post_title'    => 'Write Communications',
					  'post_status'   => 'publish',
					  'post_type'   => 'page',
					  'post_content'   => '[gravityform id="4" name="Client Communications" title="false" description="false" ajax="true"]',
					  'post_author'   => 1
				);

				// Insert the post into the database
				$new_page_id = wp_insert_post( $my_post );
				//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
				//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

				//add to appropriate menus  -
				$menu_url = get_page_link($new_page_id);
				//echo $menu_url . "<BR><BR>";
				$add_communications_form_menu_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
						'menu-item-title' =>  __('Write Communications'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $edit_prop_data_id,
						'menu-item-position' => 1,
						'menu-item-status' => 'publish'));
					//echo $add_contacts_menu_id . "<BR><BR>";
				wp_reset_postdata();

			}

			if ( !in_array( 'Add Vendors', $cur_titles ) ) {

				//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
				$my_post = array(
					  'post_title'    => 'Add Vendors',
					  'post_status'   => 'publish',
					  'post_type'   => 'page',
					  'post_content'   => '[gravityform id="2" name="Trustee Vendor Management" ajax="true"]',
					  'post_author'   => 1
				);

				// Insert the post into the database
				$new_page_id = wp_insert_post( $my_post );
				//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
				//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

				//add to appropriate menus  -
				$menu_url = get_page_link($new_page_id);
				//echo $menu_url . "<BR><BR>";
				$add_communications_form_menu_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
						'menu-item-title' =>  __('Add Vendors'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $edit_prop_data_id,
						'menu-item-position' => 2,
						'menu-item-status' => 'publish'));
					//echo $add_contacts_menu_id . "<BR><BR>";
				wp_reset_postdata();

			}

			if ( !in_array( 'Add Documents', $cur_titles ) ) {

				//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
				$my_post = array(
					  'post_title'    => 'Add Documents',
					  'post_status'   => 'publish',
					  'post_type'   => 'page',
					  'post_content'   => '[gravityform id="3" name="Trustee Document Management" title="false" ajax="true"]',
					  'post_author'   => 1
				);

				// Insert the post into the database
				$new_page_id = wp_insert_post( $my_post );
				//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
				//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

				//add to appropriate menus  -
				$menu_url = get_page_link($new_page_id);
				//echo $menu_url . "<BR><BR>";
				$add_communications_form_menu_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
						'menu-item-title' =>  __('Add Documents'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $edit_prop_data_id,
						'menu-item-position' => 3,
						'menu-item-status' => 'publish'));
					//echo $add_contacts_menu_id . "<BR><BR>";
				wp_reset_postdata();

			}


			if ( in_array( 'Add Units', $cur_titles ) ) {
				//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
			} else {
				//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
				/*no longer uses shortcode but will use a template
				as described in */
				$my_post = array(
					  'post_title'    => 'Add/Edit Unit Data',
					  'post_status'   => 'publish',
					  'post_content'  => '[gravityform id="8" name="Add/Edit Units" title="false" description="false" ajax="true"]',
					  'post_type'   => 'page',
					  'post_author'   => 1
					);

				// Insert the post into the database
				$new_page_id = wp_insert_post( $my_post );
				//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
				//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);


				//add to appropriate menus  -
				$menu_url = get_page_link($new_page_id);
				//echo $menu_url . "<BR><BR>";
				$add_communications_form_menu_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
						'menu-item-title' =>  __('Add Units'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $edit_prop_data_id,
						'menu-item-position' => 4,
						'menu-item-status' => 'publish'));
					//echo $add_contacts_menu_id . "<BR><BR>";
				wp_reset_postdata();

			}



		if ( in_array( 'Property Overview', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
			/*no longer uses shortcode but will use a template
			as described in */
			$my_post = array(
				  'post_title'    => 'Property Overview',
				  'post_status'   => 'publish',
				  'post_content'  => '[property_data]',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			$new_page_id = wp_insert_post( $my_post );
			//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
			//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

			//add to appropriate menus
			$menu_url = get_page_link($new_page_id);
			$prop_overview_menu_id = wp_update_nav_menu_item($psn_menu_id, 1, array(
					'menu-item-title' =>  __('Property Overview'),
					'menu-item-url' => $menu_url,
					'menu-item-status' => 'publish'));

			$prop_overview_trustee_menu_id = wp_update_nav_menu_item($trustee_menu_id, 1, array(
					'menu-item-title' =>  __('Property Overview'),
					'menu-item-url' => $menu_url,
					'menu-item-position' => 1,
					'menu-item-status' => 'publish'));

			wp_reset_postdata();
		}

			/*sub menu*/
			if ( !in_array( 'The Latest', $cur_titles ) ) {

				//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
				$my_post = array(
					  'post_title'    => 'The Latest',
					  'post_status'   => 'publish',
					  'post_type'   => 'page',
					  'post_content'   => '<P>Here are the most recent communications from property management, site staff, maintenance, etc. Older communications are available in the archives and specific message types are available on their own in the Scheduled Services or Property Documents page.</P>',
					  'post_author'   => 1
				);

				// Insert the post into the database
				$new_page_id = wp_insert_post( $my_post );
				//$this_page_template = plugins_url( 'page-property-options.php', __FILE__ );
				//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);

				//add to appropriate menus  -
				$menu_url = get_page_link($new_page_id);
				//echo $menu_url . "<BR><BR>";
				$the_latest_menu_id = wp_update_nav_menu_item($psn_menu_id, 0, array(
						'menu-item-title' =>  __('The Latest'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $prop_overview_menu_id,
						'menu-item-position' => 0,
						'menu-item-status' => 'publish'));
					//echo $add_contacts_menu_id . "<BR><BR>";

				$the_latest_trustee_menu_id = wp_update_nav_menu_item($trustee_menu_id, 0, array(
						'menu-item-title' =>  __('The Latest'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => $prop_overview_trustee_menu_id,
						'menu-item-position' => 0,
						'menu-item-status' => 'publish'));

				wp_reset_postdata();

			}



		//read only for low level users
		//edit link for upperlevel users
		//edit this into shortcode and use different menu titles
		if ( in_array( 'Unit Data', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Unit Data',
				  'post_content'  => '[unit_data]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		//read only for low level users
		if ( in_array( 'Property Documents', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Property Documents',
				  'post_content'  => "<P>Here's the property documents page. I will soon separate out a separate section for unit specific documents. Also, the ability to give certain access to trustees or other property officers.
					</P>
					[property_documents]",
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		//upload and edit form for upper level users
		if ( in_array( 'Add/Edit Documents', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Add/Edit Documents',
				  'post_content'  => '[gravityform id="3" name="Trustee Document Management" title="false" description="false" ajax="true"]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		if ( in_array( 'Log In', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Log In',
				  'post_content'  => '[theme-my-login]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}


		if ( in_array( 'Log Out', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Log Out',
				  'post_content'  => '[theme-my-login]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		if ( in_array( 'Lost Password', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Lost Password',
				  'post_content'  => '[theme-my-login]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		if ( in_array( 'Maintenance Quick Request', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Maintenance Quick Request',
				  'post_content'  => '[fgpsn_wo_request_form_quick]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		if ( in_array( 'Schedule Services', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Schedule Services',
				  'post_content'  => '[app_monthly_schedule add="1"]
										<table>
										<tbody>
										<tr>
										<td colspan="2">[app_my_appointments]</td>
										</tr>
										<tr>
										<td>[app_services]</td>
										<td>[app_service_providers]</td>
										</tr>
										<tr>
										<td colspan="2">[app_monthly_schedule]</td>
										</tr>
										<tr>
										<td colspan="2">[app_pagination step="2" month="1"]</td>
										</tr>
										<tr>
										<td colspan="2">[app_login]</td>
										</tr>
										<tr>
										<td colspan="2">[app_confirmation]</td>
										</tr>
										<tr>
										<td colspan="2">[app_paypal]</td>
										</tr>
										</tbody>
										</table>',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			//wp_insert_post( $my_post );
			wp_reset_postdata();

		}


		if ( in_array( 'Property Directory', $cur_titles ) ) {

		} else {


			$my_post = array(
				  'post_title'    => 'Property Directory',
				  'post_content'  => '[property_contacts]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}


	/*
		if ( in_array( 'Contact Us', $cur_titles ) ) {
			echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Contact Us',
				  'post_content'  => '[gravityform id="1" name="Contact Us" description="false"]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}
	*/



		if ( in_array( 'Property Vendors', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Property Vendors',
				  'post_content'  => '[property_vendors]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}


		if ( in_array( 'Add/Edit Vendors', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Add/Edit Vendors',
				  'post_content'  => '[gravityform id="2" name="Trustee Vendor Management" title="false" description="false" ajax="true"]',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		//default messages/blog page
		if ( in_array( 'Messages', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Messages',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		//Client Services Vendors
		if ( in_array( 'Other Vendors and Services', $cur_titles ) ) {
			//echo "<H2>ay, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Other Vendors and Services',
				  'post_status'   => 'publish',
				  'post_content'  => 'This can be a list of affiliated vendors or <em>preferred</em> vendors who may or may not have service contracts with the property. Residents can also add and manage their own preferred and manage communications, scheduling, and payments through the same Front Gate system.

					[property_vendors vendor_parent="43"]',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		//Property Vendors
		if ( in_array( 'Property Vendors 2', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Property Vendors',
				  'post_status'   => 'publish',
				  'post_content'  => '[property_vendors vendor_parent="42"]',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}

		//User Registration
		if ( in_array( 'User Registration', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'User Registration',
				  'post_status'   => 'publish',
				  'post_content'  => '[theme-my-login default_action="register" register_template="user-panel.php"]',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}


		if ( in_array( 'Your Profile', $cur_titles ) ) {
			//echo "<H2>In the array, no  problem " . $cur_titles . "</H2>";
		} else {
			//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";

			$my_post = array(
				  'post_title'    => 'Your Profile',
				  'post_status'   => 'publish',
				  'post_content'  => '[theme-my-login]',
				  'post_type'   => 'page',
				  'post_author'   => 1
				);

			// Insert the post into the database
			wp_insert_post( $my_post );
			wp_reset_postdata();

		}


	}
	
/* End of creating 'temp' start up pages */
/******************************************************/	
	
	
	
	
	$menu_exists = wp_get_nav_menu_object( 'PSN Default' );
	$locations = get_nav_menu_locations();

		foreach($locations as $k=>$v) {
			//echo "<LI>" . $k . " - " . $v . "</LI>";
		}
	// If it doesn't exist, let's create it.
	if( !$menu_exists ){


		$menu_id = wp_create_nav_menu( 'PSN Default' );
		register_nav_menus( array(
				'fgpsn-init-menu' => 'PSN Default'
			) );

		$menu_url = get_site_url() . '/contact_data/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Contact Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/property_data/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Property Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/unit_data/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Unit Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/property_vendor/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Vendor Data'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/property_comm/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Property Communications'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/property_doc/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Property Documents'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		$menu_url = get_site_url() . '/maintenance_requests/';
		wp_update_nav_menu_item($menu_id, 0, array(
			'menu-item-title' =>  __('Maintenance Requests'),
			'menu-item-url' => $menu_url,
			'menu-item-status' => 'publish'));

		echo "<H3>1147 - " . $wpdb->last_query . "</H3>";
		} else {
		if (!is_admin()) {
		global $wpdb;

		$tablename = $wpdb->prefix.'terms'; // use always table prefix
		$menu_name = 'Top Navigation'; // menu name
		$menu_id = $wpdb->get_results(
			"
			SELECT term_id
			FROM ".$tablename."
			WHERE name= '".$menu_name."'
			"
		);

		// results in array
		foreach($menu_id as $menu):
			//echo "<H1>" .  $menu->term_id . "</H1>";
			$this_id = $menu->term_id;


			//update_option();
		endforeach;

		/* Set up default menu items
		$cont_us_page = get_page_by_path( 'contact-us' );
		$cont_us_page = get_permalink( $cont_us_page );

		$prop_vend_page = get_page_by_path( 'property-vendors' );
		$prop_vend_page = get_permalink( $prop_vend_page );

		$prop_data_page = get_page_by_path( 'property-data' );
		$prop_data_page = get_permalink( $prop_data_page );

		$prop_docs_page = get_page_by_path( 'property-documents' );
		$prop_docs_page = get_permalink( $prop_docs_page );

		$unit_data_page = get_page_by_path( 'unit-data' );
		$unit_data_page = get_permalink( $unit_data_page );

		$contacts_page = get_page_by_path( 'property-vendors' );
		$contacts_page = get_permalink( $contacts_page );



	$menu_items = wp_get_nav_menu_items($menu_exists->term_id);

		foreach ( $menu_items as $key => $menu_item ) {
			$menu_item_title[] = $menu_item->title;
		}


		if (!in_array('Property Vendors', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Property Vendors'),
				'menu-item-url' => home_url( '/' . $prop_vend_page . '/' ),
				'menu-item-status' => 'publish'));

		 }
		if (!in_array('Contact Us', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Contact Us'),
				'menu-item-url' => home_url( '/' . $cont_us_page . '/'  ),
				'menu-item-status' => 'publish'));

		 }

		 if (!in_array('Property Data', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Property Data'),
				'menu-item-url' => home_url( '/' . $prop_data_page . '/' ),
				'menu-item-status' => 'publish'));

		 }
		if (!in_array('Property Documents', $menu_item_title)) {
			wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Property Documents'),
				'menu-item-url' => home_url( '/' . $prop_docs_page . '/'  ),
				'menu-item-status' => 'publish'));

		 }

			if (!in_array('Unit Data', $menu_item_title)) {
				wp_update_nav_menu_item($menu_exists->term_id, 0, array(
				'menu-item-title' =>  __('Unit Data'),
				'menu-item-url' => home_url( '/' . $unit_data_page . '/' ),
				'menu-item-status' => 'publish'));

			}
			if (!in_array('Contacts', $menu_item_title)) {
				wp_update_nav_menu_item($menu_exists->term_id, 0, array(
					'menu-item-title' =>  __('Contacts'),
					'menu-item-url' => home_url( '/' . $contacts_page . '/'  ),
					'menu-item-status' => 'publish'));

			}
			* * */
		}

	}

	//after the menu exists make it default
	//$menu_exists->term_id;

}

//add_action('admin_init', 'tempAddPage');
