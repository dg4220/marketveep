<?PHP
/******************************************************
 * DG Creating Property Logs post type and meta boxes
*******************************************************/
class FGPSN_Contact {

	/**
	 * Hook into the appropriate actions when the class is constructed.
	 */
	public function __construct() {

		
	}

	/*add public unility methods*/

	/*getting a property menu from a passed value or 'all' properties */
	public function fgpsn_contact_menu($unit_array) {
	  
	  $fgpsn_log_selected_contacts = get_post_meta(get_the_id(), 'fgpsn_log_selected_contacts', true);

	  //should also be able to take a passed value of property IDs  
		$args = array(
	    'posts_per_page'  => -1,
	    'post_type'  => 'contact_data',
	    'post_status' => 'publish',
	    'meta_query' => array(
	                    array(
	                      'key' => 'fgpsn_contact_unit_id',
	                      'value' => $unit_array
                      )
                )
	  );

		
		echo  '<SELECT multiple ID="contact_selection_menu" name="fgpsn_log_selected_contacts[]" size=5 >
	          <option value="0"> -- Selected Contacts -- </option>';
	      
	  $getem = get_posts($args);
		foreach ( $getem as $property ) {
			
      setup_postdata($property );
			$fgpsn_contact_first_name = get_post_meta($property->ID, 'fgpsn_contact_first_name', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);
	    
	      if ($property->post_title) {
        echo '<OPTION value="' . $property->ID . '"';

  			if ( in_array($property->ID, $fgpsn_log_selected_contacts) ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $property->post_title . "</A><BR>";
  			}

  			echo '>' .  $property->post_title . '</OPTION>';
  			
      } else {
				echo '<OPTION value="' . $property->ID . '"';

  			if ( in_array($property->ID, $fgpsn_log_selected_contacts) ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $property->post_title . "</A><BR>";
  			}

  			echo '>' .  $fgpsn_contact_first_name . '</OPTION>';      }
	         
    }
	  echo  '</SELECT>';
	  wp_reset_postdata();	  
	 
	}
	

}//end class

new FGPSN_Contact;
?>
