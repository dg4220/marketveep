<?PHP
/* Set file for maintenance module.
 * Includes user, role, and capability definitions as well as default content, custom navigation, sidebars, * etc.
 */

function readContacts() {
	
}

function readPropertyVendors() {
	
}

function readPropertySpecs() {
	
}

function fieldDashboard() {
	
	//gets 'new' work orders
	global $wpdb;
	global $current_user;
      get_currentuserinfo();
	global $table_prefix;
	//wp_enqueue_script('repeatingfield-script', plugins_url('jquery.repeater-master/jquery.repeater.js', __FILE__), array('jquery'), '1.0', true);
	
	
	if ( isset( $_GET['singlewo'] ) ) {
		$cur_wo = get_post( $_GET['singlewonumber'] );
		$unit_owner_id = get_post_meta($cur_wo, 'unit_owner_id', true);
		echo "<DIV>
		<H2>Current WO: " . $cur_wo->ID . ", " . $unit_owner_id . "</H2>";
		echo "<H3>Unit Owner: " . $cur_wo->post_title . "</H3>";
		echo "<DIV class='alert'><H4>Access Notes: " . $cur_wo->post_date . "</H4>
		<P>" . $cur_wo->post_date . "</P></DIV>";
		echo "<H4>Request Date: " . $cur_wo->post_date . "</H4><H4>Current Data: " . $cur_wo->post_date . "</H4>";
		echo "<H4>Request: " . $cur_wo->post_title . "</H4><H4>Room: : " . $cur_wo->post_date . "</H4>";
		echo "<H4>Request Details:</H4>
		<P>" . $cur_wo->post_content . "</P>";
		
		
		//echo "</DIV>";
/*
		echo "<form class='repeater'>
			<DIV><H3>Add Notes</H3>
				<TEXTAREA></TEXTAREA>
			</DIV>
			<div data-repeater-list='group-a'>
			<H3>Add Materials</H3>
			  <div data-repeater-item>
				<label>Desc. </label><input type='text' name='mat_item_desc' value='Desc.'/>
				<label>Qty. </label><input type='text' name='mat_item_qty' SIZE=3 value='Qty'/>
				<input data-repeater-delete type='button' value=' - '/>
			  </div>
			  <div data-repeater-item>
				<label>Desc. </label><input type='text' name='mat_item_desc' value='Desc.'/>
				<label>Qty. </label><input type='text' name='mat_item_qty' SIZE=3 value='Qty'/>
				<input data-repeater-delete type='button' value=' - '/>
			  </div>
			</div>
			<div>
			<input data-repeater-create type='button' value=' + '/>
			</div>
			<DIV><INPUT TYPE=button VALUE='Send to Vendor'><INPUT TYPE=button VALUE='Request P.O.'></DIV>
			
		</form>

		<script src='http://code.jquery.com/jquery-1.10.2.js'></script>
		
		<script>
			jQuery(document).ready(function() {
			jQuery('.repeater').repeater({
					// (Optional)
					// 'defaultValues' sets the values of added items.  The keys of
					// defaultValues refer to the value of the inputs name attribute.
					// If a default value is not specified for an input, then it will
					// have its value cleared.
					defaultValues: {
						'mat_item_desc': 'foo'
					},
					// (Optional)
					// 'show' is called just after an item is added.  The item is hidden
					// at this point.  If a show callback is not given the item will
					// have $(this).show() called on it.
					show: function () {
						$(this).slideDown();
					},
					// (Optional)
					// 'hide' is called when a user clicks on a data-repeater-delete
					// element.  The item is still visible.  'hide' is passed a function
					// as its first argument which will properly remove the item.
					// 'hide' allows for a confirmation step, to send a delete request
					// to the server, etc.  If a hide callback is not given the item
					// will be deleted.
					hide: function (deleteElement) {
						if(confirm('Are you sure you want to delete this element?')) {
							$(this).slideUp(deleteElement);
						}
					}
				})
			});
		</script>";
*/	
	gravity_form( 28 );
	//echo "</DIV>";
	} else {
	
	$get_wos_sql = "SELECT ID,
							post_title,
							post_date,
							post_status,
							post_author,
							post_date,
							post_excerpt
						FROM  " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND ( post_status = 'Assigned'
						OR ID IN
							( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'assigned_staff' AND meta_value = $current_user->ID ) 
								
								OR post_status = 'Publish')";
								
	$terms2 = $wpdb->get_results( $wpdb->prepare($get_wos_sql), OBJECT);

	if ( is_wp_error( $terms2 ) ) {
		$error_string = $terms2->get_error_message();
		echo '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
	}
	
	// echo $disp_data;
	$count2 = count($terms2);
	if ( $count2 > 0 ){
	 /* echo "<ul class='no_bullets'>"; */
	//get user role - certain roles can edit document data
	
	echo "<DIV STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'>
	<DIV><SPAN>Title</SPAN><SPAN>Date</SPAN><SPAN>View</SPAN><SPAN>Edit</SPAN></SPAN></DIV>
		<DIV>";
	
		foreach ( $terms2 as $wos ) {
					  
			$user_info = get_userdata($wos->post_author);
			$first_name = $user_info->first_name;
			$last_name = $user_info->last_name;
			$excerpt = $wos->post_excerpt;
			if ( isset($excerpt) && $excerpt != '' ) {
				$excerpt = $excerpt;
			} else {
				$excerpt = $excerpt = $wos->post_cntent;
			}
					  
			echo "<THEAD><TR><TH>" . $wos->post_title . "</TH>
			<TH>" . get_the_time('D j, Y', $wos->ID) . "</TH>
			<TH>" . $first_name . " " . $first_name . "</TH></TR></THEAD>
			 <TBODY>
			  <TR><TD COLSPAN=2>" . $wos->post_excerpt . "</TD><TD>
			  <A HREF='?singlewo=TRUE&singlewonumber=" . $wos->ID . "'>Open</A>
			  <DIV>
			<A HREF='?send_to_maint=TRUE&work_order_status=New&ID" . $wos->post_title . "'>Send To Maintenence</A></DIV>";
					
			echo "</TD></TR></TBODY>";
		}
	
		} else {
			echo "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'></TABLE>";
		}
		echo "</DIV>";
	}
	echo "</DIV>";
		 //echo $disp_data;
	//return $disp_data;
	
}
	
add_shortcode( 'maintenance_field_dash', 'fieldDashboard' );



function readPropertyData() {
	
	$this_property_data = '';
	
	$property_addr1 = get_option('property_addr1');
	$property_addr2 = get_option('property_addr2');
	$property_city = get_option('property_city');
	$property_state = get_option('property_state');
	$property_zip = get_option('property_zip');
	$property_type = get_option('property_type');
	$property_title = get_option('property_title');
	$cur_property_manager = get_option('property_manager');
	$number_of_units = get_option('number_of_units');



	$args = array(
       'post_type' => 'contact_data',
       'tax_query' => array(
                   array(
                       'taxonomy' => 'contact_data_types',
                       'field' => 'slug',
                       'terms' => 'desk-staff'
                    )
                )
        );
        $posts = get_posts($args);


		if(is_array($posts)) :  foreach($posts as $post) :

			if ($cur_property_manager == $post->ID) {

				$this_property_data .= "<P>Property Manager: " .  $post->post_title . "</P>";

			}


		endforeach; endif;
		
		
	$args = array(
		 'posts_per_page' => -1,
		 'orderby' => 'rand',
		 'post_type' => 'contact_data',
		 'contact_data_types' => 'trustee',
		 'post_status' => 'publish'
	);
	$show_trustees = get_posts( $args );

	if(is_array($show_trustees)) :  foreach($show_trustees as $show_trustee) :

	$this_property_data .= "<TR><TD>" . $show_trustee->post_title . "</TD><TD>Contact Information:<BR></TD></TR>";

	endforeach; endif;

	
	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);


	$this_property_data .= "<TABLE><TR><TH COLSPAN=2>Add New Specification Type: <INPUT TYPE=text NAME=property_data_options[fg_property_spec_type]></TH></TR>";


	$terms = get_terms("property_vendor_services", $args);
	$count = count($terms);
	if ( $count > 0 ){

		foreach($terms as $term) {
			$this_property_data .= "<TR><TH>" .  $term->name . "</TH>";

			$cur_term = $term->slug;

			$all_vendors_args = array(
						'post_type'=>'property_vendor',
						'numberposts'=>-1,
						'orderby'=>'post_title',
						'order'=>'ASC',
						'taxonomy'=>'property_vendor_services',
						'term'=>$term->name
					);

					$vendors = get_posts($all_vendors_args);

		$check_cur = get_option($cur_term);

		$this_property_data .= "<TD><select name=\"property_data_options['" .  $cur_term . "']\" id=\"property_data_options['" . $cur_term . "']\">
		<option value=\"0\"> - Select - </option>";

		foreach($vendors as $vendor) : 

			$this_property_data .= "<option value='" .  $vendor->ID . "'>" . $vendor->post_title . "</option>";
		
		endforeach;
		
		$this_property_data .= "</select></TD></TR>";

		 }

		$this_property_data .= "";
	$this_property_data .= "</TABLE></DIV></LI>";

	 }










	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 0);


	$terms = get_terms("property_specifications", $args);
	 $count = count($terms);
	 if ( $count > 0 ){

	$this_property_data .= "<TABLE>";

		foreach($terms as $term) {
			$this_property_data .= "<TR><TH>" .  $term->name . "</TH>";

			$specification = get_post_meta($ID, $term->slug, TRUE);

			$spec_content = get_option('property_' . $term->slug);

			$this_property_data .= "<TD>" .  $specification . "</TD><TD><input id='property_" . $term->slug . "' name='property_data_options[property_" . $term->slug . "]' size='3' type='text' value='{$spec_content}' /></TD></TR>";


		}
		$this_property_data .= "</TABLE>";

	}


	return $this_property_data;
}





function fieldMaintInit() {
	
	global $wpdb;
	
	/*first see if the page exists
	once the pages are added set the menu below*/


	$fixed_page_args = array(
		'post_type'        => 'page',
		'post_status'      => 'publish',
		'suppress_filters' => true );

	$fixed_pages = get_posts($fixed_page_args);
	
	$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
	if ( !$maint_field_emp_menu_id ) {
		$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
		register_nav_menus( array(
			'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
		) );
	}
	
	
	foreach ( $fixed_pages as $post ) {

		$cur_titles[$post->ID] = $post->post_title;
	
	}
	
	
	/********************************************/
	/*testing page*/
	
	if ( !in_array( 'Create Test Page', $cur_titles ) ) {
			
		$templatefile = plugin_dir_path( __FILE__ ) . 'template-property_comm.php';

		//echo "<H2>Not in the array, add the page 'Create Test Page'<BR>File" . $templatefile . "</H2>";
		$my_post = array(
			'post_title'    => 'Create Test Page',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '',
			  'post_author'   => 1,
			  'page_template' => $templatefile
		);

		// Insert the post into the database
		//$new_page_id = wp_insert_post( $my_post );
			if( is_wp_error( $new_page_id ) ) {
				echo "<H2>Error! " . $return->get_error_message() . "</H2>";
			} else {
				update_post_meta($new_page_id, '_wp_page_template', $templatefile);
			}

	} else {
		$templatefile = plugin_dir_path( __FILE__ ) . 'template-property_comm.php';
		update_post_meta(2794, '_wp_page_template', $templatefile);
	}
		
	
	
	/**********************************************/

	
	if ( !in_array( 'Maintenance Quick Request', $cur_titles ) ) {

		//echo "<H2>Not in the array, add the page 'Add/Edit Work Order'</H2>";
		$my_post = array(
			'post_title'    => 'Maintenance Quick Request',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '[fgpsn_wo_request_form_quick]',
			  'post_author'   => 1
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Maintenance Quick Request'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 0,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {
		//echo "<H2>In the array, don't add the page 'Add/Edit Work Order'</H2>";
		
		//make sure we have the correct menu reference
		$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
		if ( !$maint_field_emp_menu_id ) {
			$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
			register_nav_menus( array(
				'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
			) );
		}
		
		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>467 - VIEW MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
			if ( !in_array( 'Add/Edit Work Order', $title ) ) {
				//echo "<H3>'View/Edit Work Order' not in menu array - </H3>";
				foreach ($cur_titles as $k=>$v) {
					if ( $v == 'Add/Edit Work Order' ) {
						$menu_url = get_page_link($k);
					}
				}
				
				$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
						'menu-item-title' =>  __('Add/Edit Work Order'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => 0, //$edit_prop_data_id
						'menu-item-position' => 1,
						'menu-item-status' => 'publish'));
			}
	
		} else {
			
			//if count is 0 there is no menu so start it with this item
			foreach ($cur_titles as $k=>$v) {
				if ( $v == 'Add/Edit Work Order' ) {
					$menu_url = get_page_link($k);
				}
			}
			
			//echo "<H3>@@@'Add/Edit Work Order' not in menu array - " . $maint_field_emp_menu_id->term_id . ", " . $menu_item['url'] . "</H3>";
			$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
					'menu-item-title' =>  __('Add/Edit Work Order'),
					'menu-item-url' => $menu_url,
					'menu-item-parent-id' => 0, //$edit_prop_data_id
					'menu-item-position' => 1,
					'menu-item-status' => 'publish'));
			
		}

	}
	
	
	//Field detail screen
	if ( !in_array( 'View/Edit Work Order', $cur_titles ) ) {

		//echo "<H2>Not in the array, add the page 'View/Edit Work Order'</H2>";
		$my_post = array(
			'post_title'    => 'View/Edit Work Order',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '[maintenance_field_dash]
			  [app_schedule]',
			  'post_author'   => 1
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('View/Edit Work Order'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 0,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {
		//echo "<H2>In the array, don't add the page 'View/Edit Work Order'</H2>";
		
		//make sure we have the correct menu reference
		$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
		if ( !$maint_field_emp_menu_id ) {
			$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
			register_nav_menus( array(
				'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
			) );
		}
		
		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>467 - VIEW MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
			if ( !in_array( 'View/Edit Work Order', $title ) ) {
				//echo "<H3>'View/Edit Work Order' not in menu array - </H3>";
				foreach ($cur_titles as $k=>$v) {
					if ( $v == 'View/Edit Work Order' ) {
						$menu_url = get_page_link($k);
					}
				}
				
				$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
						'menu-item-title' =>  __('View/Edit Work Order'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => 0, //$edit_prop_data_id
						'menu-item-position' => 1,
						'menu-item-status' => 'publish'));
			}
	
		} else {
			
			//if count is 0 there is no menu so start it with this item
			foreach ($cur_titles as $k=>$v) {
				if ( $v == 'View/Edit Work Order' ) {
					$menu_url = get_page_link($k);
				}
			}
			
			//echo "<H3>@@@'View/Edit Work Order' data not in menu array - " . $maint_field_emp_menu_id->term_id . ", " . $menu_item['url'] . "</H3>";
			$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
					'menu-item-title' =>  __('View/Edit Work Order'),
					'menu-item-url' => $menu_url,
					'menu-item-parent-id' => 0, //$edit_prop_data_id
					'menu-item-position' => 1,
					'menu-item-status' => 'publish'));
			
		}

	}
	
	if ( !in_array( 'Property Data', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page 'Property Data'</H2>";
		$my_post = array(
			'post_title'    => 'Property Data',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '',
			  'post_author'   => 1,
			  'page_template' => 'page-template-property-data.php'
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Property Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 0,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {
		
		//$needed_index = $cur_titles;
		//make sure its also added to the correct menu
		
	$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
	if ( !$maint_field_emp_menu_id ) {
		$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
		register_nav_menus( array(
			'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
		) );
	}
		//echo "<H2>In the array, don't add the page 'Property Data' - " . $maint_field_emp_menu_id->term_id . "</H2>";
	

		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
	if ( !in_array( 'Property Data', $title ) ) {
		foreach ($cur_titles as $k=>$v) {
			if ( $v == 'Property Data' ) {
				$menu_url = get_page_link($k);
			}
		}
	  //  echo "<H3>Property data not in menu array - " .  $maint_field_emp_menu_id->term_id . ", " . $menu_item['url'] . "</H3>";
		$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
				'menu-item-title' =>  __('Property Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 1,
				'menu-item-status' => 'publish'));
	}
	} else {
		
		foreach ($cur_titles as $k=>$v) {
			if ( $v == 'Property Data' ) {
				$menu_url = get_page_link($k);
			}
		}
	   // echo "<H3>@@@Property data not in menu array - " . $maint_field_emp_menu_id->term_id . ", " . $menu_item['url'] . "</H3>";
		$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
				'menu-item-title' =>  __('Property Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 1,
				'menu-item-status' => 'publish'));
		
	}
		
	}
	
	/*unit data pge*/
	if ( !in_array( 'Unit Data', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
		$my_post = array(
			'post_title'    => 'Unit Data',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '',
			  'post_author'   => 1,
			  'page_template' => 'page-template-unit-data.php'
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Unit Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 2,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {

		//echo "<H2>In the array, don't add the page 'Unit Data'</H2>";
		
		//make sure we have the correct menu reference
		$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
		if ( !$maint_field_emp_menu_id ) {
			$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
			register_nav_menus( array(
				'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
			) );
		}
		
		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>703 - VIEW MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
			if ( !in_array( 'Unit Data', $title ) ) {
				//echo "<H3>'View/Edit Work Order' not in menu array - </H3>";
				foreach ($cur_titles as $k=>$v) {
					if ( $v == 'Unit Data' ) {
						$menu_url = get_page_link($k);
					}
				}
				
				$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
						'menu-item-title' =>  __('Unit Data'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => 0, //$edit_prop_data_id
						'menu-item-position' => 1,
						'menu-item-status' => 'publish'));
			}
	
		} else {
			
			//if count is 0 there is no menu so start it with this item
			foreach ($cur_titles as $k=>$v) {
				if ( $v == 'Unit Data' ) {
					$menu_url = get_page_link($k);
				}
			}
			
			
			$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
					'menu-item-title' =>  __('Unit Data'),
					'menu-item-url' => $menu_url,
					'menu-item-parent-id' => 0, //$edit_prop_data_id
					'menu-item-position' => 1,
					'menu-item-status' => 'publish'));
			
		}

		
	}
	
/*Network Workorder Summary page*/
	if ( !in_array( 'Work Order Summary', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
		$my_post = array(
			'post_title'    => 'Work Order Summary',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '[fgpsn_wo_summary_table]',
			  'post_author'   => 1,
			  
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Work Order Summary'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 2,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {

		//echo "<H2>In the array, don't add the page 'Work Order Summary'</H2>";
		//make sure we have the correct menu reference
		$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
		if ( !$maint_field_emp_menu_id ) {
			$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
			register_nav_menus( array(
				'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
			) );
		}
		
		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>703 - VIEW MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
			if ( !in_array( 'Work Order Summary', $title ) ) {
				//echo "<H3>'View/Edit Work Order' not in menu array - </H3>";
				foreach ($cur_titles as $k=>$v) {
					if ( $v == 'Work Order Summary' ) {
						$menu_url = get_page_link($k);
					}
				}
				
				$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
						'menu-item-title' =>  __('Work Order Summary'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => 0, //$edit_prop_data_id
						'menu-item-position' => 1,
						'menu-item-status' => 'publish'));
			}
	
		} else {
			
			//if count is 0 there is no menu so start it with this item
			foreach ($cur_titles as $k=>$v) {
				if ( $v == 'Work Order Summary' ) {
					$menu_url = get_page_link($k);
				}
			}
			
			//echo "<H3>@@@'Add/Edit Work Order' not in menu array - " . $maint_field_emp_menu_id->term_id . ", " . $menu_item['url'] . "</H3>";
			$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
					'menu-item-title' =>  __('Work Order Summary'),
					'menu-item-url' => $menu_url,
					'menu-item-parent-id' => 0, //$edit_prop_data_id
					'menu-item-position' => 1,
					'menu-item-status' => 'publish'));
			
		}

		
	}

/*Network Communications Summary page*/
	if ( !in_array( 'Client Communications', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
		$my_post = array(
			'post_title'    => 'Client Communications',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '',
			  'post_author'   => 1,
			  'page_template' => 'page-template-network-comm-summary.php'
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Client Communications'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 3,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {

		//echo "<H2>In the array, don't add the page 'Client Communications'</H2>";
		//make sure we have the correct menu reference
		$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
		if ( !$maint_field_emp_menu_id ) {
			$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
			register_nav_menus( array(
				'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
			) );
		}
		
		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>703 - VIEW MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
			if ( !in_array( 'Client Communications', $title ) ) {
				foreach ($cur_titles as $k=>$v) {
					if ( $v == 'Client Communications' ) {
						$menu_url = get_page_link($k);
					}
				}
				
				$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
						'menu-item-title' =>  __('Client Communications'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => 0, //$edit_prop_data_id
						'menu-item-position' => 3,
						'menu-item-status' => 'publish'));
			}
	
		} else {
			
			//if count is 0 there is no menu so start it with this item
			foreach ($cur_titles as $k=>$v) {
				if ( $v == 'Client Communications' ) {
					$menu_url = get_page_link($k);
				}
			}
			
			$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
					'menu-item-title' =>  __('Client Communications'),
					'menu-item-url' => $menu_url,
					'menu-item-parent-id' => 0, //$edit_prop_data_id
					'menu-item-position' => 3,
					'menu-item-status' => 'publish'));
			
		}

		
	}
	
	
/*Property Datasheet page*/
	if ( !in_array( 'Property Data', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
		$my_post = array(
			'post_title'    => 'Property Data',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '',
			  'post_author'   => 1,
			  'page_template' => 'page-template-property-datasheet.php'
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Property Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 4,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {

		//echo "<H2>In the array, don't add the page 'Client Communications'</H2>";
		//make sure we have the correct menu reference
		$maint_field_emp_menu_id = wp_get_nav_menu_object( 'Maintenance Field Menu' );
		if ( !$maint_field_emp_menu_id ) {
			$maint_field_emp_menu_id = wp_create_nav_menu( 'Maintenance Field Menu' );
			register_nav_menus( array(
				'fgpsn-maint-field-menu' => 'Maintenance Field Menu'
			) );
		}
		
		$menu_items = wp_get_nav_menu_items( $maint_field_emp_menu_id->term_id );
		$count = count($menu_items);
		//echo "<H2>703 - VIEW MENU ITEMS - " . $menu_items . ", " . $count . "</H2>";
		if ( $count > 0 ) {
			foreach ( $menu_items as $key => $menu_item ) {
				//echo "<H2>MENU ITEM - " . $menu_item->title . "</H2>";
				$title[$menu_item->ID] = $menu_item->title;
				$url[$menu_item->ID] = $menu_item->url;
				
			}
		
			if ( !in_array( 'Property Data', $title ) ) {
				foreach ($cur_titles as $k=>$v) {
					if ( $v == 'Property Data' ) {
						$menu_url = get_page_link($k);
					}
				}
				
				$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
						'menu-item-title' =>  __('Property Data'),
						'menu-item-url' => $menu_url,
						'menu-item-parent-id' => 0, //$edit_prop_data_id
						'menu-item-position' => 4,
						'menu-item-status' => 'publish'));
			}
	
		} else {
			
			//if count is 0 there is no menu so start it with this item
			foreach ($cur_titles as $k=>$v) {
				if ( $v == 'Property Data' ) {
					$menu_url = get_page_link($k);
				}
			}
			
			$add_contacts_menu_id = wp_update_nav_menu_item( $maint_field_emp_menu_id->term_id, 0, array(
					'menu-item-title' =>  __('Property Data'),
					'menu-item-url' => $menu_url,
					'menu-item-parent-id' => 0, //$edit_prop_data_id
					'menu-item-position' => 3,
					'menu-item-status' => 'publish'));
			
		}

		
	}
	
	
	
/****************************************************************/	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	if ($aadv) {
	/*Vendor data pge*/
	if ( !in_array( 'Vendor Data', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
		$my_post = array(
			'post_title'    => 'Vendor Data',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '[vendor_data]',
			  'post_author'   => 1
		);

		// Insert the post into the database
		$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Vendor Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 3,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {
		
		//$needed_index = $cur_titles;
		
		foreach ($cur_titles as $k=>$v) {
			if ( $v == 'Vendor Data' ) {
				$menu_url = get_page_link($k);
			}
		}
		
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Vendor Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 3,
				'menu-item-status' => 'publish'));
		
	}
	
		/*Schedule data pge*/
	if ( !in_array( 'Schedule Data', $cur_titles ) ) {
		
		//readPropertyData();
		//echo "<H2>Not in the array, add the page " . $cur_titles . "</H2>";
		$my_post = array(
			'post_title'    => 'Schedule Data',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_content'   => '[app_services]
				[app_service_providers require_service="1"]
				[app_worker_monthly_calendar]
				[app_schedule]
				[app_confirmation service_id="0" worker_id="0"]
				[app_pagination]',
			  'post_author'   => 1
		);

		// Insert the post into the database
		//$new_page_id = wp_insert_post( $my_post );
			
		//add to appropriate menus  -
		$menu_url = get_page_link($new_page_id);
		//echo $menu_url . "<BR><BR>";
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Schedule Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 4,
				'menu-item-status' => 'publish'));
				//echo $add_contacts_menu_id . "<BR><BR>";
		wp_reset_postdata();

	} else {
		
		//$needed_index = $cur_titles;
		
		foreach ($cur_titles as $k=>$v) {
			if ( $v == 'Schedule Data' ) {
				$menu_url = get_page_link($k);
			}
		}
		
		$add_contacts_menu_id = wp_update_nav_menu_item($maint_field_emp_menu_id, 0, array(
				'menu-item-title' =>  __('Schedule Data'),
				'menu-item-url' => $menu_url,
				'menu-item-parent-id' => 0, //$edit_prop_data_id
				'menu-item-position' => 4,
				'menu-item-status' => 'publish'));
		
	}
	
}
}

//add_action('admin_init', 'fieldMaintInit');
