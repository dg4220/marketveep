<?php
/*
Plugin Name: Display Work Order Details in a Sidebar
Plugin URI: http://www.2265solutions.com
Description: Add Document Post type with custom taxonomy, display shortcodes, and sidebar widget to display a customizable selection of documents. Premium version includes ability to restrict document access by document type, user role, and/or individually as well as additional display parameters.
Version: 1
Author: Dennis Gannon
Author URI: http://www.2265solutions.com
*/

/*  Copyright 2013  Dennis Gannon  (email : dgannon@2265solutions.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


class fgpsn_work_order_details_widget extends WP_Widget {

	function fgpsn_work_order_details_widget() {
		//Load Language
		load_plugin_textdomain( 'work-order-details', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows work order details, relevant unit data, vendors amybe also.', 'work-order-details' ) );
		//Create widget
		$this->WP_Widget( 'workorderdetails', __( 'W.O. Details', 'work-order-details' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		//extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );
		$link = empty( $instance[ 'link' ]) ? '' : $instance[ 'link' ];
		

		if ( !empty( $title ) &&  !empty( $link ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}
		else if ( !empty( $title ) ) {
			 echo $before_title . $title . $after_title;
		}
        //print recent posts
		dg_recentdocuments($parameters);
		echo $after_widget;

  } //end of widget()

	
}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_work_order_details_widget");') );
//Register Widget


?>
