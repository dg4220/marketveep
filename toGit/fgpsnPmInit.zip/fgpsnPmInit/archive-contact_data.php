<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @since 3.0.0
 */
get_header(); 
global $wpdb;

?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP
		global $wpdb;


				$args = array(
				'offset'           => 0,
				'orderby'          => 'post_title',
				'meta_key'         => '',
				'meta_value'       => '',
				'post_type'        => 'contact_data',
				'post_status'      => 'publish',
				'suppress_filters' => true );
						
				$recipients = get_posts( $args );
				//echo '<H4>' . $recipients . ' -- Select Properties -- ' . $wpdb->last_query . '</H4>';
				$property_ct = count( $property_ids);
				//echo '<OPTION> -- Select Properties -- </OPTION>';
				//$recip_opt = array();
				//$blog_details = get_blog_details($k, true);
				$cur_property = $blog_details->blogname;
			
				echo '<p><TABLE><TR><TH>' . $cur_property . ' contacts</TH></TR>';
						//for each property, set the message and recipients as a Metavalue?
				
					foreach ($recipients as $recipient) {
						$recip_email = get_post_meta( $recipient->ID, 'client_email', true );
						$recip_unit = get_post_meta( $recipient->ID, 'client_unit', true );
						$recip_cell = get_post_meta( $recipient->ID, 'client_cell', true );
						//$recip_all = get_post_meta( $recipient->ID );
						
						$recip_roles = get_the_terms( $recipient->ID, 'contact_data_types' );
						//////find custom taxonomy category name
						echo '<TR><TD><B>Contact:</B> ' . $recipient->post_title . '</TD></TR>';
						echo '<TR><TD><B>Email:</B>' . $recip_email . '</TD></TR>';
						echo '<TR><TF><BR></TF></TR>';
						
					}
					echo '</table>';
					//unset($recipients);
				
				
			echo '</P>';

		
	?>

	</div><!-- #primary.c6 -->

<?php get_footer(); ?>
