1<?PHP

$widget_string = ",10 Crosby Street Place,Augusta,ME,04330,,10 Noyes Court,Augusta,ME,04330,3,10 Oxford St,Augusta,ME,04330,2,113 Winthrop St,Augusta,ME,04330,2,114 Northern Avenue,Augusta,ME,04330,2,12 Crosby Street Place,Augusta,ME,04330,home,121 Cony Street,Augusta,ME,04330,,13 Carr Lane,Farmingdale,ME,04330,2,13 State street,Augusta,ME,04330,home,146 Sewall Street,Augusta,ME,04330,,15 Carr Lane,Farmingdale,ME,04330,home,16 Hayden Hill Rd,Litchfield,ME,04350,2,166 Water St,Randolph,ME,04330,,183 State Street,Augusta,ME,04330,home,20 Kendall St,Augusta,ME,04330,3,21 Washington St,Augusta,ME,04330,,22 Kendall St,Augusta,ME,04330,1,23 Elm Street,Augusta,ME,04330,1,23 Washington St,Augusta,ME,04330,,23 Winthrop St,Augusta,ME,04330,1,2392 Riverside Drive,Vassalboro,ME,04989,1,24 Sewall St,Augusta,ME,04330,1,26 Sewall St,Augusta,ME,04330,2,2647 West River Road,Sidney,ME,04330,1,27 Eastern Ave,Augusta,ME,04330,1,28 Sewall St,Augusta,ME,04330,HOME,28 Sheldon Street,Farmindale,ME,04344,,29 Pleasant St,Gardiner,ME,04345,1,3 Crosby Street Place,Augusta,ME,04330,,31 Bog Road,Augusta,ME,04330,1,31 laurel Street,Augusta,ME,04330,3,36 Malta,Augusta,ME,04330,,37 Bangor St,Augusta,ME,04330,TRLR,38 Stevens Lane,Farmingdale,ME,04344,B,4 Ryan Court,Augusta,ME,04330,B,40 Mt Vernon Ave.,Augusta,ME,04330,,42 Sheldon St,Farmingdale,ME,04344,1,43 Franklin St,Augusta,ME,04330,1,45 Jefferson,Augusta,ME,04330,,49 Pleasant St,Gardiner,ME,04330,1,50 Mt Vernon Ave,Augusta,ME,04330,HOME,50 Westwood,Augusta,ME,04330,2,524 Water Street,Gardiner,ME,04330,,58 Winthrop St,Augusta,ME,04330,,6 Arrowhead Drive,Vassalboro,ME,04989,2-Jan,6 Crosby Street Place,Augusta,ME,04330,,61 Pleasant St,Gardiner,ME,04330,,61 Water St,Hallowell,ME,04347,,62 State St,Augusta,ME,04330,2,7 Gannett Street,Augusta,ME,04330,1,71 Washington St,Augusta,ME,04330,,71 Water St,Hallowell,ME,04347,1,79 Willow St,Augusta,ME,04330,1,81 Willow St,Augusta,ME,04330,2,95 Summer St,Gardiner,ME,04330,1,97 summer St,Gardiner,ME,04330,B,98 Northern Ave.,Augusta,ME,04330,1,Hummingbird Circle 10,Augusta,ME,04330,1,Hummingbird Circle 12,Augusta,ME,04330,1,Hummingbird Circle 5,Augusta,ME,04330,1,Hummingbird Circle 6,Augusta,ME,04330,1,Hummingbird Circle 9,Augusta,ME,04330";

$properties_array = split(',',$widget_string);
$number = count($properties_array);
//echo "$number";
$add_contact = "<Table><thead><TR>
					<TH>Floors</TH>
					<TH>Street</TH>
					<TH>City</TH>
					<TH>State</TH>
					<TH>Zip</TH>
					
				</TR></thead>
				<tbody></tbody>";
for ($i = 0; $i <= (count($properties_array) -1); $i = ($i+5)) {


		$floors = $properties_array[$i];
		$street = $properties_array[$i+1];
		$city = $properties_array[$i+2];
		$state = $properties_array[$i+3];
		$zip = $properties_array[$i+4];

		//echo "<B>$i - $first_name $last_name</B>";




//////////////////////////////////////////////////////////////

$add_contact .= "<TR>
					<TH>" . $floors . "</TH>
					<TH>" . $street . "</TH>
					<TH>" . $city . "</TH>
					<TH>" . $state . "</TH>
					<TH>" . $zip . "</TH>
					
				</TR>";


//echo "$add_contact<BR><BR>";


//INSERT INTO residents (contact_ID,
//					property_ID,
//					board_member,
//					resident_type
//
//
//				) VALUES (@next_contact_ID,
//					28,
//					1,
//				'Owner')
//
//	INSERT INTO employees (
//
//				contact_ID,
//				work_eligibility_documentation,
//				department,
//				approval_code,
//				title,
//				employment_level
//				)
//
//				VALUES (
//
//				@next_contact_ID,
//				'Passport',
//				'Property Management',
//				'pm_approval',
//				'Property Manager',
//				'Full Time'
//				)
//
//
//		UPDATE employees SET
//				assigned_clients = '26,27,28,29,30,31,32,33,34,35'
//				WHERE contact_ID = @next_contact_ID
//
//
//


//$make_add_contact = odbc_exec($yardi_connection, $add_contact);
//odbc_free_result($make_add_contact);
//$update = "UPDATE employees SET
//					assigned_clients = '11,12'
//					WHERE contact_ID = '12';";
//
//$make_update = odbc_exec($db_connection, $update);

if (isset($make_update)) {

print odbc_error();

}

}//end for loop

$add_contact .= "</tbody></Table>";






?>
