<?PHP


add_filter("gform_predefined_choices", "add_predefined_choice");
function add_predefined_choice($choices){

	global $wpdb;
	global $current_user;
	get_currentuserinfo();

	$args = array(
				'network_id' => $wpdb->siteid,
				'public'     => null,
				'archived'   => null,
				'mature'     => null,
				'spam'       => null,
				'deleted'    => null,
				'limit'      => 100,
				'offset'     => 0,
				);
				
	$property_ids = wp_get_sites( $args );
	$property_ct = count( $property_ids);
	echo "<H1>IDS: " . $property_ids . ", Count: " . $property_ct . "</H1>";
   $choices["Contacts"] = array();
   $choices["Network Contacts"] = array();
   $choices["Network Properties"] = array();
   $choices["User Groups"] = array();
   $choices["Document Types"] = array();
   $choices["Units"] = array();
   $choices["Vendors"] = array();
   $choices["Vendor Services"] = array();
   $choices["Vendor Contacts"] = array();
   $choices["Assigned Properties"] = array();
   $choices["Roles"] = array();//the formal user role rather than contact type above
   //use for site access permissions - use groups for content access
   
	global $wpdb;
	global $current_user;
	
	get_currentuserinfo();

		$args = array(
					'network_id' => $wpdb->siteid,
					'public'     => null,
					'archived'   => null,
					'mature'     => null,
					'spam'       => null,
					'deleted'    => null,
					'limit'      => 100,
					'offset'     => 0,
					);
							
		$property_ids = wp_get_sites( $args );
		$property_ct = count( $property_ids);
			
		foreach ($property_ids as $k=>$v) {
			foreach ($v as $k1=>$v1) {
				//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
				if ($k1 == 'blog_id') {
					$blog_details = get_blog_details($v1, true);
//echo '<LI>Array1: ' . $blog_details->blog_id . ' => ' . $blog_details->blogname . '</LI>';
					$choices["Assigned Properties"][] = $blog_details->blogname . '|' . $blog_details->blog_id;
				}
			}
		}
			

	$blogusers = get_users( array( 'fields' => array( 'display_name', 'role', 'ID' ) ) );
     //Array of stdClass objects.
     foreach ( $blogusers as $user ) {
     	//echo '<span>' . esc_html( $user->display_name ) . '</span>';
     	if ( $user->role == 'property_vendor' || $user->role != 'property_vendor' ) {
			$choices["Vendor Contacts"][] = $user->display_name . ' | ' . $user->ID . '-' . $user->role;
		}
   	}

   $contacts = get_posts( array( 'post_type' => 'contact_data', 'post_status' => 'publish' ) );
   // Array of stdClass objects.
   foreach ( $contacts as $contact ) {
      	$choices["Contacts"][] = $contact->post_title . ' | ' . $contact->ID;
   }
   
	foreach ($property_ids as $k=>$v) {
		//$blog_details = get_blog_details($k, true);
		//echo "<H4>K: " . $k . ", V: " . $v . "</H4>";
		foreach ($v as $k1=>$v1) {
			//echo "<H4>K1: " . $k1 . ", V1: " . $v1 . "</H4>";
			if ($k1 == 'blog_id') {
				$blog_details = get_blog_details($v1, true);
				switch_to_blog($v1);
			}
		}
		//echo "<H4>Name?: " . $blog_details->blogname . "</H4>";
		$choices["Network Properties"][] = $blog_details->blogname . ' | ' . $blog_details->blog_id;
		$args = array( 'post_type' => 'contact_data', 'post_status'=> 'publish' );

		$myposts = get_posts( $args );
		//echo "<H4>SQL?: " . $wpdb->last_query . "</H4>";
		foreach ( $myposts as $post ) : setup_postdata( $post );

			$contact_user_id = get_post_meta($post->ID, 'unit_owner_id', true);
			$choices["Network Contacts"][] = $post->post_title . ' | ' . $post->ID;
				
		endforeach; 
		wp_reset_postdata();

	}
	restore_current_blog();
		
   // Array of stdClass objects.

	
	$taxonomy = 'contact_data_types';
	$term_args=array(
	  'hide_empty' => false,
	  'orderby' => 'name',
	  'order' => 'ASC'
	);
	$user_tax = get_terms($taxonomy,$term_args);
	foreach ( $user_tax as $user ) {

     	$choices["User Groups"][] = $user->name . ' | ' . $user->term_id;
   	}

	$taxonomy = 'property_document_types';
	$term_args=array(
	  'hide_empty' => false,
	  'orderby' => 'name',
	  'order' => 'ASC'
	);
	$user_tax = get_terms($taxonomy,$term_args);
	foreach ( $user_tax as $user ) {

     	$choices["Document Types"] [] = $user->name . ' | ' . $user->term_id;
   	}

	$post_args=array(
	  'post_type' => 'unit_data',
	  'post_status' => 'publish',
	  'order' => 'ASC'
	);
	$unit_posts = get_posts($post_args);
	foreach ( $unit_posts as $post ) {
	$title = $post->post_title;
	$this_id = $post->ID;

		$choices["Units"][] = $title . ' | ' . $this_id;
		//$choices["Units"][] = $wpdb->last_query;
	}

	$vendors = get_posts( array( 'post_type' => 'property_vendor', 'post_status' => 'publish' ) );
		// Array of stdClass objects.
		foreach ( $vendors as $vendor ) {
			$choices["Vendors"][] = $vendor->post_title . ' | ' . $vendor->ID;
   		}

	$taxonomy = 'property_vendor_services';
	$term_args=array(
	  'hide_empty' => false,
	  'orderby' => 'name',
	  'order' => 'ASC'
	);
	$vendor_tax = get_terms($taxonomy,$term_args);
	foreach ( $vendor_tax as $service ) {

     	$choices["Vendor Services"] [] = $service->name . ' | ' . $service->term_id;
   	}

	//get roles
	global $wp_roles;

	if ( ! isset( $wp_roles ) ) {
		$wp_roles = new WP_Roles();
		$roles = $wp_roles->get_names();
	}
		foreach ($wp_roles as $role_name => $role_value) {
		//$choices["Roles"] [] = $role_name . ' | ' . $role_value;
			if ($role_name == 'roles') {
				foreach( $role_value as $k=>$v ) {
					//$choices["Roles"] [] = $v . ' | ' . $k;
					//if ( $v == 'role_names' ) {
						foreach( $v as $k1=>$v1 ) {
							if ( $k1 == 'name' ) {
								$choices["Roles"][] =  $v1 . ' | ' . $k;
							}
						}
						
					//}
				}

			}
	  	}




   return $choices;

}








//additional gform processing

//processing Compose Message Form 16
//add_filter( "gform_after_submission", "sendCommunicationEmails", 10, 4 );

function sendCommunicationEmails( $entry, $lead, $field, $form ){
	global $user;
	global $wpdb;

    if( $entry['form_id'] != 16 ) { return; }
    $message = "<H2>Entry</H2><UL>";
    if ( is_array($entry) ) {
		
		foreach ($entry as $k=>$v) {
			if ( !is_array($v) ) {
				$message .= "<li>Level 1: " . $k . ", " . $v . "</li>";
			} else {
				$message .= "<H3>Nested</H3><UL>";
				foreach ( $v as $k1=>$v1 ) {
					$message .= "<li>Level 2: " . $k1 . ", " . $v1 . "</li>";
				}
				$message .= "</ul>";
			}
		}
		$message .= "</ul>";
	}
    
    
    $message .= "<p><hr>";
    $message .= "<H1>Form ID: " . $entry['form_id'] . "<H1>";
    add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
 		
    
	//$message = print_r($entry, true);
    $message .= "<P>Additional Emails:<BR>";
    if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
    if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

    $recip_ids = explode( ",", $entry[14] );
    $type_test = gettype($entry[14]);
    $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>";
        
    $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>";
    
    add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
        
    $admin_email = get_option( 'admin_email', $default );
	$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
        
    for($i=0; $i < count($recip_ids); $i++) {
        
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        //$recip_email = get_userdata($recip_ids[$i]);
        $recip_id = get_user_by('id', $recip_ids[$i]);
        $recip_email = get_post_meta( $recip_ids[$i], 'client_email', true );
        $recip_subject = $entry[1];
        $recip_message = $entry[3];
        $recip_message = wordwrap($recip_message, 70);

		//add_filter( 'wp_mail_content_type', 'set_html_content_type' );
		//$admin_email = get_option( 'admin_email', $default );
		//$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
		//wp_mail( $recip_email, 'Recip', $message );

		/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
			echo "<H1>Not dg_419HOTMAIL</H1>";
		}
		*/
			
        $message .= '<P>Email to: ' . $recip_email;
        //wp_mail( $recip_email, $recip_subject, $recip_message, $headers, $attachments );

        foreach($v  as $k1=>$v1) {
			$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        }
        	
    }

	//$message = wordwrap($message, 70);
	 // Send
	// $attachments = array( $entry[12] );
	move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
	$use_filename = str_replace('http://www.ptechinternational.com/ptiMulti/pmsuite/wp-content/uploads/', '', $entry[12]);
		 		 
	$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
	$message .= '<P>' . $attachments[0];

	wp_mail( 'dg_419@hotmail.com', $recip_subject, $recip_message, $headers, $attachments );
	wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
 		
	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	
}

add_filter( "gform_after_submission", "run_form_processes", 10, 4 );

function run_form_processes( $entry, $lead, $field, $form ){
	global $user;
	global $wpdb;

 	/*************************************************/
 	//if document post notification is set
    if( $entry['form_id'] == 2 ) {
		$message = print_r($entry, true);
		$message .= "<P>Additional Emails:<BR>";
		$new_vendor_service = $entry[46];

		if ( !empty( $entry[46] ) ) {
			if ( wp_insert_term(
			  		$entry[46], // the term
					'property_vendor_services', // the taxonomy
					 array(
						'description'=> '',
						'parent'=> 42
					 )

					)
				)

			{
				$message .= "<H1>GOOD</H1>";
				add_predefined_choice($choices);//reset gforms menu options
			} else {
				$message .= "<H1>NOT GOOD</H1>";
			}

  		mail('dg_419@hotmail.com', 'Getting the Gravity Form 2', $message);
 		}


 	//add contact as a user if not already present
	global $wp_roles;

	$all_roles = $wp_roles->roles;
	$user_id = username_exists( $entry[2] );
	if ( email_exists($entry[6]) == false ) {

         $message = "<P>Add user and contact data:<BR>";
         $message .= print_r($entry, true);

         $post = array(
		 	        'post_status'  => 'publish' ,
		 	        'post_title'  => $entry[1] . ' ' . $entry[4],
		 	        'post_type'  => 'contact_data' ,
		 	    );

		 	    // insert the post
	    $post_id = wp_insert_post( $post );




		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		//$user_id = wp_create_user( $entry[1], $random_password, $entry[5] );


		$userdata = array(
		    'user_login'  =>  $entry[1],
		    'user_email'    =>  $entry[5],
		    'user_pass'   =>  $random_password,
		    'role' => 'property_trustee'
		);
		$user_id = wp_insert_user( $userdata );

		//$updatethis = update_user_meta( $user_id, 'role', 'property_trustee' );



		if ( $updatethis === false ) {
		$message .= "<H4>Bad Role: " . $updatethis . ", " . $user_id . "</H4>";
		} else {
		$message .= "<H4>GOOD Role: " . $updatethis . ", " . $user_id . "</H4>";
		}


		//get_editable_roles();
		$message .= "<H4>Roles: " . $all_roles . "</H4>";
		foreach($all_roles as $role => $name) {
		$message .= "<H5>Role Key: " . $role . "; Role Value: " . $name[0] . "</H4>";
		foreach($name as $k => $v) {
				$message .= "<UL><H5>Role Key: " . $k . "; Role Value: " . $v . "</H4></UL>";
				if ($v == 'Trustee') {
				//$updatethis = update_user_meta( $user_id, 'role', $v );

				}
		}
		}

		//set user role based on contact type - entry[9]
		//if entry[9] == 3 user role is 'trustee' for example
		switch( $entry[9] ) {
			case 4:
				//update_user_meta( $user_id, 'role', 'fg_prop_occupant' );
				break;

			case 3:
				//update_user_meta( $user_id, 'role', 'fg_prop_owner' );
				break;


			case 2:
				//update_user_meta( $user_id, 'role', 'fg_prop_trustee' );
				break;



		}

		update_user_meta( $user_id, 'contact_data_id', $post_id );
		update_user_meta( $user_id, 'contact_first_name', $entry[1] );
		update_user_meta( $user_id, 'contact_last_name', $entry[4] );
		update_user_meta( $user_id, 'client_phone', $entry[2] );
		update_user_meta( $user_id, 'client_email', $entry[5] );
		update_user_meta( $user_id, 'client_cell', $entry[3] );
		/*
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );
		*/

		}



 	}


 	/*************************************************/
 	//if document post notification is set
     if( $entry['form_id'] == 3 ) {
         $message = print_r($entry, true);
         $message .= "<P>Additional Emails:<BR>";

         //group recipients
         $recip_group_ids = explode( ",", $entry[4] );
         //use group ids to get individual ids and merge arrays below
         for($i=0; $i < count($recip_group_ids); $i++) {
				$message .= "<H2>Group Ids Look: " . $recip_group_ids[$i] . "</H2>";
				$args = array(
				'post_type' => 'contact_data',
				'tax_query' => array(
					array(
					'taxonomy' => 'contact_data_types',
					'field' => 'term_id',
					'value' => $recip_group_ids[$i]
					 )
				  )
				);
				$query = new WP_Query( $args );

				if ( $query->have_posts() ) {
					$message .= "<ul>";
					while ( $query->have_posts() ) {
						$query->the_post();
						$message .= "<li>Title" . the_title() . "</li>";
					}
					$message .= "</ul>";
				} else {
					$message .= "<H3>" . $wpdb->last_query . "</H3>";
				}
				/* Restore original Post Data */
				wp_reset_postdata();
		}


         $recip_contact_ids = explode( ",", $entry[5] );
         $type_test = gettype($entry[4]);
         $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
         ";
         $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
         ";
         for($i=0; $i < count($recip_contact_ids); $i++) {
         $message .= "<P>K: " . $i . ", V: " . $recip_contact_ids[$i];
         	//$recip_email = get_userdata($recip_contact_ids[$i]);
         	$recip_email = get_user_by('id', $recip_contact_ids[$i]);
         	$recip_subject = $entry[1];
         	$recip_message = $entry[2];
         	$recip_message = wordwrap($recip_message, 70);

 			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
 			$admin_email = get_option( 'admin_email', $default );
 			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
 			//wp_mail( $recip_email, 'Recip', $message );


			if ( isset( $entry[6.1] ) && $entry[6.1] != '' ) {
				//if ( !wp_mail( $recip_email->user_email, $recip_subject, //$recip_message, $headers ) ) {
					$message .= '<H1>Not dg_419HOTMAIL</H1>';
				//}
 			} else {

 			$recip_subject .= 'NO NOTICE' . $recip_subject;
 			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
								$message .= '<H1>Later dg_419HOTMAIL</H1>';
				}
				*/
 			}

 			remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
         	$message .= '<P>Email to: ' . $recip_email->user_email;

         	foreach($v  as $k1=>$v1) {
         	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
         	}
         }

 		$message = wordwrap($message, 70);
 		 // Send
  		mail('dg_419@hotmail.com', 'Getting the Gravity Form 3', $message);
 	}


    //if client communications form
    if( $entry['form_id'] == 6 ) {
        $message = print_r($entry, true);
        $message .= "<P>Additional Emails:<BR>";
        if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
        if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

        $recip_ids = explode( ",", $entry[14] );
        $type_test = gettype($entry[14]);
        $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
        add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
        $admin_email = get_option( 'admin_email', $default );
		$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
        for($i=0; $i < count($recip_ids); $i++) {
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	$recip_id = get_user_by('id', $recip_ids[$i]);
        	$recip_email = get_post_meta( $recip_ids[$i], 'client_email', true );
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			//add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			//$admin_email = get_option( 'admin_email', $default );
			//$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			//wp_mail( $recip_email, 'Recip', $message );

			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
				echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			*/
			
        	$message .= '<P>Email to: ' . $recip_email;
        	wp_mail( $recip_email, $recip_subject, $recip_message, $headers, $attachments );

        	foreach($v  as $k1=>$v1) {
        	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        	
        }

		$message = wordwrap($message, 70);
		 // Send
		// $attachments = array( $entry[12] );
		 move_uploaded_file( $entry[12],WP_CONTENT_DIR .'/uploads/'.basename($entry[12] ) );
		 $use_filename = str_replace('http://www.ptechinternational.com/ptiMulti/pmsuite/wp-content/uploads/', '', $entry[12]);
		 
		 
		$attachments = array(WP_CONTENT_DIR ."/uploads/".$use_filename);
		$message .= '<P>' . $attachments[0];

		wp_mail( 'dg_419@hotmail.com', $recip_subject, $recip_message, $headers, $attachments );
		wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );
 		
 		remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	}


 	/*************************************************/
 	//if document post notification is set
     if( $entry['form_id'] == 9 ) {

		global $wp_roles;
		$all_roles = $wp_roles->roles;
		$user_id = username_exists( $entry[1] );
		if ( email_exists($entry[5]) == false ) {

         $message = "<P>Add user and contact data:<BR>";
         $message .= print_r($entry, true);

         $post = array(
		 	        'post_status'  => 'publish' ,
		 	        'post_title'  => $entry[1] . ' ' . $entry[4],
		 	        'post_type'  => 'contact_data' ,
		 	    );

		 	    // insert the post
	    $post_id = wp_insert_post( $post );




		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		//$user_id = wp_create_user( $entry[1], $random_password, $entry[5] );


		$userdata = array(
		    'user_login'  =>  $entry[1],
		    'user_email'    =>  $entry[5],
		    'user_pass'   =>  $random_password,
		    'role' => 'property_trustee'
		);
		$user_id = wp_insert_user( $userdata );

		//$updatethis = update_user_meta( $user_id, 'role', 'property_trustee' );



		if ( $updatethis === false ) {
		$message .= "<H4>Bad Role: " . $updatethis . ", " . $user_id . "</H4>";
		} else {
		$message .= "<H4>GOOD Role: " . $updatethis . ", " . $user_id . "</H4>";
		}


		//get_editable_roles();
		$message .= "<H4>Roles: " . $all_roles . "</H4>";
		foreach($all_roles as $role => $name) {
		$message .= "<H5>Role Key: " . $role . "; Role Value: " . $name[0] . "</H4>";
		foreach($name as $k => $v) {
				$message .= "<UL><H5>Role Key: " . $k . "; Role Value: " . $v . "</H4></UL>";
				if ($v == 'Trustee') {
				//$updatethis = update_user_meta( $user_id, 'role', $v );

				}
		}
		}

		//set user role based on contact type - entry[9]
		//if entry[9] == 3 user role is 'trustee' for example
		switch( $entry[9] ) {
			case 4:
				//update_user_meta( $user_id, 'role', 'fg_prop_occupant' );
				break;

			case 3:
				//update_user_meta( $user_id, 'role', 'fg_prop_owner' );
				break;


			case 2:
				//update_user_meta( $user_id, 'role', 'fg_prop_trustee' );
				break;



		}

		update_user_meta( $user_id, 'contact_data_id', $post_id );
		update_user_meta( $user_id, 'contact_first_name', $entry[1] );
		update_user_meta( $user_id, 'contact_last_name', $entry[4] );
		update_user_meta( $user_id, 'client_phone', $entry[2] );
		update_user_meta( $user_id, 'client_email', $entry[5] );
		update_user_meta( $user_id, 'client_cell', $entry[3] );
		/*
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );
		*/

			} else {
			$really = email_exists($entry[5]);
			$message .= "<H4>No Roles: " . $entry[5] . ", Really: " . $really . "</H4>";
			$return_email_fail;
			return false;
			}
         //update_post_meta($post_id, 'contact_first_name', $entry[1]);
         //update_post_meta($post_id, 'contact_first_name', $entry[4]);

	//set contact type
	wp_set_post_terms( $post_id, $entry[9], 'contact_data_types', $append );
	update_post_meta( $post_id, 'contact_first_name', $entry[1] );
	update_post_meta( $post_id, 'contact_last_name', $entry[4] );
	update_post_meta( $post_id, 'client_phone', $entry[2] );
	update_post_meta( $post_id, 'client_email', $entry[5] );
	update_post_meta( $post_id, 'client_cell', $entry[3] );
	/*
	update_post_meta( $client_addr1, 'client_addr1', $client_addr1 );
	update_post_meta( $client_addr2, 'client_addr2', $client_addr2 );
	update_post_meta( $client_city, 'client_city', $client_city );
	update_post_meta( $client_zip, 'client_zip', $client_zip );
	*/
	// Send
  		mail('dg_419@hotmail.com', 'Getting the Gravity Form 9', $message);
 	}
	/***************************************************************/

 	//Enter work order and send notifications
     if( $entry['form_id'] == 22 ) {
		add_filter( 'wp_mail_content_type', 'set_html_content_type' );
       $message = print_r($entry, true);
       foreach($entry as $k=>$v) {
		   $message .= "<P>Form Data:<UL>";
		   $message .= "<li>Key: " . $k . "; Value: " . $v . "<li>";
	   }
        $message .= "</UL><P>Additional Emails:<BR>";
        if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
        if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

        $recip_ids = explode( ",", $entry[14] );
        $type_test = gettype($entry[14]);
        $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
        for($i=0; $i < count($recip_ids); $i++) {
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	$recip_email = get_user_by('id', $recip_ids[$i]);
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$admin_email = get_option( 'admin_email', $default );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			//wp_mail( $recip_email, 'Recip', $message );

			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
				echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			*/
			
        	$message .= '<P>Email to: ' . $recip_email->user_email;

        	foreach($v  as $k1=>$v1) {
        	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        }

		$message = wordwrap($message, 70);
		 // Send
 		mail('dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message);
 		remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
 	}
 	
 	/***************************************************************/

 	//Testing Event plugin as WO request
     if( $entry['form_id'] == 23 ) {
		add_filter( 'wp_mail_content_type', 'set_html_content_type' );
       $message = print_r($entry, true);
       $message .= "<P>Form Data:<UL>";
       foreach($entry as $k=>$v) {
		   
		   $message .= "<li>Key: " . $k . "; Value: " . $v . "<li>";
	   }
        $message .= "</UL><P>Additional Emails:<BR>";
        if (is_array($entry[14])) { $message .= "<P>Field forteen Array:" . $entry[14] . "<BR>";}
        if (is_string($entry[14])) { $message .= "<P>Field forteen String:" . $entry[14] . "<BR>";}

        $recip_ids = explode( ",", $entry[14] );
        $type_test = gettype($entry[14]);
        $message .= "<P>IDs Array:" . $type_test . ", " . $recip_ids . "<BR>
        ";
        $message .= "<P>Form ID: " . $entry['form_id'] . "<BR>
        ";
        for($i=0; $i < count($recip_ids); $i++) {
        $message .= "<P>K: " . $i . ", V: " . $recip_ids[$i];
        	//$recip_email = get_userdata($recip_ids[$i]);
        	$recip_email = get_user_by('id', $recip_ids[$i]);
        	$recip_subject = $entry[1];
        	$recip_message = $entry[3];
        	$recip_message = wordwrap($recip_message, 70);

			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$admin_email = get_option( 'admin_email', $default );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
			//wp_mail( $recip_email, 'Recip', $message );

			/*if ( !wp_mail( $recip_email->user_email, $recip_subject, $recip_message, $headers ) ) {
				echo "<H1>Not dg_419HOTMAIL</H1>";
			}
			*/
			
        	$message .= '<P>Email to: ' . $recip_email->user_email;

        	foreach($v  as $k1=>$v1) {
        	$message .= "<P>Array: " . $k1 . ";<BR>Vale: " . $v1;
        	}
        }

		$message = wordwrap($message, 70);
		 // Send
 		mail('dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message, $headers);
 		remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
 	}
	/***************************************************************/
}

add_filter('gform_validation_9', 'validate_user');

function validate_user($validation_result) {
    // 2 - Get the form object from the validation result
    $form = $validation_result["form"];

    // 3 - Get the current page being validated
    $current_page = rgpost('gform_source_page_number_' . $form['id']) ? rgpost('gform_source_page_number_' . $form['id']) : 1;
foreach($form['fields'] as &$field){
if ( email_exists($field['client_email']) ) {

		$field['failed_validation'] = true;
        $field['validation_message'] = 'The email address you registered is already in use.';
}
}

    // 14 - Assign our modified $form object back to the validation result
    $validation_result['form'] = $form;

    // 15 - Return the validation result
    return $validation_result;

}
?>
