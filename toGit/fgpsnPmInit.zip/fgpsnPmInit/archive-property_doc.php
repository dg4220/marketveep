<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @since 3.0.0
 */
get_header(); 
global $wpdb;

?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP

$args = array(
	'offset'           => 0,
	'post_type'        => 'property_doc',
	'post_status'      => 'publish',
	'suppress_filters' => true );

	$communications = get_posts( $args );

	/*foreach ($communications as $communication) {
		$cur_doc_file = get_post_meta($communication->ID, 'property_doc_file', true);
		if (is_array($cur_doc_file)) {
			$cur_file = $cur_doc_file[url];
		} else {
			$cur_file = $cur_doc_file;
		}
		echo "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $communication->ID . "'>" . $communication->post_title . "</A></TD>
				<TD>" . get_the_time('D j, Y', $communication->ID) . "</TD>
				<TD><A HREF='" . $cur_file . "' target='_blank'>View</A></TD></TR>";

	}
	echo '</table>';
	* */
		//unset($communications);


		echo '</P>';

	wp_enqueue_script( 'jquery-ui-accordion' );
	$disp_data = "<script type='text/javascript' language='javascript' src='http://datatables.net/release-datatables/media/js/jquery.js'></script><link rel='stylesheet' href='http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css' />

	<script>
	jQuery(document).ready(function() {
	jQuery( '#fg-documents-accordion' ).accordion({
	heightStyle: 'content'
	});
	});
	</script>";
	
	/* setup attribute distinguish property vs. service vendor using parent categories */
	
	
	$args = array(
		'post_type'        => 'property_doc',
		'taxonomy' => 'property_document_types',
		'hide_empty'  		=> 1,
		'show_count'         => 1,
		'hierarchical'  => true,
		'order' => ASC);

	$terms = get_terms("property_document_types", $args);

	 $count = count($terms);
	 if ( $count > 0 ){
		 /* $disp_data .= "<ul class='no_bullets top'>"; */
		 $disp_data .= "<div id='fg-documents-accordion'>";
		 foreach ( $terms as $term ) {

			//now get terms where ID is parent
			/* $disp_data .= "<li class='level_1'><A HREF='"  . get_bloginfo('url') . "/property_document_types/" . $term->slug . "/'>" . $term->name . " (" . $term->count . ")</A>"; */

			$disp_data .= "<H3>" . $term->name . " <DIV STYLE='display: inline; position: relative; float: right; font-size: 70%; color: blue; padding-right: 20px; padding-top: 7px;'> Total: " . $term->count . "</DIV><DIV STYLE='display: inline; position: relative; float: right; font-size:  70%; color: blue; padding-right: 20px; padding-top: 7px;'> Most Recent:" . get_the_time('D j, Y', $term->ID) . "</DIV></H3>";
			$cur_slug = $term->slug;

		 $args2 = array(
			'post_type'        => 'property_doc',
			'property_document_types' => $cur_slug,
			'hide_empty'  		=> 0,
			'hierarchical'  => true,
			'show_count'         => 1
			);

		 $terms2 = get_posts($args2);
		  $count2 = count($terms2);
		  if ( $count2 > 0 ){
			  /* $disp_data .= "<ul class='no_bullets'>"; */
			  $disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH></TR></THEAD>
			  <TBODY>";
			  foreach ( $terms2 as $term2 ) {

				$cur_doc_file = get_post_meta($term2->ID, 'property_doc_file', true);
				if (is_array($cur_doc_file)) {

					$cur_file = $cur_doc_file[url];

				} else {

					$cur_file = $cur_doc_file;

				}
				$disp_data .= "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $term2->ID . "'>" . $term2->post_title . "</A></TD>
				<TD>" . get_the_time('D j, Y', $term2->ID) . "</TD>
				<TD><A HREF='" . $cur_file . "' target='_blank'>View</A></TD></TR>";

			  }
			  $disp_data .= "</TABLE>";
		 }


		/* $disp_data .= "</li>"; */

		 }
		/* $disp_data .= "</ul>"; */
		$disp_data .= "</DIV>";
	 }
	
echo $disp_data;

?>

	</div><!-- #primary.c6 -->

<?php get_footer(); ?>
