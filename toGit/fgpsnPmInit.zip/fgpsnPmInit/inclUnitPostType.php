<?PHP

/******************************************************
 * DG Creating Data post type and meta boxes: Data type and the actual file.
*******************************************************/
function add_jquery() {
   wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'jquery-ui-core' );
	wp_enqueue_script( 'jquery-ui-slider' );
	
	/*wp_enqueue_style( 'fgpsn-unit-styles', 'http://www.apexpropertymanagement-me.com/wp-content/plugins/fgpsnPmInit/css/fgpsn-unit-styles.css' );

	wp_register_script('fgpsnUnitScripts', plugins_url() . '/fgpsnPmInit/js/fgpsnUnitScripts.js', array('jquery'),null,true   );
	  
	wp_enqueue_script( 'fgpsnUnitScripts' );
	*/

}
add_action( 'wp_enqueue_scripts', 'add_jquery' );

wp_enqueue_style( 'fgpsn-unit-styles', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/css/fgpsn-unit-styles.css' );

wp_register_script('fgpsnUnitScripts', plugins_url() . '/fgpsnPmInit/js/fgpsnUnitScripts.js', array('jquery'),null,true   );
  
wp_enqueue_script( 'fgpsnUnitScripts' );

function custom_post_unit_data() {

		$labels = array(
			'name'               => _x( 'Units', 'post type general name' ),
			'singular_name'      => _x( 'Unit', 'post type singular name' ),
			'add_new'            => _x( 'Add Unit', 'unit_data' ),
			'add_new_item'       => __( 'Add New Unit' ),
			'edit_item'          => __( 'Edit Unit Data' ),
			'new_item'           => __( 'New Unit' ),
			'all_items'          => __( 'All Units' ),
			'view_item'          => __( 'View Unit' ),
			'search_items'       => __( 'Search Units' ),
			'not_found'          => __( 'No Units Found' ),
			'not_found_in_trash' => __( 'No Units found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Units'
		);

		$args = array(
			'labels'        => $labels,
			'description'   => 'Holds our Unit Data',
			'public'        => true,
			'menu_position' => 5,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes', 'excerpt', 'thumbnail'/*, 'custom-fields'*/ ),
			'taxonomies'      => array( 'unit_data_types', 'unit_ammenities'  ),
			'hierarchical' => true,
			'has_archive'   => true
		);


	register_post_type( 'unit_data', $args );
}
add_action( 'init', 'custom_post_unit_data' );

/**/
add_action( 'init', 'create_unit_data_types' );

function create_unit_data_types() {
 $labels = array(
    'name' => _x( 'Unit Data Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Data Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Data Types' ),
    'all_items' => __( 'All Data Types' ),
    'parent_item' => __( 'Parent Data Type' ),
    'parent_item_colon' => __( 'Parent Data Type:' ),
    'edit_item' => __( 'Edit Data Type' ),
    'update_item' => __( 'Update Data Type' ),
    'add_new_item' => __( 'Add New Data Type' ),
    'new_item_name' => __( 'New Data Type Name' ),
    
  );

  register_taxonomy('unit_data_types','unit_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    'query_vars'		=> true,
    'show_in_nav_menus' => true,
    'public' => true,
    'show_ui' => true,
    'show_tagcloud' => true,
    

  ));
}


add_action( 'init', 'create_unit_ammenities' );

function create_unit_ammenities() {
 $labels = array(
    'name' => _x( 'Unit Ammenities', 'taxonomy general name' ),
    'singular_name' => _x( 'Ammenity', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Ammenities' ),
    'all_items' => __( 'All Ammenities' ),
    'parent_item' => __( 'Parent Ammenity' ),
    'parent_item_colon' => __( 'Parent Ammenity' ),
    'edit_item' => __( 'Edit Ammenity' ),
    'update_item' => __( 'Update Ammenity' ),
    'add_new_item' => __( 'Add New Ammenity' ),
    'new_item_name' => __( 'New Ammenity Name' ),
  );

  register_taxonomy('unit_ammenities','unit_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    'query_vars'		=> true,
    'show_in_nav_menus' => true,
    'public' => true,
    'show_ui' => true,
    'show_tagcloud' => true,

  ));
}


add_action( 'init', 'create_fgpsn_unit_locations' );

function create_fgpsn_unit_locations() {
 $labels = array(
    'name' => _x( 'Unit Location', 'taxonomy general name' ),
    'singular_name' => _x( 'Unit Location', 'taxonomy singular name' ),
    'search_items' =>  __( 'Locations' ),
    'all_items' => __( 'All Locations' ),
    'parent_item' => __( 'Parent Location' ),
    'parent_item_colon' => __( 'Parent Location' ),
    'edit_item' => __( 'Edit Locations' ),
    'update_item' => __( 'Update Locations' ),
    'add_new_item' => __( 'Add New Locations' ),
    'new_item_name' => __( 'New Locations Name' ),
  );

  register_taxonomy('fgpsn_unit_locations','unit_data',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    'query_vars'		=> true,
    'show_in_nav_menus' => true,
    'public' => true,
    'show_ui' => true,
    'show_tagcloud' => true,

  ));
}


/**/




/*****************************************************************************************/
/*****************************************************************************************/
add_action( 'add_meta_boxes', 'unit_info' );
function unit_info() {

	$screens = array( 'unit_data', 'fg_contact_data' );
    foreach ($screens as $screen) {
		add_meta_box(
			'unit_info',
			__( 'Unit Data', 'myplugin_textdomain' ),
			'unit_info_content',
			$screen,
			'normal',
			'high'
		);
	}
}


function unit_info_content( $post ) {
	
	global $wpdb;
	global $table_prefix;


	$fgpsn_property_id = get_post_meta( get_the_ID(), 'fgpsn_property_id', true );
	//$fgpsn_property_id = $fgpsn_property_id + 1000;
	echo '<h2>fgpsn_property_id: ' . $fgpsn_property_id . ', ' . get_the_ID() . '</h2>';
	//echo 'the meta' . the_meta();
	//var_dump($_POST);
	$fgpsn_property_unit_number = get_post_meta(get_the_ID(), 'fgpsn_property_unit_number', true);
	$fgpsn_property_unit_beds_number = get_post_meta(get_the_ID(), 'fgpsn_property_unit_beds_number', true);
	$fgpsn_property_address_1 = get_post_meta(get_the_ID(), 'fgpsn_property_address_1', true);
    $fgpsn_property_address_2 = get_post_meta(get_the_ID(), 'fgpsn_property_address_2', true);
    $fgpsn_property_city = get_post_meta($fgpsn_property_id, 'fgpsn_property_city', true);
    $fgpsn_property_unit_occupant_id = get_post_meta($post->ID, 'fgpsn_property_unit_occupant_id', true);


    
    $fgpsn_property_unit_owner_id = get_post_meta(get_the_ID(), 'fgpsn_property_unit_owner_id', true);
	$owner_link = get_permalink($fgpsn_property_unit_owner_id);
	
	wp_enqueue_script('jquery-ui-datepicker');
	
	echo '<script>

		  jQuery(document).ready(function() {
			jQuery("#fgpsn_property_unit_lease_start").datepicker();
			jQuery("#fgpsn_property_unit_lease_end").datepicker();
			jQuery("#fgpsn_property_unit_rent_effective_date").datepicker();
			jQuery("#fgpsn_property_unit_rent_effective_date").datepicker();
			jQuery("#fgpsn_property_unit_option_start").datepicker();
			jQuery("#fgpsn_property_unit_option_end").datepicker();
			jQuery("#fgpsn_property_unit_option_notification").datepicker();

		  });
		</script>';
	wp_nonce_field( plugin_basename( __FILE__ ), 'unit_info_content_nonce' );
	echo '<FIELDSET><DIV>';
	
/*
	$getem = $wpdb->get_results( "SELECT post_title, ID, post_type, post_status
						FROM " .  $table_prefix . "posts
						WHERE post_type = 'properties'");
	*/
		  
	echo '<P><input id="fgpsn_property_city" name="fgpsn_property_city" size=5 value="' . $fgpsn_property_city . '" type="hidden">
	<label for="fgpsn_property_id" STYLE="width: 110px;">Attach to Property, <b>NOW!</b></label><BR>

     	<SELECT id="fgpsn_property_id" STYLE="width: 120px;" name="fgpsn_property_id"  />

			<OPTION value=""> - Select - </OPTION>\n';
			
      $getem = get_posts(array('post_type' => 'properties', 'posts_per_page' => -1));

		  foreach ( $getem as $property ) {
			
      setup_postdata($property );
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);

      if ($address_1) {
        echo '<OPTION value="' . $property->ID . '"';

  			if ( $property->ID == $fgpsn_property_id ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $address_1 . " " . $city . "</A><BR>";
  			}

  			echo '>' .  $address_1  . ' ' . $address_2 . ', ' . $city . ', ' . $property->ID . ', ' . 
  			$fgpsn_property_id . '</OPTION>';
  			
      } else {
        echo '<OPTION value="' . $property->ID . '"';
        echo '>' . $property->ID . ', ' . $property->ID . '</OPTION>';
      }
				
			
			
		 
      }
      wp_reset_postdata();
		echo '</SELECT>' . $property_link . '</P>';
	echo '<P><label for="fgpsn_property_unit_number" STYLE="width: 110px;">Unit Number</label>
	<input id="fgpsn_property_unit_number" name="fgpsn_property_unit_number" size=5 value="' . $fgpsn_property_unit_number . '" type="text"></P>';


/*************************************************************************************/

	$fgpsn_property_unit_usage = get_post_meta($post->ID, 'fgpsn_property_unit_usage', true);
	echo '<P><label for="fgpsn_property_unit_usage" STYLE="width: 110px;">Approved Usage: ' .$fgpsn_property_unit_usage  . '</label><BR>';

			echo '<SELECT id="fgpsn_property_unit_usage" STYLE="width: 120px;" name="fgpsn_property_unit_usage"  />

				<OPTION value=""> - Select - </OPTION>\n
				<OPTION value="residential"';

				if ($fgpsn_property_unit_usage == 'residential') {
					echo ' SELECTED';
				}

				echo '> Residential </OPTION>\n
				<OPTION value="commercial"';

				if ($fgpsn_property_unit_usage == 'commercial') {
					echo ' SELECTED';
				}

				echo '> Commercial </OPTION>\n
				<OPTION value="mixeduse"';

				if ($fgpsn_property_unit_usage == 'mixeduse') {
					echo ' SELECTED';
				}

				echo '> Mixed Use </OPTION>\n

			</SELECT>


			</P>';
		//need to get this before the new loop
		
		
		/* update args for when owners are included*/
		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
							array(
								'taxonomy' => 'contact_data_types',
								'field' => 'slug',
								'terms' => 'owner'
							)
						)
					);

        $args = array(
			'post_type' => 'contact_data',
			'post_status' => 'publish',
			'nopaging'	=> true
		
			);

		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :

     	echo '<P><label for="fgpsn_property_unit_owner_id" STYLE="width: 110px;">Unit Owner: </label><BR>
		<H3>id' . $fgpsn_property_unit_owner_id . '</H3>
     	<SELECT id="fgpsn_property_unit_owner_id" STYLE="width: 120px;" name="fgpsn_property_unit_owner_id"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              $contact_id = get_post_meta(get_the_ID(), 'network_user_id', true);
              $contact_first_name = get_post_meta(get_the_ID(), 'fgpsn_contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_ID(), 'fgpsn_contact_last_name', true);
			if ( get_the_title() != '') {
				echo '<OPTION value="' . get_the_ID() . '"';

				if ($fgpsn_property_unit_owner_id == get_the_ID()) {
					echo ' selected';
					$fgpsn_property_unit_owner_link = "<BR><A HREF=" . get_the_permalink(get_the_ID())  . ">" . $contact_last_name . ", " . $contact_first_name . "</A><BR>";
				}

				echo '>' .  get_the_title() . '</OPTION>\n';
			}
          endwhile;
          
          echo '</SELECT>' . $fgpsn_property_unit_owner_link . '</P>';
     	endif;
		wp_reset_postdata();

	/*echo '<P><label for="fgpsn_property_unit_beds_number">Number of Bedrooms</label>';

	$fgpsn_property_unit_beds_number = get_post_meta($post->ID, 'fgpsn_property_unit_beds_number', true);
	echo '<input id="fgpsn_property_unit_beds_number" name="fgpsn_property_unit_beds_number" size=5 value="' . $fgpsn_property_unit_beds_number . '" type="text"></P>';
	*/
/*$oocids = get_post_meta($post->ID, 'fgpsn_property_unit_occupant_id', true);
var_dump($oocids);
echo '<H2>K ' . $k2 . ', ' . $v2 . ', ' . $post->ID . '</H2>';
if (is_array($oocids)) {

	foreach($oocids as $k2=>$v2) {
		echo '<H2>K1 ' . $k2 . ', ' . $v2 . ', ' . $post->ID . '</H2>';
		//$didit = update_post_meta($v2, 'fgpsn_property_unit_occupant_id', $post_id);
	}
} else {
	echo '<H2>K11111</H2>';
}
*/

	$oocids = get_post_meta($post->ID, 'fgpsn_property_unit_occupant_id', true);
	

	echo '<P><label for="fgpsn_property_unit_baths_number">Number of Baths</label>';

		$fgpsn_property_unit_baths_number = get_post_meta($post->ID, 'fgpsn_property_unit_baths_number', true);
		echo '<input id="fgpsn_property_unit_baths_number" name="fgpsn_property_unit_baths_number" size=5 value="' . $fgpsn_property_unit_baths_number . '" type="text">

		<P><label for="fgpsn_property_unit_lease_start">Lease Start Date: </label>';

		$fgpsn_property_unit_lease_start = get_post_meta($post->ID, 'fgpsn_property_unit_lease_start', true);
		echo '<input id="fgpsn_property_unit_lease_start" name="fgpsn_property_unit_lease_start" size=10 value="' . $fgpsn_property_unit_lease_start . '" type="text">

		<P><label for="fgpsn_property_unit_lease_end">Lease Start End: </label>';

		$fgpsn_property_unit_lease_end = get_post_meta($post->ID, 'fgpsn_property_unit_lease_end', true);
		echo '<input id="fgpsn_property_unit_lease_end" name="fgpsn_property_unit_lease_end" size=10 value="' . $fgpsn_property_unit_lease_end . '" type="text">

		<P><label for="fgpsn_property_unit_owner_occupied">Owner Occupied: </label>';

		$fgpsn_property_unit_owner_occupied = get_post_meta($post->ID, 'fgpsn_property_unit_owner_occupied', true);
		
		
		
		echo '<SELECT id="fgpsn_property_unit_owner_occupied" name="fgpsn_property_unit_owner_occupied"  />

			<OPTION value=""> - Select - </OPTION>\n
			<OPTION value="True"';

			if ($fgpsn_property_unit_owner_occupied == 'True') {
				echo ' selected';
			}

			echo '> True </OPTION>\n
			<OPTION value="False"';

			if ($fgpsn_property_unit_owner_occupied == 'False') {
				echo ' selected';
			}

			echo '> False </OPTION>\n

		</SELECT>';


		

     	echo '<P><label for="fgpsn_property_unit_occupant_id">Unit Occupants: </label><BR>';

       

    $meta_key = 'fgpsn_contact_last_name';  // The meta_key of the Custom Field
    $sql = "
       SELECT p.*,m.meta_value,
       p.*,m.post_id
       FROM $wpdb->posts p
       LEFT JOIN $wpdb->postmeta m ON (p.ID = m.post_id)
       WHERE p.post_type = 'contact_data'
          AND p.post_status = 'publish'
          AND m.meta_key = '$meta_key'
       ORDER BY m.meta_value, p.post_date DESC
    ";

    global $wpdb;
    $rows = $wpdb->get_results($sql);
    echo $wpdb->last_query;

    if ($rows) {
    	echo '<SELECT multiple name="fgpsn_property_unit_occupant_id[]" size=5 >
    			<option value="0"> -- N/AAA -- </option>';
       foreach ($rows as $post) {
          setup_postdata($post);
          if ($post->meta_value != $current_value) {

          	echo '<option value="' . $post->ID . '"';
    			 
    			 if ( in_array( $post->ID, $oocids ) ) {
    				 echo ' selected';
    			 } elseif($post->ID == $oocids) {
    			 	echo ' selected';
    			 }
    			 
    			 echo '>' . $post->meta_value . ", "  . get_post_meta($post->ID, 'fgpsn_contact_first_name', true) . '</option>';



          }
         
       }
        echo '</SELECT>';
    }






/*


get meta_value from unit_data where meta key = fgpsn_property_unit_occupant_id

contact post_id = get_post_meta( , fgpsn_property_unit_occupant_id, true);

*/






     echo '</DIV></FIELDSET>';

}


add_action( 'save_post', 'unit_info_save' );
function unit_info_save( $post_id ) {
	//echo "<H1>LINE 369 - " . $fgpsn_property_unit_occupant_id . " - " . $_POST['fgpsn_property_unit_occupant_id'] . "</H1>";

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['unit_info_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
//echo "<H1>LINE 268 - " . $post_id . " - " . $_POST['fgpsn_property_unit_occupant_id'] . "</H1>";
//var_dump($_POST);
	

//echo "<H1>LINE 369 - " . $fgpsn_property_unit_occupant_id . " - " . $_POST['fgpsn_property_unit_occupant_id'] . ", " . $post_id . "</H1>";
	// Update the post into the database
	//wp_update_post( $my_post );


	update_post_meta( $post_id, 'fgpsn_property_id', $_POST['fgpsn_property_id'] );
	update_post_meta( $post_id, 'fgpsn_property_city', $_POST['fgpsn_property_city'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_number', $_POST['fgpsn_property_unit_number'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_beds_number', $_POST['fgpsn_property_unit_beds_number'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_baths_number', $_POST['fgpsn_property_unit_baths_number'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_usage',  $_POST['fgpsn_property_unit_usage']);
	update_post_meta( $post_id, 'fgpsn_property_unit_lease_start',  $_POST['fgpsn_property_unit_lease_start']);
	update_post_meta( $post_id, 'fgpsn_property_unit_lease_end', $_POST['fgpsn_property_unit_lease_end']);
	update_post_meta( $post_id, 'fgpsn_property_unit_owner_occupied', $_POST['fgpsn_property_unit_owner_occupied']);
	update_post_meta( $post_id, 'fgpsn_property_unit_owner_id', $_POST['fgpsn_property_unit_owner_id'] );
	
	update_post_meta( $post_id, 'fgpsn_property_unit_occupant_id','' );

	$fgpsn_property_unit_occupant_id = get_post_meta($post_id, 'fgpsn_property_unit_occupant_id', true);
//echo '<h2>Emptied? ' . $fgpsn_property_unit_occupant_id . '</H2>';

	update_post_meta( $post_id, 'fgpsn_property_unit_occupant_id',$_POST['fgpsn_property_unit_occupant_id'] );

	$term = term_exists($_POST['fgpsn_property_city'], 'fgpsn_property_city');
if ($term !== 0 && $term !== null) {
  //echo "'City ' category exists!";
  wp_set_object_terms( $post_id, $_POST['fgpsn_property_city'], 'fgpsn_property_city' );
} else {

	$newtid = wp_insert_term( $_POST['fgpsn_property_city'], 'fgpsn_property_city' );
	//echo "'Added City ' category exists!";
  wp_set_object_terms( $post_id, $_POST['fgpsn_property_city'], 'fgpsn_property_city' );
}



	$fgpsn_property_unit_occupant_id = get_post_meta($post_id, 'fgpsn_property_unit_occupant_id', true);
//echo '<h2>Updated? ' . $fgpsn_property_unit_occupant_id . '</H2>';

		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'unit_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'unit_info_save');
	}

}


/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/


add_action( 'add_meta_boxes', 'unit_rent_info' );
function unit_rent_info() {

	$screens = array( 'unit_data', 'fg_contact_data' );
    foreach ($screens as $screen) {
		add_meta_box(
			'unit_rent_info',
			__( 'Rent Information', 'myplugin_textdomain' ),
			'unit_rent_info_content_fn',
			$screen,
			'side',
			'high'
		);
	}
}

function unit_rent_info_content_fn( $post ) {

	wp_nonce_field( plugin_basename( __FILE__ ), 'unit_rent_info_content_fn_nonce' );
	/*global $rent_desc;
	getUnitTemplatePriv($post->ID);
	echo $rent_desc;*/
	$fgpsn_property_unit_rent_data = get_post_meta(get_the_ID(), 'fgpsn_property_unit_rent_data', true);
	if ( !isset($fgpsn_property_unit_rent_data) || empty($fgpsn_property_unit_rent_data)) {
		$fgpsn_property_unit_rent_data = get_post_meta(267, 'fgpsn_property_unit_rent_data', true);
	}


	$fgpsn_property_for_sale_amt = get_post_meta($post->ID, 'fgpsn_property_for_sale_amt', true);
	 $fgpsn_property_for_sale_email = get_post_meta($post->ID, 'fgpsn_property_for_sale_email', true);
	 $fgpsn_property_for_sale_phone = get_post_meta($post->ID, 'fgpsn_property_for_sale_phone', true);
	 $fgpsn_property_for_sale_owner_info = get_post_meta($post->ID, 'fgpsn_property_for_sale_owner_info', true);
	 $fgpsn_property_unit_rentable = get_post_meta($post->ID, 'fgpsn_property_unit_rentable', true);
	 $fgpsn_property_unit_available = get_post_meta($post->ID, 'fgpsn_property_unit_available', true);
	 $fgpsn_property_for_sale = get_post_meta($post->ID, 'fgpsn_property_for_sale', true);
	 
	 $fgpsn_property_unit_rent_amt = get_post_meta($post->ID, 'fgpsn_property_unit_rent_amt', true);
	
	$fgpsn_property_unit_sqft = get_post_meta($post->ID, 'fgpsn_property_unit_sqft', true);
	
	$fgpsn_property_unit_sqft_cst = get_post_meta($post->ID, 'fgpsn_property_unit_sqft_cst', true);	
	
	$fgpsn_property_unit_rent_amt_month = get_post_meta($post->ID, 'fgpsn_property_unit_rent_amt_month', true);	
	
	$fgpsn_property_unit_rent_amt_year = get_post_meta($post->ID, 'fgpsn_property_unit_rent_amt_year', true);	
	
	$fgpsn_property_unit_rent_effective_date = get_post_meta($post->ID, 'fgpsn_property_unit_rent_effective_date', true);	
	$fgpsn_property_unit_option_start = get_post_meta($post->ID, 'fgpsn_property_unit_option_start', true);	
	$fgpsn_property_unit_option_end = get_post_meta($post->ID, 'fgpsn_property_unit_option_end', true);	
	$fgpsn_property_unit_option_notification = get_post_meta($post->ID, 'fgpsn_property_unit_option_notification', true);	


	$fgpsn_property_unit_cpi_date = get_post_meta($post->ID, 'fgpsn_property_unit_cpi_date', true);	
	$fgpsn_property_unit_cpi_amt = get_post_meta($post->ID, 'fgpsn_property_unit_cpi_amt', true);	
	$fgpsn_property_unit_cpi_monthly_amt = get_post_meta($post->ID, 'fgpsn_property_unit_cpi_monthly_amt', true);	
	$fgpsn_property_unit_option_rent = get_post_meta($post->ID, 'fgpsn_property_unit_option_rent', true);	
	$fgpsn_property_unit_sec_dep = get_post_meta($post->ID, 'fgpsn_property_unit_sec_dep', true);
	
	$fgpsn_property_unit_parking = get_post_meta($post->ID, 'fgpsn_property_unit_parking', true);
	
	$fgpsn_property_unit_deeded_parking = get_post_meta($post->ID, 'fgpsn_property_unit_deeded_parking', true);
	
	$fgpsn_property_unit_parking_type = get_post_meta($post->ID, 'fgpsn_property_unit_parking_type', true);	
	
	$fgpsn_property_unit_parking_charge = get_post_meta($post->ID, 'fgpsn_property_unit_parking_charge', true);	
	$fgpsn_property_unit_rent_date = get_post_meta($post->ID, 'fgpsn_property_unit_rent_date', true);
	
	
		
	echo '<FIELDSET>

		<P><input id="fgpsn_property_unit_rentable" name="fgpsn_property_unit_rentable" type="checkbox"';
		
		 if ( $fgpsn_property_unit_rentable == 'on' ) {
			echo ' checked';
		} 
		
		echo '><label for="fgpsn_property_unit_rentable">( ' . $fgpsn_property_unit_rentable . ' )Rentable</label>
		
		<P><input id="fgpsn_property_unit_available" name="fgpsn_property_unit_available" type="checkbox"';
		
		 if ( $fgpsn_property_unit_available == 'on' ) {
			echo ' checked';
		} 
		
		echo '><label for="fgpsn_property_unit_available">( ' . $fgpsn_property_unit_available . ' )Available</label>

		<P><input id="fgpsn_property_for_sale" name="fgpsn_property_for_sale" type="checkbox"';
		
		 if ( $fgpsn_property_for_sale == 'on' ) {
			echo ' checked';
		} 
		
		echo '><label for="fgpsn_property_for_sale">( ' . $fgpsn_property_for_sale . ' )For Sale</label>';
		
		
		 if ( $fgpsn_property_for_sale == 'on' ) {
			echo '<P><label for="fgpsn_property_for_sale_amt">Selling Price</label>
		<input id="fgpsn_property_for_sale_amt" name="fgpsn_property_for_sale_amt" size=5 value="' . $fgpsn_property_for_sale_amt . '" type="text" STYLE="position: relative; float: right;" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_for_sale_email">Seller Email</label>
		<input id="fgpsn_property_for_sale_email" name="fgpsn_property_for_sale_email" size=20 maxsize=50 value="' . $fgpsn_property_for_sale_email . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_for_sale_phone">Seller Phone</label>
		<input id="fgpsn_property_for_sale_phone" name="fgpsn_property_for_sale_phone" size=20 value="' . $fgpsn_property_for_sale_phone . '" type="text" STYLE="position: relative; float: right;">


		<P><label for="fgpsn_property_for_sale_owner_info">Include Owner Info</label>
		<input id="fgpsn_property_for_sale_owner_info" name="fgpsn_property_for_sale_owner_info" type="checkbox" STYLE="position: relative; float: right;">';
		} 




		echo '<P><label for="fgpsn_property_unit_rent_amt">Rent/Month</label>
		<input id="fgpsn_property_unit_rent_amt" name="fgpsn_property_unit_rent_amt" size=5 value="' . $fgpsn_property_unit_rent_amt . '" type="text" STYLE="position: relative; float: right;" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_sqft">Sq. Ft.</label>
		<input id="fgpsn_property_unit_sqft" name="fgpsn_property_unit_sqft" size=5 value="' . $fgpsn_property_unit_sqft . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_sqft_cst">Cost/Sq. Ft.</label>
		<input id="fgpsn_property_unit_sqft_cst" name="fgpsn_property_unit_sqft_cst" size=5 value="' . $fgpsn_property_unit_sqft_cst . '" type="text" STYLE="position: relative; float: right;">


		<P><label for="fgpsn_property_unit_rent_amt_month">Basic Rent Month</label>
		<input id="fgpsn_property_unit_rent_amt_month" name="fgpsn_property_unit_rent_amt_month" size=5 value="' . $fgpsn_property_unit_rent_amt_month . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_rent_amt_year">Basic Rent Year</label>
		<input id="fgpsn_property_unit_rent_amt_year" name="fgpsn_property_unit_rent_amt_year" size=5 value="' . $fgpsn_property_unit_rent_amt_year . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_rent_effective_date">Basic Rent Start Date</label>
		<input id="fgpsn_property_unit_rent_effective_date" name="fgpsn_property_unit_rent_effective_date" size=5 value="' . $fgpsn_property_unit_rent_effective_date . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_start">Option Term Start</label>
		<input id="fgpsn_property_unit_option_start" name="fgpsn_property_unit_option_start" size=5 value="' . $fgpsn_property_unit_option_start . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_end">Option Term End</label>
		<input id="fgpsn_property_unit_option_end" name="fgpsn_property_unit_option_end" size=5 value="' . $fgpsn_property_unit_option_end . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_notification">Option Term Notification Date</label>
		<input id="fgpsn_property_unit_option_notification" name="fgpsn_property_unit_option_notification" size=5 value="' . $fgpsn_property_unit_option_notification . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_cpi_date">Basic Price Index Date</label>
		<input id="fgpsn_property_unit_cpi_date" name="fgpsn_property_unit_cpi_date" size=5 value="' . $fgpsn_property_unit_cpi_date . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_cpi_amt">Basic CPI Amount</label>
		<input id="fgpsn_property_unit_cpi_amt" name="fgpsn_property_unit_cpi_amt" size=5 value="' . $fgpsn_property_unit_cpi_amt . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_cpi_monthly_amt">Month/CPI Amount</label>
		<input id="fgpsn_property_unit_cpi_monthly_amt" name="fgpsn_property_unit_cpi_monthly_amt" size=5 value="' . $fgpsn_property_unit_cpi_monthly_amt . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_rent">Option Rent</label>
		<input id="fgpsn_property_unit_option_rent" name="fgpsn_property_unit_option_rent" size=5 value="' . $fgpsn_property_unit_option_rent . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_sec_dep">Security Deposit</label>
		<input id="fgpsn_property_unit_sec_dep" name="fgpsn_property_unit_sec_dep" size=5 value="' . $fgpsn_property_unit_sec_dep . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_deeded_parking">Includes Parking?</label><BR>
		Yes <input id="fgpsn_property_unit_deeded_parking" name="fgpsn_property_unit_deeded_parking" value="1" type="radio" STYLE="position: relative; float: right;"';
		
		if ($fgpsn_property_unit_deeded_parking == 1 ) {
			echo ' checked';
		}
		
		
		echo '><BR>
		No <input id="fgpsn_property_unit_deeded_parking" name="fgpsn_property_unit_deeded_parking" value="0" type="radio" STYLE="position: relative; float: right;"';
		
		if ($fgpsn_property_unit_deeded_parking == 0 ) {
			echo ' checked';
		}
		
		
		echo '>
		
		<P><label for="fgpsn_property_unit_parking">Parking Space</label>
		<input id="fgpsn_property_unit_parking" name="fgpsn_property_unit_parking" size=5 value="' . $fgpsn_property_unit_parking . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_parking_charge">Parking Charge</label>
		<input id="fgpsn_property_unit_parking_charge" name="fgpsn_property_unit_parking_charge" size=5 value="' . $fgpsn_property_unit_parking_charge . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_rent_date">Rent Date: </label>
		<input id="fgpsn_property_unit_rent_date" name="fgpsn_property_unit_rent_date" size=2 value="' . $fgpsn_property_unit_rent_date . '" type="text" STYLE="position: relative; float: right;"> day of month;

    </FIELDSET>';


}

add_action( 'save_post', 'unit_rent_info_save' );
function unit_rent_info_save( $post_id ) {
	

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['unit_rent_info_content_fn_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$_POST[fgpsn_property_unit_sqft_cst] = $_POST[fgpsn_property_unit_rent_amt]/$_POST[fgpsn_property_unit_sqft];
	$_POST[fgpsn_property_unit_rent_amt_year] = $_POST[fgpsn_property_unit_rent_amt_month] * 12;
	$_POST[fgpsn_property_unit_option_notification] = gmdate("m/d/Y", strtotime("-30 day", strtotime($_POST[fgpsn_property_unit_option_end])));
	
	update_post_meta( $post_id, 'fgpsn_property_unit_rentable', $_POST['fgpsn_property_unit_rentable'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_available', $_POST['fgpsn_property_unit_available'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_rent_data', $_POST['fgpsn_property_unit_rent_data'] );
	update_post_meta( $post_id, 'fgpsn_property_for_sale', $_POST['fgpsn_property_for_sale'] );






	update_post_meta( $post_id, 'fgpsn_property_for_sale_amt', $_POST['fgpsn_property_for_sale_amt'] );
	update_post_meta( $post_id, 'fgpsn_property_for_sale_email', $_POST['fgpsn_property_for_sale_email'] );
	update_post_meta( $post_id, 'fgpsn_property_for_sale_phone', $_POST['fgpsn_property_for_sale_phone'] );
	update_post_meta( $post_id, 'fgpsn_property_for_sale_owner_info', $_POST['fgpsn_property_for_sale_owner_info'] );

	
	update_post_meta( $post_id, 'fgpsn_property_unit_rent_amt', $_POST['fgpsn_property_unit_rent_amt'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_rent_amt_month', $_POST['fgpsn_property_unit_rent_amt_month'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_rent_amt_year', $_POST['fgpsn_property_unit_rent_amt_year'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_sqft_cst', $_POST['fgpsn_property_unit_sqft_cst'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_sqft', $_POST['fgpsn_property_unit_sqft'] );
	
	update_post_meta( $post_id, 'fgpsn_property_unit_rent_effective_date', $_POST['fgpsn_property_unit_rent_effective_date'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_option_start', $_POST['fgpsn_property_unit_option_start'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_option_end', $_POST['fgpsn_property_unit_option_end'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_option_notification', $_POST['fgpsn_property_unit_option_notification'] );
	
	update_post_meta( $post_id, 'fgpsn_property_unit_cpi_amt', $_POST['fgpsn_property_unit_cpi_amt'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_cpi_date', $_POST['fgpsn_property_unit_cpi_date'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_cpi_monthly_amt', $_POST['fgpsn_property_unit_cpi_monthly_amt'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_option_rent', $_POST['fgpsn_property_unit_option_rent'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_sec_dep', $_POST['fgpsn_property_unit_sec_dep'] );


	update_post_meta( $post_id, 'fgpsn_property_unit_parking', $_POST['fgpsn_property_unit_parking'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_parking_charge', $_POST['fgpsn_property_unit_parking_charge'] );
	update_post_meta( $post_id, 'fgpsn_property_unit_rent_date', $_POST['fgpsn_property_unit_rent_date'] );

		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'unit_rent_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'unit_rent_info_save');
	}

}


//unit access metabox
add_action( 'add_meta_boxes', 'unit_access_notes' );
function unit_access_notes() {

	$screens = array( 'unit_data', 'fg_contact_data' );
    foreach ($screens as $screen) {
		add_meta_box(
			'unit_access_notes',
			__( 'Access Notes', 'myplugin_textdomain' ),
			'unit_access_notes_content',
			$screen,
			'side',
			'high'
		);
	}
}

function unit_access_notes_content( $post ) {

	wp_nonce_field( plugin_basename( __FILE__ ), 'unit_access_notes_content_nonce' );
	$fgpsn_property_unit_rent_data = get_post_meta($post->ID, 'fgpsn_property_unit_access_notes', true);
	if ( !isset($fgpsn_property_unit_access_notes) || empty($fgpsn_property_unit_access_notes)) {
		$fgpsn_property_unit_access_notes = get_post_meta($post->ID, 'fgpsn_property_unit_access_notes', true);
	}
	$fgpsn_property_unit_access_notes = get_post_meta( $post->ID, 'fgpsn_property_unit_access_notes', true);
	echo '<FIELDSET>

		<P><label for="fgpsn_property_unit_rent_amt">Unit Access Notes</label>
		<TEXTAREA name="fgpsn_property_unit_access_notes">' . $fgpsn_property_unit_access_notes . '</TEXTAREA>
    </FIELDSET>';


}


add_action( 'save_post', 'unit_access_notes_save' );
function unit_access_notes_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['unit_access_notes_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$_POST[fgpsn_property_unit_access_notes] = $_POST[fgpsn_property_unit_access_notes];
	update_post_meta( $post_id, 'fgpsn_property_unit_access_notes', $_POST[fgpsn_property_unit_access_notes] );


		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'unit_access_notes_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'unit_access_notes_save');
	}

}


// Add to admin_init function
add_filter('manage_edit-unit_data_columns', 'add_edit_unit_data_columns');

function add_edit_unit_data_columns($unit_data_columns) {
    $new_columns['cb'] = '<input type="checkbox" />';
    
    $new_columns['title'] = _x( 'Unit No.' );
    
    $new_columns['unit_data_types'] = __('Bedrooms/<br>Floor Level');

    $new_columns['fgpsn_property_id'] =  __('Attached Property', 'column name');
    
    $new_columns['unit_contacts'] = __('Contacts');

    $new_columns['fgpsn_property_unit_rent_amt'] = __('Monthly Rent');

    return $new_columns;
}


add_action('manage_unit_data_posts_custom_column', 'manage_unit_data_columns', 10, 2);
function manage_unit_data_columns($column_name, $id) {
    global $wpdb;
    global $table_prefix;
    global $query;
    $property_title = get_the_title(get_post_meta($id, 'fgpsn_property_id', true));

    switch ($column_name) {
		case 'id':
			echo $id;
				break;

		case 'fgpsn_property_id':
			
			echo $property_title;

			break;
			
		case 'unit_contacts':
			// tenants

			$contacts = get_post_meta( $id, 'fgpsn_property_unit_occupant_id', true );
			
			
			if (isset($contacts) && !is_null($contacts) && !empty($contacts)) {
				if (is_array($contacts)) {
					foreach($contacts as $k=>$v) {
						
						$fgpsn_contact_first_name = get_post_meta( $v, 'fgpsn_contact_first_name', true );
						$fgpsn_contact_last_name = get_post_meta( $v, 'fgpsn_contact_last_name', true );

						$fgpsn_contact_phone = get_post_meta( $v, 'fgpsn_contact_phone', true );
						$fgpsn_contact_email = get_post_meta( $v, 'fgpsn_contact_email', true );
						$fgpsn_contact_cell_phone = get_post_meta( $v, 'fgpsn_contact_cell_phone', true );

						echo "<a href='http://apexpm.fgpsn.com/wp-admin/post.php?post=\'" . $v . "\'&action=edit'>";
						echo get_post_meta( $v, 'fgpsn_contact_last_name', true ) . ',
						 ' . get_post_meta( $v, 'fgpsn_contact_first_name', true ) . '</a><br>
						<b>Phone: </b>' . get_post_meta( $v, 'fgpsn_contact_phone', true ) . '<br>
						<b>Email: </b>' . get_post_meta( $v, 'fgpsn_contact_email', true ) . '<br>
						<b>Cell: </b>' . get_post_meta( $v, 'fgpsn_contact_cell_phone', true ) . '<br>';
					}
				} else {

					echo "<a href='http://apexpm.fgpsn.com/wp-admin/post.php?post=" . $contacts . "&action=edit'>";
						echo get_post_meta( $contacts, 'fgpsn_contact_last_name', true ) . ',
						 ' . get_post_meta( $contacts, 'fgpsn_contact_first_name', true ) . '</a><br>
						<b>Phone: </b>' . get_post_meta( $contacts, 'fgpsn_contact_phone', true ) . '<br>
						<b>Email: </b>' . get_post_meta( $contacts, 'fgpsn_contact_email', true ) . '<br>
						<b>Cell: </b>' . get_post_meta( $contacts, 'fgpsn_contact_cell_phone', true ) . '<br>';
				}
				
			}
			
			break;

		case 'unit_data_types':
			// Get number of images in gallery
			$terms = wp_get_post_terms( $id, 'unit_data_types' );
			echo '<b>Type:</b><br>';
			foreach($terms as $term) {
				echo $term->name . '<br>';
			}
			$terms = wp_get_post_terms( $id, 'fgpsn_unit_locations' );
			echo '<b>Location:</b><br>';
			foreach($terms as $term) {
				echo $term->name . '<br>';
			}
			$terms = wp_get_post_terms( $id, 'unit_ammenities' );
			echo '<b>Ammenities:</b><br>';
			foreach($terms as $term) {
				echo $term->name . '<br>';
			}
			break;

		case 'fgpsn_property_unit_rent_amt':
				// Get number of images in gallery
				echo get_post_meta( $id, 'fgpsn_property_unit_rent_amt', true );

			break;

		default:
			break;
    } // end switch
}

/*Make columns sortable*/
add_filter( 'manage_edit-unit_data_sortable_columns', 'fgpsn_unit_data_table_sorting' );
function fgpsn_unit_data_table_sorting( $columns ) {
  $columns['fgpsn_property_id'] = 'fgpsn_property_id';
  //$columns['unit_contacts'] = 'unit_contacts';
 
  return $columns;
}

/*Set sorting parameters
THIS NEEDS TO BE SET INDIVIDUALLY FOR EACH SORTABLE COLUMN DESCRIBED ABOVE*/
add_filter( 'request', 'fgpsn_property_column_orderby' );
function fgpsn_property_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'fgpsn_property_id' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'fgpsn_property_id',
            'orderby' => 'meta_value'
        ) );
    } elseif ( isset( $vars['orderby'] ) && 'unit_contacts' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'fgpsn_property_unit_occupant_id',
            'orderby' => 'meta_value'
        ) );
    }

    return $vars;
}


// Add to our admin_init function
//add_action('quick_edit_custom_box',  'shiba_add_quick_edit', 10, 2);
 
function shiba_add_quick_edit( $column_name, $post_type ) {
	global $table_prefix;
    if ($column_name != 'fgpsn_property_id') return;
    //echo "<h3>CN " . $column_name . "</h3>";
    ?>
    <fieldset class="inline-edit-col-left">
    <div class="inline-edit-col">
        <span class="title">Widget Set</span>
        <input type="hidden" name="shiba_widget_set_noncename" id="shiba_widget_set_noncename" value="" />
        <?php 
        
        global $wpdb;
        $fgpsn_property_unit_owner_id = get_post_meta(get_the_ID(), 'fgpsn_property_unit_owner_id', true);
		$owner_link = get_permalink($fgpsn_property_unit_owner_id);
		$fgpsn_property_id =  get_post_meta(get_the_ID(), 'fgpsn_property_id', true);

		 echo '<P>ID: ' . the_ID();
		$getem = $wpdb->get_results( "SELECT post_title, ID, post_type, post_status
						FROM " .  $table_prefix . "posts
						WHERE post_type = 'properties'");
		  
		   echo '<P><label for="fgpsn_property_id" STYLE="width: 110px;">Attach to Property</label><BR>

     	<SELECT id="fgpsn_property_id" STYLE="width: 120px;" name="fgpsn_property_id"  />

			<OPTION value=""> - Select - </OPTION>\n';
			
		 foreach ( $getem as $property ) 
			{
				
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
              $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
              $city = get_post_meta($property->ID, 'fgpsn_property_city', true);
              
              $args = array(
					'post_type' => 'unit_data',
					'meta_query' => array(
						array(
							'key' => 'fgpsn_property_id',
							'value' => $address_1,
						)
					)
				 );
				$update_wo = get_posts( $args );
              
              
              
 echo '<option value = "' . $property->ID . '">' . $property->post_title .  ', ' . $fgpsn_property_id . ', ' .  $property->ID . ', ' . get_the_ID() . '</option>';
             // echo '<OPTION value="' . $property->ID . '"';

			if ( $property->ID == $fgpsn_property_id ) {
				echo " selected";
				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $address_1 . " " . $city . "</A><BR>";
			}

			//echo '>' .  $address_1  . ' ' . $address_2 . ', ' . $city . ', ' . $property->ID . ', ' . $fgpsn_property_id . '</OPTION>';
				
				
			}
		 echo '</SELECT>' . $update_wo->ID . ' = ' . $property_link . '</P>';
        ?>
    </div>
    </fieldset>
    <?php
}



// Add to our admin_init function
add_action('save_post', 'shiba_save_quick_edit_data');
 
function shiba_save_quick_edit_data($post_id) {
	
    // verify if this is an auto save routine. If it is our form has not been submitted, so we dont want
    // to do anything
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
        return $post_id;    
    // Check permissions
    if ( 'page' == $_POST['post_type'] ) {
        if ( !current_user_can( 'edit_page', $post_id ) )
            return $post_id;
    } else {
        if ( !current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    }   
    // OK, we're authenticated: we need to find and save the data
    $post = get_post($post_id);
    if (isset($_POST['fgpsn_property_id']) && ($post->post_type != 'revision')) {
        $fgpsn_property_id_set_id = esc_attr($_POST['fgpsn_property_id']);
        if ($fgpsn_property_id_set_id)
            update_post_meta( $post_id, 'fgpsn_property_id', $fgpsn_property_id_set_id);     
        else
            delete_post_meta( $post_id, 'fgpsn_property_id');     
    
			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'shiba_save_quick_edit_data');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'shiba_save_quick_edit_data');
    
    }       
    return $fgpsn_property_id_set_id;  

}



/*shortcode for unit summary table*/

function fgpsnUnitSummaryTable( $atts ){
	global  $disp_data;
	  /*wp_enqueue_script('fgpsndatatablemin', get_template_directory_uri() . '/js/jquery-1.11.1.min.js', array(), '1.11.1', true );
	  */
   /*wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );
   wp_enqueue_style('jquery.dataTables', get_stylesheet_uri() );*/
   
	$fgpsn_table_display_script .=  "<script>
		jQuery(document).ready(function() {
			jQuery('#fgpsn_unit_summary_table').dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );
		} );

	</SCRIPT>";


	assignedPropertyComms('unit_data');
	return $disp_data . $fgpsn_table_display_script;
	//echo $disp_data;
}
add_shortcode( 'fgpsn_unit_summary_table', 'fgpsnUnitSummaryTable' );

add_action( 'pre_get_posts', 'addtosearchfilter' );

function addtosearchfilter() {
	global $wpdb;
	 if ($query->is_search) {
	 	//echo '<h1>Called 1092</h1>';
	 } else {
	 	//echo '<h1>Called 11103 - ' . $wpdb->last_query . '</h1>';
	 	//var_dump($query);
	 }
}





/*ajax called finctions */

/* end populate gform property selection menu */
function getAvailableFgpsnUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	$items =  "<h2>Header - " . $dealerCountry . "</H2>";
	 echo "<div class='archive-container-div'>"; 
	if ( $_POST['dealerCountry'] == 'false') {
	    $args = array(
		'post_type'  => 'unit_data',
		'meta_key'   => 'fgpsn_property_unit_available',
		'orderby'    => 'title',
		'order'      => 'ASC',
		'post_status'      => 'publish',
		'nopaging'	=> true,
		'meta_query' => array(
				array(
					'key'     => 'fgpsn_property_unit_available',
					'value'   => 'on',
					'compare' => '=',
				),
			),
		);
	} 
		$units = new WP_Query( $args );
		$sqlcheck = $wpdb->last_query;

		while( $units->have_posts() ) {
			//getUnitTemplate( $fgpsn_unit->ID );
			$units->the_post();
			$items .=  get_the_title() . '<br>';
			//get_template_part('content','unit_data'); 

			getUnitTemplate( $post->ID );
		}
		wp_reset_postdata();

	$items .= "</div>";
	echo $items;
    die;
    

}

add_action('wp_ajax_getAvailableFgpsnUnitList', 'getAvailableFgpsnUnitList_fn');
add_action('wp_ajax_getAvailableFgpsnUnitList', 'getAvailableFgpsnUnitList_fn');

function getFgpsnUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	echo "<h2>Header - " . $dealerCountry . "</H2>";

	   $args = array(
					'post_type'  => 'unit_data',
					'posts_per_page'  => 5,
					'orderby'    => 'title',
					'order'      => 'ASC',
					'post_status'      => 'publish',
					'nopaging'	=> true,
					
					);
					//echo "<H3>Args line 1245 inclUnitPostType.php: " . $args . "</H3>";
	$fgpsn_units = get_posts($args);
					
 	
	echo "<div class='archive-container-div'>";

	
	foreach ( $fgpsn_units as $fgpsn_unit ) {
		getUnitTemplate( $fgpsn_unit->ID );
		
	}
echo '</div>';
	
    die;
    

}

add_action('wp_ajax_getFgpsnUnitList', 'getFgpsnUnitList_fn');
add_action('wp_ajax_getFgpsnUnitList', 'getFgpsnUnitList_fn');






/*unit short codes*/

function archiveAvailableUnits() {

	global $unit_temp_output;
	$archive_output = '';;
	$archive_output .=  '<div class="filter-message">Currently viewing all available units.<div class="clear-filter-button">Clear Filters</div></div>
		<div style="clear: both;"></div>
		<div class="availability-filter-box">
			<div class="availability_filter">';
	//set up category alnd meta filters
	$terms = get_terms( 'unit_data_types', 'orderby=name&hide_empty=0' );
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		$count = count( $terms );
		$i = 0;
		$term_list = '<h3 class="widgettitle">Search by Unit Size</h3>

		<label class="availibility-dropdown">
		<select class="property-beds-filter" multiple>';

			
		foreach ( $terms as $term ) {
			$i++;
			$term_list .= '<option value="' . $term->slug . '">' . $term->name . '</option>';
			
		}
			$term_list .= '</select></label>';
			$archive_output .=  $term_list;
	}


	$archive_output .=  '</div>
			<div class="availability_filter">';
	//set up category alnd meta filters
	//$terms = get_terms( 'fgpsn_property_city', $args );
	$terms = get_terms( 'fgpsn_property_city', 'orderby=name&hide_empty=0' );
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		$count = count( $terms );
		$i = 0;
		$term_list = '<h3 class="widgettitle">Search by Town</h3>

			<label class="availibility-dropdown">
			<select class="property-city-filter" multiple>';

		foreach ( $terms as $term ) {
			$i++;
			$term_list .= '<option value="' . $term->name . '">' . $term->name . '</option>';
		}
		$term_list .= '</select></label>';
		$archive_output .=  $term_list;
	}

	$archive_output .=   '</div>
			</div>';


	global $wpdb;	
	
    $args = array(
		
		'post_type'  => 'unit_data',
		'meta_key'   => 'fgpsn_property_unit_available',
		'orderby'    => 'title',
		'order'      => 'ASC',
		'post_status'      => 'publish',
		'nopaging'	=> true,
		'meta_query' => array(
							array(
								'key'     => 'fgpsn_property_unit_available',
								'value'   => 'on',
								'compare' => '=',
							),
						),
	);
	 
	$units = new WP_Query( $args );
	$sqlcheck = $wpdb->last_query;

	$archive_output .= "<div class='archive-container-div'>";

	
	while( $units->have_posts() ) {
		$units->the_post();
		//var_dump($units);
		$ththth = get_the_ID();
		//echo '<H2>alrighty then - ' . $ththth . '</h2>';
		getUnitTemplate($ththth);
		$archive_output .= $unit_temp_output;
	}
	$archive_output .= '</div>';
	wp_reset_postdata();

	return $archive_output;



	

}
add_shortcode( 'fgpsn_archive_available_units', 'archiveAvailableUnits' );



//add shortcode for unit archive
function fgpsnArchiveUnitData() {
	global $unit_temp_output;
	$archive_output = '';

	wp_enqueue_style( 'fgpsn-unit-styles', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/css/fgpsn-unit-styles.css' );

	wp_register_script('fgpsnUnitScripts', plugins_url() . '/fgpsnPmInit/js/fgpsnUnitScripts.js', array('jquery'),null,true   );
  
	wp_enqueue_script( 'fgpsnUnitScripts' );
	

	 $args = array(
					'post_type'  => 'unit_data',
					'orderby'    => 'title',
					'order'      => 'ASC',
					'post_status'      => 'publish',
					'nopaging'	=> true,
					
					);
					//echo "<H3>Args line 1245 inclUnitPostType.php: " . $args . "</H3>";
	$fgpsn_units = get_posts($args);
					
 	/*echo '<h4 class="unit_display_filter"><input type="radio" name="display_unit_list" value="all_units"> Display All Units&nbsp';
	echo '<input type="radio" name="display_unit_list" value="available_units"> Available Units
	</h4>';
	*/

	
	//no search filter for archive page - only available units page
	//for archive use sidebar category and toxonomy links
	/*$archive_output .= '<div class="filter-message">Currently viewing all available units.<div class="clear-filter-button">Clear Filters</div></div>
		<div style="clear: both;"></div>
		<div class="availability-filter-box">
			<div class="availability_filter">';
		//set up category alnd meta filters
		$terms = get_terms( 'unit_data_types', 'orderby=name&hide_empty=0' );
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			$count = count( $terms );
			$i = 0;
			$term_list = '<h3 class="widgettitle">Search by Unit Size</h3>

			<label class="availibility-dropdown">
			<select class="property-beds-filter" multiple>';

			
			
			foreach ( $terms as $term ) {
				$i++;
				$term_list .= '<option value="' . $term->slug . '">' . $term->name . '</option>';
				
			}
			$term_list .= '</select></label>';
			$archive_output .= $term_list;
		}


		$archive_output .= '</div>
			<div class="availability_filter">';
		//set up category alnd meta filters
		//$terms = get_terms( 'fgpsn_property_city', $args );
		$terms = get_terms( 'fgpsn_property_city', 'orderby=name&hide_empty=0' );
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			$count = count( $terms );
			$i = 0;
			$term_list = '<h3 class="widgettitle">Search by Town</h3>

			<label class="availibility-dropdown">
			<select class="property-city-filter" multiple>';

			
			
			foreach ( $terms as $term ) {
				$i++;
				$term_list .= '<option value="' . $term->name . '">' . $term->name . '</option>';
				
			}
			$term_list .= '</select></label>';
			$archive_output .= $term_list;
		}

		$archive_output .= '</div>
			</div>';
*/

	$archive_output .= "<div class='archive-container-div'>";

	
	foreach ( $fgpsn_units as $fgpsn_unit ) {
		getUnitTemplate( $fgpsn_unit->ID );
		$archive_output .= $unit_temp_output;
	}
$archive_output .= '</div>';
return $archive_output;
}

add_shortcode( 'fgpsn_archive_unit_data', 'fgpsnArchiveUnitData' );



function getUnitTemplate( $unit_id ) {

	//echo '<H2>alrighty then - ' . $fgpsn_unit->post_title . '</h2>';
	global $unit_temp_output;
	$unit_temp_output = '';
		$term =  get_post_meta($prop_id, "fgpsn_property_city", true);

		$data_types = wp_get_post_terms( $unit_id, 'unit_data_types' );
		$use_desc = '';
		if ( $fgpsn_unit->post_content != '' ){
			$use_desc = $fgpsn_unit->post_content;
		} elseif ( $fgpsn_unit->post_excerpt != '' ){
			$use_desc = $fgpsn_unit->post_excerpt;
		} else {
			$use_desc = get_post_meta($unit_id, '_yoast_wpseo_metadesc', true);
		}

		$unit_prop_id =  get_post_meta($unit_id, 'fgpsn_property_id', true);
		
		//$here = '<H3 class="archive-header">' . $unit_id . ' - ' . get_the_id() . ', ' . $data_types . '</H3>';
		$unit_temp_output .= '<div class="fgpsn-unit-archive-display';
		foreach ($data_types as $data_type) {
			$unit_temp_output .= ' ' . $data_type->slug;
		}


		$fgpsn_property_city = get_post_meta($unit_prop_id, 'fgpsn_property_city', true);

		$unit_temp_output .= ' ' . $fgpsn_property_city;
		
		if ( get_post_meta($unit_id, 'fgpsn_property_unit_available', true) == 'on') {
			$unit_temp_output .= ' fgpsn-unit-available ';
		} else {
			$unit_temp_output .= ' fgpsn-unit-unavailable';
		}

		$unit_temp_output .= '">';
		$use_image = get_the_post_thumbnail( $unit_prop_id, 'post-thumbnail' );
		 if ( !is_single() ) {
			if ( $use_image != '' ) {

				//the_post_thumbnail('thumbnail');
				$unit_temp_output .= $use_image;

			} else {
				$unit_temp_output .= '<img class="attachment-thumbnail" src="http://apexpm.fgpsn.com/wp-content/uploads/sites/2/2015/10/FinalLogo1-e1329407646137-300x201.png" alt="' . the_title() . '" />';

			}

		} 
		//the_post_thumbnail('thumbnail');
		$terms=get_terms('unit_data_types');
			$fgpsn_property_unit_beds_number = ''; 
						
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
						 
			  foreach ( $terms as $term ) {
				
				if ( has_term( $term->name, 'unit_data_types', $unit_id ) ) {
					$fgpsn_property_unit_beds_number .=  $term->name . ', ';
				} 		
				
			  }
			} 
		$fgpsn_property_unit_beds_number =  rtrim( $fgpsn_property_unit_beds_number, ', ' );
		$unit_temp_output .= '<div class="unit-archive-description"><a href="' . get_the_permalink($unit_id) . '"><H3 class="archive-header">' . get_the_title($unit_id) . '</H3></a>

		<div class="size-location-highlight"><span>' . $fgpsn_property_unit_beds_number . '</span> in
			<span>' . $fgpsn_property_city . '</span> 
			</div>' . $use_desc . '</div>';
		 
		 $unit_temp_output .= '<div style="clear: both;"></div>

		 <div class="entry-summary">
				<h4>Unit Specifications</h4>';
			
			$fgpsn_property_id = get_post_meta($unit_id, 'fgpsn_property_id', true);
			
			$fgpsn_property_street_address_1 = get_post_meta($fgpsn_property_id, 'fgpsn_property_address_1', true);
			$fgpsn_property_city = get_post_meta($fgpsn_property_id, 'fgpsn_property_city', true);
			$fgpsn_property_state = get_post_meta($fgpsn_property_id, 'fgpsn_property_state', true);
			$fgpsn_property_zip = get_post_meta($fgpsn_property_id, 'fgpsn_property_zip', true);
			
			//$fgpsn_property_unit_beds_number = get_post_meta($unit_id, 'fgpsn_property_unit_beds_number', true);
			
			$fgpsn_property_unit_baths = get_post_meta(get_the_ID(), 'fgpsn_property_unit_baths', true);
			
			$fgpsn_property_unit_rent_amt = get_post_meta(get_the_ID(), 'fgpsn_property_unit_rent_amt', true);
			
			$fgpsn_property_unit_sec_dep = get_post_meta(get_the_ID(), 'fgpsn_property_unit_sec_dep', true);
			
			
			$unit_temp_output .= '<div class = "fgpsn-unit-details">';
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Bedrooms: ' . $fgpsn_property_unit_beds_number . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Bathrooms: ' . $fgpsn_property_unit_baths . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Rent: ' . $fgpsn_property_unit_rent_amt . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Sec. Dep.: ' . $fgpsn_property_unit_sec_dep . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">
			Show Map <input type="checkbox" name="show-location-map" id="unit-archive-location-map-' . get_the_id() . '"
			 class="show-location-map"></span>';
			 $unit_temp_output .= '</div>

			 </div>';

			$unit_temp_output .= '<div style="clear: both;"></div> ';
	 
	
			$fgpsn_property_address_1 = get_post_meta(get_post_meta($unit_id, 'fgpsn_property_id', true), 'fgpsn_property_address_1', true);
						
			$fgpsn_property_address_2 = get_post_meta(get_post_meta($unit_id, 'fgpsn_property_id', true), 'fgpsn_property_address_2', true);
						
			$fgpsn_property_city = get_post_meta(get_post_meta($unit_id, 'fgpsn_property_id', true), 'fgpsn_property_city', true);	
						

						
			$terms=get_terms('unit_ammenities');
			$ammenities_list = ''; 
						
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
						 
			  foreach ( $terms as $term ) {
				
				if ( has_term( $term->name, 'unit_ammenities', $unit_id ) ) {
					$ammenities_list .=  '<span class="span-selected"><input type="checkbox"';
					$ammenities_list .=  ' checked';
					$ammenities_list .=  ' disabled> ' . $term->name . '</span>';
				} else {

					$ammenities_list .=  '<span class="span-unselected"><input type="checkbox" disabled> ' . $term->name . '</span>';
				}
							
				
			  }
			}  
			$unit_temp_output .= "<div class='unit-archive-ammenities'>
			<h4>Unit Amenities</h4>" . $ammenities_list . "</div>";	  
              
			
			$unit_temp_output .= "<DIV class='unit-archive-location-map-" . get_the_ID() ."' style='display: none;'><iframe width='384' height='315' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city . ",+" . $fgpsn_property_state . "&amp;aq=&amp;hnear=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city  . ",+" . $fgpsn_property_state  . "+" . $fgpsn_property_zip . "&amp;output=embed'></iframe><br /><small><a href='https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city  . ",+" . $fgpsn_property_state . "&amp;aq=&amp;sll=42.036922,-71.683501&amp;sspn=2.823195,4.993286&amp;ie=UTF8&amp;hq=&amp;hnear=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city  . ",+" . $fgpsn_property_state . "+" . $fgpsn_property_zip . "&amp;t=m&amp;z=14&amp;iwloc=A' style='color:#0000FF;text-align:left'>View Larger Map</a></small>
			</DIV>
			</div>";

	return $unit_temp_output;		

}

function getUnitSidebar( $unit_id ){

	global $unit_sidebar;
	$unit_sidebar = '<div class="fgpsn-prop-nav-container">
						<h3>Browse Unit Data</h3>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-data-' . $unit_id . '">Property Data</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-specs-' . $unit_id . '">Property Specifications</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-vendors-' . $unit_id . '">Property Vendors</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-contacts-' . $unit_id . '">Property Concacts</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-wo-history-' . $unit_id . '">Maintenance History</div>
						</div>';
	return $unit_sidebar;
}

//fgpsn_property_unit_access_notes
//$temp_posts = get_posts('post_type' => 'unit_data');


function getUnitTemplatePriv_fn( $unit_id ){
	//echo '<H2>alrighty then - ' . get_the_ID() . ', ' . $unit_id . ', ' . $prop_id . '</h2>';
	global $unit_temp_output;
	global $rent_desc;

	if ( !isset($unit_id) || $unit_id == '' ) {
		$unit_id = $_POST['useID'];
	
	} elseif( get_post_type() == 'properties' ){ $unit_id = get_post_meta( $_POST['useID'], 'fgpsn_property_id', true); }// in this case unit_id is a property

	$unit_temp_output = '';


	$fgpsn_property_unit_rent_data = get_post_meta(get_the_ID(), 'fgpsn_property_unit_rent_data', true);
	$fgpsn_property_for_sale_amt = get_post_meta($unit_id, 'fgpsn_property_for_sale_amt', true);
	 $fgpsn_property_for_sale_email = get_post_meta($unit_id, 'fgpsn_property_for_sale_email', true);
	 $fgpsn_property_for_sale_phone = get_post_meta($unit_id, 'fgpsn_property_for_sale_phone', true);
	 $fgpsn_property_for_sale_owner_info = get_post_meta($unit_id, 'fgpsn_property_for_sale_owner_info', true);
	 $fgpsn_property_unit_rentable = get_post_meta($unit_id, 'fgpsn_property_unit_rentable', true);
	 $fgpsn_property_unit_available = get_post_meta($unit_id, 'fgpsn_property_unit_available', true);
	 $fgpsn_property_for_sale = get_post_meta($unit_id, 'fgpsn_property_for_sale', true);
	 
	 $fgpsn_property_unit_rent_amt = get_post_meta($unit_id, 'fgpsn_property_unit_rent_amt', true);
	
	$fgpsn_property_unit_sqft = get_post_meta($unit_id, 'fgpsn_property_unit_sqft', true);
	
	$fgpsn_property_unit_sqft_cst = get_post_meta($unit_id, 'fgpsn_property_unit_sqft_cst', true);	
	
	$fgpsn_property_unit_rent_amt_month = get_post_meta($unit_id, 'fgpsn_property_unit_rent_amt_month', true);	
	
	$fgpsn_property_unit_rent_amt_year = get_post_meta($unit_id, 'fgpsn_property_unit_rent_amt_year', true);	
	
	$fgpsn_property_unit_rent_effective_date = get_post_meta($unit_id, 'fgpsn_property_unit_rent_effective_date', true);	
	$fgpsn_property_unit_option_start = get_post_meta($unit_id, 'fgpsn_property_unit_option_start', true);	
	$fgpsn_property_unit_option_end = get_post_meta($unit_id, 'fgpsn_property_unit_option_end', true);	
	$fgpsn_property_unit_option_notification = get_post_meta($unit_id, 'fgpsn_property_unit_option_notification', true);	


	$fgpsn_property_unit_cpi_date = get_post_meta($unit_id, 'fgpsn_property_unit_cpi_date', true);	
	$fgpsn_property_unit_cpi_amt = get_post_meta($unit_id, 'fgpsn_property_unit_cpi_amt', true);	
	$fgpsn_property_unit_cpi_monthly_amt = get_post_meta($unit_id, 'fgpsn_property_unit_cpi_monthly_amt', true);	
	$fgpsn_property_unit_option_rent = get_post_meta($unit_id, 'fgpsn_property_unit_option_rent', true);	
	$fgpsn_property_unit_sec_dep = get_post_meta($unit_id, 'fgpsn_property_unit_sec_dep', true);
	
	$fgpsn_property_unit_parking = get_post_meta($unit_id, 'fgpsn_property_unit_parking', true);
	
	$fgpsn_property_unit_deeded_parking = get_post_meta($unit_id, 'fgpsn_property_unit_deeded_parking', true);
	
	$fgpsn_property_unit_parking_type = get_post_meta($unit_id, 'fgpsn_property_unit_parking_type', true);	
	
	$fgpsn_property_unit_parking_charge = get_post_meta($unit_id, 'fgpsn_property_unit_parking_charge', true);	
	$fgpsn_property_unit_rent_date = get_post_meta($unit_id, 'fgpsn_property_unit_rent_date', true);
	
	
		
	$rent_desc =  '<FIELDSET>

		<P><input id="fgpsn_property_unit_rentable" name="fgpsn_property_unit_rentable" type="checkbox"';
		
		 if ( $fgpsn_property_unit_rentable == 'on' ) {
			$rent_desc .= ' checked';
		} 
		
		$rent_desc .= '><label for="fgpsn_property_unit_rentable">( ' . $fgpsn_property_unit_rentable . ' )Rentable</label>
		
		<P><input id="fgpsn_property_unit_available" name="fgpsn_property_unit_available" type="checkbox"';
		
		 if ( $fgpsn_property_unit_available == 'on' ) {
			$rent_desc .= ' checked';
		} 
		
		$rent_desc .= '><label for="fgpsn_property_unit_available">( ' . $fgpsn_property_unit_available . ' )Available</label>

		<P><input id="fgpsn_property_for_sale" name="fgpsn_property_for_sale" type="checkbox"';
		
		 if ( $fgpsn_property_for_sale == 'on' ) {
			$rent_desc .= ' checked';
		} 
		
		$rent_desc .= '><label for="fgpsn_property_for_sale">( ' . $fgpsn_property_for_sale . ' )For Sale</label>';
		
		
		 if ( $fgpsn_property_for_sale == 'on' ) {
			$rent_desc .= '<P><label for="fgpsn_property_for_sale_amt">Selling Price</label>
		<input id="fgpsn_property_for_sale_amt" name="fgpsn_property_for_sale_amt" size=5 value="' . $fgpsn_property_for_sale_amt . '" type="text" STYLE="position: relative; float: right;" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_for_sale_email">Seller Email</label>
		<input id="fgpsn_property_for_sale_email" name="fgpsn_property_for_sale_email" size=20 maxsize=50 value="' . $fgpsn_property_for_sale_email . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_for_sale_phone">Seller Phone</label>
		<input id="fgpsn_property_for_sale_phone" name="fgpsn_property_for_sale_phone" size=20 value="' . $fgpsn_property_for_sale_phone . '" type="text" STYLE="position: relative; float: right;">


		<P><label for="fgpsn_property_for_sale_owner_info">Include Owner Info</label>
		<input id="fgpsn_property_for_sale_owner_info" name="fgpsn_property_for_sale_owner_info" type="checkbox" STYLE="position: relative; float: right;">';
		} 




		$rent_desc .= '<P><label for="fgpsn_property_unit_rent_amt">Rent/Month</label>
		<input id="fgpsn_property_unit_rent_amt" name="fgpsn_property_unit_rent_amt" size=5 value="' . $fgpsn_property_unit_rent_amt . '" type="text" STYLE="position: relative; float: right;" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_sqft">Sq. Ft.</label>
		<input id="fgpsn_property_unit_sqft" name="fgpsn_property_unit_sqft" size=5 value="' . $fgpsn_property_unit_sqft . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_sqft_cst">Cost/Sq. Ft.</label>
		<input id="fgpsn_property_unit_sqft_cst" name="fgpsn_property_unit_sqft_cst" size=5 value="' . $fgpsn_property_unit_sqft_cst . '" type="text" STYLE="position: relative; float: right;">


		<P><label for="fgpsn_property_unit_rent_amt_month">Basic Rent Month</label>
		<input id="fgpsn_property_unit_rent_amt_month" name="fgpsn_property_unit_rent_amt_month" size=5 value="' . $fgpsn_property_unit_rent_amt_month . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_rent_amt_year">Basic Rent Year</label>
		<input id="fgpsn_property_unit_rent_amt_year" name="fgpsn_property_unit_rent_amt_year" size=5 value="' . $fgpsn_property_unit_rent_amt_year . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_rent_effective_date">Basic Rent Start Date</label>
		<input id="fgpsn_property_unit_rent_effective_date" name="fgpsn_property_unit_rent_effective_date" size=5 value="' . $fgpsn_property_unit_rent_effective_date . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_start">Option Term Start</label>
		<input id="fgpsn_property_unit_option_start" name="fgpsn_property_unit_option_start" size=5 value="' . $fgpsn_property_unit_option_start . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_end">Option Term End</label>
		<input id="fgpsn_property_unit_option_end" name="fgpsn_property_unit_option_end" size=5 value="' . $fgpsn_property_unit_option_end . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_notification">Option Term Notification Date</label>
		<input id="fgpsn_property_unit_option_notification" name="fgpsn_property_unit_option_notification" size=5 value="' . $fgpsn_property_unit_option_notification . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_cpi_date">Basic Price Index Date</label>
		<input id="fgpsn_property_unit_cpi_date" name="fgpsn_property_unit_cpi_date" size=5 value="' . $fgpsn_property_unit_cpi_date . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_cpi_amt">Basic CPI Amount</label>
		<input id="fgpsn_property_unit_cpi_amt" name="fgpsn_property_unit_cpi_amt" size=5 value="' . $fgpsn_property_unit_cpi_amt . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_cpi_monthly_amt">Month/CPI Amount</label>
		<input id="fgpsn_property_unit_cpi_monthly_amt" name="fgpsn_property_unit_cpi_monthly_amt" size=5 value="' . $fgpsn_property_unit_cpi_monthly_amt . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_option_rent">Option Rent</label>
		<input id="fgpsn_property_unit_option_rent" name="fgpsn_property_unit_option_rent" size=5 value="' . $fgpsn_property_unit_option_rent . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_sec_dep">Security Deposit</label>
		<input id="fgpsn_property_unit_sec_dep" name="fgpsn_property_unit_sec_dep" size=5 value="' . $fgpsn_property_unit_sec_dep . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_deeded_parking">Includes Parking?</label><BR>
		Yes <input id="fgpsn_property_unit_deeded_parking" name="fgpsn_property_unit_deeded_parking" value="1" type="radio" STYLE="position: relative; float: right;"';
		
		if ($fgpsn_property_unit_deeded_parking == 1 ) {
			$rent_desc .= ' checked';
		}
		
		
		$rent_desc .= '><BR>
		No <input id="fgpsn_property_unit_deeded_parking" name="fgpsn_property_unit_deeded_parking" value="0" type="radio" STYLE="position: relative; float: right;"';
		
		if ($fgpsn_property_unit_deeded_parking == 0 ) {
			$rent_desc .= ' checked';
		}
		
		
		$rent_desc .= '>
		
		<P><label for="fgpsn_property_unit_parking">Parking Space</label>
		<input id="fgpsn_property_unit_parking" name="fgpsn_property_unit_parking" size=5 value="' . $fgpsn_property_unit_parking . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_parking_charge">Parking Charge</label>
		<input id="fgpsn_property_unit_parking_charge" name="fgpsn_property_unit_parking_charge" size=5 value="' . $fgpsn_property_unit_parking_charge . '" type="text" STYLE="position: relative; float: right;">

		<P><label for="fgpsn_property_unit_rent_date">Rent Date: </label>
		<input id="fgpsn_property_unit_rent_date" name="fgpsn_property_unit_rent_date" size=2 value="' . $fgpsn_property_unit_rent_date . '" type="text" STYLE="position: relative; float: right;"> day of month;

    </FIELDSET>';


	/*global $prop_spec_temp;
	global $prop_vend_temp;
	getPropSpecTemplate( get_the_ID() );
	getPropVendorList( get_the_ID() );
*/
		$term =  get_post_meta($unit_id, "fgpsn_property_city", true);

		$data_types = wp_get_post_terms( $unit_id, 'unit_data_types' );
		//var_dump($data_types);
		$use_desc = '';
		if ( $fgpsn_unit->post_content != '' ){
			$use_desc = $fgpsn_unit->post_content;
		} elseif ( $fgpsn_unit->post_excerpt != '' ){
			$use_desc = $fgpsn_unit->post_excerpt;
		} else {
			$use_desc = get_post_meta($unit_id, '_yoast_wpseo_metadesc', true);
		}

		$unit_prop_id =  get_post_meta($unit_id, 'fgpsn_property_id', true);
		
		//$here = '<H3 class="archive-header">' . $unit_id . ' - ' . get_the_id() . ', ' . $data_types . '</H3>';
		$unit_temp_output .= '<div class="fgpsn-unit-archive-display';
		
		$terms=get_terms('unit_data_types');			
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
						 
			foreach ( $terms as $term ) {
				
				if ( has_term( $term->name, 'unit_data_types', get_the_ID() ) ) {
					$unit_temp_output .= ' ' . $term->slug;
				} 		
				
			}
		} 
			
		$fgpsn_property_id = get_post_meta($unit_id, 'fgpsn_property_id', true);
		$fgpsn_property_city = get_post_meta($fgpsn_property_id, 'fgpsn_property_city', true);

		$unit_temp_output .= ' ' . $fgpsn_property_city;
				
		 

		if ( get_post_meta($unit_id, 'fgpsn_property_unit_available', true) == 'on') {
			$unit_temp_output .= ' fgpsn-unit-available ';
		} else {
			$unit_temp_output .= ' fgpsn-unit-unavailable';
		}

		$unit_temp_output .= '">';
		

		$use_image = get_the_post_thumbnail( $unit_prop_id, 'post-thumbnail' );
		if ( !is_single() ) {
			if ( $use_image != '' ) {
				//the_post_thumbnail('thumbnail');
				$unit_temp_output .= $use_image;

			} else {
				
				$unit_temp_output .= '<img class="attachment-thumbnail" src="http://apexpm.fgpsn.com/wp-content/uploads/sites/2/2015/10/FinalLogo1-e1329407646137-300x201.png" alt="' . the_title() . '" />';
				

			}

		} else {
			$use_image = get_the_post_thumbnail('thumbnail');
			if ( $use_image == '' ) {
				
				$use_image .= '<img class="attachment-thumbnail" src="http://apexpm.fgpsn.com/wp-content/uploads/sites/2/2015/10/FinalLogo1-e1329407646137-300x201.png" alt="' . the_title() . '" />';

			}


		}

		$fgpsn_property_id = get_post_meta($unit_id, 'fgpsn_property_id', true);
		$fgpsn_property_street_address_1 = get_post_meta($fgpsn_property_id, 'fgpsn_property_address_1', true);
		$fgpsn_property_city = get_post_meta($fgpsn_property_id, 'fgpsn_property_city', true);
		$fgpsn_property_state = get_post_meta($fgpsn_property_id, 'fgpsn_property_state', true);
		$fgpsn_property_zip = get_post_meta($fgpsn_property_id, 'fgpsn_property_zip', true);
			
		$fgpsn_property_unit_baths = get_post_meta($unit_id, 'fgpsn_property_unit_baths', true);
		$fgpsn_property_unit_rent_amt = get_post_meta($unit_id, 'fgpsn_property_unit_rent_amt', true);
		$fgpsn_property_unit_sec_dep = get_post_meta($unit_id, 'fgpsn_property_unit_sec_dep', true);
			
		$terms=get_terms('unit_data_types');
		$fgpsn_property_unit_beds_number = ''; 
					
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
						 
			  foreach ( $terms as $term ) {
				
				if ( has_term( $term->name, 'unit_data_types', $unit_id ) ) {
					$fgpsn_property_unit_beds_number .=  $term->name . ', ';
				} 		
				
			  }
			} 
		$fgpsn_property_unit_beds_number =  rtrim( $fgpsn_property_unit_beds_number, ', ' );
		//the_post_thumbnail('thumbnail');
		$unit_temp_output .= '<div class="unit-archive-description">' . the_post_thumbnail() . '<a href="' . get_the_permalink() . '"><H3 class="archive-header">' . get_the_title($unit_id) . '</H3></a>

			<div class="size-location-highlight"><span>' . $fgpsn_property_unit_beds_number . '</span> in
			<span>' . $fgpsn_property_city . '</span> 
			</div>

		' . $use_desc . '</div>';
		 
		 $unit_temp_output .= '<div style="clear: both;"></div> 

		 	<div class="entry-summary">
			<h4>Unit Specifications</h4>';
			
			$unit_temp_output .= '<div class = "fgpsn-unit-details">';
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Bedrooms: ' . $fgpsn_property_unit_beds_number . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Bathrooms: ' . $fgpsn_property_unit_baths . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Rent: ' . $fgpsn_property_unit_rent_amt . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">Sec. Dep.: ' . $fgpsn_property_unit_sec_dep . '</span>';
			
			$unit_temp_output .= '<span class="fgpsn-unit-detail">
			Show Map <input type="checkbox" name="show-location-map" id="unit-archive-location-map-' . get_the_id() . '"  class="show-location-map" value=' . get_the_ID()  . '></span>';
			 $unit_temp_output .= '</div>

			 </div>	

			 <div style="clear: both;"></div> ';
	 
	
			$fgpsn_property_address_1 = get_post_meta(get_post_meta($unit_id, 'fgpsn_property_id', true), 'fgpsn_property_address_1', true);
						
			$fgpsn_property_address_2 = get_post_meta(get_post_meta($unit_id, 'fgpsn_property_id', true), 'fgpsn_property_address_2', true);
						
			$fgpsn_property_city = get_post_meta(get_post_meta($unit_id, 'fgpsn_property_id', true), 'fgpsn_property_city', true);	
						

						
			$terms=get_terms('unit_ammenities');
			$ammenities_list = ''; 
						
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
						 
			  foreach ( $terms as $term ) {
				
				if ( has_term( $term->name, 'unit_ammenities', $unit_id ) ) {
					$ammenities_list .=  '<span class="span-selected"><input type="checkbox"';
					$ammenities_list .=  ' checked';
					$ammenities_list .=  ' disabled> ' . $term->name . '</span>';
				} else {

					$ammenities_list .=  '<span class="span-unselected"><input type="checkbox" disabled> ' . $term->name . '</span>';
				}
							
				
			  }
			} 
			/*$unit_temp_output .= $rent_desc;
			$unit_temp_output .= $prop_spec_temp;
			$unit_temp_output .= $prop_vend_temp;*/
			$unit_temp_output .= "<div class='unit-archive-ammenities'>
			<h4>Unit Amenities</h4>" . $ammenities_list . "</div>";	  
              
			
			$unit_temp_output .= "<DIV class='unit-archive-location-map-" . get_the_ID() ."'' id='unit-archive-location-map' style='display: none;'><iframe width='384' height='315' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city . ",+" . $fgpsn_property_state . "&amp;aq=&amp;hnear=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city  . ",+" . $fgpsn_property_state  . "+" . $fgpsn_property_zip . "&amp;output=embed'></iframe><br /><small><a href='https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city  . ",+" . $fgpsn_property_state . "&amp;aq=&amp;sll=42.036922,-71.683501&amp;sspn=2.823195,4.993286&amp;ie=UTF8&amp;hq=&amp;hnear=" . $fgpsn_property_street_address_1 . ",+" . $fgpsn_property_city  . ",+" . $fgpsn_property_state . "+" . $fgpsn_property_zip . "&amp;t=m&amp;z=14&amp;iwloc=A' style='color:#0000FF;text-align:left'>View Larger Map</a></small>
			</DIV>
			</div>";
					
	echo '<div class="fgpsn-property-data-display">' . $unit_temp_output . '</div>';
	return $unit_temp_output;

	//return $cur_unit_output;
}
add_action('wp_ajax_getUnitTemplatePriv', 'getUnitTemplatePriv_fn');
add_action('wp_ajax_getUnitTemplatePriv', 'getUnitTemplatePriv_fn');

?>
