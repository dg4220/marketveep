<?PHP

/******************************************************
 * DG Creating Maintenance Request post type and meta boxes.
 * Include this in the designated PM site theme ONLY
 * The include allows posting messages to all sites in a network
 * Use inclCommPostTypeClient.php to allow property sites to post messages only to thier property
 * and designated residents, employees, management, vendors, etc.
*******************************************************/
function createFgpsnTimeLog() {
	$labels = array(
			'name'               => _x( 'Time Logs', 'post type general name' ),
			'singular_name'      => _x( 'Time Sheet', 'post type singular name' ),
			'add_new'            => _x( 'Create Time Sheet', 'fgpsn_time_sheets' ),
			'add_new_item'       => __( 'Create Time Sheet' ),
			'edit_item'          => __( 'Review Time Sheet' ),
			'new_item'           => __( 'New Time Sheets' ),
			'all_items'          => __( 'View Time Logs' ),
			'view_item'          => __( 'View Time Sheet' ),
			'search_items'       => __( 'Search Time Sheets' ),
			'not_found'          => __( 'No Time Sheets Found' ),
			'not_found_in_trash' => __( 'No Time Sheets found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Time Log'
		);
    $args = array(
      'description'   => 'Timer to log time spent during specific, property centered, activities. Log time on the phone, preparing reports, etc. and attach to a property and unit',
			'public'        => true,
			'menu_position' => 1,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes', 'excerpt', 'comments', 'thumbnail' ),
			'taxonomies'      => array( 'fgpsn_time_log_entry_types'  ),
			'hierarchical' => true,
			'has_archive'   => true,
      'labels'  => $labels
    );
    register_post_type( 'fgpsn_time_sheets', $args );
}
add_action( 'init', 'createFgpsnTimeLog' );

/* add contact types taxonomy */
function create_log_types() {
 $labels = array(
    'name' => _x( 'Time Log Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Log Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Log Types' ),
    'all_items' => __( 'All Log Types' ),
    'parent_item' => __( 'Parent Log Type' ),
    'parent_item_colon' => __( 'Parent Log Type:' ),
    'edit_item' => __( 'Edit Log Type' ),
    'update_item' => __( 'Update Log Type' ),
    'add_new_item' => __( 'Add New Log Type' ),
    'new_item_name' => __( 'New Log Type Name' ),
  );

  register_taxonomy('fgpsn_time_log_entry_types','fgpsn_time_sheets',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_log_types' );





function fgpsn_time_sheet_attachments() {
     $screens = array( 'fgpsn_time_sheets' );
    foreach ($screens as $screen) {
			add_meta_box(
			'fgpsn_time_sheet_attachments',
			__( 'Attach Document', 'myplugin_textdomain' ),
			'fgpsn_time_sheet_attachments_content',
			$screen,
			'side',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'fgpsn_time_sheet_attachments' );
/////////////////////////////////////////////////////////////////////////////////////////////

function fgpsn_time_sheet_attachments_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_time_sheet_attachments_content_nonce' );
	echo '<label for="property_doc_file">Attach File: </label>';

	$cur_doc_file = get_post_meta($post->ID, 'fgpsn_time_sheet_attachments', true);

	if (isset($cur_doc_file) && $cur_doc_file != '') {
		if (is_array($cur_doc_file)) {
var_dump($cur_doc_file);
			$cur_file = $cur_doc_file[url];

		} else {

			$cur_file = $cur_doc_file;

		}
		$doc_type = get_post_meta($post->ID, 'fgpsn_time_log_entry_types', true);
		echo '<A HREF="' . $cur_file . '" target="_blank">View Document</A><br>';
		echo '<input id="type" name="fgpsn_time_log_entry_types" value="' . $doc_type . '" type="hidden">
		<label for="fgpsn_time_log_entry_types">Attachment Type: </label> ';
		echo $doc_type;
		echo '<BR>Replace Document: <input id="fgpsn_time_sheet_attachments" name="fgpsn_time_sheet_attachments" value="" type="file">';
		

	} else {

		echo '<input id="fgpsn_time_sheet_attachments" name="fgpsn_time_sheet_attachments" value="" type="file">';
		echo '<input id="type" name="fgpsn_time_log_entry_types" value="Estimate" type="radio"><br>';
		echo '<input id="type" name="fgpsn_time_log_entry_types" value="Invoice" type="radio"><br>';
		echo '<input id="type" name="fgpsn_time_log_entry_types" value="Warranty" type="radio"><br>';

	}

	echo '<label for="fgpsn_time_log_entry_types">Attach File: </label>';

}


add_action( 'save_post', 'fgpsn_time_sheet_attachments_save' );
function fgpsn_time_sheet_attachments_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_time_sheet_attachments_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

/*
	$property_doc_file = $_POST['property_doc_file']['name'];
	update_post_meta( $post_id, 'property_doc_file', $property_doc_file );

*/

	    // Make sure the file array isn't empty
	    if(!empty($_FILES['fgpsn_time_sheet_attachments']['name'])) {
	   // echo '<H1>NOT EMPTY:' . $_FILES['property_doc_file']['name'] . '</H1>';

	        // Setup the array of supported file types. In this case, it's just PDF.
	        $supported_types = array('application/pdf', 'application/vnd.ms-word');

	        // Get the file type of the upload
	        $arr_file_type = wp_check_filetype(basename($_FILES['fgpsn_time_sheet_attachments']['name']));
	        $uploaded_type = $arr_file_type['type'];

	        // Check if the type is supported. If not, throw an error.
	        if(in_array($uploaded_type, $supported_types) || !in_array($uploaded_type, $supported_types)) {

	            // Use the WordPress API to upload the file
	            $upload = wp_upload_bits($_FILES['fgpsn_time_sheet_attachments']['name'], null, file_get_contents($_FILES['fgpsn_time_sheet_attachments']['tmp_name']));

	            if(isset($upload['error']) && $upload['error'] != 0) {
	                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
	            } else {
	               // add_post_meta(get_the_ID(), 'fgpsn_time_sheet_attachments', $upload);
	                add_post_meta(get_the_ID(), 'fgpsn_time_sheet_attachments', $upload);
	                //update_post_meta(get_the_ID(), 'fgpsn_time_sheet_attachments', $upload);
	         update_post_meta(get_the_ID(), 'fgpsn_time_log_entry_types', $_POST['fgpsn_time_log_entry_types']);

	                
	            } // end if/else

	        } else {
	            wp_die("The file type that you've uploaded is not a PDF.");
	        } // end if/else

	    } // end if

} // end save_custom_meta_data

/*Add metabox for time estimates*/




/* Add metaboxes for resident/owner/unit/data */

add_action( 'add_meta_boxes', 'fgpsn_time_sheet_property_unit_info' );
function fgpsn_time_sheet_property_unit_info() {

	$screens = array( 'fgpsn_time_sheets' );
    foreach ($screens as $screen) {
		add_meta_box(
			'fgpsn-time-sheet-property_unit-info',
			__( 'Property/Unit Information', 'myplugin_textdomain' ),
			'fgpsn_time_sheet_property_unit_info_content',
			$screen,
			'side',
			'high'
		);
	}
}


function fgpsn_time_sheet_property_unit_info_content( $post ) {

	$fgpsn_time_sheet_selected_properties = get_post_meta( $post->ID, 'fgpsn_time_sheet_selected_properties', true );
	$fgpsn_time_sheet_selected_units = get_post_meta($post->ID, 'fgpsn_time_sheet_selected_units', true);
	$fgpsn_time_sheet_room_location = get_post_meta($post->ID, 'fgpsn_time_sheet_room_location', true);

	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_time_sheet_property_unit_info_content_nonce' );
	echo '<FIELDSET><DIV>' . $fgpsn_time_sheet_room_location . ',' .  $post->ID;
	
	echo '<P><label for="fgpsn_time_sheet_selected_properties" STYLE="width: 110px;">Attach to Property</label><BR>

   	<SELECT id="fgpsn_time_sheet_selected_properties" STYLE="width: 120px;" name="fgpsn_time_sheet_selected_properties"  />

	<OPTION value=""> - Select - </OPTION>\n';
		$args = array(
			'post_type' => 'properties',
			'post_status' => 'publish',
			'nopaging'	=> true	
		
		);

		 
		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :
         while ($my_query->have_posts()) : $my_query->the_post();

              $address_1 = get_post_meta(get_the_ID(), 'fgpsn_property_address_1', true);
              $address_2 = get_post_meta(get_the_ID(), 'fgpsn_property_address_2', true);
              $city = get_post_meta(get_the_ID(), 'fgpsn_property_city', true);

              echo '<OPTION value="' . get_the_ID() . '"';

			if ( get_the_ID() == $fgpsn_time_sheet_selected_properties ) {
				echo " selected";
				$property_link = "<BR><A HREF=?" . get_the_ID()  . ">" . $address_1 . " " . $post->ID . "</A><BR>";
			}

			echo '>' .  $address_1  . ' ' . $address_2 . ', ' . $city . '</OPTION>';

          endwhile;
          wp_reset_postdata();
          echo '</SELECT>' . $property_link . '</P>';
     	endif;

	/*get selected unit and then get owner/tenant info*/
	echo '<P><label for="fgpsn_time_sheet_selected_units" STYLE="width: 110px;">Attach to Units</label><BR>

   	<SELECT id="fgpsn_time_sheet_selected_units" STYLE="width: 120px;" name="fgpsn_time_sheet_selected_units"  />

	<OPTION value=""> - Select - </OPTION>\n';
		$args = array(
			'post_type' => 'unit_data',
			'post_status' => 'publish',
			'nopaging'	=> true		
		
		);

		 
		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :
         while ($my_query->have_posts()) : $my_query->the_post();

              $unitno = get_the_title();
              $owner_id = get_post_meta(get_the_ID(), 'fgpsn_property_unit_owner_id', true);

              echo '<OPTION value="' . get_the_ID() . '"';

			if ( get_the_ID() == $fgpsn_time_sheet_selected_units ) {
				echo " selected";
				$unit_link = "<BR><A HREF=?" . get_the_ID()  . ">" . $unitno . "</A><BR>";
			}

			echo '>' .  $unitno . '</OPTION>';

          endwhile;
          wp_reset_postdata();
          echo '</SELECT>' . $unit_link . '</P>';
     	endif;
		
		
		
		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
							array(
								'taxonomy' => 'contact_data_types',
								'field' => 'slug',
								'terms' => 'owner'
							)
						)
					);

		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :

     	echo '<P><label for="fgpsn_time_sheet_selected_units" STYLE="width: 110px;">Unit Owner: </label><BR>

     	<SELECT id="fgpsn_time_sheet_selected_unitsssss" STYLE="width: 120px;" name="fgpsn_time_sheet_selected_unitsssss"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              $contact_id = get_post_meta(get_the_id(), 'network_user_id', true);
              $contact_first_name = get_post_meta(get_the_id(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_id(), 'contact_last_name', true);

              echo '<OPTION value="' . $contact_id . '"';

			if ($unit_owner_id == $contact_id) {
				echo " selected";
				$unit_owner_link = "<BR><A HREF=" . $owner_link  . ">" . $contact_first_name . " " . $contact_last_name . "</A><BR>";
			}

			echo '>' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';
			
			
          endwhile;
          echo '</SELECT>' . $unit_owner_link . '</P>';
     	endif;
		echo '<P><label for="fgpsn_time_sheet_room_location">Room/Location: </label>';
				echo '<input id="fgpsn_time_sheet_room_location" name="fgpsn_time_sheet_room_location" size=15 value="' . $fgpsn_time_sheet_room_location . '" type="text">';
				echo $fgpsn_time_sheet_room_location . ': location,' . $post->ID . ',' . $post_id;
		
		echo '</DIV></FIELDSET>';



}

add_action( 'save_post', 'fgpsn_time_sheet_property_unit_info_save' );
function fgpsn_time_sheet_property_unit_info_save( $post_id ) {
		global $post;
	//echo "<H1>LINE 253 - " . $unit_occupant_id . " - " . $_POST['unit_occupant_id'] . "</H1>";

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_time_sheet_property_unit_info_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
	
	update_post_meta( $post_id, 'fgpsn_time_sheet_selected_properties', $_POST['fgpsn_time_sheet_selected_properties'] );
	update_post_meta( $post_id, 'fgpsn_time_sheet_selected_units', $_POST['fgpsn_time_sheet_selected_units'] );
	update_post_meta( $post_id, 'fgpsn_time_sheet_room_location', $_POST['fgpsn_time_sheet_room_location'] );
	

		if ( ! wp_is_post_revision( $post_id ) ){

			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'fgpsn_time_sheet_property_unit_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'fgpsn_time_sheet_property_unit_info_save');
	}

}






function wp_ajax_getTimeSheetHistTemplatee_fn( $useID ) {
	//echo "<h1>Oh Here we go!</h1>";
	global $table_prefix;
	global $fgpsn_array_of_time_sheet_ids;
	global $disp_data_time_sheet_sidebar;
	global $disp_data;
	global $wpdb;
			
	$disp_data_time_sheet_sidebar = '<TABLE id="wo_summary_table_sidebar" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Subject</th>
					<th>Date Rec\'d</th>
					
				</tr>
			</thead>
						<TBODY>';
			
			$disp_data = '<div class="fgpsn-property-data-display"><script>
		jQuery(document).ready(function() {
			jQuery("#wo_summary_table").dataTable( {

				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );

		jQuery("#wo_summary_table_sidebar").dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, ]
			} );
		} );
		</SCRIPT>
		<TABLE id="wo_summary_table" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Location/<br>Contact</th>
					<th>Issue</th>
					<th>Date Rec\'d</th>
					<th>Estimate?</th>
					<th>Employee</th>
					
				</tr>
			</thead>
						<TBODY>';
		
		$prop_id = get_post_meta($_POST['useID'], 'fgpsn_property_id', true);

			$args = array(
				'post_type'  => 'fgpsn_time_sheets',
				'meta_key'   => 'fgpsn_time_sheet_selected_properties',
				'orderby'    => 'title',
				'order'      => 'ASC',
				'post_status'      => 'publish',
				'nopaging'	=> true,
				'meta_query' => array(
						array(
							'key'     => 'fgpsn_time_sheet_selected_properties',
							'value'   => $prop_id,
							'compare' => '=',
						),
					),
				);
				$units = new WP_Query( $args );
				
				while( $units->have_posts() ) {

					$units->the_post();
					//echo '<li>' . get_the_title() . '</li>';
					//$pc_from_info = $post->post_author;
					$cur_property = get_the_title( get_post_meta( get_the_id(), 'fgpsn_time_sheet_selected_units', true) );
					//echo $pc_from_info;
					$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
					$pc_from_email = $pc_from_info->user_email;
					$disp_data .= '<tr>
						<td>' . $cur_property . '</td>
						<td>' . get_the_title() . '</td>
						<td>' . $cur_property . '</td>
						<td>' . $cur_property . '</td>
						<td>' . $cur_property . '</td>
					
					</tr>';

				}
				$disp_data .= '</tbody></table></div>';
				/*foreach ( $units as $unit ) : setup_postdata( $unit );
					$unitno = get_the_title( $unit->ID);
					
					$items[] = array("value" => '111', "text" => $sqlcheck);
				endforeach; */
				wp_reset_postdata();


		
			
		$disp_data .= "</tbody><tfoot>
				<tr>
					<th>Property</th>
					<th>Name</th>
					<th>Issue</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</foot></table>";

		$disp_data_time_sheet_sidebar .= '</tbody><tfoot>
				<tr>
					<th>Label</th>
					<th>Data</th>
					
				</tr>
			</foot></table>';

			//$disp_data .= "<h1>rgnrgrnt" . $fgpsn_array_of_time_sheet_ids . "</H1>";
			//echo $disp_data;
	echo $disp_data;
}

add_action('wp_ajax_getTimeSheetHistTemplate', 'getTimeSheetHistTemplate_fn');
add_action('wp_ajax_nopriv_getTimeSheetHistTemplate', 'getTimeSheetHistTemplate_fn');




?>
