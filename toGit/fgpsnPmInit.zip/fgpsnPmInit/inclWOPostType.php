<?PHP

/******************************************************
 * DG Creating Maintenance Request post type and meta boxes.
 * Include this in the designated PM site theme ONLY
 * The include allows posting messages to all sites in a network
 * Use inclCommPostTypeClient.php to allow property sites to post messages only to thier property
 * and designated residents, employees, management, vendors, etc.
*******************************************************/
function codex_main_req_init() {
	$labels = array(
			'name'               => _x( 'Maintenance Requests', 'post type general name' ),
			'singular_name'      => _x( 'Work Order', 'post type singular name' ),
			'add_new'            => _x( 'Create Work Order', 'maintenance_requests' ),
			'add_new_item'       => __( 'Create Work Order' ),
			'edit_item'          => __( 'Review Work Order' ),
			'new_item'           => __( 'New Work Orders' ),
			'all_items'          => __( 'All Work Orders' ),
			'view_item'          => __( 'View Work Order' ),
			'search_items'       => __( 'Search Work Orders' ),
			'not_found'          => __( 'No Work Orders Found' ),
			'not_found_in_trash' => __( 'No Work Orders found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Maintance Requests'
		);
    $args = array(
      'description'   => 'Receive and Execute Maintenance Work Orders',
			'public'        => true,
			'menu_position' => 6,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes', 'excerpt', 'comments', 'thumbnail' ),
			'taxonomies'      => array( 'request_types'  ),
			'hierarchical' => true,
			'has_archive'   => true,
      'labels'  => $labels
    );
    register_post_type( 'maintenance_requests', $args );
}
add_action( 'init', 'codex_main_req_init' );

/* add contact types taxonomy */
function create_request_types() {
 $labels = array(
    'name' => _x( 'Requests Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Request Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Request Types' ),
    'all_items' => __( 'All Request Types' ),
    'parent_item' => __( 'Parent Request Type' ),
    'parent_item_colon' => __( 'Parent Request Type:' ),
    'edit_item' => __( 'Edit Request Type' ),
    'update_item' => __( 'Update Request Type' ),
    'add_new_item' => __( 'Add New Request Type' ),
    'new_item_name' => __( 'New Request Type Name' ),
  );

  register_taxonomy('request_types','maintenance_requests',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_request_types' );


function send_notices() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return;

  // verify this came from the our screen and with proper authorization,
  // because save_post can be triggered at other times
	$new_status = $_POST['work_order_status'];
	foreach( $_POST as $k=>$v ){
		$new_status .= "<H4>Key: " . $k . ", Value: " . $k . "</H4>";
	}
	if ($new_status == 'New') {
		mail('dg_419@hotmail.com', 'WO Status Update New!', $new_status . ' - NEW');
	}
 mail('dg_419@hotmail.com', 'WO Status Update New!', $new_status . ' - NEW');

}

add_action( 'save_post_maintenance_requests', 'send_notices' );


add_action( 'add_meta_boxes', 'fgpsn_wo_attachments' );
function fgpsn_wo_attachments() {
     $screens = array( 'maintenance_requests' );
    foreach ($screens as $screen) {
			add_meta_box(
			'fgpsn_wo_attachments',
			__( 'Attach Document', 'myplugin_textdomain' ),
			'fgpsn_wo_attachments_content',
			$screen,
			'side',
			'high'
		);
	}
}


function fgpsn_wo_attachments_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_wo_attachments_content_nonce' );
	echo '<label for="property_doc_file">Attach File: </label>';

	$cur_doc_file = get_post_meta($post->ID, 'fgpsn_wo_attachments', true);

	if (isset($cur_doc_file) && $cur_doc_file != '') {
		if (is_array($cur_doc_file)) {
var_dump($cur_doc_file);
			$cur_file = $cur_doc_file[url];

		} else {

			$cur_file = $cur_doc_file;

		}
		$doc_type = get_post_meta($post->ID, 'fgpsn_wo_attachment_type', true);
		echo '<A HREF="' . $cur_file . '" target="_blank">View Document</A><br>';
		echo '<input id="type" name="fgpsn_wo_attachment_type" value="' . $doc_type . '" type="hidden">
		<label for="fgpsn_wo_attachment_type">Attachment Type: </label> ';
		echo $doc_type;
		echo '<BR>Replace Document: <input id="fgpsn_wo_attachments" name="fgpsn_wo_attachments" value="" type="file">';
		

	} else {

		echo '<input id="fgpsn_wo_attachments" name="fgpsn_wo_attachments" value="" type="file">';
		echo '<input id="type" name="fgpsn_wo_attachment_type" value="Estimate" type="radio"><br>';
		echo '<input id="type" name="fgpsn_wo_attachment_type" value="Invoice" type="radio"><br>';
		echo '<input id="type" name="fgpsn_wo_attachment_type" value="Warranty" type="radio"><br>';

	}

	echo '<label for="fgpsn_wo_attachment_type">Attach File: </label>';

}


add_action( 'save_post', 'fgpsn_wo_attachments_save' );
function fgpsn_wo_attachments_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_wo_attachments_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

/*
	$property_doc_file = $_POST['property_doc_file']['name'];
	update_post_meta( $post_id, 'property_doc_file', $property_doc_file );

*/

	    // Make sure the file array isn't empty
	    if(!empty($_FILES['fgpsn_wo_attachments']['name'])) {
	   // echo '<H1>NOT EMPTY:' . $_FILES['property_doc_file']['name'] . '</H1>';

	        // Setup the array of supported file types. In this case, it's just PDF.
	        $supported_types = array('application/pdf', 'application/vnd.ms-word');

	        // Get the file type of the upload
	        $arr_file_type = wp_check_filetype(basename($_FILES['fgpsn_wo_attachments']['name']));
	        $uploaded_type = $arr_file_type['type'];

	        // Check if the type is supported. If not, throw an error.
	        if(in_array($uploaded_type, $supported_types) || !in_array($uploaded_type, $supported_types)) {

	            // Use the WordPress API to upload the file
	            $upload = wp_upload_bits($_FILES['fgpsn_wo_attachments']['name'], null, file_get_contents($_FILES['fgpsn_wo_attachments']['tmp_name']));

	            if(isset($upload['error']) && $upload['error'] != 0) {
	                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
	            } else {
	               // add_post_meta(get_the_ID(), 'fgpsn_wo_attachments', $upload);
	                add_post_meta(get_the_ID(), 'fgpsn_wo_attachments', $upload);
	                //update_post_meta(get_the_ID(), 'fgpsn_wo_attachments', $upload);
	         update_post_meta(get_the_ID(), 'fgpsn_wo_attachment_type', $_POST['fgpsn_wo_attachment_type']);

	                
	            } // end if/else

	        } else {
	            wp_die("The file type that you've uploaded is not a PDF.");
	        } // end if/else

	    } // end if

} // end save_custom_meta_data

/*Add metabox for time estimates*/

add_action( 'add_meta_boxes', 'fgpsn_wo_time_estimate_info' );
function fgpsn_wo_time_estimate_info() {

	$screens = array( 'maintenance_requests', 'fgpsn_wo_time_estimates' );
    foreach ($screens as $screen) {
		add_meta_box(
			'fgpsn-wo-time-estimate-info',
			__( 'Work Estimates Information', 'myplugin_textdomain' ),
			'fgpsn_wo_time_estimate_info_content',
			$screen,
			'side',
			'high'
		);
	}
}


function fgpsn_wo_time_estimate_info_content( $post ) {
	//echo $fgpsn_wo_start_date . ',' . $post->ID;
	$fgpsn_wo_requires_est = get_post_meta($post->ID, 'fgpsn_wo_requires_est', true);
	$fgpsn_wo_est_completed = get_post_meta($post->ID, 'fgpsn_wo_est_completed', true);
	$fgpsn_wo_estimate_date = get_post_meta( $post->ID, 'fgpsn_wo_estimate_date', true );$fgpsn_wo_time_estimate = get_post_meta( $post->ID, 'fgpsn_wo_time_estimate', true );
	$fgpsn_wo_prep_time_estimate = get_post_meta($post->ID, 'fgpsn_wo_prep_time_estimate', true);
	$fgpsn_wo_work_time_estimate = get_post_meta($post->ID, 'fgpsn_wo_work_time_estimate', true);

	$fgpsn_wo_time_actual = get_post_meta( $post->ID, 'fgpsn_wo_time_actual', true );
	$fgpsn_wo_prep_time_actual = get_post_meta($post->ID, 'fgpsn_wo_prep_time_actual', true);
	$fgpsn_wo_work_time_actual = get_post_meta($post->ID, 'fgpsn_wo_work_time_actual', true);
	
	
	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_wo_time_estimate_info_content_nonce' );
	echo '<FIELDSET><DIV>';
	echo '<P><label for="fgpsn_wo_requires_est">Estimate Required: </label>' . $fgpsn_wo_requires_est;
		echo '<input id="fgpsn_wo_requires_est" name="fgpsn_wo_requires_est" type="checkbox" ';

		if ($fgpsn_wo_requires_est == '1') { echo ' checked';}


		echo '>';
	
	echo '<P><label for="fgpsn_wo_estimate_date">Date of Estimate: </label>';
		echo '<input id="fgpsn_wo_estimate_date" name="fgpsn_wo_estimate_date" size=10 value="' . $fgpsn_wo_estimate_date . '" type="text">';
	echo '<P><label for="fgpsn_wo_prep_time_estimate">Estimated Prep Time: </label>';
		
	echo '<input id="fgpsn_wo_prep_time_estimate" name="fgpsn_wo_prep_time_estimate" size=10 value="' . $fgpsn_wo_prep_time_estimate . '" type="text">

		<P><label for="fgpsn_wo_work_time_estimate">Estimated Working Time: </label>';
	echo '<input id="fgpsn_wo_work_time_estimate" name="fgpsn_wo_work_time_estimate" size=10 value="' . $fgpsn_wo_work_time_estimate . '" type="text">

	<P><label for="fgpsn_wo_time_estimate">Estimated Total Time: </label>';
	echo '<input id="fgpsn_wo_time_estimate" name="fgpsn_wo_time_estimate" size=10 value="' . $fgpsn_wo_time_estimate . '" type="text">
	
	<P><label for="fgpsn_wo_prep_time_actual">Actual Prep Time: </label>';
	echo '<input id="fgpsn_wo_prep_time_actual" name="fgpsn_wo_prep_time_actual" size=10 value="' . $fgpsn_wo_prep_time_actual . '" type="text">
	
	<P><label for="fgpsn_wo_work_time_actual">Actual Working Time: </label>';
	echo '<input id="fgpsn_wo_work_time_actual" name="fgpsn_wo_work_time_actual" size=10 value="' . $fgpsn_wo_work_time_actual . '" type="text">
	
	<P><label for="fgpsn_wo_time_actual">Actual Total Working Time: </label>';
	echo '<input id="fgpsn_wo_time_actual" name="fgpsn_wo_time_actual" size=10 value="' . $fgpsn_wo_time_actual . '" type="text">';

	echo '<P><label for="fgpsn_wo_est_completed">Estimate Completed: </label>' . $fgpsn_wo_est_completed;
		echo '<input id="fgpsn_wo_est_completed" name="fgpsn_wo_est_completed" type="checkbox" ';

		if ($fgpsn_wo_est_completed == '1') { echo ' checked';}


		echo '>';

     echo '</DIV></FIELDSET>';

}

add_action( 'save_post', 'fgpsn_wo_time_estimate_info_save' );

function fgpsn_wo_time_estimate_info_save( $post_id ) {
	global $post;
	//echo "<H1>LINE 253 - " . $unit_occupant_id . " - " . $_POST['unit_occupant_id'] . "</H1>";

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_wo_time_estimate_info_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

		if ( ! wp_is_post_revision( $post_id ) ){

			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'fgpsn_wo_time_estimate_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'fgpsn_wo_time_estimate_info_save');
	}
	
	update_post_meta( $post_id, 'fgpsn_wo_estimate_date', $_POST['fgpsn_wo_estimate_date'] );
	update_post_meta( $post_id, 'fgpsn_wo_time_estimate', $_POST['fgpsn_wo_time_estimate'] );
	update_post_meta( $post_id, 'fgpsn_wo_prep_time_estimate', $_POST['fgpsn_wo_prep_time_estimate'] );
	update_post_meta( $post_id, 'fgpsn_wo_work_time_estimate', $_POST['fgpsn_wo_work_time_estimate'] );
	update_post_meta( $post_id, 'fgpsn_wo_time_actual', $_POST['fgpsn_wo_time_actual'] );
	update_post_meta( $post_id, 'fgpsn_wo_prep_time_actual', $_POST['fgpsn_wo_prep_time_actual'] );
	update_post_meta( $post_id, 'fgpsn_wo_work_time_actual', $_POST['fgpsn_wo_work_time_actual'] );
	update_post_meta( $post_id, 'fgpsn_wo_requires_est', $_POST['fgpsn_wo_requires_est'] );
	update_post_meta( $post_id, 'fgpsn_wo_est_completed', $_POST['fgpsn_wo_est_completed'] );

}




/* Add metaboxes for resident/owner/unit/data */

add_action( 'add_meta_boxes', 'fgpsn_wo_property_unit_info' );
function fgpsn_wo_property_unit_info() {

	$screens = array( 'maintenance_requests', 'fgpsn_wo_property_unit_data' );
    foreach ($screens as $screen) {
		add_meta_box(
			'fgpsn-wo-property_unit-info',
			__( 'Property/Unit Information', 'myplugin_textdomain' ),
			'fgpsn_wo_property_unit_info_content',
			$screen,
			'side',
			'high'
		);
	}
}


function fgpsn_wo_property_unit_info_content( $post ) {

	$fgpsn_wo_selected_properties = get_post_meta( $post->ID, 'fgpsn_wo_selected_properties', true );
	$fgpsn_wo_selected_units = get_post_meta($post->ID, 'fgpsn_wo_selected_units', true);
	$fgpsn_wo_room_location = get_post_meta($post->ID, 'fgpsn_wo_room_location', true);

	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_wo_property_unit_info_content_nonce' );
	echo '<FIELDSET><DIV>' . $fgpsn_wo_room_location . ',' .  $post->ID;
	
	echo '<P><label for="fgpsn_wo_selected_properties" STYLE="width: 110px;">Attach to Property</label><BR>

   	<SELECT id="fgpsn_wo_selected_properties" STYLE="width: 120px;" name="fgpsn_wo_selected_properties"  />

	<OPTION value=""> - Select - </OPTION>\n';
		$args = array(
			'post_type' => 'properties',
			'post_status' => 'publish',
			'nopaging'	=> true	
		
		);

		 
		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :
         while ($my_query->have_posts()) : $my_query->the_post();

              $address_1 = get_post_meta(get_the_ID(), 'fgpsn_property_address_1', true);
              $address_2 = get_post_meta(get_the_ID(), 'fgpsn_property_address_2', true);
              $city = get_post_meta(get_the_ID(), 'fgpsn_property_city', true);

              echo '<OPTION value="' . get_the_ID() . '"';

			if ( get_the_ID() == $fgpsn_wo_selected_properties ) {
				echo " selected";
				$property_link = "<BR><A HREF=?" . get_the_ID()  . ">" . $address_1 . " " . $post->ID . "</A><BR>";
			}

			echo '>' .  $address_1  . ' ' . $address_2 . ', ' . $city . '</OPTION>';

          endwhile;
          wp_reset_postdata();
          echo '</SELECT>' . $property_link . '</P>';
     	endif;

	/*get selected unit and then get owner/tenant info*/
	echo '<P><label for="fgpsn_wo_selected_units" STYLE="width: 110px;">Attach to Units</label><BR>

   	<SELECT id="fgpsn_wo_selected_units" STYLE="width: 120px;" name="fgpsn_wo_selected_units"  />

	<OPTION value=""> - Select - </OPTION>\n';
		$args = array(
			'post_type' => 'unit_data',
			'post_status' => 'publish',
			'nopaging'	=> true		
		
		);

		 
		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :
         while ($my_query->have_posts()) : $my_query->the_post();

              $unitno = get_the_title();
              $owner_id = get_post_meta(get_the_ID(), 'fgpsn_property_unit_owner_id', true);

              echo '<OPTION value="' . get_the_ID() . '"';

			if ( get_the_ID() == $fgpsn_wo_selected_units ) {
				echo " selected";
				$unit_link = "<BR><A HREF=?" . get_the_ID()  . ">" . $unitno . "</A><BR>";
			}

			echo '>' .  $unitno . '</OPTION>';

          endwhile;
          wp_reset_postdata();
          echo '</SELECT>' . $unit_link . '</P>';
     	endif;
		
		
		
		$args = array(
        'post_type' => 'contact_data',
        'tax_query' => array(
							array(
								'taxonomy' => 'contact_data_types',
								'field' => 'slug',
								'terms' => 'owner'
							)
						)
					);

		 $my_query = new WP_Query( $args );
		 if($my_query->have_posts()) :

     	echo '<P><label for="fgpsn_wo_selected_units" STYLE="width: 110px;">Unit Owner: </label><BR>

     	<SELECT id="fgpsn_wo_selected_unitsssss" STYLE="width: 120px;" name="fgpsn_wo_selected_unitsssss"  />

			<OPTION value=""> - Select - </OPTION>\n';

         while ($my_query->have_posts()) : $my_query->the_post();

              $contact_id = get_post_meta(get_the_id(), 'network_user_id', true);
              $contact_first_name = get_post_meta(get_the_id(), 'contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_id(), 'contact_last_name', true);

              echo '<OPTION value="' . $contact_id . '"';

			if ($unit_owner_id == $contact_id) {
				echo " selected";
				$unit_owner_link = "<BR><A HREF=" . $owner_link  . ">" . $contact_first_name . " " . $contact_last_name . "</A><BR>";
			}

			echo '>' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';
			
			
          endwhile;
          echo '</SELECT>' . $unit_owner_link . '</P>';
     	endif;
		echo '<P><label for="fgpsn_wo_room_location">Room/Location: </label>';
				echo '<input id="fgpsn_wo_room_location" name="fgpsn_wo_room_location" size=15 value="' . $fgpsn_wo_room_location . '" type="text">';
				echo $fgpsn_wo_room_location . ': location,' . $post->ID . ',' . $post_id;
		
		echo '</DIV></FIELDSET>';



}

add_action( 'save_post', 'fgpsn_wo_property_unit_info_save' );
function fgpsn_wo_property_unit_info_save( $post_id ) {
		global $post;
	//echo "<H1>LINE 253 - " . $unit_occupant_id . " - " . $_POST['unit_occupant_id'] . "</H1>";

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_wo_property_unit_info_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
	
	update_post_meta( $post_id, 'fgpsn_wo_selected_properties', $_POST['fgpsn_wo_selected_properties'] );
	update_post_meta( $post_id, 'fgpsn_wo_selected_units', $_POST['fgpsn_wo_selected_units'] );
	update_post_meta( $post_id, 'fgpsn_wo_room_location', $_POST['fgpsn_wo_room_location'] );
	

		if ( ! wp_is_post_revision( $post_id ) ){

			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'fgpsn_wo_property_unit_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'fgpsn_wo_property_unit_info_save');
	}

}


add_action( 'add_meta_boxes', 'fgpsn_wo_schedule_info' );
function fgpsn_wo_schedule_info() {

	$screens = array( 'maintenance_requests', 'fgpsn_wo_schedule_data' );
    foreach ($screens as $screen) {
		add_meta_box(
			'fgpsn-wo-schedule-info',
			__( 'Schedule Information', 'myplugin_textdomain' ),
			'fgpsn_wo_schedule_info_content',
			$screen,
			'side',
			'high'
		);
	}
}


function fgpsn_wo_schedule_info_content( $post ) {
	
	wp_enqueue_script( 'fgpsnDateTimeScripts' );
	wp_enqueue_style( 'fgpsnDateTime-style', 'style.css' );
	echo $fgpsn_wo_start_date . ',' . $post->ID;

	$fgpsn_wo_start_date = get_post_meta( $post->ID, 'fgpsn_wo_start_date', true );
	$fgpsn_wo_end_date = get_post_meta( $post->ID, 'fgpsn_wo_end_date', true);

	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_wo_schedule_info_content_nonce' );
	echo '<script>

		  jQuery(document).ready(function() {
			jQuery("#fgpsn_wo_start_date").datetimepicker();
			jQuery("#fgpsn_wo_end_date").datetimepicker();

		  });
		</script><FIELDSET><DIV>';
	
	
	echo '<P><label for="fgpsn_wo_start_date">Project Start Date: </label>';
		echo '<input id="fgpsn_wo_start_date" name="fgpsn_wo_start_date" size=10 value="' . $fgpsn_wo_start_date . '" type="text">';
echo $fgpsn_wo_start_date . ',' . $post->ID . ',' . $post_id;
		echo '<P><label for="fgpsn_wo_end_date">Project Start End: </label>';
		echo '<input id="fgpsn_wo_end_date" name="fgpsn_wo_end_date" size=10 value="' . $fgpsn_wo_end_date . '" type="text">';

     echo '</DIV></FIELDSET>';



}

add_action( 'save_post', 'fgpsn_wo_schedule_info_save' );
function fgpsn_wo_schedule_info_save( $post_id ) {
		global $post;
	//echo "<H1>LINE 253 - " . $unit_occupant_id . " - " . $_POST['unit_occupant_id'] . "</H1>";

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_wo_schedule_info_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
	//echo "<H3>LINE 224 - " . $post_id . " - " . $_POST['fgpsn_wo_start_date'] . "</H3>";
	//echo "<H3>LINE 225 - " . $post_id . " - " . $_POST['fgpsn_wo_start_date'] . "</H3>";

	$fgpsn_wo_start_date = $_POST['fgpsn_wo_start_date'];
	$fgpsn_wo_end_date = $_POST['fgpsn_wo_end_date'];

	// Update the post into the database
	//wp_update_post( $my_post );

	update_post_meta( $post_id, 'fgpsn_wo_start_date', $fgpsn_wo_start_date );
	update_post_meta( $post_id, 'fgpsn_wo_end_date', $fgpsn_wo_end_date );
	

		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'fgpsn_wo_schedule_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'fgpsn_wo_schedule_info_save');
	}

}





/* Add metabox for wo approval information */

add_action( 'add_meta_boxes', 'fgpsn_wo_approval_info' );
function fgpsn_wo_approval_info() {

	$screens = array( 'maintenance_requests', 'fgpsn_wo_approvals' );
    foreach ($screens as $screen) {
		add_meta_box(
			'fgpsn-wo-approval-info',
			__( 'Work Approvals Information', 'myplugin_textdomain' ),
			'fgpsn_wo_approval_info_content',
			$screen,
			'side',
			'high'
		);
	}
}


function fgpsn_wo_approval_info_content( $post ) {
echo $fgpsn_wo_start_date . ',' . $post->ID;
	$fgpsn_wo_approval_date = get_post_meta( $post->ID, 'fgpsn_wo_approval_date', true );
	$fgpsn_wo_priority = get_post_meta($post->ID, 'fgpsn_wo_priority', true);
	$fgpsn_wo_approval_by = get_post_meta($post->ID, 'fgpsn_wo_approval_by', true);

	$fgpsn_wo_approval_comments = get_post_meta( $post->ID, 'fgpsn_wo_approval_comments', true );
	$fgpsn_wo_end_date = get_post_meta($post->ID, 'fgpsn_wo_end_date', true);
	$fgpsn_wo_total_hours_approval = get_post_meta($post->ID, 'fgpsn_wo_total_hours_approval', true);
	$fgpsn_wo_materials_cost_approval = get_post_meta($post->ID, 'fgpsn_wo_materials_cost_approval', true);
	$fgpsn_wo_total_cost_approval = get_post_meta($post->ID, 'fgpsn_wo_total_cost_approval', true);
	$fgpsn_wo_additional_vendors_approval = get_post_meta($post->ID, 'fgpsn_wo_additional_vendors_approval', true);
	$fgpsn_wo_participating_staff_approval = get_post_meta($post->ID, 'fgpsn_wo_participating_staff_approval', true);
	
	
	wp_nonce_field( plugin_basename( __FILE__ ), 'fgpsn_wo_approval_info_content_nonce' );
	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-ui-datepicker');
	echo '<script>

		  jQuery(document).ready(function() {
			jQuery("#fgpsn_wo_approval_date").datepicker({
				  dateFormat: "yy-mm-dd"
				});
			jQuery("#fgpsn_wo_date_completed_approval").datepicker({
				  dateFormat: "yy-mm-dd"
				});
		  });
		</script>
		<FIELDSET><DIV>';
	
	echo '<P><label for="fgpsn_wo_approval_date">Approval Date: </label>';
		
	echo '<input id="fgpsn_wo_approval_date" name="fgpsn_wo_approval_date" size=10 value="' . $fgpsn_wo_approval_date . '" type="text">';

	echo '<P><label for="fgpsn_wo_priority" STYLE="width: 110px;">WO Priority</label><BR>

     	<SELECT id="fgpsn_wo_priority" STYLE="width: 120px;" name="fgpsn_wo_priority"  />

			<OPTION value="0"';
			if ($fgpsn_wo_priority == 0) {
				echo ' selected';
			}
			
			echo '> Low </OPTION>\n
			<OPTION value="1"';
			if ($fgpsn_wo_priority == 1) {
				echo ' selected';
			}
			
			echo '> Normal </OPTION>\n
			<OPTION value="2"';
			if ($fgpsn_wo_priority == 2) {
				echo ' selected';
			}
			
			echo '> Elevated </OPTION>\n
			<OPTION value="3"';
			if ($fgpsn_wo_priority == 3) {
				echo ' selected';
			}
			
			echo '> Top </OPTION>\n
			
		</SELECT></P>';

	echo '<P><label for="fgpsn_wo_approval_by" STYLE="width: 110px;">Approved By</label><BR>

     	<SELECT id="fgpsn_wo_approval_by" STYLE="width: 120px;" name="fgpsn_wo_approval_by"  />

			<OPTION value=""> - Select - </OPTION>\n';
			
		   $args = array(
			'post_type' => 'employee_data',
			'post_status' => 'publish'	
		
			);

		 
			$my_query = new WP_Query( $args );
		   // Array of stdClass objects.
		    while ($my_query->have_posts()) : $my_query->the_post();

              $contact_id = get_the_id();
              $contact_first_name = get_post_meta(get_the_id(), 'fgpsn_contact_first_name', true);
              $contact_last_name = get_post_meta(get_the_id(), 'fgpsn_contact_last_name', true);

              echo '<OPTION value="' . $contact_id . '"';

			if ($fgpsn_wo_approval_by == $contact_id) {
				echo " selected";
				$unit_owner_link = "<BR><A HREF=" . $owner_link  . ">" . $contact_first_name . " " . $contact_last_name . "</A><BR>";
			}

			echo '>' .  $contact_first_name  . ' ' . $contact_last_name . '</OPTION>\n';
			
			
          endwhile;
		  wp_reset_postdata();
			
	echo '</SELECT></P>';

	
	echo '<P><label for="fgpsn_wo_approval_comments">Approval Comments: </label>
	<P><TEXTAREA id="fgpsn_wo_approval_comments" name="fgpsn_wo_approval_comments">
	' . $fgpsn_wo_approval_comments . '</TEXTAREA>';
	
	echo '<P><label for="fgpsn_wo_end_date">Work Completed Date: </label>
	<input id="fgpsn_wo_end_date" name="fgpsn_wo_end_date" size=10 value="' . $fgpsn_wo_end_date . '" type="text">';
	
	echo '<P><label for="fgpsn_wo_total_hours_approval">Total Project Hours: </label>
	<input id="fgpsn_wo_total_hours_approval" name="fgpsn_wo_total_hours_approval" size=10 value="' . $fgpsn_wo_total_hours_approval . '" type="text">';
	
	echo '<P><label for="fgpsn_wo_materials_cost_approval">Total Materials Cost: </label>
	<input id="fgpsn_wo_materials_cost_approval" name="fgpsn_wo_materials_cost_approval" size=10 value="' . $fgpsn_wo_materials_cost_approval . '" type="text">';
	
	echo '<P><label for="fgpsn_wo_additional_vendors_approval" STYLE="width: 110px;">Vendors Used</label><BR>

     	<SELECT MULTI SIZE=5 id="fgpsn_wo_additional_vendors_approval" STYLE="width: 120px;" name="fgpsn_wo_additional_vendors_approval"  />

			<OPTION value=""> - Select - </OPTION>\n';
			
		  $args = array(
			'post_type' => 'property_vendor',
			'post_status' => 'publish'	
		
			);

		 
			$my_query = new WP_Query( $args );
		   // Array of stdClass objects.
		    while ($my_query->have_posts()) : $my_query->the_post();

              $vendor_id = get_the_ID();
              $vendor_name = get_the_title();

              echo '<OPTION value="' . $vendor_id . '"';

				if ($fgpsn_wo_additional_vendors_approval == $vendor_id) {
					echo " selected";
					$vendor_link = "<BR><A HREF=" . $owner_link  . ">" . $contact_first_name . " " . $contact_last_name . "</A><BR>";
				}

				echo '>' .  $vendor_name . '</OPTION>\n';
				
			endwhile;
		  wp_reset_postdata();
	echo '</SELECT>' . $vendor_link . '</P>';
	
	echo '<P><label for="fgpsn_wo_participating_staff_approval" STYLE="width: 110px;">Work Completed By</label><BR>

     	<SELECT id="fgpsn_wo_participating_staff_approval" STYLE="width: 120px;" name="fgpsn_wo_participating_staff_approval"  />

			<OPTION value=""> - Select - </OPTION>\n';
			
		   $contacts = get_posts( array( 'post_type' => 'employee_data', 'post_status' => 'publish', 'nopaging' => 'true' ) );
		   // Array of stdClass objects.
		   foreach ( $contacts as $contact ) {
				
				 echo '<OPTION value="' . $contact->ID;
				 echo '"';
				 if ( $fgpsn_wo_participating_staff_approval == $contact->ID) {
					 echo ' selected';
				 }
				 
				 echo '>' . $contact->post_title . ', ' . $contact->ID . '</option>';
		   }
			
	echo '</SELECT></P>';

     echo '</DIV></FIELDSET>';

}

add_action( 'save_post', 'fgpsn_wo_approval_info_save' );

function fgpsn_wo_approval_info_save( $post_id ) {
	global $post;
	//echo "<H1>LINE 253 - " . $unit_occupant_id . " - " . $_POST['unit_occupant_id'] . "</H1>";

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['fgpsn_wo_approval_info_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
	//echo "<H3>LINE 224 - " . $post_id . " - " . $_POST['fgpsn_wo_start_date'] . "</H3>";
	//echo "<H3>LINE 225 - " . $post_id . " - " . $_POST['fgpsn_wo_start_date'] . "</H3>";

	// Update the post into the database
	//wp_update_post( $my_post );


	update_post_meta( $post_id, 'fgpsn_wo_approval_date', $_POST['fgpsn_wo_approval_date'] );
	update_post_meta( $post_id, 'fgpsn_wo_approval_by', $_POST['fgpsn_wo_approval_by'] );
	update_post_meta( $post_id, 'fgpsn_wo_priority', $_POST['fgpsn_wo_priority'] );
	update_post_meta( $post_id, 'fgpsn_wo_approval_comments', $_POST['fgpsn_wo_approval_comments'] );
	
	
	update_post_meta( $post_id, 'fgpsn_wo_date_completed_approval', $_POST['fgpsn_wo_date_completed_approval'] );
	update_post_meta( $post_id, 'fgpsn_wo_total_hours_approval', $_POST['fgpsn_wo_total_hours_approval'] );
	update_post_meta( $post_id, 'fgpsn_wo_materials_cost_approval', $_POST['fgpsn_wo_materials_cost_approval'] );
	update_post_meta( $post_id, 'fgpsn_wo_total_cost_approval', $_POST['fgpsn_wo_total_cost_approval'] );
	update_post_meta( $post_id, 'fgpsn_wo_additional_vendors_approval', $_POST['fgpsn_wo_additional_vendors_approval'] );
	update_post_meta( $post_id, 'fgpsn_wo_participating_staff_approval', $_POST['fgpsn_wo_participating_staff_approval'] );

	

		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'fgpsn_wo_approval_info_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'fgpsn_wo_approval_info_save');
	}

}

/*include functions*/

//include( plugin_dir_path( __FILE__ ) . '/functions-wo.php' );
/*begin shortcodes*/
/*shortcode for work order calendar*/



function fgpsnWoCalendar1( $atts ){

		global $wpdb;
		$args = array(
				'post_type' => 'maintenance_requests',
				'post_status' => 'publish');

		
		$postlist = get_posts( $args );

		foreach ( $postlist as $post ) :
		  
		  setup_postdata( $post );
		  $start_data = get_post_meta($post->ID, 'fgpsn_wo_start_date', true);
		  $end_data = get_post_meta($post->ID, 'fgpsn_wo_end_date', true);
		  if ( $start_data === false || $start_data === false ) {
			  $start_data = $post->post_date;
			  $end_data = $post->post_date;
		  }
		 	//$start_data = $post->post_date;
			  //$end_data = $post->post_date;
		  
		  //var_dump($post);
			$className = get_post_meta($post->ID, 'fgpsn_wo_priority', true);
			switch($className) {
				
				case '0' :
					$className = 'low-priority';
					break;
					
				case '1' :
					$className = 'normal-priority';
					break;
					
				case '2' :
					$className = 'elevated-priority';
					break;
					
				case '3' :
					$className = 'high-priority';
					break;
					
				default:
					$className = 'elevated-priority';
					break;
					
			}
			$event_start_date = strtotime(get_post_meta($post->ID, 'fgpsn_wo_start_date', true));
			$event_start_date = date('M-d-y', $event_start_date);
			$event_end_date = strtotime(get_post_meta($post->ID, 'fgpsn_wo_end_date', true));
			$event_end_date = date('M-d-y', $event_end_date);
			  
			$events_string .= "{ title: '" . $post->post_title . "',";
			$events_string .= "allDay: 'false',";
			$events_string .= "description: '<div>";
			
			$events_string .= "<a id=\"save-changes\"\/inline-wo-form\/?gform_post_id=" . $post->ID . "&TB_iframe=true&width=600&height=550\" class=\"thickbox\">Save Changes</a>";
			
			$events_string .= "</div>',";
			$events_string .= "id: '" . $post->ID . "',";
			$events_string .= "className: '" . $className . "',";
			//$events_string .= "start: '" . get_post_meta($post->ID, 'fgpsn_wo_start_date', true) . "',";
			//$events_string .= "end: '" . get_post_meta($post->ID, 'fgpsn_wo_end_date', true) . "',";
			$events_string .= "start: '" .  $post->post_date . "',";
			$events_string .= "end: '" . $post->post_date . "',";
			$events_string .= "url: '/inline-wo-form/?gform_post_id=" . $post->ID . "&TB_iframe=true&width=600&height=550'";
			$events_string .= "},";	
				
		endforeach;
		
       $events_string = rtrim($events_string, ',');
  //echo "<H3>String: " . $events_string . "</H3>";
      wp_reset_postdata();
       
    global $fgpsn_calendar_display;
	$fgpsn_calendar_display = "<div class='fgpsn-wo-calendar'></div>
	<div id='fgpsn-wo-calendar'></div>
	<div id='fgpsn-wo-update-notice'></div>";

	$fgpsn_calendar_display .= '<div style="clear: both"></div><div id="fgpsn-wo-table"></div>';

	/*
		
	wp_enqueue_style('fgpsncalendarstyle', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/fullcalendar-master/dist/fullcalendar.css', true );
	
	wp_enqueue_script('fgpsncalendar', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/fullcalendar-master/dist/fullcalendar.js', true );
	
*/
/*

<script>
	jQuery(document).ready(function() {
		//alert(jQuery('#draggable1').attr('id'));
	
    // page is now ready, initialize the calendar...
    jQuery('#fgpsn-wo-calendar').fullCalendar({
        // put your options and callbacks here
       
        header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			
		defaultView: 'agendaWeek',
		editable: true,
		droppable: true,
		timeFormat: 'ddd, hA',
		eventClick: function(calEvent, jsEvent, view) {
			
			jQuery(this).css('border-color', 'red');
			jQuery(this).draggable('eventObject');
			jQuery(this).droppable('eventObject');
			//jQuery(this).on('drop', alert('Event: '));

		},
		eventDrop: function(calEvent, jsEvent, view) {
			
			
			//alert('Dropped on: ' + calEvent.start);
			//alert('ID: ' + calEvent.id);
				// retrieve the dropped element's stored Event Object
				var originalEventObject = jQuery(this).data('eventObject');
				
				// we need to copy it, so that multiple events don't have a reference to the same object
				//var copiedEventObject = jQuery.extend({}, originalEventObject);
				
				// assign it the date that was reported
				//copiedEventObject.start = date;
				
				// render the event on the calendar
				// the last `true` argument determines if the event 'sticks' (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
				
				jQuery().fullCalendar('renderEvent', originalEventObject, true);
				jQuery(originalEventObject).remove();
				
				//update database
				
				jQuery.ajax({
					type: 'POST',
					url: '" . admin_url('admin-ajax.php') . "',
					data: { wo_id : calEvent.id, action: 'updateWoDate' },
					dataType: 'html',
					success: function(data){
									//alert('" . $worked . "');
									//alert(jQuery('#save-changes'));
									jQuery('.fc-clear').empty();
									jQuery('.fc-clear').append('<h4>Confirm!</h4>');
								}
				});
				
				// is the 'remove after drop' checkbox checked?
				if (jQuery('#drop-remove').is(':checked')) {
					// if so, remove the element from the 'Draggable Events' list
					jQuery(originalEventObject).remove();
				}
			},
				
			
      events: [" . $events_string . "],
     
       //events: '/fgpsn_wos.php'
       
      eventRender: function(event, element) {
			element.find('.fc-event-title').remove();
			//element.find('.fc-event-time').remove();
			var new_description =   
				moment(event.start).format('ddd, hA') + '-'
				+ moment(event.end).format('ddd, hA') + '<br/>'
			   
				+ '<strong>Address: </strong><br/>' + event.description + '<br/>';
			element.append(new_description);
		
		}
		

    })

});
</SCRIPT>


*/






	$fgpsn_calendar_display .=  "<script>
	jQuery(document).ready(function() {
		//alert(jQuery('#draggable1').attr('id'));
	
    // page is now ready, initialize the calendar...
    jQuery('#fgpsn-wo-calendar').fullCalendar({
        // put your options and callbacks here
       
        header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			
		defaultView: 'agendaWeek',
		editable: true,
		droppable: true,
		timeFormat: 'ddd, hA',
		eventClick: function(calEvent, jsEvent, view) {
			
			jQuery(this).css('border-color', 'red');
			jQuery(this).draggable('eventObject');
			jQuery(this).droppable('eventObject');
			//jQuery(this).on('drop', alert('Event: '));

		},
		eventDrop: function(calEvent, jsEvent, view) {
			
			
			if( calEvent.end === null ){ 

				var ret = (calEvent.start + 360000);

				 }
			//alert('Dropped on: ' + calEvent.start + ' ID: ' + ret + ' ID: ' + calEvent.id);
			
			var droppedInfo = 'new_start=' + calEvent.start + '&new_end=' + ret + '&wo_id=' + calEvent.id;
			
				
			alert('Dropped on: ' + droppedInfo );

				// retrieve the dropped element's stored Event Object
				var originalEventObject = jQuery(this).data('eventObject');
				
				// we need to copy it, so that multiple events don't have a reference to the same object
				//var copiedEventObject = jQuery.extend({}, originalEventObject);
				
				// assign it the date that was reported
				//copiedEventObject.start = date;
				
				// render the event on the calendar
				// the last `true` argument determines if the event 'sticks' (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
				
				jQuery().fullCalendar('renderEvent', originalEventObject, true);
				jQuery(originalEventObject).remove();
				
				//update database
				
				jQuery.ajax({
					type: 'POST',
					url: '" . admin_url('admin-ajax.php') . "',
					data: { droppedInfo,
							action: 'updateWoDate' },
					dataType: 'text',
					success: function(data){
									alert(data);
									//alert(jQuery('#save-changes'));
									jQuery('.fc-clear').empty();
									jQuery('.fc-clear').append('<h4>Confirm!</h4>');
								}
				});
				
				// is the 'remove after drop' checkbox checked?
				if (jQuery('#drop-remove').is(':checked')) {
					// if so, remove the element from the 'Draggable Events' list
					jQuery(originalEventObject).remove();
				}
			},
				
			
      events: [" . $events_string . "],
     
       //events: '/fgpsn_wos.php'
       
      eventRender: function(event, element) {
			element.find('.fc-event-title').remove();
			//element.find('.fc-event-time').remove();
			var new_description =   
				moment(event.start).format('ddd, hA') + '-'
				+ moment(event.end).format('ddd, hA') + '<br/>'
			   
				+ '<strong>Address: </strong><br/>' + event.description + '<br/>';
			element.append(new_description);
		
		}
		

    })

	});</SCRIPT>";
	echo $fgpsn_calendar_display;
	return $fgpsn_calendar_display;
}
add_shortcode( 'fgpsn_wo_calendar1', 'fgpsnWoCalendar1' );



function getWoHistTemplate_fn( $useID ) {
	//echo "<h1>Oh Here we go!</h1>";
	global $table_prefix;
	global $fgpsn_array_of_wo_ids;
	global $disp_data_wo_sidebar;
	global $disp_data;
	global $wpdb;
			
	$disp_data_wo_sidebar = '<TABLE id="wo_summary_table_sidebar" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Subject</th>
					<th>Date Rec\'d</th>
					
				</tr>
			</thead>
						<TBODY>';
			
			$disp_data = '<div class="fgpsn-property-data-display"><script>
		jQuery(document).ready(function() {
			jQuery("#wo_summary_table").dataTable( {

				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );

		jQuery("#wo_summary_table_sidebar").dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, ]
			} );
		} );
		</SCRIPT>
		<TABLE id="wo_summary_table" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Location/<br>Contact</th>
					<th>Issue</th>
					<th>Date Rec\'d</th>
					<th>Estimate?</th>
					<th>Employee</th>
					
				</tr>
			</thead>
						<TBODY>';
		
		$prop_id = get_post_meta($_POST['useID'], 'fgpsn_property_id', true);

			$args = array(
				'post_type'  => 'maintenance_requests',
				'meta_key'   => 'fgpsn_wo_selected_properties',
				'orderby'    => 'title',
				'order'      => 'ASC',
				'post_status'      => 'publish',
				'nopaging'	=> true,
				'meta_query' => array(
						array(
							'key'     => 'fgpsn_wo_selected_properties',
							'value'   => $prop_id,
							'compare' => '=',
						),
					),
				);
				$units = new WP_Query( $args );
				
				while( $units->have_posts() ) {

					$units->the_post();
					//echo '<li>' . get_the_title() . '</li>';
					//$pc_from_info = $post->post_author;
					$cur_property = get_the_title( get_post_meta( get_the_id(), 'fgpsn_wo_selected_units', true) );
					//echo $pc_from_info;
					$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
					$pc_from_email = $pc_from_info->user_email;
					$disp_data .= '<tr>
						<td>' . $cur_property . '</td>
						<td>' . get_the_title() . '</td>
						<td>' . $cur_property . '</td>
						<td>' . $cur_property . '</td>
						<td>' . $cur_property . '</td>
					
					</tr>';

				}
				$disp_data .= '</tbody></table></div>';
				/*foreach ( $units as $unit ) : setup_postdata( $unit );
					$unitno = get_the_title( $unit->ID);
					
					$items[] = array("value" => '111', "text" => $sqlcheck);
				endforeach; */
				wp_reset_postdata();


			//$disp_data .= "<H4>Query!" . $wpdb->last_query . "</H4>";
			//echo "<H4>Query!" . $wpdb->last_query . " - " . $disp_data . " - " . count($cur_comms) . "</H4>";
			/*if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
				//$disp_data .= "<H4>Array 2!</H4>";
				 //$disp_data .= '';
				add_thickbox();
				foreach ($cur_comms as $k=>$v) {
					//$disp_data .= "<H4>Array Row 3033: " . $k . " - " . $v . "</H4>";
					
					foreach ($v as $kv=>$vV) {

						if ($kv == 'post_author') {
							$pc_from_info = get_userdata( $vV );
							$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
							$pc_from_email = $pc_from_info->user_email;
						}
						if ($kv == 'post_date') {
							$pc_from_date = strtotime($vV);
							$pc_from_date = date('M-d-y', $pc_from_date);
						}
						if ($kv == 'post_title') {
							$pc_from_subject = $vV;
						}
						if ($kv == 'ID') {


							$print_link = '<a href="' . get_permalink(3518) . '?fgpsn_wo_id=' . $vV . '&TB_iframe=true&width=1000&height=750" class="thickbox">( Print Form )</A>';



							$fgpsn_array_of_wo_ids[] = $vV;
							$pc_original_id = $vV;
							$unitno = get_the_title(get_post_meta($vV, 'fgpsn_wo_selected_units', true));
							$propertyno = get_post_meta($vV, 'fgpsn_wo_selected_properties', true);
							$city = get_post_meta($propertyno, 'fgpsn_property_city', true);
							$contact_notes = get_post_meta($vV, 'fgpsn_wo_contact_notes', true);
							$deadline = get_post_meta($vV, 'fgpsn_wo_deadline', true);
							
							$estimate_required = get_post_meta($vV, 'fgpsn_wo_requires_est', true);
							$estimate_completed = get_post_meta($vV, 'fgpsn_wo_est_completed', true);
							$wo_approved_by = get_post_meta( $vV, 'fgpsn_wo_approval_by', true );
							
							$comm_link = get_permalink($vV);
							$prop_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_selected_units', true));
							
								
								if (get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true)) {
									$staff_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true));
									$assigned_staff = get_the_title(get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true));
								} else {
									$assigned_staff = 'N/A';
								}
							}
						if ($kv == 'guid') {
							$pc_link = $vV;
							//$comm_link = $vV;
						}
							
					}
						
					$estimate_status = '';
					if(!is_null($estimate_required) && !empty($estimate_required)) {
						//$disp_data .= "<br>Req Not Null: " . $estimate_required . "<br>";
						$estimate_status = 'Estimate Required';
						
						
						if(!is_null($estimate_completed) && !empty($estimate_completed)) {
							
							$estimate_status = 'Completed:<br>' . $wo_approved_by. "<br>";
							
							//if it is completed see if it is approved
							if(!is_null($wo_approved_by) && !empty($wo_approved_by)){
								$estimate_status = 'Approved By:<br>' . get_the_title($wo_approved_by) . "<br>";
							} else {
								$estimate_status = 'Approval Pending';
							}

						} else {
							$estimate_status = 'Estimate Pending';
						}

					} else {
						$estimate_status = 'N/A';
					}


					$disp_data .= "<tr><td valign=top><A HREF='" . $prop_link . "'>" . $unitno . "</a><br>" . $city . "</a><br><b>Contact:</b> " . $contact_notes . "</td>
					<td>";
					$disp_data_wo_sidebar .= "<tr><td valign=top>";
					
					$user_roles = get_userdata( $current_user->ID );
					$cur_role = $user_roles->roles;
					if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
						$disp_data .= "<A HREF='/maintenance-request/?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . ",</a>
						<br><A HREF='" . $comm_link . "?gform_post_id=" . $pc_original_id . "'>Read Details</a>";
					} else {
						$disp_data .=  "<A HREF='" . $comm_link . "?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . "</a>";
					}


					$disp_data .= "<br>" . $print_link . "</td><td valign=top>" . $pc_from_date;

					if( $deadline != '' ) { $disp_data .= "<br><B>Deadline:</B> " . $deadline; }

					 $disp_data .= "</td>
						<td valign=top>" . $estimate_status . "
						</td>
						<td valign=top><A HREF='" . $staff_link . "'>" . $assigned_staff . "</A></td>
						</TR>";


					if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
						$disp_data_wo_sidebar .= "<A HREF='/maintenance-request/?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . ",</a>";
					} else {
						$disp_data_wo_sidebar .=  "<A HREF='" . $comm_link . "'>" . $pc_from_subject . "</a>";
					}
					$disp_data_wo_sidebar .= "</td>
					<td valign=top>" . $pc_from_date . "</td></TR>";

				}

				
			}*/
			
		$disp_data .= "</tbody><tfoot>
				<tr>
					<th>Property</th>
					<th>Name</th>
					<th>Issue</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</foot></table>";

		$disp_data_wo_sidebar .= '</tbody><tfoot>
				<tr>
					<th>Label</th>
					<th>Data</th>
					
				</tr>
			</foot></table>';

			//$disp_data .= "<h1>rgnrgrnt" . $fgpsn_array_of_wo_ids . "</H1>";
			//echo $disp_data;
	echo $disp_data;
}

add_action('wp_ajax_getWoHistTemplate', 'getWoHistTemplate_fn');
add_action('wp_ajax_nopriv_getWoHistTemplate', 'getWoHistTemplate_fn');



function fgpsnWoSummaryTable1() {
	//echo "<h1>Oh Here we go!</h1>";
	global $table_prefix;
	global $fgpsn_array_of_wo_ids;
	global $disp_data_wo_sidebar;
	global $disp_data;
	global $wpdb;
			
	$disp_data_wo_sidebar = '<TABLE id="wo_summary_table_sidebar" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Issue</th>
					<th>Date Rec\'d</th>
				</tr>
			</thead>
			<TBODY>';
			
			$disp_data = '<TABLE id="wo_summary_table"  class="table table-bordered table-striped" cellspacing="0" ><thead>
				<tr>
					<th>Location/<br>Contact</th>
					<th>Issue</th>
					<th>Date Rec\'d</th>
					<th>Estimate?</th>
					<th>Employee</th>
					
				</tr>
			</thead>
						<TBODY>';
		
		
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'ai1ec_events'
						AND post_status = 'publish'
						AND ID
						IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'cpm_dashboard_view'
								AND meta_value <> '' AND meta_value <> 0 )";
								
			
			//check role and get assignment based list
			global $current_user;
			$user_roles = get_userdata( $current_user->ID );
			$fgpsn_contact_post_id = get_user_meta( $current_user->ID,  'fgpsn_contact_post_id', true );
 			//print_r( $all_meta_for_user );
			//get post id from user_meta
			$cur_role = $user_roles->roles;
			if ( in_array('maint_staff', $cur_role) ||  in_array('maint_manager_role', $cur_role)  ) {
				$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND post_status ='publish'
						AND ID IN (SELECT post_id
											FROM " . $table_prefix . "postmeta
											WHERE meta_key = 'fgpsn_wo_participating_staff_approval'
											AND meta_value = " . $fgpsn_contact_post_id . " ) 
						ORDER BY post_date DESC";
			


			} else {
				$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND post_status ='publish'
						ORDER BY post_date DESC";
			}


			$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);
			//$disp_data .= "<H4>Query!" . $wpdb->last_query . "</H4>";
			//echo "<H4>Query!" . $wpdb->last_query . " - " . $disp_data . " - " . count($cur_comms) . "</H4>";
			if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
				//$disp_data .= "<H4>Array 2!</H4>";
				 //$disp_data .= '';
				add_thickbox();
				foreach ($cur_comms as $k=>$v) {
					//$disp_data .= "<H4>Array Row 3033: " . $k . " - " . $v . "</H4>";
					
					foreach ($v as $kv=>$vV) {

						if ($kv == 'post_author') {
							$pc_from_info = get_userdata( $vV );
							$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
							$pc_from_email = $pc_from_info->user_email;
						}
						if ($kv == 'post_date') {
							$pc_from_date = strtotime($vV);
							$pc_from_date = date('M-d-y', $pc_from_date);
						}
						if ($kv == 'post_title') {
							$pc_from_subject = $vV;
						}
						if ($kv == 'ID') {
							//this is the wo post id so use it to get all the meta

							$print_link = '<a href="' . get_permalink(3518) . '?fgpsn_wo_id=' . $vV . '&TB_iframe=true&width=1000&height=750" class="thickbox">( Print Form )</A>';

							$fgpsn_array_of_wo_ids[] = $vV;
							$pc_original_id = $vV;


							//get class name for styling table rows belos
							$className = get_post_meta($vV, 'fgpsn_wo_priority', true);
							switch($className) {
								
								case '0' :
									$className = 'low-priority';
									break;
									
								case '1' :
									$className = 'normal-priority';
									break;
									
								case '2' :
									$className = 'elevated-priority';
									break;
									
								case '3' :
									$className = 'high-priority';
									break;
									
								default:
									$className = 'normal-priority';
									break;
									
							}
							$unitno = get_the_title(get_post_meta($vV, 'fgpsn_wo_selected_units', true));
							$propertyno = get_post_meta($vV, 'fgpsn_wo_selected_properties', true);
							$city = get_post_meta($propertyno, 'fgpsn_property_city', true);
							$contact_notes = get_post_meta($vV, 'fgpsn_wo_contact_notes', true);
							$deadline = get_post_meta($vV, 'fgpsn_wo_deadline', true);
							
							$estimate_required = get_post_meta($vV, 'fgpsn_wo_requires_est', true);
							$estimate_completed = get_post_meta($vV, 'fgpsn_wo_est_completed', true);
							$wo_approved_by = get_post_meta( $vV, 'fgpsn_wo_approval_by', true );
							
							$comm_link = get_permalink($vV);
							$prop_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_selected_units', true));
							
								
							if (get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true)) {
								$staff_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true));
								$assigned_staff = get_the_title(get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true));
							} else {
								$assigned_staff = 'N/A';
							}

							if (get_post_meta($vV, 'fgpsn_wo_additional_vendors_approval', true)) {
								$vendor_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_additional_vendors_approval', true));
								$assigned_vendor = get_the_title(get_post_meta($vV, 'fgpsn_wo_additional_vendors_approval', true));
							} else {
								$assigned_vendor = 'N/A';
							}


						}
				
						if ($kv == 'guid') {
							$pc_link = $vV;
							//$comm_link = $vV;
						}
							
					}
						
					$estimate_status = '';
					if(!is_null($estimate_required) && !empty($estimate_required)) {
						//$disp_data .= "<br>Req Not Null: " . $estimate_required . "<br>";
						$estimate_status = 'Estimate Required';
						
						
						if(!is_null($estimate_completed) && !empty($estimate_completed)) {
							
							$estimate_status = 'Completed:<br>' . $wo_approved_by. "<br>";
							
							//if it is completed see if it is approved
							if(!is_null($wo_approved_by) && !empty($wo_approved_by)){
								$estimate_status = 'Approved By:<br>' . get_the_title($wo_approved_by) . "<br>";
							} else {
								$estimate_status = 'Approval Pending';
							}

						} else {
							$estimate_status = 'Estimate Pending';
						}

					} else {
						$estimate_status = 'N/A';
					}


					/* Add css class to <tr> to indicate wo priority */
					$disp_data .= "<tr class='" . $className . "'>
					<td valign=top><A HREF='" . $prop_link . "'>" . $unitno . "</a>, " . $city . "</a>
					</td>
					<td>";//took out <br><b>Contact:</b> " . $contact_notes . "
					$disp_data_wo_sidebar .= "<tr><td valign=top>";
					
					
					/*This should link to the WO SIngle
					The WO Single will then allow Print and edit options?
					Maybe add a little 'Print' link here
					*/

					$user_roles = get_userdata( $current_user->ID );
					$cur_role = $user_roles->roles;
					if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
						$disp_data .= "<A HREF='/maintenance-request-quick-edit/?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . ",</a>
						<br><A HREF='" . $comm_link . "?gform_post_id=" . $pc_original_id . "'>Read Details</a>";
					} else {
						$disp_data .=  "<A HREF='" . $comm_link . "?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . "</a>";
					}


					$disp_data .= "<br>" . $print_link . "</td><td valign=top>" . $pc_from_date;

					if( $deadline != '' ) { $disp_data .= "<br><B>Deadline:</B> " . $deadline; }

					 $disp_data .= "</td>
						<td valign=top>" . $estimate_status . "
						</td>
						<td valign=top><A HREF='" . $staff_link . "'>" . $assigned_staff . "</A><br>
						<A HREF='" . $vendor_link . "'>" . $assigned_vendor . "</A></td>
						</TR>";


					if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
						$disp_data_wo_sidebar .= "<A HREF='/maintenance-request-quick-edit/?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . ",</a>";
					} else {
						$disp_data_wo_sidebar .=  "<A HREF='" . $comm_link . "'>" . $pc_from_subject . "</a>";
					}
					$disp_data_wo_sidebar .= "</td>
					<td valign=top>" . $pc_from_date . "</td></TR>";

				}

				
			}
			
		$disp_data .= "</tbody><tfoot>
				<tr>
					<th>Property</th>
					<th>Name</th>
					<th>Issue</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</foot></table>";

		$disp_data_wo_sidebar .= '</tbody><tfoot>
				<tr>
					<th>Label</th>
					<th>Data</th>
					
				</tr>
			</foot></table>';

			//$disp_data .= "<h1>rgnrgrnt" . $fgpsn_array_of_wo_ids . "</H1>";
			//echo $disp_data;
	return $disp_data;
}





function fgpsnWoSummaryTableJsn() {
	//echo "<h1>Oh Here we go!</h1>";
	global $table_prefix;
	global $fgpsn_array_of_wo_ids;
	global $disp_data_wo_sidebar;
	global $disp_data;
	global $wpdb;
			
	$disp_data_wo_sidebar = '<TABLE id="wo_summary_table_sidebar" class="display" cellspacing="0" ><thead>
				<tr>
					<th>Issue</th>
					<th>Date Rec\'d</th>
				</tr>
			</thead>
			<TBODY>';
			
			$disp_data = '<TABLE id="wo_summary_table"  class="table table-bordered table-striped" cellspacing="0" ><thead>
				<tr>
					<th>Location/<br>Contact</th>
					<th>Issue</th>
					<th>Date Rec\'d</th>
					<th>Estimate?</th>
					<th>Employee</th>
					
				</tr>
			</thead>
						<TBODY>';
		
		
			$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'ai1ec_events'
						AND post_status = 'publish'
						AND ID
						IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'cpm_dashboard_view'
								AND meta_value <> '' AND meta_value <> 0 )";
								
			
			//check role and get assignment based list
			global $current_user;
			$user_roles = get_userdata( $current_user->ID );
			$fgpsn_contact_post_id = get_user_meta( $current_user->ID,  'fgpsn_contact_post_id', true );
 			//print_r( $all_meta_for_user );
			//get post id from user_meta
			$cur_role = $user_roles->roles;
			if ( in_array('maint_staff', $cur_role) ||  in_array('maint_manager_role', $cur_role)  ) {
				$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND post_status ='publish'
						AND ID IN (SELECT post_id
											FROM " . $table_prefix . "postmeta
											WHERE meta_key = 'fgpsn_wo_participating_staff_approval'
											AND meta_value = " . $fgpsn_contact_post_id . " ) 
						ORDER BY post_date DESC";
			
			} else {
				$get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND post_status ='publish'
						ORDER BY post_date DESC";
			}

			$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);
			//$disp_data .= "<H4>Query!" . $wpdb->last_query . "</H4>";
			//echo "<H4>Query!" . $wpdb->last_query . " - " . $disp_data . " - " . count($cur_comms) . "</H4>";
			if ( is_array( $cur_comms ) && !empty( $cur_comms ) ) {
				//$disp_data .= "<H4>Array 2!</H4>";
				 //$disp_data .= '';
				add_thickbox();
				foreach ($cur_comms as $k=>$v) {
					//$disp_data .= "<H4>Array Row 3033: " . $k . " - " . $v . "</H4>";
					
					foreach ($v as $kv=>$vV) {

						if ($kv == 'post_author') {
							$pc_from_info = get_userdata( $vV );
							$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
							$pc_from_email = $pc_from_info->user_email;
						}
						if ($kv == 'post_date') {
							$pc_from_date = strtotime($vV);
							$pc_from_date = date('M-d-y', $pc_from_date);
						}
						if ($kv == 'post_title') {
							$pc_from_subject = $vV;
						}
						if ($kv == 'ID') {
							//this is the wo post id so use it to get all the meta

							$print_link = '<a href="' . get_permalink(3518) . '?fgpsn_wo_id=' . $vV . '&TB_iframe=true&width=1000&height=750" class="thickbox">( Print Form )</A>';

							$fgpsn_array_of_wo_ids[] = $vV;
							$pc_original_id = $vV;


							//get class name for styling table rows belos
							$className = get_post_meta($vV, 'fgpsn_wo_priority', true);
							switch($className) {
								
								case '0' :
									$className = 'low-priority';
									break;
									
								case '1' :
									$className = 'normal-priority';
									break;
									
								case '2' :
									$className = 'elevated-priority';
									break;
									
								case '3' :
									$className = 'high-priority';
									break;
									
								default:
									$className = 'normal-priority';
									break;
									
							}
							$unitno = get_the_title(get_post_meta($vV, 'fgpsn_wo_selected_units', true));
							$propertyno = get_post_meta($vV, 'fgpsn_wo_selected_properties', true);
							$city = get_post_meta($propertyno, 'fgpsn_property_city', true);
							$contact_notes = get_post_meta($vV, 'fgpsn_wo_contact_notes', true);
							$deadline = get_post_meta($vV, 'fgpsn_wo_deadline', true);
							
							$estimate_required = get_post_meta($vV, 'fgpsn_wo_requires_est', true);
							$estimate_completed = get_post_meta($vV, 'fgpsn_wo_est_completed', true);
							$wo_approved_by = get_post_meta( $vV, 'fgpsn_wo_approval_by', true );
							
							$comm_link = get_permalink($vV);
							$prop_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_selected_units', true));
							
								
							if (get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true)) {
								$staff_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true));
								$assigned_staff = get_the_title(get_post_meta($vV, 'fgpsn_wo_participating_staff_approval', true));
							} else {
								$assigned_staff = 'N/A';
							}

							if (get_post_meta($vV, 'fgpsn_wo_additional_vendors_approval', true)) {
								$vendor_link = get_permalink(get_post_meta($vV, 'fgpsn_wo_additional_vendors_approval', true));
								$assigned_vendor = get_the_title(get_post_meta($vV, 'fgpsn_wo_additional_vendors_approval', true));
							} else {
								$assigned_vendor = 'N/A';
							}


						}
				
						if ($kv == 'guid') {
							$pc_link = $vV;
							//$comm_link = $vV;
						}
							
					}
						
					$estimate_status = '';
					if(!is_null($estimate_required) && !empty($estimate_required)) {
						//$disp_data .= "<br>Req Not Null: " . $estimate_required . "<br>";
						$estimate_status = 'Estimate Required';
						
						
						if(!is_null($estimate_completed) && !empty($estimate_completed)) {
							
							$estimate_status = 'Completed:<br>' . $wo_approved_by. "<br>";
							
							//if it is completed see if it is approved
							if(!is_null($wo_approved_by) && !empty($wo_approved_by)){
								$estimate_status = 'Approved By:<br>' . get_the_title($wo_approved_by) . "<br>";
							} else {
								$estimate_status = 'Approval Pending';
							}

						} else {
							$estimate_status = 'Estimate Pending';
						}

					} else {
						$estimate_status = 'N/A';
					}


					/* Add css class to <tr> to indicate wo priority */
					$disp_data .= "<tr class='" . $className . "'>
					<td valign=top><A HREF='" . $prop_link . "'>" . $unitno . "</a>, " . $city . "</a>
					</td>
					<td>";//took out <br><b>Contact:</b> " . $contact_notes . "
					$disp_data_wo_sidebar .= "<tr><td valign=top>";
					
					
					/*This should link to the WO SIngle
					The WO Single will then allow Print and edit options?
					Maybe add a little 'Print' link here
					*/

					$user_roles = get_userdata( $current_user->ID );
					$cur_role = $user_roles->roles;
					if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
						$disp_data .= "<A HREF='/maintenance-request-quick-edit/?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . ",</a>
						<br><A HREF='" . $comm_link . "?gform_post_id=" . $pc_original_id . "'>Read Details</a>";
					} else {
						$disp_data .=  "<A HREF='" . $comm_link . "?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . "</a>";
					}


					$disp_data .= "<br>" . $print_link . "</td><td valign=top>" . $pc_from_date;

					if( $deadline != '' ) { $disp_data .= "<br><B>Deadline:</B> " . $deadline; }

					 $disp_data .= "</td>
						<td valign=top>" . $estimate_status . "
						</td>
						<td valign=top><A HREF='" . $staff_link . "'>" . $assigned_staff . "</A><br>
						<A HREF='" . $vendor_link . "'>" . $assigned_vendor . "</A></td>
						</TR>";


					if ( in_array('property_manager', $cur_role) || in_array('administrator', $cur_role)) {
						$disp_data_wo_sidebar .= "<A HREF='/maintenance-request-quick-edit/?gform_post_id=" . $pc_original_id . "'>" . $pc_from_subject . ",</a>";
					} else {
						$disp_data_wo_sidebar .=  "<A HREF='" . $comm_link . "'>" . $pc_from_subject . "</a>";
					}
					$disp_data_wo_sidebar .= "</td>
					<td valign=top>" . $pc_from_date . "</td></TR>";

				}

				
			}
			
		$disp_data .= "</tbody><tfoot>
				<tr>
					<th>Property</th>
					<th>Name</th>
					<th>Issue</th>
					<th>Date</th>
					<th>Open</th>
				</tr>
			</foot></table>";

		$disp_data_wo_sidebar .= '</tbody><tfoot>
				<tr>
					<th>Label</th>
					<th>Data</th>
					
				</tr>
			</foot></table>';

			//$disp_data .= "<h1>rgnrgrnt" . $fgpsn_array_of_wo_ids . "</H1>";
			//echo $disp_data;
	return $disp_data;
}

/*Form Processing Functions*/

/* populate gform property selection menu */

add_filter("gform_pre_render_6", "populateWoPropertyDropdown");
add_filter("gform_admin_pre_render_6", "populateWoPropertyDropdown");
add_filter("gform_pre_submission_filter_6", "populateWoPropertyDropdown");
add_filter( 'gform_pre_validation_6', 'populateWoPropertyDropdown' );


function populateWoPropertyDropdown($form){
    
    //form 2 is maintenance request - populate properties for work order
    if($form["id"] != 6)
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Property  inclwoposttype line 1544  -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'properties', 'post_status'=> 'publish', 'nopaging' => true );

	$properties = get_posts( $args );
	foreach ( $properties as $property ) : setup_postdata( $property );
		$addr1 = get_post_meta( $property->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $property->ID, 'fgpsn_property_city', true);
		$fgpsn_wo_selected_properties = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_properties', true);
		
		$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_properties == $property->ID ) {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => true);
		} else {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
    
    foreach($form["fields"] as &$field)
    
		if($field["id"] == 57){
			$field["choices"] = $items;
		}

    return $form;
}


add_filter("gform_pre_render_6", "populateWoPropertyDependentUnitDropdown");
add_filter("gform_admin_pre_render_6", "populateWoPropertyDependentUnitDropdown");
add_filter("gform_pre_submission_filter_6", "populateWoPropertyDependentUnitDropdown");
add_filter( 'gform_pre_validation_6', 'populateWoPropertyDependentUnitDropdown' );


function populateWoPropertyDependentUnitDropdown($form){
   
    //form 2 is maintenance request - populate properties for work order
    if( $form["id"] != 6 && $form["id"] != 10 )
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Unit -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish', 'nopaging' => true, 'posts_per_page' => -1 );

	$units = get_posts( $args );
	$this_query = $wpdb->last_query;
	foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		//$items[] = array("value" => $unit->ID, "text" => $unitno);
		
		$fgpsn_wo_selected_units = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_units', true);
		
		//$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_units == $unit->ID ) {
			$items[] = array("value" => $unit->ID, "text" => $unitno, "isSelected" => true);
		} else {
			$items[] = array("value" => $unit->ID, "text" => $unitno . $fgpsn_wo_selected_units, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
	foreach($form["fields"] as &$field)
    
		if($field["id"] == 58){

			$field["choices"] = $items;
		}
    return $form;
}




/* end populate gform property selection menu */
function getWOUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	//echo "<H2>Query: " . $dealerCountry  . "</H2>";

	 //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    
     //Adding post titles to the items array
    //$args = array( 'post_type' => 'contact_data', 'post_status'=> 'publish' );
    $args = array(
	'post_type'  => 'unit_data',
	'meta_key'   => 'fgpsn_property_id',
	'orderby'    => 'title',
	'order'      => 'ASC',
	'post_status'      => 'publish',
	'nopaging'	=> true,
	'meta_query' => array(
			array(
				'key'     => 'fgpsn_property_id',
				'value'   => $dealerCountry,
				'compare' => '=',
			),
		),
	);
	$units = new WP_Query( $args );
	$sqlcheck = $wpdb->last_query;
	//echo "<H2>Query: " . $wpdb->last_query . "</H2>";
	/*echo "<H2>Query: " . $wpdb->last_query . "</H2>";
	while ( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_title(), "text" => get_the_title());
	}

	wp_reset_postdata();
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish',
		'nopaging'	=> true );

	$units = get_posts( $args );
	* */
	$items[] = array("text" => " -- Selected Units -- ", "value" => "");
	while( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_ID(), "text" => get_the_title() );
	}
	/*foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		$items[] = array("value" => '111', "text" => $sqlcheck);
	endforeach; */
	wp_reset_postdata();
	echo json_encode($items);
	//echo $items;
    die;
    
    /*
    $dealerCountry = $_POST['fgpsn_wo_selected_properties'];
    $dealers = get_posts(array(
        "post_type" => "unit_data",
        "post_status" => "publish",
        "orderby" => "title",
        "order" => "ASC",
        "posts_per_page"  => -1
    ));
    $items = array();
    $items[] = array( "text" => __('Select dealer...','theme'), "value" => 'default' );
    foreach($dealers as $dealer){
        $items[] = array( "text" => $dealer->post_title, "value" => $dealer->post_title );
    }
    echo json_encode($items);
    die;
    */

}

add_action('wp_ajax_getWOUnitList', 'getWOUnitList_fn');
add_action('wp_ajax_nopriv_getWOUnitList', 'getWOUnitList_fn');



/*shortcode for work order table display*/

function fgpsnWoSummaryTable( $atts ){
	global  $disp_data;
	global $wpdb;
		$args = array(
				'post_type' => 'maintenance_requests',
				'post_status' => 'publish');

		$postlist = get_posts( $args );

		foreach ( $postlist as $post ) :
		  
		  setup_postdata( $post );
		  $start_data = get_post_meta($post->ID, 'fgpsn_wo_start_date', true);
		  $end_data = get_post_meta($post->ID, 'fgpsn_wo_end_date', true);
		  if ( $start_data === false || $start_data === false ) {
			  $start_data = $post->post_date;
			  $end_data = $post->post_date;
		  }
		 	//$start_data = $post->post_date;
			  //$end_data = $post->post_date;
		  
		  //var_dump($post);
			$className = get_post_meta($post->ID, 'fgpsn_wo_priority', true);
			switch($className) {
				
				case '0' :
					$className = 'low-priority';
					break;
					
				case '1' :
					$className = 'normal-priority';
					break;
					
				case '2' :
					$className = 'elevated-priority';
					break;
					
				case '3' :
					$className = 'high-priority';
					break;
					
				default:
					$className = 'elevated-priority';
					break;
					
			}
			$event_start_date = strtotime(get_post_meta($post->ID, 'fgpsn_wo_start_date', true));
			$event_start_date = date('M-d-y', $event_start_date);
			$event_end_date = strtotime(get_post_meta($post->ID, 'fgpsn_wo_end_date', true));
			$event_end_date = date('M-d-y', $event_end_date);
			  
			$events_string .= "{ Name: '" . $post->post_title . "',";
			$events_string .= "Age: 'false',";
			$events_string .= "Gender: '" . $post->ID . "',";
			$events_string .= "Height: '" . $post->ID . "',";
			$events_string .= "Color: '" . $className . "'";
			
			$events_string .= "},";	
				
		endforeach;
		
       $events_string = rtrim($events_string, ',');
	
	
//wp_enqueue_script('jquery-ui-core');
//wp_enqueue_script('jquery-ui-datepicker');
  
   add_thickbox();
   wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );

	$fgpsn_table_display_script .=  "<script>
		jQuery(document).ready(function() {
			jQuery('#wo_summary_table').dataTable( {

				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );

		jQuery('#wo_summary_table_sidebar').dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, ]
			} );
		} );
		</SCRIPT>";

	

	 if ( is_page_template( 'template-fullwidth.php' ) ) {
	    // Returns true when 'about.php' is being used.
	    //echo "<h1>2222222DKJKJDKJDDJK</H1>";
	} 
	// search
	if( isset( $display_page_title_props['pages'] ) && $display_page_title_props['pages'] != 1 ) {
		$show_title = false;
	}


	//assignedPropertyComms('maintenance_requests');
	fgpsnWoSummaryTable1();
	
	return $disp_data . $fgpsn_table_display_script . $select;

	//return $disp_data . $fgpsn_table_display_script;
	//echo $disp_data;
}
add_shortcode( 'fgpsn_wo_summary_table', 'fgpsnWoSummaryTable' );



function fgpsnJsnWoSummaryTable( $atts ){
	global  $disp_data;
	global $wpdb;
	global $fgpsn_table_display_script;
	/*
		$args = array(
				'post_type' => 'maintenance_requests',
				'post_status' => 'publish');

		$postlist = get_posts( $args );

		foreach ( $postlist as $post ) :
		  
		  setup_postdata( $post );
		  $start_data = get_post_meta($post->ID, 'fgpsn_wo_start_date', true);
		  $end_data = get_post_meta($post->ID, 'fgpsn_wo_end_date', true);
		  if ( $start_data === false || $start_data === false ) {
			  $start_data = $post->post_date;
			  $end_data = $post->post_date;
		  }
		 	//$start_data = $post->post_date;
			  //$end_data = $post->post_date;
		  
		  //var_dump($post);
			$className = get_post_meta($post->ID, 'fgpsn_wo_priority', true);
			switch($className) {
				
				case '0' :
					$className = 'low-priority';
					break;
					
				case '1' :
					$className = 'normal-priority';
					break;
					
				case '2' :
					$className = 'elevated-priority';
					break;
					
				case '3' :
					$className = 'high-priority';
					break;
					
				default:
					$className = 'elevated-priority';
					break;
					
			}
			$event_start_date = strtotime(get_post_meta($post->ID, 'fgpsn_wo_start_date', true));
			$event_start_date = date('M-d-y', $event_start_date);
			$event_end_date = strtotime(get_post_meta($post->ID, 'fgpsn_wo_end_date', true));
			$event_end_date = date('M-d-y', $event_end_date);
			  
			$events_string .= "{ Name: '" . $post->post_title . "',";
			$events_string .= "Age: 'false',";
			$events_string .= "Gender: '" . $post->ID . "',";
			$events_string .= "Height: '" . $post->ID . "',";
			$events_string .= "Color: '" . $className . "'";
			
			$events_string .= "},";	
				
		endforeach;
		
       $events_string = rtrim($events_string, ',');
	*/
	
//wp_enqueue_script('jquery-ui-core');
//wp_enqueue_script('jquery-ui-datepicker');
  
   add_thickbox();
   wp_enqueue_script('fgpsndatatables', 'http://www.fgpsn.com/wp-content/plugins/fgpsnPmInit/js/jquery.dataTables.min.js', array(), '1.10.4', true );

	$fgpsn_table_display_script .=  "<script>
		jQuery(document).ready(function() {
			jQuery('#wo_summary_table').dataTable( {

				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, {
					targets: [ 3 ],
					orderData: [ 3, 0 ]
				} ]
			} );

		jQuery('#wo_summary_table_sidebar').dataTable( {
				columnDefs: [ {
					targets: [ 0 ],
					orderData: [ 0, 1 ]
				}, {
					targets: [ 1 ],
					orderData: [ 1, 0 ]
				}, ]
			} );
		} );
		</SCRIPT>";
		$fgpsn_table_display_script .=  "<script type='text/javascript'>

		jQuery(document).ready(function(){
            jQuery.ajax({
	        type: 'GET',
	        url: 'http://www.mediatemanagement.com/pm/pm_prod/jsonp-pm-dashboard.php',
	        data: { theseAssignedProps : '0', action: 'getAlertCounts' },
	        dataType: 'jsonp',
	        crossDomain: true,
	            }).done(function(response){
	              //alert(response['woinfo'].length);
	              //alert(response['woinfo'][0]);
	             console.log(response['woinfo']);
	              
	             var text = '';

                 jQuery.each(response['woinfo'], function(idx, cur_wo){
                    text += '<tr><td>' + cur_wo.WOStatus + '</td>';
                    text += '<td>' + cur_wo.DateRecvd + '</td>';
                    text += '<td>' + cur_wo.Address1 + '</td>';
                    text += '<td>' + cur_wo.FirstName + ' ' + cur_wo.FirstName + '<br>Unit: ' + cur_wo.UnitNo + '</td>';
                    text += '<td>link</td></tr>';
                  });

                   
                text += '</table>';
                
            }).fail(function(error){
              alert('fail ' + error.statusText);
                console.log(error.statusText);
            });

});


</script>";

	

	 if ( is_page_template( 'template-fullwidth.php' ) ) {
	    // Returns true when 'about.php' is being used.
	    //echo "<h1>2222222DKJKJDKJDDJK</H1>";
	} 
	// search
	if( isset( $display_page_title_props['pages'] ) && $display_page_title_props['pages'] != 1 ) {
		$show_title = false;
	}

	
	return $$fgpsn_table_display_script . "<table id='fgpsn-wo-table'><thead><tr><th>Status</th><th>Date</th><th>Property</th><th>Requested For</th><th>View</th></tr></thead><tbody>
		</tbody></table>";

}
add_shortcode( 'fgpsnjsn_wo_summary_table', 'fgpsnJsnWoSummaryTable' );
/*shortcode for work order single*/

function getWoTemplate( $unit_id ) {

	//echo '<H2>alrighty then - ' . $fgpsn_unit->post_title . '</h2>';
	global $wo_tabs;
	$wo_title = get_the_title();
    $property_title = get_the_title(get_post_meta( get_the_ID(), 'fgpsn_wo_selected_properties', true));
    $unit_id = get_post_meta( get_the_ID(), 'fgpsn_wo_selected_units', true);
    $unit_title = get_the_title($unit_id);


    $tenant_ids = get_post_meta($unit_id, 'fgpsn_property_unit_occupant_id', true);


    $unit_contacts = $tenant_ids . ' - ';
    if (is_array($tenant_ids)) {
        foreach($tenant_ids as $k=>$v) {
            $unit_contacts = $unit_contacts . 'Name: ' . get_the_title($v) . '<br>'
            . 'Phone: ' . get_post_meta( $v, 'fgpsn_contact_phone', true) . '<br>'
            . 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( $v, 'fgpsn_contact_cell_phone', true)
             . '<br>';
        }
    } else {
        $unit_contacts = $unit_contacts . get_the_title($tenant_ids) . '<br>'
        . 'Phone: ' . get_post_meta( $tenant_ids, 'fgpsn_contact_phone', true) . '<br>'
        . 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( $tenant_ids, 'fgpsn_contact_cell_phone', true);
    }



    $unit_owner_id = get_post_meta( get_the_ID(), 'unit_owner_id', true);
    $room = get_post_meta( get_the_ID(), 'fgpsn_wo_room_location', true);
    $post_author_id = get_post_field( 'post_author', get_the_ID() );
    
    
    $fgpsn_wo_requires_est = get_post_meta( get_the_ID(), 'fgpsn_wo_requires_est', true );
    $fgpsn_wo_est_completed = get_post_meta( get_the_ID(), 'fgpsn_wo_est_completed', true );
    $fgpsn_wo_approval_by = get_post_meta( get_the_ID(), 'fgpsn_wo_approval_by', true );
    $fgpsn_wo_estimate_date = get_post_meta( get_the_ID(), 'fgpsn_wo_estimate_date', true );
    $fgpsn_wo_time_estimate = get_post_meta( get_the_ID(), 'fgpsn_wo_time_estimate', true );
    
    $fgpsn_wo_prep_time_estimate = get_post_meta(get_the_ID(), 'fgpsn_wo_prep_time_estimate', true);
    $fgpsn_wo_work_time_estimate = get_post_meta(get_the_ID(), 'fgpsn_wo_work_time_estimate', true);

    $fgpsn_wo_time_actual = get_post_meta( get_the_ID(), 'fgpsn_wo_time_actual', true );
    $fgpsn_wo_prep_time_actual = get_post_meta(get_the_ID(), 'fgpsn_wo_prep_time_actual', true);
    $fgpsn_wo_work_time_actual = get_post_meta(get_the_ID(), 'fgpsn_wo_work_time_actual', true);
    
    $fgpsn_wo_start_date = get_post_meta(get_the_ID(), 'fgpsn_wo_start_date', true);
    $fgpsn_wo_end_date = get_post_meta(get_the_ID(), 'fgpsn_wo_end_date', true);
    
    $fgpsn_wo_request_types = get_post_meta(get_the_ID(), 'fgpsn_wo_request_types', true);
    $staff_id = get_post_meta(get_the_ID(), 'fgpsn_wo_participating_staff_approval', true);
    $fgpsn_wo_contact_notes = get_post_meta(get_the_ID(), 'fgpsn_wo_contact_notes', true);
    $fgpsn_wo_short_description = get_post_meta(get_the_ID(), 'fgpsn_wo_short_description', true);
    $fgpsn_wo_deadline = get_post_meta(get_the_ID(), 'fgpsn_wo_deadline', true);
    $fgpsn_wo_materials = get_post_meta( get_the_ID(), 'fgpsn_wo_materials', true);
    $fgpsn_wo_materials_notes = get_post_meta( get_the_ID(), 'fgpsn_wo_materials_notes', true);
    $fgpsn_wo_access_notes = get_post_meta( get_the_ID(), 'fgpsn_wo_access_notes', true);
    $fgpsn_wo_additional_vendors_approval = get_post_meta( get_the_ID(), 'fgpsn_wo_additional_vendors_approval', true);
    $fgpsn_wo_materials = maybe_unserialize($fgpsn_wo_materials);
    
    $update_form = gravity_form( 12, false, false, false, '', false, false );

    if ( $staff_id != '' ) {
        $approved_staff = get_the_title( $staff_id );
        $staff_email = get_post_meta($staff_id, 'fgpsn_employee_email', true);
    } else { 
        $approved_staff = 'N/A';
        $staff_email = 'N/A';
    }
    
    if( ( !$fgpsn_wo_requires_est ) && !empty( $fgpsn_wo_requires_est ) ) {
                        //$disp_data .= "<br>Req Not Null: " . $estimate_required . "<br>";
        $estimate_status = 'Estimate Required';
                        
                        
        if( ( !$fgpsn_wo_est_completed ) && !empty( $fgpsn_wo_est_completed ) ) {
                            
            $estimate_status = 'Completed:<br>' . $staff_group . "<br>";
                            
            //if it is completed see if it is approved
            if( ( !$fgpsn_wo_approval_by ) && !empty( $fgpsn_wo_approval_by ) ){
                $estimate_status = 'Approved By:<br>' . get_the_title($fgpsn_wo_approval_by) . "<br>";
            } else {
                $estimate_status = 'Approval Pending';
            }

        } 

    } else {
        $estimate_status = 'N/A';
    }


    $wo_tabs = "<H4 style='border-bottom: 1px solid black;'>FGPSN Work Order Request Details</H4>";
            //the_meta();
    $wo_tabs .= "<H4 style='display: inline; float: left; width: 45%;'><b>Rec'd Date:</b>" . get_the_date() . "

             <br><b>W.O. Title:</b> " . $wo_title . "</H4>";

             $wo_tabs .= '<h4 style="display: inline; float: right; width: 45%;"><b>Deadline:</b>' . $fgpsn_wo_deadline . '
             <br><b>W.O.#</b> ' . get_the_ID() . '</h4><div style="clear: both; border-bottom: 1px solid black;"></div>';

                
            //$req_by = get_userdata( $post_author_id );
             // echo 'Username: ' . $req_by->user_login . "\n";
              $wo_tabs .= '<div class="fgpsn-display-wo-form">Update Work Order</div>
              <TABLE id="fgpsn-wo-print">
               <TR><TH valign=top>Assigned To:</TH>
                    <TD>Name: ' . $approved_staff . '<BR>
                    Email: ' . $staff_email . '</TD></TR>

               <TR><TH valign=top>Additional Vendors:</TH>
                    <TD>Name: ' . get_the_title($fgpsn_wo_additional_vendors_approval) . '<BR>
                    Email: ' . $staff_email . '</TD></TR>


                <TR><TH valign=top>Requested For:</TH>
                    <TD>Property: ' . $property_title . '<BR>
                    Unit: ' . $unit_title . '<BR>
                    Tenants:' . $unit_contacts . '</TD></TR>

                <TR><TH valign=top>W.O. Contact:</TH>
                    <TD>' . $fgpsn_wo_contact_notes . '</TD></TR>

                 <TR><TH valign=top align=left colspan=2>Access Notes:</TH></TR>
                 <TR><TD valign=top align=left colspan=2>';
                 $wo_tabs .=  $fgpsn_wo_access_notes;
                 $wo_tabs .= '</TD></TR>
                
                <TR><TH valign=top align=left colspan=2>Short Description:</TH></TR>
                 <TR><TD valign=top align=left colspan=2>
                ';
                 $wo_tabs .= $fgpsn_wo_short_description;
                 $wo_tabs .= '</TD></TR>
                 <TR><TH valign=top align=left colspan=2>Additional Field Notes:</TH></TR>
                 <TR><TD valign=top align=left colspan=2>
                ' .  $update_form;

                 $wo_tabs .= get_the_content();
                 $wo_tabs .= '</TD></TR>

                </TABLE>';

             $wo_tabs .= '<h4><b>Estimates and Approvals:</b></h4>';

              $wo_tabs .= '<TABLE id="fgpsn-wo-print">
               <TR><TH valign=top>Estimate Status:</TH>
                    <TD valign=top>' . $estimate_status . '</TD></TR>


                <TR><TH valign=top>Est. Prep Time:</TH>
                    <TD valign=top>' . $fgpsn_wo_prep_time_estimate . '</TD></TR>

                <TR><TH valign=top>Est. Work Time:</TH>
                    <TD valign=top>' . $fgpsn_wo_work_time_estimate . '</TD></TR>
                
                <TR><TH valign=top align=left>Total Time Est:</TH><TD valign=top align=left>';
                 $wo_tabs .= $fgpsn_wo_time_estimate;
                 $wo_tabs .= '</TD></TR>
                 <TR><TH valign=top align=left colspan=2>Additional Field Notes:</TH></TR>
                 <TR><TD valign=top align=left colspan=2>
                ';
                 $wo_tabs .= get_the_content();
                 $wo_tabs .= '</TD></TR>
                </TABLE>';

             $wo_tabs .= '<h4><b>Materials:</b></h4>';
             $wo_tabs .= '<p><label>Materials Notes</label>' . $fgpsn_wo_materials_notes . '<p>';
            // var_dump( $fgpsn_wo_materials_notes );
              $wo_tabs .= '<TABLE id="fgpsn-wo-print">
               <TR><TH valign=top>Item</TH><TH valign=top>Number</TH><TH valign=top>Cost</TH></tr>';

               for($i = 0; $i< count($fgpsn_wo_materials);  $i++) {
                   $wo_tabs .= '<tr><TD valign=top>' . $fgpsn_wo_materials[$i]['Description'] . '</TD>
                    <TD valign=top>' . $fgpsn_wo_materials[$i]['Number'] . '</TD>
                    <TD valign=top>' . $fgpsn_wo_materials[$i]['Cost'] . '</TD></TR>';
                }
                $wo_tabs .= '</TABLE>';
				
	$wo_tabs .= "<script>jQuery(document).ready(function () { 
	jQuery( '.fgpsn-display-wo-form' ).click(function() {
			alert( jQuery('.fgpsn-toggle-wo-form').css('display') );
	 		if( jQuery('.fgpsn-toggle-wo-form').css('display') == 'block') {
		  		jQuery('.fgpsn-toggle-wo-form').css('display', 'none');
		  		jQuery('.fgpsn-display-wo-form').replaceWith('<div class=\"fgpsn-display-wo-form\">Update Work Order</div>');
		  	} else {
		  		jQuery('.fgpsn-toggle-wo-form').css('display', 'block');
		  		jQuery('.fgpsn-display-wo-form').replaceWith('<div class=\"fgpsn-hide-wo-form\">Hide Form</div>');
		  	}
		});
		jQuery( '.fgpsn-hide-wo-form' ).click(function() {jQuery('.fgpsn-toggle-wo-form').css('display', 'none');
		  		jQuery('.fgpsn-hide-wo-form').replaceWith('<div class=\"fgpsn-display-wo-form\">Update Work Order</div>'); });      
	});
	</script>";
	return $wo_tabs;		

}
add_shortcode( 'fgpsn_wo_single', 'getWoTemplate' );

/*shortcode for work order table display*/

function fgpsnWoReqFormFull( $atts ){

   wp_register_script('fgpsnWoScripts', plugins_url() . '/fgpsnPmInit/js/fgpsnWoScripts.js', array('jquery'),null,true   );
   echo plugins_url() . '/fgpsnPmInit/js/fgpsnWoScripts.js';
   wp_enqueue_script( 'fgpsnWoScripts' );
   
  gravity_form( 2, $display_title = false, $display_description = false, $echo = false );
  	//return $disp_form;
	//echo $disp_data;
}
add_shortcode( 'fgpsn_wo_request_form_full', 'fgpsnWoReqFormFull' );

function fgpsnWoReqFormQuick( $atts ){

   wp_register_script('fgpsnWoScripts', plugins_url() . '/fgpsnPmInit/js/fgpsnWoScripts.js', array('jquery'),null,true   );
  
    wp_enqueue_script( 'fgpsnWoScripts' );
   
  gravity_form( 6, $display_title = false, $display_description = false, $echo = false );
  	//return $disp_form;
	//echo $disp_data;
}
add_shortcode( 'fgpsn_wo_request_form_quick', 'fgpsnWoReqFormQuick' );

function updateWoDate_fn(){
	//print json?
	//return to ajax call
	//var_dump($_POST);
	//echo "Output: " . $_REQUEST['droppedInfo'];
	$query_str = parse_url($_POST['droppedInfo'], PHP_URL_QUERY);
parse_str($_POST['droppedInfo'], $query_params);
//print_r($query_params);
	//echo "Output: " . $query_params;
	
		if ( update_post_meta($query_params['wo_id'], 'fgpsn_wo_start_date', $query_params['new_start']) ) {
echo "Yay!";
		} else {echo   "No! " . $query_params['new_start'];}
		if ( update_post_meta($query_params['wo_id'], 'fgpsn_wo_end_date',  $query_params['new_end'])  ) {
echo "Yay!";
		} else {echo  $query_params['new_end'];}
	
		
	
	//update_post_meta($_POST['wo_id'], 'fgpsn_wo_start_date', true);
	//update_post_meta($_POST['wo_id'], 'fgpsn_wo_end_date', true);
	die;
}
add_action('wp_ajax_updateWoDate', 'updateWoDate_fn');
add_action('wp_ajax_nopriv_updateWoDate', 'updateWoDate_fn');


function getWoSidebar($wo_id) {

	global $fg_wo_sidebar;

	$fg_wo_sidebar = "<H3>Attachments</H3>";
	$wo_attachments = get_post_meta($wo_id, 'fgpsn_wo_attachments', true);
	
	$attachment_array = json_decode($wo_attachments);
	foreach($attachment_array as $k=>$v) {echo "<A HREF='" . $v . "'>Estimates</A><BR>";}
	$fg_wo_sidebar .= "<H3>Attachments</H3>";

}

?>
