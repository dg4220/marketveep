<?PHP

//create property setup tabs for admin
add_action('admin_menu', 'frontGate_property_settings_menu');

function frontGate_property_settings_menu() {
	add_options_page('Property Setup', 'Property Setup', 'manage_options', 'property-data-settings', 'property_settings_page');
}

/*********************************************************************************/
//property setting in the
function property_settings_page() {
	if ( !current_user_can( 'manage_options') || current_user_can( 'manage_options') )  {
		//wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}

?>
<div class="wrap">

<?php screen_icon(); ?>
<h2>Settings</h2>
<form method="post" action="options.php">
	<?php
	 // This prints out all hidden setting fields
		settings_fields('property_data_options');
		do_settings_sections('property-data-settings');
		submit_button();

	?>
</form>
</div>

<?PHP

}//end property_settings_page function

add_action('admin_init', 'property_admin_init');

function property_admin_init(){
	register_setting( 'property_data_options', 'property_options', 'property_options_validate' );
	add_settings_section('property_main', 'Property Data', 'property_settings_section_text', 'property-data-settings');
	add_settings_field('property_title', 'Property Text Input', 'property_setting_string', 'property-data-settings', 'property_main');
}

function property_settings_section_text() {
	//echo '<p>Set up your persistent Property Data here</p>';
	//dummy - is this necessary?
}

//create taxonomy to handle property specifications

add_action( 'init', 'create_property_specification_types' );
function create_property_specification_types() {
 $labels = array(
    'name' => _x( 'Property Specifications', 'taxonomy general name' ),
    'singular_name' => _x( 'Property Specification', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Property Specifications' ),
    'all_items' => __( 'All Property Specifications' ),
    'parent_item' => __( 'Parent Property Specification' ),
    'parent_item_colon' => __( 'Parent Property Specification:' ),
    'edit_item' => __( 'Edit Specification' ),
    'update_item' => __( 'Update Specification' ),
    'add_new_item' => __( 'Add New Property Specification' ),
    'new_item_name' => __( 'New Vendor Property Specification' ),
  );

  register_taxonomy('property_specifications','page',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

function property_setting_string($fgpsn_prop_id) {

	$states_util = array('AL'=>"Alabama",
                'AK'=>"Alaska",
                'AZ'=>"Arizona",
                'AR'=>"Arkansas",
                'CA'=>"California",
                'CO'=>"Colorado",
                'CT'=>"Connecticut",
                'DE'=>"Delaware",
                'DC'=>"District Of Columbia",
                'FL'=>"Florida",
                'GA'=>"Georgia",
                'HI'=>"Hawaii",
                'ID'=>"Idaho",
                'IL'=>"Illinois",
                'IN'=>"Indiana",
                'IA'=>"Iowa",
                'KS'=>"Kansas",
                'KY'=>"Kentucky",
                'LA'=>"Louisiana",
                'ME'=>"Maine",
                'MD'=>"Maryland",
                'MA'=>"Massachusetts",
                'MI'=>"Michigan",
                'MN'=>"Minnesota",
                'MS'=>"Mississippi",
                'MO'=>"Missouri",
                'MT'=>"Montana",
                'NE'=>"Nebraska",
                'NV'=>"Nevada",
                'NH'=>"New Hampshire",
                'NJ'=>"New Jersey",
                'NM'=>"New Mexico",
                'NY'=>"New York",
                'NC'=>"North Carolina",
                'ND'=>"North Dakota",
                'OH'=>"Ohio",
                'OK'=>"Oklahoma",
                'OR'=>"Oregon",
                'PA'=>"Pennsylvania",
                'RI'=>"Rhode Island",
                'SC'=>"South Carolina",
                'SD'=>"South Dakota",
                'TN'=>"Tennessee",
                'TX'=>"Texas",
                'UT'=>"Utah",
                'VT'=>"Vermont",
                'VA'=>"Virginia",
                'WA'=>"Washington",
                'WV'=>"West Virginia",
                'WI'=>"Wisconsin",
                'WY'=>"Wyoming");
		/*********************************************************************/
		//start tlc

	/* Not anymorrrre
	$property_addr1 = get_option('property_addr1');
	$property_addr2 = get_option('property_addr2');
	$property_city = get_option('property_city');
	$property_state = get_option('property_state');
	$property_zip = get_option('property_zip');
	$property_type = get_option('property_type');
	$property_title = get_option('property_title');
	$cur_property_manager = get_option('property_manager');
	$number_of_units = get_option('number_of_units');


	$property_management_co = get_option('property_management_co');
	$property_management_co_addr1 = get_option('property_management_co_addr1');
	$property_management_co_addr2 = get_option('property_management_co_addr2');
	$property_management_co_city = get_option('property_management_co_city');
	$property_management_co_state = get_option('property_management_co_state');
	$property_management_co_zip = get_option('property_management_co_zip');
	$property_manager_fname = get_option('property_manager_fname');
	$property_manager_lname = get_option('property_manager_lname');
	$property_manager_phone = get_option('property_manager_phone');
	$property_manager_email = get_option('property_manager_email');
	*/

	//$cur_prop = get_post($prop_data_string);
	//foreach( $cur_prop as $fgpsn_prop) {
		
	$fgpsn_property_address_1 = get_post_meta($fgpsn_prop_id, 'fgpsn_property_address_1', 'address_1', true);
	$fgpsn_property_address_2 = get_post_meta($fgpsn_prop_id, 'fgpsn_property_address_2', true);
	$fgpsn_property_city = get_post_meta($fgpsn_prop_id, 'fgpsn_property_city', true);
	$fgpsn_property_state = get_post_meta($fgpsn_prop_id, 'fgpsn_property_state', true);
	$fgpsn_property_zip = get_post_meta($fgpsn_prop_id, 'fgpsn_property__zip', true);
	$fgpsn_property_type = get_post_meta($fgpsn_prop_id, 'fgpsn_property_type', true);
	
	//$fgpsn_property_title = get_the_title($fgpsn_prop_id);
	//using the network compatable version

	$blog_details = get_blog_details( get_current_blog_id() );
	$fgpsn_property_title =  $blog_details->blogname;
	$current_site = get_current_site();
	//$fgpsn_property_title =  $current_site->site_name;

	$fgpsn_property_anager = get_post_meta($fgpsn_prop_id, 'fgpsn_property_manager', true);
	$number_of_units = get_post_meta($fgpsn_prop_id, 'fgpsn_property_number_of_units', true);


	$fgpsn_property_management_co = get_post_meta($fgpsn_prop_id, 'fgpsn_property_management_co', true);
	$fgpsn_property_management_co_addr1 = get_post_meta($fgpsn_prop_id, 'fgpsn_property_management_co_addr1', true);
		
	$fgpsn_property_management_co_addr2 = get_post_meta($fgpsn_prop_id, 'fgpsn_property_management_co_addr2', true);
		
	$fgpsn_property_management_co_city = get_post_meta($fgpsn_prop_id, 'fgpsn_property_management_co_city', true);
		
	$fgpsn_property_management_co_state = get_post_meta($fgpsn_prop_id, 'fgpsn_property_management_co_state', true);
		
	$fgpsn_property_management_co_zip = get_post_meta($fgpsn_prop_id, 'fgpsn_property_management_co_zip', true);
		
	$fgpsn_property_manager_fname = get_post_meta($fgpsn_prop_id, 'fgpsn_property_manager_fname', true);
	$fgpsn_property_manager_lname = get_post_meta($fgpsn_prop_id, 'fgpsn_property_manager_lname', true);
	$fgpsn_property_manager_phone = get_post_meta($fgpsn_prop_id, 'fgpsn_property_manager_phone', true);
	$fgpsn_property_manager_email = get_post_meta($fgpsn_prop_id, 'fgpsn_property_manager_email', true);
		
	//}

	$prop_data_string = "<ul class='tabs'><li>
             <input type='radio' checked name='tabs' id='tab1'>
             <label for='tab1'>Property Data</label>
             <div id='tab-content1' class='tab-content animated fadeIn'>

	<TABLE class='property-options' BGCOLOR=#ffffff>

	<!-- <TR><TH colspan=2><INPUT TYPE='button' VALUE = 'Export to Excel' ></TD></TR> -->

		<TR><TH>Property Title:</TH>

			<TD><input id='fgpsn_property_title' name='property_data_options[fgpsn_property_title]' size='40' type='text' value='{$fgpsn_property_title}' /></TD>

		</TR>
		<TR>
			<TH>Address 1</TH>
			<TD><input id='fgpsn_property_address_1' name='property_data_options[fgpsn_property_address_1]' size='40' type='text' value='{$fgpsn_property_address_1}' /></TD>
		</TR>
		<TR>
		<TH>Address 2*</TH>
		<TD><input id='fgpsn_property_address_2' name='property_data_options[fgpsn_property_address_2]' size='40' type='text' value='{$fgpsn_property_address_2}' /></TD></TR>

		<TR>
			<TH>City*</TH>
			<TD ><input id='fgpsn_property_city' name='property_data_options[fgpsn_property_city]' size='40' type='text' value='{$fgpsn_property_city}' /></TD>
		</TR>
			<TH>State/Province*</TH><TD><SELECT id='fgpsn_property_state' name='property_data_options[fgpsn_property_state]' />";

				$this_count = count($states_util);

				$prop_data_string .= "<OPTION value=''> - Here -" . $this_count . " </OPTION>\n";

				foreach ($states_util as $key => $value) {

						$prop_data_string .= "<OPTION value='" . $key . "'";
						if ($property_state == $key) {
							$prop_data_string .= " selected";
						}

						$prop_data_string .= ">" . $value . "</OPTION>\n";

				}
			$prop_data_string .= "</SELECT></TD></TR>

		<TR>

			<Th>Zip Code:</TH>
			<TD ><input id='fgpsn_property_zip' name='property_data_options[fgpsn_property_zip]' size='5' type='text' value='{$fgpsn_property_zip}' /></TD>

		</TR>

		<TR>
			<TH>Property Type:</TH>
			<TD><SELECT id='fgpsn_property_type' name='property_data_options[fgpsn_property_type]' />

			<OPTION value=''> - Select - </OPTION>\n
			<OPTION value='Condominium'";

			if ($property_type == 'Condominium') {
				$prop_data_string .= " selected";
			}

			$prop_data_string .= "> Condominium </OPTION>\n
			<OPTION value='Rental Property'";

			if ($property_type == 'Rental Property') {
				$prop_data_string .= " selected";
			}


			$prop_data_string .= "> Rental Property </OPTION>\n
			<OPTION value='Commercial'";

			if ($property_type == 'Commercial') {
				$prop_data_string .= " selected";
			}


			$prop_data_string .= "> Commercial </OPTION>\n
			<OPTION value='HOA'";

			if ($property_type == 'HOA') {
				$prop_data_string .= " selected";
			}


			$prop_data_string .= "> HOA </OPTION>\n
			<OPTION value='Retirement Community'";

			if ($property_type == 'Retirement Community') {
				$prop_data_string .= " selected";
			}


			$prop_data_string .= "> Retirement Community </OPTION>\n

		</SELECT></TD>

	</TR>
	<TR>

		<TH>Property Manager: </TH>
		<TD ><SELECT id='fgpsn_property_manager' name='property_data_options[fgpsn_property_manager]' />
	<OPTION VALUE=''> - Select - </OPTION>";

		//the manager becomes a user with this role when they get assigned the property
		$prop_managers = new WP_User_Query( array( 'role' => 'property_manager' ) );
		if ( ! empty( $prop_managers->results ) ) {
			foreach ( $prop_managers->results as $prop_manager ) {
			$prop_data_string .= "<OPTION VALUE='" . $prop_manager->ID . "'";

			if ($cur_property_manager == $prop_manager->ID) {

				$manager_email = $prop_manager->user_email;
				$manager_phone = $prop_manager->client_phone;

				$prop_data_string .= " selected";

			}


			$prop_data_string .= ">" .  $prop_manager->display_name . " Title: " . $check_role . "</OPTION>";
			}

		$prop_data_string .= "</SELECT>

		<BR>
				Cell: " .  $manager_phone . "<BR>
			   Phone: (617) 316-3313<BR>
			   Fax: (617) 316-3363<BR>
		   Email: " .  $manager_email;

		} else {
		   			$prop_data_string .= "<OPTION VALUE=''>No users found.</Option>";
		}

		$prop_data_string .= "<TR>

			<Th>Manager Cell:</TH>
			<TD ><input id='manager_cell' name='property_data_options[manager_cell]' size='5' type='text' value='{$manager_cell}' /></TD>

		</TR>

		<TR>
			<Th>Manager Office:</TH>
			<TD ><input id='manager_office_ph' name='property_data_options[manager_office_ph]' size='5' type='text' value='{$manager_office_ph}' /></TD>

		</TR>

		<TR>
			<Th>Manager Fax:</TH>
			<TD ><input id='manager_office_fax' name='property_data_options[manager_office_fax]' size='5' type='text' value='{$manager_office_fax}' /></TD>

		</TR>";


		  $prop_data_string .= "</TD></TR>
		  <TR><TH COLSPAN=2>Management Data</TH></TR>
		  <TR>

			<th>Management Company:</th>
			<td><input id='fgpsn_property_management_co' name='property_data_options[fgpsn_property_management_co]' size='40' type='text' value='{$fgpsn_property_management_co}' /></td>
			</tr>
			<tr>
			<th>Address line 1:</th>
			<td><input id='fgpsn_property_management_co_addr1' name='property_data_options[fgpsn_property_management_co_addr1]' size='40' type='text' value='{$fgpsn_property_management_co_addr1}' /></td>
			</tr>
			<tr>
			<th>Address line 2:</th>
			<td><input id='fgpsn_property_management_co_addr2' name='property_data_options[fgpsn_property_management_co_addr2]' size='40' type='text' value='{$fgpsn_property_management_co_addr2}' /></td>
			</tr>
			<tr>
			<th>City:</th>
			<td><input id='fgpsn_property_management_co_city' name='property_data_options[fgpsn_property_management_co_city]' size='40' type='text' value='{$fgpsn_property_management_co_city}' /></td>
			</tr>
			<tr>
			<th>State:</th>
			<td><input id='property_management_co_state' name='property_data_options[property_management_co_state]' size='40' type='text' value='{$fgpsn_property_management_co_state}' /></td>
			</tr>
			<tr>
			<th>Zip Code:</th>
			<td><input id='fgpsn_property_management_co_zip' name='property_data_options[fgpsn_property_management_co_zip]' size='40' type='text' value='{$fgpsn_property_management_co_zip}' /></tr>
			<tr>
			<th>Property Manager:</th>

			<td><input id='fgpsn_property_manager_fname' name='property_data_options[fgpsn_property_manager_fname]' size='40' type='text' value='{$fgpsn_property_manager_fname}' />
			
			<input id='fgpsn_property_manager_lname' name='property_data_options[fgpsn_property_manager_lname]' size='40' type='text' value='{$fgpsn_property_manager_lname}' /></td></tr>
			<tr>
			<th>Manager Phone:</th>

			<td><input id='fgpsn_property_manager_phone' name='property_data_options[fgpsn_property_manager_phone]' size='40' type='text' value='{$fgpsn_property_manager_phone}' /></th></tr>
			<tr>

			<th>Manager Email:</th>

			<td><input id='fgpsn_property_manager_email' name='property_data_options[fgpsn_property_manager_email]' size='40' type='text' value='{$fgpsn_property_manager_email}' /></td>
			</TR>

	<TR>
		<TH>Assigned Staff: </TH>
		<TD ><SELECT id='fgpsn_propety_desk_staff' name='property_data_options[fgpsn_propety_desk_staff][]' multiple=multiple />
				<OPTION VALUE=''> - Select - </OPTION>";

	$args = array(
       'post_type' => 'contact_data',
       'tax_query' => array(
                   array(
                       'taxonomy' => 'contact_data_types',
                       'field' => 'slug',
                       'terms' => 'desk-staff'
                    )
                )
        );
        $posts = get_posts($args);


		if(is_array($posts)) :  foreach($posts as $post) :

			$prop_data_string .= "<OPTION VALUE='" . $post->ID . "'";


			if ($cur_property_manager == $post->ID) {

				$emp_phone = get_post_meta($cur_property_manager, 'emp_phone', true);
				$emp_email = get_post_meta($cur_property_manager, 'emp_email', true);
				$prop_data_string .= " selected";

			}


			$prop_data_string .= ">" .  $post->post_title . "</OPTION>";

		endforeach; endif;

		$prop_data_string .= "</SELECT></TD></TR>

		<TR><TD>Dennis Gannon</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email: N/A
							<BR><A HREF=''>Edit</A></TD></TR>

		<TR ><TD>Tom McMullin</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email:
							<BR><A HREF=''>Edit</A></TD></TR>

		<TR ><TD>cliff snider</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email:
							<BR><A HREF=''>Edit</A></TD></TR>

		<TR ><TD>Stephen Furqueron</TD><TD>Desk Staff -
							Phone: (617) 437-0766; Email:
							<BR><A HREF=''>Edit</A></TD></TR>


			<TR><TH>Superintendent:</TH>

					<TD >Adam Barbour (<A HREF=''>Edit</A>)<BR>Phone: (617) 592-2349<BR></TD></TR>
					<TR><TH COLSPAN=2>Superintendent Notes:</TH></TR>
					<TR><TD COLSPAN=2>
				Please call Adam Barbour for any emergency calls. Cell phone (617)592-2349.<BR>(<A HREF=''>Edit</A>)</TD>

				</TR>

				<TR ><TH COLSPAN=2>Additional Notes:</TH></TR>

				<TR ><TD COLSPAN=2  >
				Property has one elevator in lobby.  Certificate of Inspection expires February 1, 2014 and car identification is 1-P-2605.<BR>(<A HREF=''>Edit</A>)</TD></TR>

				<TR ><TH COLSPAN=2>Trustees</TH></TR>";

	$args = array(
		 'posts_per_page' => -1,
		 'orderby' => 'rand',
		 'post_type' => 'contact_data',
		 'contact_data_types' => 'trustee',
		 'post_status' => 'publish'
	);
	$show_trustees = get_posts( $args );

	if(is_array($show_trustees)) :  foreach($show_trustees as $show_trustee) :

	$prop_data_string .= "<TR><TD>" . $show_trustee->post_title . "</TD><TD>Contact Information:<BR></TD></TR>";

	endforeach; endif;


	$prop_data_string .= "<TR>

		<TH>Number of Units</TH>
		<TD><input id='fgpsn_propety_number_of_units' name='property_data_options[fgpsn_propety_number_of_units]' size='3' type='text' value='{$fgpsn_propety_number_of_units}' /></TD>

		</TR>

	</TABLE></div>
           </li>

           <li>
             <input type='radio' name='tabs' id='tab2'>
             <label for='tab2'>Property Vendors</label>
             <div id='tab-content2' class='tab-content animated fadeIn'>";

	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);


	$prop_data_string .= "<TABLE><TR><TH COLSPAN=2>Add New Vendor Services: <INPUT TYPE=text NAME=property_data_options[fg_property_vendor_service]></TH></TR>";


	$terms = get_terms("property_vendor_services", $args);
	$count = count($terms);
	if ( $count > 0 ){

		foreach($terms as $term) {
			$prop_data_string .= "<TR><TH>" .  $term->name . ", " . $term->slug . "</TH>";

			$cur_term = $term->slug;

			$all_vendors_args = array(
						'post_type'=>'property_vendor',
						'numberposts'=>-1,
						'orderby'=>'post_title',
						'order'=>'ASC',
						'taxonomy'=>'property_vendor_services',
						'term'=>$term->name
					);

					$vendors = get_posts($all_vendors_args);

		$check_cur = get_option('property_' . $cur_term);

		$prop_data_string .= "<TD><select name='property_data_options['" . $cur_term . "']' id='property_data_options[$cur_term]'>
		<option value=0> - Select - </option>";
		foreach($vendors as $vendor) :

		$prop_data_string .= "<option value=" .  $vendor->ID;

		$prop_data_string .= " selected";

		$prop_data_string .= ">" .  $vendor->post_title . "Slug: " . $check_cur . "</option>";

		endforeach;
		$prop_data_string .= "</select></TD></TR>";

		}


	 }
         $prop_data_string .= "</TABLE></DIV></LI><li>
             <input type='radio' name='tabs' id='tab3'>
             <label for='tab3'>Property Specifications</label>
             <div id='tab-content3' class='tab-content animated fadeIn'>";
/*
$new_spec_id = wp_insert_term(
			  'Property Specifications', // the term
			  'property_specifications', // the taxonomy
			  array(
				'description'=> '',

				'parent'=> 0
			  )
			);
echo "<H1>" . $new_spec_id . "</H1>";
*/
	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 82);


	$terms = get_terms("property_specifications", $args);
	 $count = count($terms);
	 $prop_data_string .= "<TABLE><TR><TH COLSPAN=2>Add New Specification: <INPUT TYPE=text NAME=property_data_options[fg_property_spec_type]></TH></TR>";
	 if ( $count > 0 ){

		foreach($terms as $term) {

			$specification = get_post_meta(186, 'property_' . $term->slug, TRUE);

			$spec_content = get_option('property_' . $term->slug);

			$prop_data_string .= "<TR><TH>" .  $spec_content . "</TH><TD><input id='property_" . $term->slug . "' name='property_data_options[property_" . $term->slug . "]' size='3' type='text' value='" . $specification . "' /></TD></TR>";

		}

	}
	$prop_data_string .= "</TABLE>";
	$prop_data_string .= "</div>
           </li>";


$prop_data_string .= "</ul>";
echo $prop_data_string;
//return $prop_data_string;


}

function property_options_validate($input) {
	global $wpdb;
	$stopper = "<H1>Line 1309</H1>";
	//return $stopper;
		//adds a new specification type
		if ( !empty( $_POST['property_data_options']['fg_property_vendor_service'] ) ) {

			if ( wp_insert_term(
			  $_POST['property_data_options']['fg_property_vendor_service'], // the term
			  'property_vendor_services', // the taxonomy
			  array(
				'description'=> '',

				'parent'=> 42
			  )
			) ) {

				echo "<H1>GOOD</H1>";


			} else {

			echo "<H1>NOT GOOD</H1>";
			}
		}


		if ( !empty( $_POST['property_data_options']['fg_property_spec_type'] ) ) {


			echo "<H1>Not Empty</H1>";
			update_option( 'property_' .  sanitize_title( $_POST['property_data_options']['fg_property_spec_type'] ), $_POST['property_data_options']['fg_property_spec_type'] );

			wp_insert_term(
			  $_POST['property_data_options']['fg_property_spec_type'], // the term
			  'property_specifications', // the taxonomy
			  array(
				'description'=> '',

				'parent'=> 82
			  )
			);

			echo "<H1>GOOD</H1>";

		}
	/*
	need to have an option for each vendor service type

	foreach vendor service { update_option( 'vendor-service-slug') }


	*/


	$args = array(
		'hide_empty'  		=> 0,
		'show_count'         => 1,
		'hierarchical'  => true,
	    'parent'      => 42);

	$terms = get_terms("property_vendor_services", $args);
	$count = count($terms);
	if ( $count > 0 ){
		foreach($terms as $term) {
			$all_vendors_args = array(
						'post_type'=>'property_vendor',
						'numberposts'=>-1,
						'orderby'=>'post_title',
						'order'=>'ASC',
						'taxonomy'=>'property_vendor_services',
						'term'=>$term->name
					);

			$vendors = get_posts($all_vendors_args);


			$cur_option = $_POST['property_data_options'][$term->slug];
			echo "<TR><TH>" .  $cur_option . "</TH>";
			update_option('property_', $term->slug, $cur_option);
			echo "<H1>Update Terms stuff " . $term->slug . "</H1>";


	 	}

	}

	//property specifications are saved as post meta for page 186
	//the frontend form page for managing property data
	global $wpdb;
	$args = array(
			'hide_empty'  		=> 0,
			'show_count'         => 1,
			'hierarchical'  => true,
		    'parent'      => 82);

		$terms = get_terms("property_specifications", $args);
		$count = count($terms);
		if ( $count > 0 ){
			foreach($terms as $term) {

				$return_result = update_post_meta( 186, 'property_' . $term->slug, $_POST['property_data_options']['property_' . $term->slug]);

		 	}

	}


/**********************************************************************************/
	$property_title = $_POST['property_data_options']['property_title'];
	update_option('property_title', $property_title);

	$property_type = $_POST['property_data_options']['property_type'];
	update_option('property_type', $property_type);

	$property_manager = $_POST['property_data_options']['property_manager'];
	//echo "<H1>Line 1293  - " . $property_manager . "</H1>";
	update_option('property_manager', $property_manager);

	$number_of_units = $_POST['property_data_options']['number_of_units'];
	update_option('number_of_units', $number_of_units);

	$property_state = $_POST['property_data_options']['property_state'];
	update_option('property_state', $property_state);

	$property_addr1 = $_POST['property_data_options']['property_addr1'];
	update_option('property_addr1', $property_addr1);

	$property_addr2 = $_POST['property_data_options']['property_addr2'];
	update_option('property_addr2', $property_addr2);

	$property_city = $_POST['property_data_options']['property_city'];
	update_option('property_city', $property_city);

	$property_zip = $_POST['property_data_options']['property_zip'];
	update_option('property_zip', $property_zip);


	update_option('property_management_co', $_POST['property_data_options']['property_management_co']);

	update_option('property_management_co_addr1', $_POST['property_data_options']['property_management_co_addr1']);

	//echo "<H1>Line 1293  - " . $property_manager . "</H1>";
	update_option('property_management_co_addr2', $_POST['property_data_options']['property_management_co_addr2']);

	update_option('property_management_co_city', $_POST['property_data_options']['property_management_co_city']);

	$property_management_co_state = $_POST['property_data_options']['property_management_co_state'];
	update_option('property_management_co_state', $property_management_co_state);

	$property_management_co_zip = $_POST['property_data_options']['property_management_co_zip'];
	update_option('property_management_co_zip', $property_management_co_zip);


	//make sure manager is a 'user'
	$user_id = username_exists( $_POST['property_data_options']['property_manager_fname'] );
	if ( !$user_id && email_exists($_POST['property_data_options']['property_manager_email']) == false ) {

		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $_POST['property_data_options']['property_manager_fname'], $random_password, $_POST['property_data_options']['property_manager_email'] );

		update_user_meta( $user_id, 'contact_data_id', $contact_data_id );
		update_user_meta( $user_id, 'contact_first_name', $contact_first_name );
		update_user_meta( $user_id, 'contact_last_name', $contact_last_name );
		update_user_meta( $user_id, 'client_phone', $client_phone );
		update_user_meta( $user_id, 'client_email', $client_email );
		update_user_meta( $user_id, 'client_cell', $client_cell );
		update_user_meta( $client_addr1, 'client_addr1', $client_addr1 );
		update_user_meta( $client_addr2, 'client_addr2', $client_addr2 );
		update_user_meta( $client_city, 'client_city', $client_city );
		update_user_meta( $client_zip, 'client_zip', $client_zip );


	}

	update_option('property_manager_fname', $_POST['property_data_options']['property_manager_fname']);

	update_option('property_manager_lname', $_POST['property_data_options']['property_manager_lname']);

	update_option('property_manager_phone', $_POST['property_data_options']['property_manager_phone']);

	update_option('property_manager_email', $_POST['property_data_options']['property_manager_email']);
/*
		$args = array(
			'hide_empty'  		=> 0,
			'show_count'         => 1,
			'hierarchical'  => true,
		    'parent'      => 0);


		$terms = get_terms("property_vendor_services", $args);
		 $count = count($terms);
		 if ( $count > 0 ){
			foreach($terms as $term) {
				$property_ . $term->slug = $_POST['property_data_options']['property_' . $term->slug];
				update_option('property_' . $term->slug, $property_ . $term->slug);
			}

	 }
*/


	$property_title = get_option('property_title');
	$property_title = trim($property_title);
	if(!preg_match('/^[a-z0-9]{32}$/i', $property_title)) {
	$property_title = '';
	}
	//return $property_title;

}

?>
