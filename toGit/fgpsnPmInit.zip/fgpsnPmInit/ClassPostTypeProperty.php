<?PHP
/******************************************************
 * DG Creating Property Logs post type and meta boxes
*******************************************************/
class FGPSN_Property {

	/**
	 * Hook into the appropriate actions when the class is constructed.
	 */
	public function __construct() {

		
	}

	/*add public unility methods*/

	/*getting a property menu from a passed value or 'all' properties */
	public function fgpsn_property_menu($post) {
	  
	  //should also be able to take a passed value of property IDs
    $fgpsn_property_id = get_post_meta(get_the_id(), 'fgpsn_log_selected_properties', true);
		$current_user = wp_get_current_user();
		if( !empty(get_user_meta( $current_user->ID, 'fgpsn_assigned_properties') ) ) {
			$args = array(
		    'posts_per_page'  => -1,
		    'post_type'  => 'properties',
		    'post_status' => 'publish',
		    'include'	=> '1',//get array from user meta
		              
		  );

		} else {
			$args = array(
		    'posts_per_page'  => -1,
		    'post_type'  => 'properties',
		    'post_status' => 'publish',
		              
		  );
		}
	   
		echo  '<SELECT multiple ID="property_selection_menu"  name="fgpsn_log_selected_properties[]" size=5 >
	          <option value="0"> -- Select Properties -- </option>';
	      
	  $getem = get_posts($args);
		foreach ( $getem as $property ) {
			
      setup_postdata($property );
			$address_1 = get_post_meta($property->ID, 'fgpsn_property_address_1', true);
      $address_2 = get_post_meta($property->ID, 'fgpsn_property_address_2', true);
      $city = get_post_meta($property->ID, 'fgpsn_property_city', true);
	    
	      if ($address_1) {
        echo '<OPTION value="' . $property->ID . '"';

  			if ( in_array($property->ID, $fgpsn_property_id) ) {
  				echo " selected";
  				$property_link = "<BR><A HREF=?" . $property->ID  . ">" . $address_1 . " " . $city . "</A><BR>";
  			}

  			echo '>' .  $address_1  . ' ' . $address_2 . ', ' . $city . ', ' . $property->ID . ', ' . 
  			$fgpsn_property_id . '</OPTION>';
  			
      } else {
        echo '<OPTION value="' . $property->ID . '"';
        echo '>' . $property->ID . ', ' . $property->ID . '</OPTION>';
      }
	         
     }
	  echo  '</SELECT>';
	  wp_reset_postdata();	  
	 
	}
	

}//end class

new FGPSN_Property;
?>
