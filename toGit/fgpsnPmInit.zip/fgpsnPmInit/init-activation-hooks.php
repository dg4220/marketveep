<?php

register_activation_hook( plugin_dir_path( __FILE__ ) . 'functions.php', 'loadFgpsnDefaultContent' );

function loadFgpsnDefaultContent() {
	global $wpdb;

	//registerFgpsnDefaultMenus();
	$var_pub_menu_slug = sanitize_title('Public Menu');
	$var_tenant_menu_slug = sanitize_title('Tenant Menu');
	$var_owner_menu_slug = sanitize_title('Owner Menu');
	$var_trustee_menu_slug = sanitize_title('Trustee Menu');
	$var_maint_staff_menu_slug = sanitize_title('Maintenance Staff');
	$var_maint_admin_menu_slug = sanitize_title('Maintenance Admin. Menu');
	$var_pm_menu_slug = sanitize_title('Property Manager Menu');
		
	$menu_exists = wp_get_nav_menu_object( 'Public Menu' );
	if ( $menu_exists === false ) {
		$var_pub_menu_id = wp_create_nav_menu( 'Public Menu' );
	} else {
		$var_pub_menu_id = $menu_exists->term_id;
	}

	$menu_exists = wp_get_nav_menu_object( 'Tenant Menu' );
	if ( $menu_exists === false ) {
		$var_tenant_menu_id = wp_create_nav_menu( 'Tenant Menu');
	} else {
		$var_tenant_menu_id = $menu_exists->term_id;
	}

	$menu_exists = wp_get_nav_menu_object( 'Owner Menu' );
	if ( $menu_exists === false ) {
		$var_owner_menu_id = wp_create_nav_menu( 'Owner Menu');
	} else {
		$var_owner_menu_id = $menu_exists->term_id;
	}

	$menu_exists = wp_get_nav_menu_object( 'Trustee Menu' );
	if ( $menu_exists === false ) {
		$var_trustee_menu_id = wp_create_nav_menu( 'Trustee Menu');
	} else {
		$var_trustee_menu_id = $menu_exists->term_id;
	}

	$menu_exists = wp_get_nav_menu_object( 'Maintenance Staff Menu' );
	if ( $menu_exists === false ) {
		$var_maint_staff_menu_id = wp_create_nav_menu( 'Maintenance Staff Menu');
	} else {
		$var_maint_staff_menu_id = $menu_exists->term_id;
	}

	$menu_exists = wp_get_nav_menu_object( 'Maintenance Admin. Menu' );
	if ( $menu_exists === false ) {
		$var_maint_admin_menu_id = wp_create_nav_menu( 'Maintenance Admin. Menu');
	} else {
		$var_maint_admin_menu_id = $menu_exists->term_id;
	}

	$menu_exists = wp_get_nav_menu_object( 'Property Manager Menu' );
	if ( $menu_exists === false ) {
		$var_pm_menu_id = wp_create_nav_menu( 'Property Manager Menu');
	} else {
		$var_pm_menu_id = $menu_exists->term_id;
	}

	register_nav_menus( array(
		$var_pub_menu_slug =>'Public Menu',
		$var_tenant_menu_slug =>'Tenant Menu',
		$var_owner_menu_slug =>'Owner Menu',
		$var_trustee_menu_slug =>'Trustee Menu',
		$var_maint_staff_menu_slug =>'Maintenance Staff Menu',
		$var_maint_admin_menu_slug =>'Maintenance Admin. Menu',
		$var_pm_menu_slug =>'Property Manager Menu') ); 
		

	$fgpsn_default_pages = array(
		0 =>'Browse Properties',
		1 =>'Browse Units',
		2 =>'Sample About Page',
		3 =>'Contact Page',
		4 =>'Services Page',
		5 =>'Tenant Maintenance Request Form',
		6 =>'Tenant Maintenance Request Confirmation',
		7 =>'Maintenance Request History',
		8 =>'Property Documents',
		9 =>'Property Communications',
		10 =>'Communications history',//line 432
		11 =>'Tenant Contact Form',
		12 =>'Add Property',
		13 =>'Add Unit',
		14 =>'Add Contact',
		15 =>'Add Employee',
		16 =>'Add Vendor',
		17 =>'Add Documents',
		18 =>'Maintenance Quick Request',
		19 =>'Maintenance Request Details and Approvals',
		20 =>'Edit Profile and Preferences',
		21 =>'Employee Directory',
		22 =>'Property Directory',
		23 =>'Unit Directory',
		24 =>'Contact Directory',
		25 =>'Vendor Directory',
		26 =>'Rental Application',
		27 =>'Available Units');

	for( $j = 0; $j < count($fgpsn_default_pages); $j++ ) {

		switch( $fgpsn_default_pages[$j] ) {

			case 'Browse Properties':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Property Browse Short Code',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 1,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Browse Units':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => '[fgpsn_archive_unit_data]',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 2,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Sample About Page':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Contact Page':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Services Page':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Tenant Maintenance Request Form':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Tenant Maintenance Request Confirmation':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Maintenance Request History':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Property Documents':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Property Communications':
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Communications history'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

/*
* FIIIIVVEE GOOOOLDEEEEN RIIIIIIIIIIIGS
*
*/		
			case 'Tenant Contact Form'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Add Property'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Add Unit'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Add Contact'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Add Employee'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Add Vendor'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Add Documents'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Maintenance Quick Request'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Maintenance Request Details and Approvals'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Edit Profile and Preferences'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Employee Directory'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Property Directory'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Unit Directory'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Contact Directory'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;


			case 'Vendor Directory'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Rental Application'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;

			case 'Available Units'://item 10
			//create the page and set th menu array
				$default_fgpsn_page = array(
								  'post_title'    => $fgpsn_default_pages[$j],
								  'post_status'   => 'publish',
								  'post_type'   => 'page',
								  'post_content'   => 'Well, ? What about it?',
								  'post_author'   => 1
								);

				$default_fgpsn_page_id = wp_insert_post( $default_fgpsn_page );
				
				$menu_item_defaults = array(
			        //'menu-item-db-id' => $menu_item_db_id,
			        //'menu-item-object-id' => 0,
			        //'menu-item-object' => '',
			        'menu-item-parent-id' => 0,
			        'menu-item-position' => 0,
			        'menu-item-title' => $fgpsn_default_pages[$j],
			        'menu-item-url' => get_page_link( $default_fgpsn_page_id ),
			        'menu-item-description' => 'public properties listing',
			        'menu-item-attr-title' => '',
			        'menu-item-target' => '',
			        'menu-item-classes' => '',
			        'menu-item-xfn' => '',
			        'menu-item-status' => 'publish',
			    );
		    
				wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);	
				
				break;





















			default:
				break;

			
		}

	}

	$fgpsn_page = array(
				  'post_title'    => 'Our properties',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_content'   => 'Property Browse Short Code',
				  'post_author'   => 1
				);

	//$new_page_id = wp_insert_post( $fgpsn_page );
	//$menu_url = get_page_link($new_page_id);
	/*
	$menu_item_defaults = array(
	        'menu-item-db-id' => $menu_item_db_id,
	        'menu-item-object-id' => 0,
	        'menu-item-object' => '',
	        'menu-item-parent-id' => 0,
	        'menu-item-position' => 0,
	        'menu-item-title' => 'Browse Properties',
	        'menu-item-url' => $menu_url,
	        'menu-item-description' => 'public properties listing',
	        'menu-item-attr-title' => '',
	        'menu-item-target' => '',
	        'menu-item-classes' => '',
	        'menu-item-xfn' => '',
	        'menu-item-status' => 'publish',
	    );
	    
	wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);
	
	$my_post = array(
				  'post_title'    => 'Our properties',
				  'post_status'   => 'publish',
				  'post_type'   => 'page',
				  'post_content'   => 'Property Browse Short Code',
				  'post_author'   => 1
				);

	$new_page_id = wp_insert_post( $my_post );
	//update_post_meta($new_page_id, '_wp_page_template', $this_page_template);
	$menu_url = get_page_link($new_page_id);

	$menu_item_defaults = array(
	        'menu-item-db-id' => $menu_item_db_id,
	        'menu-item-object-id' => 0,
	        'menu-item-object' => '',
	        'menu-item-parent-id' => 0,
	        'menu-item-position' => 0,
	        'menu-item-title' => 'Browse Properties',
	        'menu-item-url' => $menu_url,
	        'menu-item-description' => 'public properties listing',
	        'menu-item-attr-title' => '',
	        'menu-item-target' => '',
	        'menu-item-classes' => '',
	        'menu-item-xfn' => '',
	        'menu-item-status' => 'publish',
	    );
	    
	    wp_update_nav_menu_item($var_pub_menu_id, 0, $menu_item_defaults);*/

		
	
}

?>