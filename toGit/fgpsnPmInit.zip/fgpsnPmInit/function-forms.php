<?PHP


/* populate gform employee selection menu */
function set_mail_content_type() {
	return 'text/html';
}



add_filter("gform_pre_render_2", "populateEmployeeDropdown");
add_filter("gform_admin_pre_render_2", "populateEmployeeDropdown");
add_filter("gform_pre_submission_filter_2", "populateEmployeeDropdown");
add_filter( 'gform_pre_validation_2', 'populateEmployeeDropdown' );

function populateEmployeeDropdown($form){
    //form 2 is maintenance request - populate employees for assignments
    if($form["id"] == 2) {

		//Creating drop down item array.
		$assigned_staff_items = array();
	    $approval_items = array();
	    empty($assigned_staff_items);
	    empty($approval_items);
		//Adding initial blank value.
		$assigned_staff_items[] = array("value" => "0", "text" => " -- Select Employee -- ", "isSelected" => false);
		$approval_items[] = array("value" => "0", "text" => " -- Select Employee -- ", "isSelected" => false);
		//Adding post titles to the items array
		$args = array( 'post_type' => 'employee_data', 'post_status'=> 'publish', 'nopaging' => 'true' );

		$employees = get_posts( $args );
		foreach ( $employees as $employee ) : setup_postdata( $employee );
			$fname = get_post_meta( $employee->ID, 'fgpsn_contact_first_name', true);
			$lname = get_post_meta( $employee->ID, 'fgpsn_contact_last_name', true);
			$etitle = get_post_meta( $employee->ID, 'fgpsn_employee_title', true);
			$fgpsn_wo_participating_staff_approval = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_participating_staff_approval', true);
			$fgpsn_wo_approval_by = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_approval_by', true);

			$employee_name = $fname . ' ' . $lname;
			//var_dump($form['fields']['33']);
			//$items[] = array("value" => $employee->ID, "text" => $employee_name );
			
		

			if ($fgpsn_wo_approval_by == $employee->ID ) {
				$approval_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => true);
			} else {
				$approval_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => false);
			}
			
			if ($fgpsn_wo_participating_staff_approval == $employee->ID ) {
				$assigned_staff_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => true);
			} else {
				$assigned_staff_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => false);
			}
		endforeach; 
		wp_reset_postdata();
		

		//Adding items to field id 8. Replace 8 with your actual field id. You can get the field id by looking at the input name in the markup.
		foreach($form["fields"] as &$field) {
		
			if( $field["id"] == 13 ){
				$field["choices"] = $assigned_staff_items;
			}
			
		}
		foreach($form["fields"] as &$field) {
		
			if( $field["id"] == 67 ){
				$field["choices"] = $approval_items;
			}
		}
		return $form;
		

	} else {
		return $form;
	}
}

/* end populate gform employee selection menu */



/* populate gform property selection menu */

add_filter("gform_pre_render_2", "populatePropertyDropdown");
add_filter("gform_admin_pre_render_2", "populatePropertyDropdown");
add_filter("gform_pre_submission_filter_2", "populatePropertyDropdown");
add_filter( 'gform_pre_validation_2', 'populatePropertyDropdown' );

add_filter("gform_pre_render_10", "populatePropertyDropdown");
add_filter("gform_admin_pre_render_10", "populatePropertyDropdown");
add_filter("gform_pre_submission_filter_10", "populatePropertyDropdown");
add_filter( 'gform_pre_validation_10', 'populatePropertyDropdown' );

function populatePropertyDropdown($form){
    
    //form 2 is maintenance request - populate properties for work order
    if($form["id"] != 2)
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Property  function-forms phpinit line 108 -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'properties', 'post_status'=> 'publish', 'nopaging' => true );

	$properties = get_posts( $args );
	foreach ( $properties as $property ) : setup_postdata( $property );
		$addr1 = get_post_meta( $property->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $property->ID, 'fgpsn_property_city', true);
		$fgpsn_wo_selected_properties = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_properties', true);
		
		$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_properties == $property->ID ) {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => true);
		} else {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
    
    foreach($form["fields"] as &$field)
    
		if($field["id"] == 57){
			$field["choices"] = $items;
		}

    return $form;
}

/* end populate gform property selection menu */



/* populate gform property dependent Unit Selection menu */

add_filter("gform_pre_render_2", "populatePropertyDependentUnitDropdown");
add_filter("gform_admin_pre_render_2", "populatePropertyDependentUnitDropdown");
add_filter("gform_pre_submission_filter_2", "populatePropertyDependentUnitDropdown");
add_filter( 'gform_pre_validation_2', 'populatePropertyDependentUnitDropdown' );

add_filter("gform_pre_render_10", "populatePropertyDependentUnitDropdown");
add_filter("gform_admin_pre_render_10", "populatePropertyDependentUnitDropdown");
add_filter("gform_pre_submission_filter_10", "populatePropertyDependentUnitDropdown");
add_filter( 'gform_pre_validation_10', 'populatePropertyDependentUnitDropdown' );

function populatePropertyDependentUnitDropdown($form){
   
    //form 2 is maintenance request - populate properties for work order
    if( $form["id"] != 2 && $form["id"] != 10 )
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Unit -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish', 'nopaging' => true, 'posts_per_page' => -1 );

	$units = get_posts( $args );
	$this_query = $wpdb->last_query;
	foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		//$items[] = array("value" => $unit->ID, "text" => $unitno);
		
		$fgpsn_wo_selected_units = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_units', true);
		
		//$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_units == $unit->ID ) {
			$items[] = array("value" => $unit->ID, "text" => $unitno, "isSelected" => true);
		} else {
			$items[] = array("value" => $unit->ID, "text" => $unitno . $fgpsn_wo_selected_units, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
	foreach($form["fields"] as &$field)
    
		if($field["id"] == 58){
			$field["choices"] = $items;
		}
    return $form;
}

/* end populate gform property selection menu */
function getAvailableUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	$items =  "<h2>Header - " . $dealerCountry . "</H2>";
	 echo "<div class='archive-container-div'>"; 
	if ( $_POST['dealerCountry'] == 'false') {
	    $args = array(
		'post_type'  => 'unit_data',
		'meta_key'   => 'fgpsn_property_unit_available',
		'orderby'    => 'title',
		'order'      => 'ASC',
		'post_status'      => 'publish',
		'nopaging'	=> true,
		'meta_query' => array(
				array(
					'key'     => 'fgpsn_property_unit_available',
					'value'   => 'on',
					'compare' => '=',
				),
			),
		);
	} 
		$units = new WP_Query( $args );
		$sqlcheck = $wpdb->last_query;

		while( $units->have_posts() ) {
			
			$units->the_post();
			$items .=  get_the_title() . '<br>';
			get_template_part('content','unit_data'); 
		}
		wp_reset_postdata();

	$items .= "</div>";
	echo $items;
    die;
    

}

add_action('wp_ajax_getAvailableUnitList', 'getAvailableUnitList_fn');
add_action('wp_ajax_getAvailableUnitList', 'getAvailableUnitList_fn');
function getAllUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	$items =  "<h2>Header - " . $dealerCountry . "</H2>";
	 echo "<div class='archive-container-div'>"; 
	

	    $args = array(
		'post_type'  => 'unit_data',
		'orderby'    => 'title',
		'order'      => 'ASC',
		'post_status'      => 'publish',
		'nopaging'	=> true,
		);
	
		$units = new WP_Query( $args );
		$sqlcheck = $wpdb->last_query;

		while( $units->have_posts() ) {
			
			$units->the_post();
			$items .=  get_the_title() . '<br>';
			get_template_part('content','unit_data'); 
		}
		wp_reset_postdata();

	$items .= "</div>";
	echo $items;
    die;
    

}

add_action('wp_ajax_getAllUnitList', 'getAllUnitList_fn');
add_action('wp_ajax_getAllUnitList', 'getAllUnitList_fn');

function getUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	echo "<H2>Query: " . $dealerCountry  . "</H2>";
	 //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    
     //Adding post titles to the items array
    //$args = array( 'post_type' => 'contact_data', 'post_status'=> 'publish' );
    $args = array(
	'post_type'  => 'unit_data',
	'meta_key'   => 'fgpsn_property_id',
	'orderby'    => 'title',
	'order'      => 'ASC',
	'post_status'      => 'publish',
	'nopaging'	=> true,
	'meta_query' => array(
			array(
				'key'     => 'fgpsn_property_id',
				'value'   => $dealerCountry,
				'compare' => '=',
			),
		),
	);
	$units = new WP_Query( $args );
	$sqlcheck = $wpdb->last_query;
	//echo "<H2>Query: " . $wpdb->last_query . "</H2>";
	/*echo "<H2>Query: " . $wpdb->last_query . "</H2>";
	while ( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_title(), "text" => get_the_title());
	}

	wp_reset_postdata();
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish',
		'nopaging'	=> true );

	$units = get_posts( $args );
	* */
	$items[] = array("text" => " -- Selected Units -- ", "value" => "");
	while( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_ID(), "text" => get_the_title() );
	}
	/*foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		$items[] = array("value" => '111', "text" => $sqlcheck);
	endforeach; */
	wp_reset_postdata();
	echo json_encode($items);
    die;
    
    /*
    $dealerCountry = $_POST['fgpsn_wo_selected_properties'];
    $dealers = get_posts(array(
        "post_type" => "unit_data",
        "post_status" => "publish",
        "orderby" => "title",
        "order" => "ASC",
        "posts_per_page"  => -1
    ));
    $items = array();
    $items[] = array( "text" => __('Select dealer...','theme'), "value" => 'default' );
    foreach($dealers as $dealer){
        $items[] = array( "text" => $dealer->post_title, "value" => $dealer->post_title );
    }
    echo json_encode($items);
    die;
    */

}

add_action('wp_ajax_getUnitList', 'getUnitList_fn');
add_action('wp_ajax_nopriv_getUnitList', 'getUnitList_fn');


/* populate gform unit dependent contact info

add_filter("gform_pre_render_2", "populateUnitContactInfo");
add_filter("gform_admin_pre_render_2", "populateUnitContactInfo");
add_filter("gform_pre_submission_filter_2", "populateUnitContactInfo");
add_filter( 'gform_pre_validation_2', 'populateUnitContactInfo' );
 */

function populateUnitContactInfo($form){
    //var_dump($form);
    //form 2 is maintenance request - populate properties for work order
    if($form["id"] != 2)
       return $form;
		
		$fgpsn_wo_selected_units = get_post_meta( 975, 'fgpsn_property_unit_occupant_id', true);
    echo "<h1>Howl " . $unitContact . "</h1>";
    	if (isset($fgpsn_wo_selected_units) && !is_null($fgpsn_wo_selected_units) && !empty($fgpsn_wo_selected_units)) {
				$unit_contacts = '';
				if (is_array($fgpsn_wo_selected_units)) {
					foreach($fgpsn_wo_selected_units as $k=>$v) {
						$unit_contacts = $unit_contacts . get_the_title($v) . '<br>'
						. 'Phone: ' . get_post_meta( 975, 'fgpsn_contact_phone', true) . '<br>'
						. 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( 975, 'fgpsn_contact_cell_phone', true);
					}
				} else {
					$unit_contacts = $unit_contacts . get_the_title($fgpsn_wo_selected_units) . '<br>'
						. 'Phone: ' . get_post_meta( 975, 'fgpsn_contact_phone', true) . '<br>'
						. 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( 975, 'fgpsn_contact_cell_phone', true);
				}
				
			}
			
		foreach($form["fields"] as &$field) {
			if($field["id"] == 76){
			echo "<h1>Howl 2 " . $unit_contacts . "</h1>";
			$field["inputs"] = $unit_contacts;
			}
			if($field["id"] == 77){
				$field->content = $unit_contacts;
			}
		}
    return $form;
}

/* end populate gform property selection menu */

/* populate gform property selection menu for move in checklist */

add_filter("gform_pre_render_8", "populateChecklistPropertyDropdown");
add_filter("gform_admin_pre_render_8", "populateChecklistPropertyDropdown");
add_filter("gform_pre_submission_filter_8", "populateChecklistPropertyDropdown");

function populateChecklistPropertyDropdown($form){
    
    //form 2 is maintenance request - populate properties for work order
    if($form["id"] != 8)
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Property -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'properties', 'post_status'=> 'publish', 'nopaging' => true );

	$properties = get_posts( $args );
	foreach ( $properties as $property ) : setup_postdata( $property );
		$addr1 = get_post_meta( $property->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $property->ID, 'fgpsn_property_city', true);
		$fgpsn_wo_selected_properties = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_properties', true);
		
		$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_properties == $property->ID ) {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => true);
		} else {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
    
    foreach($form["fields"] as &$field)
    
		if($field["id"] == 231){
			$field["choices"] = $items;
		}

    return $form;
}

/* end populate gform property selection menu */



/* populate gform property dependent Unit Selection menu */

add_filter("gform_pre_render_8", "populatePropertyDependentChecklistUnitDropdown");
add_filter("gform_admin_pre_render_8", "populatePropertyDependentChecklistUnitDropdown");
add_filter("gform_pre_submission_filter_8", "populatePropertyDependentChecklistUnitDropdown");

function populatePropertyDependentChecklistUnitDropdown($form){
    
    //form 2 is maintenance request - populate properties for work order
    if($form["id"] != 8)
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Unit -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish', 'nopaging' => true );

	$units = get_posts( $args );
	foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		//$items[] = array("value" => $unit->ID, "text" => $unitno);
		
		$fgpsn_wo_selected_units = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_units', true);
		
		$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_units == $unit->ID ) {
			$items[] = array("value" => $unit->ID, "text" => $unitno, "isSelected" => true);
		} else {
			$items[] = array("value" => $unit->ID, "text" => $unitno, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
	foreach($form["fields"] as &$field)
    
		if($field["id"] == 232){
			$field["choices"] = $items;
		}
    return $form;
}

/* end populate gform property selection menu */



/*************************************************************************************/
/* gforms post precessing */


function updateMaintRequest($entry, $lead, $field, $form) {
	//var_dump($entry);
	//return false;
	global $wpdb;
	

	update_post_meta( $entry['post_id'], 'fgpsn_wo_request_types', $entry['11'] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_approval_by', $entry[67] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_participating_staff_approval', $entry[13] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_estimate_date', $entry[60] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_prep_time_estimate', $entry[62] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_work_time_estimate', $entry[63] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_time_estimate', $entry[61] );
	
	update_post_meta( $entry['post_id'], 'fgpsn_wo_prep_time_actual', $entry[65] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_time_actual', $entry[66] );

	update_post_meta( $entry['post_id'], 'fgpsn_wo_approval_date', $entry[55] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_start_date', $entry[53] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_end_date', $entry[54] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_priority', $entry[56] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_selected_properties', $entry[57] );

	update_post_meta( $entry['post_id'], 'fgpsn_wo_requires_est', $entry['59.1'] );
	//echo '<h3>fgpsn_wo_requires_est: ' . $entry['post_id'] . ', ' . $entry['59.1'] . '</h3>';
	//echo '<h3>fgpsn_wo_requires_est: ' . $entry['post_id'] . ', ' . $entry['59'] . '</h3>';

	update_post_meta( $entry['post_id'], 'fgpsn_wo_est_completed', $entry['75.1'] );
	//echo '<h3>fgpsn_wo_est_completed: ' . $entry['post_id'] . ', ' . $entry['75.1'] . '</h3>';
	//echo '<h3>fgpsn_wo_est_completed: ' . $entry['post_id'] . ', ' . $entry['75'] . '</h3>';

	update_post_meta( $entry['post_id'], 'fgpsn_wo_materials', $entry[69] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_selected_units', $entry[58] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_access_notes', $entry[74] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_contact_notes', $entry[76] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_deadline', $entry[77] );
	update_post_meta( $entry['post_id'], 'fgpsn_wo_short_description', $entry[9] );
	//update_post_meta( $entry['post_id'], 'fgpsn_wo_short_description', $entry[9] );

	$staff_group = get_the_title($entry[13]);
	$staff_email = get_post_meta($entry[13], 'fgpsn_employee_email', true);

	//get estimate status
	

	if(!is_null($entry['59.1']) && !empty($entry['59.1'])) {
						//$disp_data .= "<br>Req Not Null: " . $estimate_required . "<br>";
		$estimate_status = 'Estimate Required';
						
						
		if(!is_null($entry['75.1']) && !empty($entry['75.1'])) {
							
			$estimate_status = 'Completed:<br>' . $staff_group . "<br>";
							
			//if it is completed see if it is approved
			if(!is_null($entry[67]) && !empty($entry[67])){
				$estimate_status = 'Approved By:<br>' . get_the_title($entry[67]) . "<br>";
			} else {
				$estimate_status = 'Approval Pending';
			}

		} 

	} else {
		$estimate_status = 'N/A';
	}

	$tenant_ids = get_post_meta($entry[58], 'fgpsn_property_unit_occupant_id', true);
	$unit_contacts = '';
	if (is_array($tenant_ids)) {
		foreach($tenant_ids as $k=>$v) {
			$unit_contacts = $unit_contacts . 'Name: ' . get_the_title($v) . '<br>'
			. 'Phone: ' . get_post_meta( $v, 'fgpsn_contact_phone', true) . '<br>'
			. 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( $v, 'fgpsn_contact_cell_phone', true)
			 . '<br>';
		}
	} else {
		$unit_contacts = $unit_contacts . get_the_title($tenant_ids) . '<br>'
		. 'Phone: ' . get_post_meta( $tenant_ids, 'fgpsn_contact_phone', true) . '<br>'
		. 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( $tenant_ids, 'fgpsn_contact_cell_phone', true);
	}
			
	

	$staff_message = '<h4 style="display: inline; float: left;">Item:  ' . get_the_title( $entry['post_id'] ) . '</h4>';
	$staff_message .= '<h4 style="display: inline; float: right;">W.O.# ' . $entry['post_id'] . '</h4>';
	$staff_message .= '<div style="padding: 2dpi, 8dpi, 3dpi, 3dpi">';

	if ( $staff_email != '' ) {
		$staff_message .= '<h4 style="display: inline; float: left;">Assigned To: ' . $staff_email . ' ( ' . $staff_group  . ' )</h4>';
	}
	$staff_message .= '<b>Location:</b>' . get_the_title( $entry[58] ) . '<br>
	<b>Tenant Contact:</b> ' . $unit_contacts . '<br>';
	$staff_message .= '<b>Work Order Contact:</b>' . $entry[76] . '<br>';

	$staff_message .= '<div><b>Access: </b> ' . $entry[74] . '</div>';
	$staff_message .= '</div><div style="padding: 2dpi, 8dpi, 3dpi, 3dpi">
	
	<div>Short Description:  ' . $entry[9] . '<BR><BR>' . $entry[78] . '</div>
	<div>Details:  ' . get_the_title( $entry[post_id] ) . '</div>';
	
	
	$staff_message .= '<div><b>Deadline: </B> ';
	if( $entry[77] != '' ){ $staff_message .= $entry[77]; }
	$staff_message .= '</div>';
	
	$staff_message .= '<div>Estimate Status:  ' . $estimate_status . '</div>';
	$staff_message .= '<div>Current Estimate: ' . $entry[61] . ' hours</div>';
	
	$staff_message .= '</div>
	<div style="padding: 2dpi, 8dpi, 3dpi, 3dpi">
	<b>Materials: ' . $entry[61] . '</b></div>';


	add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	
	wp_mail( $staff_email, 'WO - Assigned Staff Copy', $staff_message );
	wp_mail( 'dg_419@hotmail.com', 'WO - Assigned Staff Copy' . $staff_group, $staff_message );
	wp_mail( 'cwhite@apexpropertymanagement-me.com', 'WO - Assigned Staff Copy', $staff_message );
	wp_mail( 'jmichaud@apexpropertymanagement-me.com', 'WO - Assigned Staff Copy', $staff_message );
	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );

}

add_filter( "gform_after_submission_2", "updateMaintRequest", 10, 4 );
add_filter( "gform_after_submission_10", "updateMaintRequest", 10, 4 );
































/*
add_filter( 'gform_pre_render_12', 'populate_fgpsn_wo_estimates_form' );

//Note: when changing drop down values, we also need to use the gform_pre_validation so that the new values are available when validating the field.
add_filter( 'gform_pre_validation_12', 'populate_fgpsn_wo_estimates_form' );

//Note: when changing drop down values, we also need to use the gform_admin_pre_render so that the right values are displayed when editing the entry.
add_filter( 'gform_admin_pre_render_12', 'populate_fgpsn_wo_estimates_form' );

//Note: this will allow for the labels to be used during the submission process in case values are enabled
add_filter( 'gform_pre_submission_filter_12', 'populate_fgpsn_wo_estimates_form' );

function populate_fgpsn_wo_estimates_form() {
	

}
*/
/*************************************************************************************/
/* gforms post precessing */

function updateMaintEstimates($entry, $lead, $field, $form) {
	//var_dump($entry);
	//return false;
	

	$staff_group = get_the_title($entry[13]);
	$staff_email = get_post_meta($entry[13], 'fgpsn_employee_email', true);

	//get estimate status
	

	if(!is_null($entry['59.1']) && !empty($entry['59.1'])) {
						//$disp_data .= "<br>Req Not Null: " . $estimate_required . "<br>";
		$estimate_status = 'Estimate Required';
						
						
		if(!is_null($entry['75.1']) && !empty($entry['75.1'])) {
							
			$estimate_status = 'Completed:<br>' . $staff_group . "<br>";
							
			//if it is completed see if it is approved
			if(!is_null($entry[67]) && !empty($entry[67])){
				$estimate_status = 'Approved By:<br>' . get_the_title($entry[67]) . "<br>";
			} else {
				$estimate_status = 'Approval Pending';
			}

		} 

	} else {
		$estimate_status = 'N/A';
	}

	$tenant_ids = get_post_meta($entry[58], 'fgpsn_property_unit_occupant_id', true);
	$unit_contacts = '';
	if (is_array($tenant_ids)) {
		foreach($tenant_ids as $k=>$v) {
			$unit_contacts = $unit_contacts . 'Name: ' . get_the_title($v) . '<br>'
			. 'Phone: ' . get_post_meta( $v, 'fgpsn_contact_phone', true) . '<br>'
			. 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( $v, 'fgpsn_contact_cell_phone', true)
			 . '<br>';
		}
	} else {
		$unit_contacts = $unit_contacts . get_the_title($tenant_ids) . '<br>'
		. 'Phone: ' . get_post_meta( $tenant_ids, 'fgpsn_contact_phone', true) . '<br>'
		. 'Cell: ' . $fgpsn_wo_selected_units = get_post_meta( $tenant_ids, 'fgpsn_contact_cell_phone', true);
	}
			
	

	$staff_message = '<h4 style="display: inline; float: left;">Item:  ' . get_the_title( $entry['post_id'] ) . '</h4>';
	$staff_message .= '<h4 style="display: inline; float: right;">W.O.# ' . $entry['post_id'] . '</h4>';
	$staff_message .= '<div style="padding: 2dpi, 8dpi, 3dpi, 3dpi">';

	if ( $staff_email != '' ) {
		$staff_message .= '<h4 style="display: inline; float: left;">Assigned To: ' . $staff_email . ' ( ' . $staff_group  . ' )</h4>';
	}
	$staff_message .= '<b>Location:</b>' . get_the_title( $entry[58] ) . '<br>
	<b>Tenant Contact:</b> ' . $unit_contacts . '<br>';
	$staff_message .= '<b>Work Order Contact:</b>' . $entry[76] . '<br>';

	$staff_message .= '<div><b>Access: </b> ' . $entry[74] . '</div>';
	$staff_message .= '</div><div style="padding: 2dpi, 8dpi, 3dpi, 3dpi">
	
	<div>Short Description:  ' . $entry[9] . '<BR><BR>' . $entry[78] . '</div>
	<div>Details:  ' . get_the_title( $entry[post_id] ) . '</div>';
	
	
	$staff_message .= '<div><b>Deadline: </B> ';
	if( $entry[77] != '' ){ $staff_message .= $entry[77]; }
	$staff_message .= '</div>';
	
	$staff_message .= '<div>Estimate Status:  ' . $estimate_status . '</div>';
	$staff_message .= '<div>Current Estimate: ' . $entry[61] . ' hours</div>';
	
	$staff_message .= '</div>
	<div style="padding: 2dpi, 8dpi, 3dpi, 3dpi">
	<b>Materials: ' . $entry[61] . '</b></div>';


	add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	
	//wp_mail( $staff_email, 'WO - Assigned Staff Copy', $staff_message );
	wp_mail( 'dg_419@hotmail.com', 'WO Estimate' . $staff_group, $staff_message );
	//wp_mail( 'cwhite@apexpropertymanagement-me.com', 'WO - Assigned Staff Copy', $staff_message );
	
	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );

}

add_filter( "gform_after_submission_12", "updateMaintEstimates", 10, 4 );



/* checks move in checklist form and submits entries as workorders */

function sendMoveInToMaintenance($entry, $lead, $field, $form) {
	//echo '<H2>Here</H2>';
	$message = '';
	$title_service = get_term( $entry[11], 'request_types' );
	$title_start = $title_service->name;
	$title_start .= $entry[8];
	/*$wpdb->update( 
		'wp_2_posts', 
		array( 
			'post_title' => $title_start
		), 
		array( 'ID' => $entry['post_id'] )
	);*/


	//$lead = RGFormsModel::get_lead( $entries[0]['id'] );
	$lead = RGFormsModel::get_lead( $lead ); 
	$form = GFFormsModel::get_form_meta( $lead['form_id'] ); 
	//display form questions and answers from entry 19
	//var_dump($lead); 
	$it = 0;
	foreach( $form['fields'] as $field ) {
			
		if ( $field['label'] == 'Field Group Open' || $field['label'] == 'Field Group Close' || $field['label'] == 'Group Open' ) {
				$field['label'] = "<HR>";
		}
		
		if ( $field['type'] == 'checkbox' ) {
			
			$like_new = rgar( $lead, $field['id'] . ".1" );
			$good = rgar( $lead, $field['id'] . ".2" ); 
			$acceptable = rgar( $lead, $field['id'] . ".3" );
			$not_acceptable = rgar( $lead, $field['id'] . ".4" );
			$item_status = $like_new . $good . $acceptable . $not_acceptable;
			
			if ( $item_status != '') {
				$message .= "<H4>";
				$message .=  $field['label'] . "<BR>\t";
				$message .= $item_status . "</H4>";
			}
				
		} else {
			$message .=  rgar( $lead, $field['id'] ) . "</H4>";
		}
	}
	
	add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	
	wp_mail( 'dg_419@hotmail.com', 'Siwtch to maint', $message, $headers, $attachments );
	wp_mail( 'dg4220@gmail.com', 'Siwtch to maint', $message, $headers, $attachments );
	
	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );
}

//add_filter( "gform_after_submission_8", "sendMoveInToMaintenance", 10, 4 );


/*add contacts form
 * update post type based on role
 * redirect to next form here or in the form settings redirect
 * */

function updateContactPostType($entry, $lead, $field, $form) {

	global $wpdb;
	$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
	$message = print_r($entry, true);
	//echo '<H4>' . $message . '<BR>Post: ' . $entry['post_id'] . '</H4>';
	$fgpsn_contact_last_name = $entry[1.6];
	
	
	update_post_meta( $entry['post_id'], 'fgpsn_contact_first_name', $entry['1.3']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_last_name', $entry['1.6']);
	
	update_post_meta( $entry['post_id'], 'fgpsn_contact_address_1', $entry['2.1']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_address_2', $entry['2.2']);

	update_post_meta( $entry['post_id'], 'fgpsn_contact_city', $entry['2.3']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_state', $entry['2.4']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_zip', $entry['2.5']);
	
	update_post_meta( $entry['post_id'], 'fgpsn_contact_phone', $entry['3']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_cell_phone', $entry['3']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_email', $entry['4']);	
	
	update_post_meta( $entry['post_id'], 'fgpsn_contact_role', $entry['5']);
	
	$user_id = username_exists( $entry['1.3'] );
	if ( !$user_id ) {
		while( $i < 10 ) {
			if ( username_exists( $entry['1.3'] . $i )) {
				$user_id = username_exists( $entry['1.3'] . $i );
				break;
			}
			$i++;
		}
	}
	//echo '<h4>User? ' . $user_id . '</h4>';
	if ( !$user_id && email_exists($entry['4']) == false ) {

		/*
		 */
		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $entry['1.3'], $random_password, $entry['4'] );
		
		update_post_meta( $entry['post_id'], 'fgpsn_contact_user_id', $user_id);
		update_user_meta( $user_id, 'fgpsn_contact_post_id', $entry['post_id']);
		
		update_user_meta( $user_id, 'fgpsn_contact_first_name', $entry['1.3']);
		update_user_meta( $user_id, 'fgpsn_contact_last_name', $entry['1.6']);
		
		update_user_meta( $user_id, 'fgpsn_contact_address_1', $entry['2.1']);
		update_user_meta( $user_id, 'fgpsn_contact_address_2', $entry['2.2']);

		update_user_meta( $user_id, 'fgpsn_contact_city', $entry['2.3']);
		update_user_meta( $user_id, 'fgpsn_contact_state', $entry['2.4']);
		update_user_meta( $user_id, 'fgpsn_contact_zip', $entry['2.5']);
		
		update_user_meta( $user_id, 'fgpsn_contact_phone', $entry['3']);
		update_user_meta( $user_id, 'fgpsn_contact_cell_phone', $entry['3']);
		update_user_meta( $user_id, 'fgpsn_contact_email', $entry['4']);	
		
		update_user_meta( $user_id, 'fgpsn_contact_role', $entry['5']);
		wp_update_user( array (
								'ID' => $user_id,
								'role' => $entry['5'],
								'user_email' => $entry['4'],
								'first_name' => $entry['1.3'],
								'last_name' => $entry['1.4']
								) ) ;
		
		//echo '<h4>User? ' . $user_id . '</h4>';
		return $form;

	}
		
	
	//update post_type
	if ( $entry[5] == 'property_vendor' ) {
		set_post_type($entry['post_id'], 'property_vendor');
		 
	}

	if ( $entry[5] == 'desk_staff' || $entry[5] == 'maint_staff' || $entry[5] == 'maint_manager_role' || $entry[5] == 'property_manager' ) {
		
		 $my_post = array(
      'ID'           => $entry['post_id'],
      'post_title'   => $entry[1.3] . ' ' . $entry[1.6],
      'post_type'   => 'employee_data'
		);
		
		// Update the post into the database
		  wp_update_post( $my_post );
		  
	}
	add_filter( 'wp_mail_content_type', 'set_mail_content_type' );
	
	wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments );
	/* now add user */
	
	
	$message = $message . '<H3>USER: ' . $entry[1.3] . ', ' . $user_id . '</H3>';
	wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments );


	wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message );

 	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );

}

add_filter( "gform_after_submission_3", "updateContactPostType", 10, 4 );

/*************************************************************************************/
/* Now redirect to the appropriate form based on post type or role */
add_filter( 'gform_confirmation_3', 'contactFormRedirect', 10, 4 );
function contactFormRedirect( $confirmation, $form, $entry, $ajax ) {
    
    if( $form['id'] == '3' ) {
        if ( $entry[5] == 'property_vendor' ) {
			
			$confirmation = array( 'redirect' => get_site_url() . '/vendor-data-form/?gform_post_id=' . $entry['post_id'] );
			
		} elseif ( $entry[5] == 'desk_staff' || $entry[5] == 'maint_staff' || $entry[5] == 'maint_manager_role' || $entry[5] == 'property_manager' ) {
		
			$confirmation = array( 'redirect' => get_site_url() . '/edit-employee-data/?gform_post_id=' . $entry['post_id'] );
			
		} else {
			
		}
    }
    
    
    return $confirmation;
}


/****************************************************************************/
/* Updating Employee Data form - Form ID 6 for apexpm */
function updateEmployeeDataPostType($entry, $lead, $field, $form) {

	global $wpdb;
	$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
	$message = print_r($entry, true);
	echo '<H4>' . $message . '<BR>
	Post: ' . $entry['post_id'] . '</H4>';
	
	if (!wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message )) {
		echo "<H2>Hell!0</H2>";
		
	}
	$to      = 'dg_419@hotmail.com';
$subject = 'the subject';

$headers = 'From: dg_419@hotmail.com' . "\r\n" .
    'Reply-To: dg_419@hotmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
	//$fgpsn_contact_last_name = $entry[6.3];
	
	
	update_post_meta( $entry['post_id'], 'fgpsn_contact_first_name', $entry['2']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_last_name', $entry['3']);
	
	update_post_meta( $entry['post_id'], 'fgpsn_contact_phone', $entry['5']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_cell_phone', $entry['6']);
	update_post_meta( $entry['post_id'], 'fgpsn_employee_phone', $entry['54']);
	update_post_meta( $entry['post_id'], 'fgpsn_contact_email', $entry['56']);	
	
	update_post_meta( $entry['post_id'], 'fgpsn_employee_title_role', $entry['48']);
	
	
	$fl = substr($entry['2'], 0, 1) . $entry['3'];
	$user_id = username_exists( $fl );
	echo '<h4>User? ' . $user_id . '</h4>';
	//$mail = new fgpsnMailer();


//$mail->AddAddress('dg_419@hotmail.com');

//$mail->Subject  = "First PHPMailer Message";
//$mail->Body     = "Hi! \n\n This is my first e-mail sent through PHPMailer.";
//$mail->WordWrap = 50;
/*
if(!$mail->Send()) {
  echo 'Message was not sent.';
  echo 'Mailer error: ' . $mail->ErrorInfo;
} else {
  echo 'Message has been sent.';
}
* */
	if ( !$user_id && email_exists($entry['4']) == false && email_exists($entry['4']) == true) {

		/*
		 */
		  $random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $entry['1.3'], $random_password, $entry['4'] );
		
		update_user_meta( $user_id, 'fgpsn_contact_first_name', $entry['1.3']);
		update_user_meta( $user_id, 'fgpsn_contact_last_name', $entry['1.6']);
		
		update_user_meta( $user_id, 'fgpsn_contact_address_1', $entry['2.1']);
		update_user_meta( $user_id, 'fgpsn_contact_address_2', $entry['2.2']);

		update_user_meta( $user_id, 'fgpsn_contact_city', $entry['2.3']);
		update_user_meta( $user_id, 'fgpsn_contact_state', $entry['2.4']);
		update_user_meta( $user_id, 'fgpsn_contact_zip', $entry['2.5']);
		
		update_user_meta( $user_id, 'fgpsn_contact_phone', $entry['3']);
		update_user_meta( $user_id, 'fgpsn_contact_cell_phone', $entry['3']);
		update_user_meta( $user_id, 'fgpsn_contact_email', $entry['4']);	
		
		update_user_meta( $user_id, 'fgpsn_contact_role', $entry['5']);
		wp_update_user( array (
								'ID' => $user_id,
								'role' => $entry['5'],
								'user_email' => $entry['4'],
								'first_name' => $entry['1.3'],
								'last_name' => $entry['1.4']
								) ) ;
		
		//echo '<h4>User? ' . $user_id . '</h4>';
		return $form;

	}

	
		global $wpdb;
		
		 $my_post = array(
      'ID'           => $entry['post_id'],
      'post_title'   => $entry[2] . ' ' . $entry[3],
      'post_type'   => 'employee_data'
		);
		
		// Update the post into the database
	wp_update_post( $my_post );
	
	add_filter( 'wp_mail_content_type', 'set_html_content_type' );
	if (!wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments )) {
		echo "<H2>Hell!1</H2>";
		
	}
	/* now add user */
	
	
	$message = $message . '<H3>USER: ' . $entry[1.3] . ', ' . $user_id . '</H3>';
	if (!wp_mail( 'dg_419@hotmail.com', 'Recip with attachemnts 4', $message, $headers, $attachments )) {
		echo "<H2>Hell!2</H2>";
		
	}

	if (!wp_mail( 'dg_419@hotmail.com', 'Getting the Gravity Form Field IDs', $message )) {
		echo "<H2>Hell!3</H2>";
		
	}

 	remove_filter( 'wp_mail_content_type', 'set_mail_content_type' );

}

add_filter( "gform_after_submission_6", "updateEmployeeDataPostType", 10, 4 );


/*Done Updating Employee Data Form*/
/******************************************************************************/

class GWMultipageNavigation {
    private $script_displayed;
    function __construct( $args = array() ) {
        $form_ids = false;
        if( isset( $args['form_id'] ) ) {
            $form_ids = is_array( $args['form_id'] ) ? $args['form_id'] : array( $args['form_id'] );
        }
        if( !empty($form_ids) ) {
            foreach( $form_ids as $form_id ) {
                add_filter("gform_pre_render_{$form_id}", array( &$this, 'output_navigation_script' ), 10, 2 );
                //add_filter('gform_register_init_scripts', array( &$this, 'register_script') );
            }
        } else {
            add_filter('gform_pre_render', array( &$this, 'output_navigation_script' ), 10, 2 );
        }
    }
    function output_navigation_script( $form, $is_ajax ) {
        // only apply this to multi-page forms
        if( count($form['pagination']['pages']) <= 1 )
            return $form;
        $this->register_script( $form );
        if( $this->is_last_page( $form ) || $this->is_last_page_reached() ) {
            $input = '<input id="gw_last_page_reached" name="gw_last_page_reached" value="1" type="hidden" />';
            add_filter( "gform_form_tag_{$form['id']}", create_function('$a', 'return $a . \'' . $input . '\';' ) );
        }
        // only output the gwmpn object once regardless of how many forms are being displayed
        // also do not output again on ajax submissions
        if( $this->script_displayed || ( $is_ajax && rgpost('gform_submit') ))
            return $form;
            
            
        ?>

        <script type="text/javascript">
            (function($){
                window.gwmpnObj = function( args ) {
                    this.formId = args.formId;
                    this.formElem = jQuery('form#gform_' + this.formId);
                    this.currentPage = args.currentPage;
                    this.lastPage = args.lastPage;
                    this.labels = args.labels;
                    this.init = function() {
                        // if this form is ajax-enabled, we'll need to get the current page via JS
                        if( this.isAjax() )
                            this.currentPage = this.getCurrentPage();
                        if( !this.isLastPage() && !this.isLastPageReached() )
                            return;
                        var gwmpn = this;
                        var steps = $('form#gform_' + this.formId + ' .gf_step');
                        steps.each(function(){
                            var stepNumber = parseInt( $(this).find('span.gf_step_number').text() );
                            if( stepNumber != gwmpn.currentPage ) {
                                $(this).html( gwmpn.createPageLink( stepNumber, $(this).html() ) )
                                    .addClass('gw-step-linked');
                            } else {
                                $(this).addClass('gw-step-current');
                            }
                        });
                        if( !this.isLastPage() )
                            this.addBackToLastPageButton();
                        $(document).on('click', '#gform_' + this.formId + ' a.gwmpn-page-link', function(event){
                            event.preventDefault();
                            var hrefArray = $(this).attr('href').split('#');
                            if( hrefArray.length >= 2 ) {
                                var pageNumber = hrefArray.pop();
                                gwmpn.postToPage( pageNumber );
                            }
                        });
                    }
                    this.createPageLink = function( stepNumber, HTML ) {
                        return '<a href="#' + stepNumber + '" class="gwmpn-page-link">' + HTML + '</a>';
                    }
                    this.postToPage = function(page) {
                        this.formElem.append('<input type="hidden" name="gw_page_change" value="1" />');
                        this.formElem.find('input[name="gform_target_page_number_' + this.formId + '"]').val(page);
                        this.formElem.submit();
                    }
                    this.addBackToLastPageButton = function() {
                        this.formElem.find('#gform_page_' + this.formId + '_' + this.currentPage + ' .gform_page_footer')
                            .append('<input type="button" onclick="gwmpn.postToPage(' + this.lastPage + ')" value="' + this.labels.lastPageButton + '" class="button gform_last_page_button">');
                    }
                    this.getCurrentPage = function() {
                        return this.formElem.find( 'input#gform_source_page_number_' + this.formId ).val();
                    }
                    this.isLastPage = function() {
                        return this.currentPage >= this.lastPage;
                    }
                    this.isLastPageReached = function() {
                        return this.formElem.find('input[name="gw_last_page_reached"]').val() == true;
                    }
                    this.isAjax = function() {
                        return this.formElem.attr('target') == 'gform_ajax_frame_' + this.formId;
                    }
                    this.init();
                }
            })(jQuery);
        </script>

        <?php
        $this->script_displayed = true;
        return $form;
    }
    function register_script( $form ) {
        $page_number = GFFormDisplay::get_current_page($form['id']);
        $last_page = count($form['pagination']['pages']);
        $args = array(
            'formId' => $form['id'],
            'currentPage' => $page_number,
            'lastPage' => $last_page,
            'labels' => array(
                'lastPageButton' => __('Back to Last Page')
                )
            );
        $script = "window.gwmpn = new gwmpnObj(" . json_encode( $args ) . ");";
        GFFormDisplay::add_init_script( $form['id'], 'gwmpn', GFFormDisplay::ON_PAGE_RENDER, $script );
    }
    function is_last_page( $form ) {
        $page_number = GFFormDisplay::get_current_page($form['id']);
        $last_page = count($form['pagination']['pages']);
        return $page_number >= $last_page;
    }
    function is_last_page_reached() {
        return rgpost('gw_last_page_reached');
    }
}
$gw_multipage_navigation = new GWMultipageNavigation();
?>
