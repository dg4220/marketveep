<?PHP
/* Stand alone functions for maintenance dispatch */
/* populate gform employee selection menu */
function set_mail_content_type() {
	return 'text/html';
}



add_filter("gform_pre_render_2", "populateEmployeeDropdown");
add_filter("gform_admin_pre_render_2", "populateEmployeeDropdown");
add_filter("gform_pre_submission_filter_2", "populateEmployeeDropdown");
add_filter( 'gform_pre_validation_2', 'populateEmployeeDropdown' );

function populateEmployeeDropdown($form){
    //form 2 is maintenance request - populate employees for assignments
    if($form["id"] == 2) {

		//Creating drop down item array.
		$assigned_staff_items = array();
	    $approval_items = array();
	    empty($assigned_staff_items);
	    empty($approval_items);
		//Adding initial blank value.
		$assigned_staff_items[] = array("value" => "0", "text" => " -- Select Employee -- ", "isSelected" => false);
		$approval_items[] = array("value" => "0", "text" => " -- Select Employee -- ", "isSelected" => false);
		//Adding post titles to the items array
		$args = array( 'post_type' => 'employee_data', 'post_status'=> 'publish', 'nopaging' => 'true' );

		$employees = get_posts( $args );
		foreach ( $employees as $employee ) : setup_postdata( $employee );
			$fname = get_post_meta( $employee->ID, 'fgpsn_contact_first_name', true);
			$lname = get_post_meta( $employee->ID, 'fgpsn_contact_last_name', true);
			$etitle = get_post_meta( $employee->ID, 'fgpsn_employee_title', true);
			$fgpsn_wo_participating_staff_approval = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_participating_staff_approval', true);
			$fgpsn_wo_approval_by = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_approval_by', true);

			$employee_name = $fname . ' ' . $lname;
			//var_dump($form['fields']['33']);
			//$items[] = array("value" => $employee->ID, "text" => $employee_name );
			
		

			if ($fgpsn_wo_approval_by == $employee->ID ) {
				$approval_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => true);
			} else {
				$approval_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => false);
			}
			
			if ($fgpsn_wo_participating_staff_approval == $employee->ID ) {
				$assigned_staff_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => true);
			} else {
				$assigned_staff_items[] = array("value" => $employee->ID, "text" => $employee_name, "isSelected" => false);
			}
		endforeach; 
		wp_reset_postdata();
		

		//Adding items to field id 8. Replace 8 with your actual field id. You can get the field id by looking at the input name in the markup.
		foreach($form["fields"] as &$field) {
		
			if( $field["id"] == 13 ){
				$field["choices"] = $assigned_staff_items;
			}
			
		}
		foreach($form["fields"] as &$field) {
		
			if( $field["id"] == 67 ){
				$field["choices"] = $approval_items;
			}
		}
		return $form;
		

	} else {
		return $form;
	}
}

/* end populate gform employee selection menu */



/* populate gform property selection menu */

add_filter("gform_pre_render_2", "populatePropertyDropdown");
add_filter("gform_admin_pre_render_2", "populatePropertyDropdown");
add_filter("gform_pre_submission_filter_2", "populatePropertyDropdown");
add_filter( 'gform_pre_validation_2', 'populatePropertyDropdown' );

add_filter("gform_pre_render_10", "populatePropertyDropdown");
add_filter("gform_admin_pre_render_10", "populatePropertyDropdown");
add_filter("gform_pre_submission_filter_10", "populatePropertyDropdown");
add_filter( 'gform_pre_validation_10', 'populatePropertyDropdown' );

function populatePropertyDropdown($form){
    
    //form 2 is maintenance request - populate properties for work order
    if($form["id"] != 2)
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Property -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'properties', 'post_status'=> 'publish', 'nopaging' => true );

	$properties = get_posts( $args );
	foreach ( $properties as $property ) : setup_postdata( $property );
		$addr1 = get_post_meta( $property->ID, 'fgpsn_property_address_1', true);
		$city = get_post_meta( $property->ID, 'fgpsn_property_city', true);
		$fgpsn_wo_selected_properties = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_properties', true);
		
		$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_properties == $property->ID ) {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => true);
		} else {
			$items[] = array("value" => $property->ID, "text" => $property_name, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
    
    foreach($form["fields"] as &$field)
    
		if($field["id"] == 57){
			$field["choices"] = $items;
		}

    return $form;
}

/* end populate gform property selection menu */



/* populate gform property dependent Unit Selection menu */

add_filter("gform_pre_render_2", "populatePropertyDependentUnitDropdown");
add_filter("gform_admin_pre_render_2", "populatePropertyDependentUnitDropdown");
add_filter("gform_pre_submission_filter_2", "populatePropertyDependentUnitDropdown");
add_filter( 'gform_pre_validation_2', 'populatePropertyDependentUnitDropdown' );

add_filter("gform_pre_render_10", "populatePropertyDependentUnitDropdown");
add_filter("gform_admin_pre_render_10", "populatePropertyDependentUnitDropdown");
add_filter("gform_pre_submission_filter_10", "populatePropertyDependentUnitDropdown");
add_filter( 'gform_pre_validation_10', 'populatePropertyDependentUnitDropdown' );

function populatePropertyDependentUnitDropdown($form){
   
    //form 2 is maintenance request - populate properties for work order
    if( $form["id"] != 2 && $form["id"] != 10 )
       return $form;

    //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    $items[] = array("text" => " -- Select Unit -- ", "value" => "");
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish', 'nopaging' => true, 'posts_per_page' => -1 );

	$units = get_posts( $args );
	$this_query = $wpdb->last_query;
	foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		//$items[] = array("value" => $unit->ID, "text" => $unitno);
		
		$fgpsn_wo_selected_units = get_post_meta( $_GET['gform_post_id'], 'fgpsn_wo_selected_units', true);
		
		//$property_name = $addr1 . ', ' .  $city;
		
		if ($fgpsn_wo_selected_units == $unit->ID ) {
			$items[] = array("value" => $unit->ID, "text" => $unitno, "isSelected" => true);
		} else {
			$items[] = array("value" => $unit->ID, "text" => $unitno . ' WooHoo! ' . $fgpsn_wo_selected_units, "isSelected" => false);
		}
	endforeach; 
	wp_reset_postdata();
	foreach($form["fields"] as &$field)
    
		if($field["id"] == 58){
			$field["choices"] = $items;
		}
    return $form;
}

/* end populate gform property selection menu */


function getUnitList_fn(){
	global $wpdb;
	$dealerCountry = $_POST['dealerCountry'];
	//echo "<H2>Query: " . $dealerCountry  . "</H2>";
	 //Creating drop down item array.
    $items = array();
   
    //Adding initial blank value.
    
     //Adding post titles to the items array
    //$args = array( 'post_type' => 'contact_data', 'post_status'=> 'publish' );
    $args = array(
	'post_type'  => 'unit_data',
	'meta_key'   => 'fgpsn_property_id',
	'orderby'    => 'title',
	'order'      => 'ASC',
	'post_status'      => 'publish',
	'nopaging'	=> true,
	'meta_query' => array(
			array(
				'key'     => 'fgpsn_property_id',
				'value'   => $dealerCountry,
				'compare' => '=',
			),
		),
	);
	$units = new WP_Query( $args );
	$sqlcheck = $wpdb->last_query;
	//echo "<H2>Query: " . $wpdb->last_query . "</H2>";
	/*echo "<H2>Query: " . $wpdb->last_query . "</H2>";
	while ( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_title(), "text" => get_the_title());
	}

	wp_reset_postdata();
	
    //Adding post titles to the items array
    $args = array( 'post_type' => 'unit_data', 'post_status'=> 'publish',
		'nopaging'	=> true );

	$units = get_posts( $args );
	* */
	$items[] = array("text" => " -- Selected Units -- ", "value" => "");
	while( $units->have_posts() ) {
		$units->the_post();
		$items[] = array("value" => get_the_ID(), "text" => get_the_title() . 'Oh No!');
	}
	/*foreach ( $units as $unit ) : setup_postdata( $unit );
		$unitno = get_the_title( $unit->ID);
		
		$items[] = array("value" => '111', "text" => $sqlcheck);
	endforeach; */
	wp_reset_postdata();
	echo json_encode($items);
    die;
    
    /*
    $dealerCountry = $_POST['fgpsn_wo_selected_properties'];
    $dealers = get_posts(array(
        "post_type" => "unit_data",
        "post_status" => "publish",
        "orderby" => "title",
        "order" => "ASC",
        "posts_per_page"  => -1
    ));
    $items = array();
    $items[] = array( "text" => __('Select dealer...','theme'), "value" => 'default' );
    foreach($dealers as $dealer){
        $items[] = array( "text" => $dealer->post_title, "value" => $dealer->post_title );
    }
    echo json_encode($items);
    die;
    */

}

add_action('wp_ajax_getUnitList', 'getUnitList_fn');
add_action('wp_ajax_nopriv_getUnitList', 'getUnitList_fn');



/*************************************************************************************/
?>