<?PHP

class fgpsn_time_logger extends WP_Widget {

	function fgpsn_time_logger() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-time-logger', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows recent text messages from select numbers.', 'fgpsn-time-logger' ) );
		//Create widget
		$this->WP_Widget( 'fgpsntimelogger', __( 'Time Log', 'fgpsn-time-logger' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );


		$parameters = array(
				'title' 	=> $title,
				
			);

		if ( !empty( $title ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}

        //print recent posts
		fgpsn_get_time_logs($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['api_key'] = $new_instance['api_key'];
		$instance['auth_token'] = $new_instance['auth_token'];
		$instance['from_number'] = $new_instance['from_number'];
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsn_time_logs_defaults() );

		$title 		= esc_attr($instance['title']);
		$api_key 	= $instance['api_key'];
		$auth_token = $instance['auth_token'];
		$from_number 	= $instance['from_number'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_time_logger");') );


function fgpsn_get_time_logs($args = '', $echo = true) {

	global $wpdb;
	$defaults = fgpsn_time_logs_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);
       
    

    //make modal box version
  $postlist_mb = '<a class="btn btn-block btn-social btn-bitbucket" data-toggle="modal" data-target="#time-sheet-modal">
                <i class="fa fa-bitbucket"></i> Start Time Sheet
              </a>

<div class="modal fade" id="time-sheet-modal">
  <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Primary Modal</h4>
              </div>
              <div class="modal-body">
                <p>


            <FORM NAME="watch" method="post" action="">
         <div class="element-justify">
         <input  type="text" maxlength="2" size="2" name="facehr"';

          if (isset($_REQUEST["facehr"])) {

        $postlist_mb .= ' value=$_REQUEST["facehr"]';

          } else {

            $postlist_mb .= " value=00";

          }


          $postlist_mb .=  '>
           <input  type="text" maxlength="2" size="2" name="facemn"';

          if (isset($_REQUEST["facemn"])) {

        $postlist_mb .=  " value=$_REQUEST[facemn]";

          } else {

            $postlist_mb .=  " value=00";

          }

          $postlist_mb .=  '>
                    <input  type="text" maxlength="2" size="2" name="faces"';

          if (isset($_REQUEST["faces"])) {

        $postlist_mb .=  " value=$_REQUEST[faces]";

          } else {

            $postlist_mb .=  " value=00";

          }





    $postlist_mb .=  '></div></td>
  </tr>


  <tr>
    <td COLSPAN=4>

  <div class="element-justify">
     <input type="button" CLASS="button" value="Start" onClick="startclock()">
     <input type="button" value="Stop" CLASS="button" onClick="stopclock()">
     <input type="button" value="Reset" onClick="resetclock()" CLASS="button">
     <input type="button" value="Add" onClick="addTime()" CLASS="button">
  </div>
  </FORM>


              <form id="fgpsn-time-logger" class="col-sm-12 col-md-12 col-lg-12" action="#" method="post">
                

                <div class="form-group col-sm-12 col-md-12 col-lg-12" >
                <select multiple size=1 id="timelog-property" name="selected_properties" class="fgpsn_properties_menu">
                  <option value=""> -- Select Properties -- </option>
                </select>
                  
                </div>
                <div class="form-group col-sm-12 col-md-12 col-lg-12" >
                   <select multiple size=5 name="selected_units" class="fgpsn_units_menu">
                    <option value=""> -- Select Units -- </option>
                  </select>
                </div>

                <div class="form-group col-sm-12 col-md-12 col-lg-12" >';


$postlist_mb .= wp_dropdown_categories( 'hierarchical=1&echo=0&taxonomy=fgpsn_time_log_entry_types&hide_empty=0' );


          $postlist_mb .= '</div>
          <input type="hidden" name="action" value="addFgpsnTimeSheet"/>
          <input type="Submit" value="Add Log" CLASS="button">
                </form></p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline">Save changes</button>
              </div></div>
            </div>';

/*******************************************************************************************************/




    $postlist = '<div class="box box-warning collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">Generate Time Logs</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">


            <FORM NAME="watch" method="post" action="">
         <div class="element-justify">
         <input  type="text" maxlength="2" size="2" name="facehr"';

          if (isset($_REQUEST["facehr"])) {

				$postlist .= ' value=$_REQUEST["facehr"]';

          } else {

          	$postlist .= " value=00";

          }


          $postlist .=  '>
           <input  type="text" maxlength="2" size="2" name="facemn"';

          if (isset($_REQUEST["facemn"])) {

				$postlist .=  " value=$_REQUEST[facemn]";

          } else {

          	$postlist .=  " value=00";

          }

          $postlist .=  '>
                    <input  type="text" maxlength="2" size="2" name="faces"';

          if (isset($_REQUEST["faces"])) {

				$postlist .=  " value=$_REQUEST[faces]";

          } else {

          	$postlist .=  " value=00";

          }





    $postlist .=  '></div></td>
  </tr>


  <tr>
    <td COLSPAN=4>

	<div class="element-justify">
	   <input type="button" CLASS="button" value="Start" onClick="startclock()">
	   <input type="button" value="Stop" CLASS="button" onClick="stopclock()">
	   <input type="button" value="Reset" onClick="resetclock()" CLASS="button">
	   <input type="button" value="Add" onClick="addTime()" CLASS="button">
	</div>
	</FORM>


              <form id="fgpsn-time-logger" class="col-sm-12 col-md-12 col-lg-12" action="#" method="post">
                

                <div class="form-group col-sm-12 col-md-12 col-lg-12" >
                <select multiple size=1 id="timelog-property" name="selected_properties" class="fgpsn_properties_timesheet_menu">
                  <option value=""> -- Select Properties -- </option>
                </select>
                  
                </div>
                <div class="form-group col-sm-12 col-md-12 col-lg-12" >
                   <select multiple size=5 name="selected_units" class="fgpsn_units_timesheet_menu">
                    <option value=""> -- Select Units -- </option>
                  </select>
                </div>

                <div class="form-group col-sm-12 col-md-12 col-lg-12" >';


$postlist .= wp_dropdown_categories( 'hierarchical=1&echo=0&taxonomy=fgpsn_time_log_entry_types&hide_empty=0' );


          $postlist .= '</div>
          <input type="hidden" name="action" value="addFgpsnTimeSheet"/>
          <input type="Submit" value="Add Log" CLASS="button">
                </form>
            </div>
            <!-- /.box-body -->
          </div>';

         $postlist .=  "<script language=javascript type=\"text/javascript\">

<!-- hide script




var seconds = 0
var minutes = 0
var hours = 0
var timerID = null
var timerRunning = false
var startClicked = false


function resetclock(){
    seconds = 0
    minutes = 0
    hours = 0
    timerID = null
    timerRunning = false
    startClicked = false
    document.watch.facehr.value = 0
    document.watch.facemn.value = 0
    document.watch.faces.value = 0
}


function addTime(){

  document.crm.rechr.value = document.watch.facehr.value;
  document.crm.recmn.value = document.watch.facemn.value;

}


function stopclock(){
    if(timerRunning)
        clearTimeout(timerID)
    timerRunning = false
    startClicked = false
}

function startclock(){
    if (startClicked != true){
       showtime()
       startClicked = true
    }
}

function showtime(){
    seconds = ++document.watch.faces.value

    if (seconds == 60)
      {
        seconds = 0
        minutes = ++document.watch.facemn.value
      }
    if (minutes == 60)
        {
        minutes = 0
        hours = ++document.watch.facehr.value
        }
    var timeValuehr = '' + ((hours < 10) ? '0' : '') + hours
    var timeValuemin = '' + ((minutes < 10) ? '0' : '') + minutes
    var timeValuesec = '' + ((seconds < 10) ? '0' : '') + seconds

    document.watch.facehr.value = timeValuehr
    document.watch.facemn.value = timeValuemin
    document.watch.faces.value = timeValuesec

    timerID = setTimeout('showtime()',1000)
    timerRunning = true
}















function updateForm(){

//stopclock()

    var checkProp;

       	checkProp = document.crm.selected_property.value;

    	if (checkProp == undefined) {

    	//alert (document.crm.selected_property.value);
    	} else {

    	//alert ('HERE ' + checkProp);


    	}
    	rec_hr = document.crm.rechr.value;
    	rec_mn = document.crm.recmn.value;
    	rec_content = document.crm.feedback_content.value;
    	rec_type = document.crm.contact_type.value;


       	timeValuehr = document.watch.facehr.value + ' hr'
  		timeValuemin = document.watch.facemn.value + ' min'
  		timeValuesec = document.watch.faces.value + ' sec'


		eventYear = document.crm.rec_time_year.value;
		eventMonth = document.crm.rec_time_month.value;
		eventDay = document.crm.rec_time_day.value;


		contactType = document.crm.contact_type.value;
		feedbackContent = document.crm.feedback_content.value;
		billable = document.crm.billable.value;




    document.location = 'contact_log_popup.php?selected_property=' + checkProp +
    '&rechr=' + rec_hr + '&recmn=' + rec_mn + '&feedback_content=' + rec_content + '&contact_type=' + rec_type + '&facehr=' + timeValuehr + '&facemn=' + timeValuemin + '&faces=' + timeValuesec + '&rec_time_year=' + eventYear + '&rec_time_month=' + eventMonth + '&rec_time_day=' + eventDay + '&contact_type =' + contactType + '&feedback_content =' + feedbackContent + '&billable =' + billable;



}


// end hide script-->
 </script>";


	if ($echo)
		echo $postlist;
    //echo $postlist_mb;
	else
		return $postlist;
    //echo $postlist_mb;
}



function fgpsn_time_logs_defaults() {
	$defaults = array( 	'title' => __( 'Time Logs', 'fgpsn-time-logger' ), );
	return $defaults;
}


function addTimeSheet(){
  global $wpdb;
  global  $current_user;
  $current_user = wp_get_current_user();

  $property = $_POST['selected_properties'];
  $unit = $_POST['selected_units'];
  $log_type = $_POST['cat'];
  $log_notes = $_POST['time_sheet_log_notes'];

  var_dump($_REQUEST);

  $_REQUEST["rechr"] = eregi_replace('[A-Z]|[a-z]','', $_REQUEST["rechr"]);
  $_REQUEST["recmn"] = eregi_replace('[A-Z]|[a-z]','', $_REQUEST["recmn"]);

    //$post_message .= "$rechr - $recmn.<BR>";

  $_REQUEST["rechr"] = $_REQUEST["rechr"]*3600;
  $_REQUEST["recmn"] = $_REQUEST["recmn"]*60;
    //$post_message .= "$rechr - $recmn.<BR>";

  $rec_time = ($_REQUEST["rechr"] +  $_REQUEST["recmn"]);
 

  $post = array(
      'post_author' => $current_user->ID,
      'post_date' => date('Y-m-d H:i:s'),
      'post_date_gmt' => date('Y-m-d H:i:s'),
      'post_content' => $log_notes,
      'post_title' => 'Time Sheet - WIdget',
      /*'post_name' => 'tenant-submitted-work-order',*/
      'post_excerpt' => '',
      'post_status' => 'publish',
      'comment_status' => 'closed',
      'ping_status' => 'closed',
      'post_modified' => date('Y-m-d H:i:s'),
      'post_modified_gmt' => date('Y-m-d H:i:s'),
      'post_parent' => 0,
      'post_type' => 'fgpsn_time_sheets',
      'comment_count' => 0
  );
    $wpdb->insert( 
      $wpdb->prefix . 'posts', 
      $post
      /*array( 
        'post_title' => 'Tenant Submitted Work Order', 
        'post_content' => $entry[3],
        'post_status' => 'publish',
        'post_type' => 'maintenance_requests',
        'post_author' => '1'
      )*/
    );
    $new_wo_id = $wpdb->insert_id;
    
    
  
    
    update_post_meta( $new_wo_id, 'fgpsn_time_sheet_selected_units', $unit );
    update_post_meta( $new_wo_id, 'fgpsn_time_sheet_selected_properties', $property );
    update_post_meta( $new_wo_id, 'fgpsn_time_sheet_total_time', $rec_time );
  die();
}
add_action('wp_ajax_addTimeSheet', 'addTimeSheet');
add_action('wp_ajax_nopriv_addTimeSheet', 'addTimeSheet');
/*
function fgpsn_send_time_logs( $smsfrom, $smsmessage, $message_id ) {

	global $wpdb;
	if ( !include_once( plugin_dir_path( __FILE__ ) . '/twilio/twilio-php/Services/Twilio.php' ) )
	{

	echo "<H3>Why Not! - " .plugin_dir_path( __FILE__ ) . 'twilio/twilio-php/Services/Twilio.php - </H3>';

	}

	$sid = "AC73f31202e64ac545fcf2b96d0a3a7b73";
	$token = "{{ a7da0165d7ed912c85460a01c7c38454 }}";
	$client = new Services_Twilio($sid, $token);

   $http = new Services_Twilio_TinyHttp(
		        'https://api.twilio.com',
		        array('curlopts' => array(CURLOPT_SSL_VERIFYPEER => false))
		    );

    $client = new Services_Twilio('AC73f31202e64ac545fcf2b96d0a3a7b73', 'a7da0165d7ed912c85460a01c7c38454', '2010-04-01', $http);

    //$message = $client->account->messages->get($message_id);

	$smsfrom = '+1' . $smsfrom;
	$smsto = '+1' . $smsto;
	$smsto = '+16172717634';
	$sms = $client->account->sms_messages->create($smsfrom, $smsto, $smsmessage, array());
	//echo "<H1>Reply to: " . $message->body . ", " . $message_id . "</H1>";

	echo $sms->sid;

	if ($echo)
		echo $postlist;
	else
		return $postlist;
}

if ( isset($_POST[sendsms]) || isset($_REQUESST[sendsms]) || isset($_GET[sendsms]) ) {

	fgpsn_send_time_logs($_GET['smsfrom'], $_GET['message_reply'], $_GET['message_id'] );
}*/

?>
