<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @since 3.0.0
 */
get_header(); 
global $wpdb;

?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP

echo "<DIV><table id='example" . $properties[$i][blog_id] . "' class='display' cellspacing='0' width='100%'>
        <thead>
            <tr>
                <th>From</th>
                <th>Sibject</th>
                <th>Date</th>
                <th>View</th>
                <th>Close</th>
                
            </tr>
        </thead>";
        
 $args = array(
	'offset'           => 0,
	'post_type'        => 'maintenance_requests',
	'post_status'      => 'publish',
	'suppress_filters' => true );

	$maintenance_requests = get_posts( $args );

	foreach ($maintenance_requests as $maintenance_request) {
		
		echo "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $communication->ID . "'>" . $maintenance_request->post_title . "</A></TD>
				<TD>" . get_the_time('D j, Y', $maintenance_request->post_author) . "</TD>
				<TD>" . get_the_time('D j, Y', $maintenance_request->ID) . "</TD>
				<TD><A HREF=''>View</A></TD>
				<TD><A HREF=''>Close</A></TD></TR>";

	}
	echo '</table>';
	

?>

	</div><!-- #primary.c6 -->

<?php get_footer(); ?>
