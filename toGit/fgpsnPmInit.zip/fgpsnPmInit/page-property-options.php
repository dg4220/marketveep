<?php
/**
 * Template Name: Template Property Profile
 *
 * Allow users to update their profiles from Frontend.
 *
 */

get_header(); ?>

	<div id="primary" <?php mb_primary_attr(); ?> role="main">
		<?php
property_admin_init();
//property_setting_string();
//echo $disp_data;
		?>
	</div><!-- #primary.c8 -->

<?php get_footer(); ?>
