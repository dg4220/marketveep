<?PHP
//wp_enqueue_script( 'jquery' );fgpsn_comm_selected_units
/******************************************************
 * DG Creating Communications post type and meta boxes.
 * Include this in the designated PM site theme ONLY
 * The include allows posting messages to all sites in a network
 * Use inclCommPostTypeClient.php to allow property sites to post messages only to thier property
 * and designated residents, employees, management, vendors, etc.
*******************************************************/
function codex_custom_init() {
	$labels = array(
			'name'               => _x( 'Communications', 'post type general name' ),
			'singular_name'      => _x( 'Message', 'post type singular name' ),
			'add_new'            => _x( 'Create Message', 'property_comm' ),
			'add_new_item'       => __( 'Create New Message' ),
			'edit_item'          => __( 'Review Message' ),
			'new_item'           => __( 'New Message' ),
			'all_items'          => __( 'All Messages' ),
			'view_item'          => __( 'View Message' ),
			'search_items'       => __( 'Search Messages' ),
			'not_found'          => __( 'No Messages Found' ),
			'not_found_in_trash' => __( 'No Messages found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Communications'
		);
    $args = array(
      'description'   => 'Messaging and Property Communications',
			'public'        => true,
			'menu_position' => 5,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes','custom-fields','thumbnail' ),
			'taxonomies'      => array( 'message_types'  ),
			'hierarchical' => true,
			'has_archive'   => true,
      'labels'  => $labels
    );
    register_post_type( 'property_comm', $args );
}
add_action( 'init', 'codex_custom_init' );

/* add contact types taxonomy */
function create_message_types() {
 $labels = array(
    'name' => _x( 'Message Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Message Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Message Types' ),
    'all_items' => __( 'All Message Types' ),
    'parent_item' => __( 'Parent Message Type' ),
    'parent_item_colon' => __( 'Parent Message Type:' ),
    'edit_item' => __( 'Edit Message Type' ),
    'update_item' => __( 'Update Message Type' ),
    'add_new_item' => __( 'Add New Message Type' ),
    'new_item_name' => __( 'New Message Type Name' ),
  );

  register_taxonomy('message_types','property_comm',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

add_action( 'init', 'create_message_types' );

add_action( 'add_meta_boxes', 'selected_tenant_hmy' );
function selected_tenant_hmy() {

	$screens = array( 'property_comm' );
    foreach ($screens as $screen) {
		add_meta_box(
			'selected_tenant_hmy',
			__( 'Selected Recipients', 'myplugin_textdomain' ),
			'selected_tenant_hmy_content',
			$screen,
			'normal',
			'high'
		);
	}
}

function selected_tenant_hmy_content(){
	wp_nonce_field( plugin_basename( __FILE__ ), 'selected_tenant_hmy_content_nonce' );
	echo "<FIELDSET><DIV>
	
	Selected Tenants: <br>";
	echo get_post_meta(get_the_ID(), 'selected_tenant_hmy', true );
	echo "</DIV></FIELDSET>";

}

add_action( 'add_meta_boxes', 'property_list' );
function property_list() {

	$screens = array( 'property_comm' );
    foreach ($screens as $screen) {
		add_meta_box(
			'property_list',
			__( 'Select Properties', 'myplugin_textdomain' ),
			'property_list_content',
			$screen,
			'normal',
			'high'
		);
	}
}


function property_list_content( $post ) {

	global $wpdb;

	wp_nonce_field( plugin_basename( __FILE__ ), 'property_list_content_nonce' );
	$cur_property_list = get_post_meta( get_the_ID(), 'fgpsn_comm_selected_properties', true );
	$cur_groups_list = get_post_meta( get_the_ID(), 'selected_groups', true );
	$cur_string = get_post_meta( get_the_ID(), 'first_string', true );
	$test_output = get_post_meta( get_the_ID(), 'test_output', true );

	   foreach($cur_property_list as $k => $v ) {
		   $prop_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
		   $prop_array[] = $v;
	   }
	   foreach($cur_groups_list as $k => $v ) {
		   $group_string .= 'Key: ' . $k . '; Value ' . $v . '<BR>';
		   $group_array[] = $k;
	   }
	echo "<FIELDSET><DIV>
	<DIV class='right_half' STYLE='display: inine; float: left; width: 45%;'>
	Select Properties:
	<select MULTIPLE SIZE=8 name=fgpsn_comm_selected_properties[] class='property'>";

	$args = array(
			'network_id' => $wpdb->siteid,
			'public'     => null,
			'archived'   => null,
			'mature'     => null,
			'spam'       => null,
			'deleted'    => null,
			'limit'      => 100,
			'offset'     => 0,
			);
			$property_ids = wp_get_sites( $args );
			$property_ct = count( $property_ids);
			echo '<OPTION> -- Select Properties -- </OPTION>';
			foreach ($property_ids as $k=>$v) {
				$blog_details = get_blog_details($k, true);
				echo '<OPTION value= ' . $blog_details->blog_id;
				   if ( in_array($blog_details->blog_id, $prop_array) ) {
					   echo ' selected';
				   }
				   echo '>' . $blog_details->blogname . ' - ' . $blog_details->blog_id . '</OPTION>';
			}
	echo "</select> </DIV>
	<DIV class='right_half' STYLE='display: inine; float: left; width: 45%;'>
		Select Recipient Groups:";

	$categories = get_terms( 'contact_data_types', array(
		'orderby'    => 'count',
		'hide_empty' => 0
	 ) );

	 if ( !empty( $categories ) && !is_wp_error( $categories ) ){
     echo "<ul>";
     foreach ( $categories as $category ) {
       echo "<input type='checkbox' name=fgpsn_comm_recip_group[$category->term_id] id=fgpsn_comm_recip_group[]";
       if ( in_array($category->term_id, $group_array) ) {
		   echo " checked";
	   }
       echo ">" . $category->name . " - " . $category->term_id . "<BR>";

     }
     echo "</ul>";
	}
 echo "<H4>Properties: " . $prop_string . "</H4>
	   <H4>Groups: " . $group_string . "</H4>
	   <H4>STRING: " . $cur_string . "</H4>
	   <H4>Output: " . $test_output . "</H4>";
	echo "</DIV>
	   </FIELDSET>";

	 
	
}


//add_action( 'save_post', 'property_list_save' );
function property_list_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['property_list_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}

	$fgpsn_comm_selected_properties = $_POST['fgpsn_comm_selected_properties'];
	$selected_groups = $_POST['fgpsn_comm_recip_group'];
	$first_string = '<H1>SP: ' . $fgpsn_comm_selected_properties . ' - ' . $selected_groups[0] . '</H1>';

	/*need to get users/contacts for selected 'properties' and in the selected groups
	 * if there's no group is selected send to all active users? or require group selection?
	 */
	$test_output =  "";
	foreach ( $fgpsn_comm_selected_properties as $k=>$v ) {
		global $switched;
		switch_to_blog($v); //switched to 1 & 2 but only 1 working

		//Get latest Post

		$args = array(
		'offset'           => 0,
		'category'         => $selected_groups,
		'orderby'          => 'post_title',
		'meta_key'         => '',
		'meta_value'       => '',
		'post_type'        => 'contact_data',
		'post_status'      => 'publish',
		'suppress_filters' => true );

		$recipients = get_posts( $args );
		//echo '<H1>' . $property_ids . ' -- Select Properties -- ' . $wpdb->last_query . '</H1>';
		$property_ct = count( $property_ids);
		//echo '<OPTION> -- Select Properties -- </OPTION>';
		$recip_opt = array();
		$blog_details = get_blog_details($k, true);
		$cur_property = $blog_details->blogname;
		echo "<H3>" . $cur_property . "</H3>";
		foreach ($recipients as $recipient) {
			$recip_email = get_post_meta($recipient->ID, 'client_email', true);
			$recip_opt = 'Recipient: ' . $recipient->post_title;
			echo "<H3>" . $recip_opt . " - " . $recip_email . "</H3>";
		}
		//$new_comm = wp_insert_post( $_POST, $wp_error );
				$my_post = array(
				  'post_title'    => 'My post',
				  'post_content'  => 'This is my post.',
				  'post_status'   => 'publish',
				  'post_author'   => 1
				);

				// Insert the post into the database
				//$new_comm = wp_insert_post( $my_post );

		 echo "<H3>Line 198 Insert Result: " . $new_comm . " - Post array: " . $_POST . " - WP Error: " . $fgpsn_comm_selected_properties[0] . "</H3>";
		 $post_item = '';
		 foreach( $_POST as $pk=>$pv ) {
			 //$post_item .= 'Key: ' . $pk . '; Value: ' . $pv . '<BR>';
		 }
		 $test_output .= "<H3>Line 198 Insert Result: " . $new_comm . " - Post Items: " . $post_item . " - WP Error: " . $wp_error . "</H3>";
	}






	restore_current_blog(); //switched back to main site


	/*need to add communicatons log to main PM site to track recipients across network*/

	update_post_meta( $post_id, 'fgpsn_comm_selected_properties', $fgpsn_comm_selected_properties );
	update_post_meta( $post_id, 'selected_groups', $selected_groups );
	update_post_meta( $post_id, 'first_string', $first_string );
	update_post_meta( $post_id, 'test_output', $test_output );

	if ( ! wp_is_post_revision( $post_id ) ){

		// unhook this function so it doesn't loop infinitely
		remove_action('save_post', 'property_list_save');

		// update the post, which calls save_post again
		wp_update_post( $my_post );

		// re-hook this function
		add_action('save_post', 'property_list_save');
	}

}


add_action('admin_init', 'fgcomm_add_meta_boxes', 1);
function fgcomm_add_meta_boxes() {
	add_meta_box( 'repeatable-fields',
				'Set Reminders',
				'fgcomm_repeatable_meta_box_display',
				'property_comm',
				'normal',
				'default');
}

function fgcomm_repeatable_meta_box_display() {
	global $post;
	//$repeatable_fields = get_post_meta($post->ID, 'repeatable_fields', true);
	$cur_reminders = get_post_meta(get_the_ID(), 'fg_document_reminder', true);
	$cur_doc_url = get_post_meta(get_the_ID(), 'property_doc_file', true);
	//$options = fgcomm_get_sample_options();

	wp_nonce_field( 'fgcomm_repeatable_meta_box_nonce', 'fgcomm_repeatable_meta_box_nonce' );
	?>
	<FIELDSET><div><script type="text/javascript">
	jQuery(document).ready(function( $ ){
		jQuery( '#add-row' ).on('click', function() {
			var row = $( '.empty-row.screen-reader-text' ).clone(true);
			row.removeClass( 'empty-row screen-reader-text' );
			row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
			return false;
		});

		jQuery( '.remove-row' ).on('click', function() {
			$(this).parents('tr').remove();
			return false;
		});
	});
	</script>
	<table id="repeatable-fieldset-one" width="100%">
	<thead>
		<TR>
			<TH>Reminder Notes:</TH>
			<TH>Date</TH>
			<TH>Delete</TH>
		</TR>
	</thead>
	<tbody>
	<?php

	if ( $cur_reminders ) :

	$recip_ct = 1;
	foreach ( $cur_reminders as $cur_reminder ) {
	?>
     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
		<TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />


					<OPTION value=""> - Select - </OPTION>\n

					<?PHP

					$args = array(
						'fields'       => 'all'
						 );
				$blogusers = get_users( $args );
				foreach ($blogusers as $user) {
					if ( $user->user_email != '' ) {
						echo "<OPTION value='" . $user->user_email . "'";

									if ($cur_reminder[fg_document_reminder_cc] == $user->user_email) {
										echo "selected";
									}


						echo ">" .  $user->user_email  . "</OPTION>\n";
					}
   				}

          echo '</SELECT>';
		?>
     	</TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
	<?php
	$recip_ct++;
	}
	else :
	// show a blank one
	?>

     <TR>
     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminder[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminder[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
		<TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />

					<OPTION value=""> - Select - </OPTION>\n
					<?PHP
					$args = array(
						'fields'       => 'all'
						 );
							$blogusers = get_users( $args );
							foreach ($blogusers as $user) {
								if ( $user->user_email != '' ) {
									echo "<OPTION value='" . $user->user_email . "'>" .  $user->user_email  . "</OPTION>\n";
								}
							}

					  echo '</SELECT>';
					?>
     	</TD>
		<td><a class="button remove-row" href="#">Remove</a></td>
	</tr>
<?PHP $recip_ct++; ?>
	<?php

	endif; ?>

	<!-- empty hidden one for jQuery -->
	<tr class="empty-row screen-reader-text">

     	<TD><textarea id="fg_document_reminder_notes" name="fg_document_reminder_notes[]"  /><?PHP echo $cur_reminders[fg_document_reminder_notes]; ?></TEXTAREA></TD>
     	<TD>
     	<INPUT TYPE=text NAME="fg_document_reminder_date[]" VALUE="<?PHP echo $cur_reminders[fg_document_reminder_date]; ?>" ID="fg_document_reminder_date">
     	<INPUT TYPE=hidden NAME="fg_document_reminder_url[]" VALUE="<?PHP echo $cur_doc_url[url]; ?>" ID="fg_document_reminder_url"></TD>
 <TD valign=top>
     	     	<SELECT MULTIPLE SIZE=5 id="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>" name="fg_document_reminder_cc_<?PHP echo $recip_ct; ?>[]"  />

					<OPTION value=""> - Select - </OPTION>\n

					<?PHP

					$args = array(
						'fields'       => 'all'
						 );
				$blogusers = get_users( $args );
				foreach ($blogusers as $user) {
					if ( $user->user_email != '' ) {
						echo "<OPTION value='" . $user->user_email . "'>" .  $user->user_email  . "</OPTION>\n";
					}
   				}

          echo '</SELECT>';

		?>
     	</TD>
     	<?PHP $recip_ct++; ?>
		<td><a class="button remove-row" href="#">Remove</a></td>

	</tr>
	</tbody>
	</table>

	<p><a id="add-row" class="button" href="#">Add another</a></p></DIV></FIELDSET>
	<?php
}

//add_action('save_post', 'fgcomm_repeatable_meta_box_save');
function fgcomm_repeatable_meta_box_save($post_id) {

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;

	if (!current_user_can('edit_post', $post_id))
		return;

	$old = get_post_meta($post_id, 'fg_document_reminder', true);
	$new = array();
	$reminder_notes = $_POST['fg_document_reminder_notes'];
	$reminder_dates = $_POST['fg_document_reminder_date'];
	$reminder_url = $_POST['fg_document_reminder_url'];

	$count = count( $reminder_notes );
	for ( $i = 1; $i <= $count; $i++ ) {

		$reminder_cc[$i] = $_POST['fg_document_reminder_cc_' . $i];
		//echo "<H3>CC array? " . $reminder_cc[$i] . "</H3>";
		//foreach($reminder_cc[$i] as $k=>$v) {
			//echo "<LI>CC Items? " . $k . " - " . $v . "</LI>";

		//}

	}
	for ( $i = 0; $i < $count; $i++ ) {
		if ( $reminder_notes[$i] != '' ) {
			$new[$i]['fg_document_reminder_notes'] = stripslashes( strip_tags( $reminder_notes[$i] ) );
		}
		if ( $reminder_dates[$i] != '' ) {
			$new[$i]['fg_document_reminder_date'] = $reminder_dates[$i];
		}
		if ( $reminder_url[$i] != '' ) {
			$new[$i]['fg_document_reminder_url'] = $reminder_url[$i];
		}
		if ( $reminder_cc[$i] != '' ) {
			$new[$i]['fg_document_reminder_cc'] = $reminder_cc[$i];
		}


	}

	if ( !empty( $new ) && $new != $old ) {
		update_post_meta( $post_id, 'fg_document_reminder', $new );
	} elseif ( empty($new) && $old ) {
		delete_post_meta( $post_id, 'fg_document_reminder', $old );
	}
}


//custom admin table for communications

function change_property_comm_pt_columns( $cols ) {
  $cols = array(
    'cb'       => '<input type="checkbox" />',
    'post_title'     => __( 'Subject', 'trans' ),
    'post_author'     => __( 'From', 'trans' )
  );
  return $cols;
}
add_filter( "manage_property_comm_posts_columns", "change_property_comm_pt_columns" );

function custom_columns( $column, $post_id ) {

  $contact_first_name = get_post_meta($post_id, 'recipient_contact_first_name', true);
  $contact_last_name = get_post_meta($post_id, 'recipient_contact_last_name', true);
  $contact_phone = get_post_meta($unit_occupant_ids, 'client_phone', true);
  $contact_cell = get_post_meta($unit_occupant_ids, 'client_cell', true);
  $contact_email = get_post_meta($unit_occupant_ids, 'client_email', true);

  $unit_cpt_cols[unit_sqft_cst] = 12 * ( number_format( $unit_cpt_cols[unit_sqft_cst], 2, '.', '' ) );

  switch ( $column ) {
    case "unit_monthly_rent":
      echo $unit_cpt_cols[unit_rent_amt_month] . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;

   case "unit_sqft":
      echo $unit_cpt_cols[unit_sqft] . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;
    case "unit_cst_sqft":
      echo $unit_cpt_cols[unit_sqft_cst];
      break;

    case "unit_number":
    $unit_number = get_post_meta(get_the_ID(), 'unit_number', true);
      echo $unit_number . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;

    case "unit_title":
    $unit_title = get_the_title(get_the_ID());
      echo $unit_title . "<BR>";
      edit_post_link('edit', '<p>', '</p>');
      break;

    case "occupant":
      echo $contact_first_name . " " . $contact_last_name;
      echo "<BR>Phone: " . $contact_phone;
      echo "<BR>Cell: " . $contact_cell;
      echo "<BR>Email: " . $contact_email;
      break;

     default:
      //echo "<H1>Default: " . $column . " - " . $post_id . "</H1>";
      break;
  }
}

add_action( "manage_property_comm_posts_custom_column", "custom_columns", 10, 2 );

// Make these columns sortable
function sortable_columns() {
  return array(
    /*'unit_monthly_rent'      => 'unit_monthly_rent',
    'unit_sqft' => 'unit_sqft',
    'unit_cst_sqft' => 'unit_cst_sqft',
    'unit_number' => 'unit_number',
    'occupant'     => 'occupant'
    */
    'date' => 'date',
    'message_types' => 'message_types'
    
  );
}

add_filter( "manage_edit-property_comm_sortable_columns", "sortable_columns" );

/****************************************************************************************/


//set up the communications archive/search shortcode

function get_archived_communications( $atts ){

	global $user;
	global $wpdb;
		/* set up search forms */

	$archive_results = "<table class='catalog_table' width='100%'>
		<thead><TR>
		<TH><form method='get' action='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "'>
		Search for <input type='text' name='q' value='" . $_GET['q']  . "' />
		Within

		<input type='submit' value='Search' />
		</form></TH>
		</TR>
		</thead></table>";
	$fg_vend_search_query = (empty($_GET['q'])) ? 'Nada.' : urldecode($_GET['q']);

	$results = new WP_Query();
	if( ! empty($_GET['q']) ) {
		$query_args = array(
			'post_type'=>'property_comm',
			'number_posts'=>-1,
			's'=>$_GET['q'],
		);

		$results = new WP_Query($query_args);
	}


	if($results->have_posts()) {

		while ( $results->have_posts() ) : $results->the_post();

			//$subject = get_post_meta(get_the_id(), 'emp_phone', true);

			$archive_results .= "<TABLE><TR><TD><a href='http://www.ptechinternational.com/ptiMulti/hill-condominium/addedit-communications/?gform_post_id=" . get_the_id() . "'>" . get_the_title() . "</A></TD>
			<TD>" . get_the_date() . "</TD>
			<TD>" . $client_phone . "</TD>
			<TD><a href='http://www.ptechinternational.com/ptiMulti/hill-condominium/addedit-communications/?select_recipients=" . get_the_id() . "'>" . $client_email . "</A></TD>
			</TR></TABLE>";

		endwhile;


	} else {

		$month = date( 'M' );
		$year = date( 'Y' );
		$query = new WP_Query( 'year=' . $year . '&w=' . $week );

	}
	echo $archive_results;
	fg_dashboard_prop_comms();
}
add_shortcode( 'communications_archives', 'get_archived_communications' );

// Add to admin_init function
add_filter('manage_edit-property_comm_columns', 'add_edit_property_comm_columns');

function add_edit_property_comm_columns($property_comm_columns) {
    $new_columns['cb'] = '<input type="checkbox" />';
    $new_columns['title'] = _x('Subject', 'column name');
    $new_columns['author'] = __('From');
    $new_columns['message_types'] = __('Message Type');
    $new_columns['date'] = _x('Date', 'column name');

    return $new_columns;
}


add_action('manage_property_comm_posts_custom_column', 'manage_property_comm_columns', 10, 2);

function manage_property_comm_columns($column_name, $id) {
    global $wpdb;
    switch ($column_name) {
    case 'id':
        echo $id;
            break;

    case 'message_types':
        // Get number of images in gallery
        $terms = wp_get_post_terms( $id, 'message_types' );
        foreach($terms as $term) {
        echo 'Communication Type: ' . $term->name;
        }

        break;
    default:
        break;
    } // end switch
}


//transfer communications by switch post type

//add_action( 'add_meta_boxes', 'switch_comm_type' );
function switch_comm_type() {

	$screens = array( 'property_comm' );
    foreach ($screens as $screen) {
		add_meta_box(
			'switch_comm_type',
			__( 'Assign to a New Department', 'myplugin_textdomain' ),
			'switch_comm_type_content',
			$screen,
			'side',
			'high'
		);
	}
}


function switch_comm_type_content( $post ) {

	global $wpdb;
	wp_nonce_field( plugin_basename( __FILE__ ), 'switch_comm_type_content_nonce' );
	
	echo "<FIELDSET><DIV>
	<DIV>
	Send To:
	<select name=assigned_post_type class='assign_type'>";
	$post_types = get_post_types( '', 'names' ); 

	foreach ( $post_types as $post_type ) {
		$item_value = sanitize_title( $post_type, 'post' );
		echo "<OPTION value='" . $item_value . "'>" . $post_type . "</OPTION>";
	}
	
	echo "</select> </DIV>
	
	   </FIELDSET>";
}


//add_action( 'save_post', 'switch_comm_type_save' );
function switch_comm_type_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['switch_comm_type_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
	$my_post = array(
      'ID'           => $post_id,
      'post_type' => $_POST['assigned_post_type']
	);

	// Update the post into the database
	//wp_update_post( $my_post );
	$type=  get_post_type();

    switch ($type){
    case "post":
        $url=  admin_url().'edit.php?msg=post';
        wp_redirect($url);
        exit;
    break;
    case "maintenance_requests":
        $url=  admin_url().'edit.php?post_type=maintenance_requests&msg=page';
        wp_redirect($url);
        exit;
    break;
    case "page":
        $url=  admin_url().'edit.php?post_type=page&msg=page';
        wp_redirect($url);
        exit;
    break;
    }

	if ( ! wp_is_post_revision( $post_id ) ){

		// unhook this function so it doesn't loop infinitely
		remove_action('save_post', 'switch_comm_type_save');

		// update the post, which calls save_post again
		wp_update_post( $my_post );

		// re-hook this function
		add_action('save_post', 'switch_comm_type_save');
	}



}


function sendGridTest() {


echo "<h1>cocococ" . plugin_dir_path(__FILE__) . "sendgrid-php/vendor/autoload.php" . "</h1>";
require( plugin_dir_path(__FILE__) . "sendgrid-php/vendor/autoload.php" );
$sendgrid = new SendGrid("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");
$email    = new SendGrid\Email();

$email->addTo("dgannon@fgpsn.com")
      ->setFrom("dgannon@fgpsn.com")
      ->setSubject("Sending From fgpns")
      ->setHtml("and easy to do anywhere, even with PHP");

$sendgrid->send($email);
}
if ( $_GET['sendgrid'] == true ) {
//sendGridTest();

}
?>
