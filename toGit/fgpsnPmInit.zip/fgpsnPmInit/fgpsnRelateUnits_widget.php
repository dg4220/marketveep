<?PHP

class fgpsn_related_unit_data extends WP_Widget {

	function fgpsn_related_unit_data() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-related-unit-data', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows unit data relative to the current post or page. Such as contacts, vendors, or warranties alongside a work order.', 'fgpsn-related-unit-data' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnrelatedunitdata', __( 'Related Unit Data', 'fgpsn-related-unit-data' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );


		$parameters = array(
				'title' 	=> $title,
				'fgpsn_wo_vendors' 	=> $instance[ 'fgpsn_wo_vendors'],
				'fgpsn_wo_show_map' 	=> $instance[ 'fgpsn_show_wo_map'],
				'fgpsn_wo_contacts' 	=> $instance[ 'fgpsn_wo_contacts'],
			);

		if ( !empty( $title ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}

        //print recent posts
		fgpsn_get_related_unit_data($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['fgpsn_wo_vendors'] = $new_instance['fgpsn_wo_vendors'];
		$instance['fgpsn_wo_show_map'] = $new_instance['fgpsn_wo_show_map'];
		$instance['fgpsn_wo_contacts'] = $new_instance['fgpsn_wo_contacts'];
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsn_text_alert_defaults() );

		$title 		= esc_attr($instance['title']);
		$api_key 	= $instance['fgpsn_wo_vendors'];
		$fgpsn_wo_show_map = $instance['fgpsn_wo_vendors'];
		$fgpsn_wo_contacts 	= $instance['fgpsn_wo_contacts'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('fgpsn_wo_vendors'); ?>"><?php _e('Show Vendors');?>
				<input class="widefat" id="<?php echo $this->get_field_id('api_key'); ?>" name="<?php echo $this->get_field_name('fgpsn_wo_vendors'); ?>" type="checkbox" value="1"><?php echo $fgpsn_wo_vendors; ?> />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('fgpsn_wo_show_map'); ?>"><?php _e('Show On Map');?>
				<input class="widefat" id="<?php echo $this->get_field_id('fgpsn_wo_show_map'); ?>" name="<?php echo $this->get_field_name('fgpsn_wo_show_map'); ?>" type="checkbox" value="1"><?php echo $fgpsn_wo_show_map; ?> />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('fgpsn_wo_contacts'); ?>"><?php _e('Show Vendors');?>
				<input class="widefat" id="<?php echo $this->get_field_id('fgpsn_wo_contacts'); ?>" name="<?php echo $this->get_field_name('fgpsn_wo_contacts'); ?>" type="checkbox" value="1"><?php echo $fgpsn_wo_contacts; ?> />
			</label>
		</p>

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_related_unit_data");') );


function fgpsn_get_related_unit_data($args = '', $echo = true) {

	global $wpdb;
	$defaults = fgpsn_text_alert_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);


    $postlist = '<FORM NAME="replytosms" action="' . network_home_url() . '?property_id=' . $_REQUEST['property_id'] . '">';

    $postlist .= '<div>';

    //first get contacts related to wo units and wos
    //start by doing this for singles

    $filtered_messages = get_posts('post_type' => 'maintenance_request');
    



    foreach($filtered_messages as $post) {
		
		$clip = the_title();
		$clip1 = get_posted_date();
		$postlist .= '<div><p>';
    	$postlist .= $clip;
    	if ($clip1 != '') {
			$postlist .= '<a class="read-more-show hide" href="#"> . . . Continue</a><span class="read-more-content"> ';
			$postlist .= $clip1;
			$postlist .= '<br><a class="read-more-hide hide" href="#">Show Less</a></span>';
		}
    	
    	$postlist .= '</p>';
		$postlist .= '</div>';
		$smsfrom = str_replace( '+', '', $message->from );

		$smssenders = get_users(array('meta_key' => 'contact_phone', 'meta_value' => $smsfrom, 'meta_compare' => 'like' ));

		$use_query = "SELECT user_id FROM fgpsn_usermeta
						WHERE (meta_key = 'client_phone'
						AND meta_value = '" . $smsfrom . "')
						OR(meta_key = 'contact_phone'
						AND meta_value = '" . $smsfrom . "')
						;";
		$use_ids = $wpdb->get_results($use_query, OBJECT);
		foreach( $use_ids as $use_id ) {
			$smssender = get_user_meta($use_id->user_id, 'nickname', true);
		}
		if ( !$smssender ){
			$postlist .= '<div class="sms-message-details">Unknown Sender: ' . $smssender;
		} else {

		$postlist .= '<div class="sms-message-details">
    					From: ' . $smssender;
		}
		$postlist .= ' <INPUT class="sms-message-details" TYPE="radio" NAME="message_id" VALUE="';
		$postlist .= $message->sid . '"></div>';

	}


	$postlist .= 'This area can be configured with a texting service that displays incoming texts whhich are routed to that property manager. You can also rely directly from the web page using any device. There is no need to use a text message application. <div class="sms-message-form">
	<INPUT TYPE="text" NAME="message_reply" style="width: 98%;"
	VALUE="Reply to selected message">

		<input type=hidden name=sendsms value=true>
		<input type=hidden name=smsfrom value="6174335875">
		<input type="Submit" name="submit" value="Send">';

		$postlist .= '</div></div>
	</FORM>';

	if ($echo)
		echo $postlist;
	else
		return $postlist;
}





?>
