<?PHP
/*set up Property Manager Dashboard*/


/*first check for any updates from the dash*/
	
if ( isset( $_GET['send_to_maint'] ) ) {
	
	update_post_meta( $_GET['ID'], 'work_order_status', $_GET['work_order_status']);
	//nextset post_status to new
	$my_post = array(
      'ID'           => $_GET[ID],
      'post_status' => 'publish'
  );

// Update the post into the database
 // wp_update_post( $my_post );
}


function quickDoc() {
	global $wpdb;
	echo '<div class="input-text-wrap" id="title-wrap">
			<label class="screen-reader-text prompt" for="title" id="title-prompt-text">Title</LABEL>
			<input type="text" name="document_title" id="title" autocomplete="off" />';
			//wp_editor( $post->post_content, 'post_content' );

	echo '</div>

		<div class="textarea-wrap" id="description-wrap">
			<label class="screen-reader-text prompt" for="content" id="content-prompt-text">Document desctiption</label>
			<textarea name="doc_description" id="content" class="mceEditor" rows="4" STYLE="width: 95%;"></textarea>
		</div>
		<div class="multi-select" id="property_cc-select">
			<label class="screen-reader-text prompt" for="property_cc" id="property_cc-prompt-text">Select Properties:</label>
			<SELECT MULTIPLE SIZE=5>';
				$args = array(
								'network_id' => $wpdb->siteid,
								'public'     => null,
								'archived'   => null,
								'mature'     => null,
								'spam'       => null,
								'deleted'    => null,
								'limit'      => 100,
								'offset'     => 0,
							);
				$property_ids = wp_get_sites( $args );
				$property_ct = count( $property_ids);
				echo '<OPTION> -- Select Properties -- </OPTION>';
				foreach ($property_ids as $k=>$v) {
					$blog_details = get_blog_details($k, true);
					echo '<OPTION ID= ' . $k . '>' . $blog_details->blogname . '</OPTION>';
				}
			echo '</SELECT></div>';

}

function fg_dashboard_prop_comms() {
	if ( isset( $_GET['show_comm'] ) && $_GET['show_comm'] != '' ) {
		$display_comm = update_post_meta($_GET['pid'], 'cpm_dashboard_view', $_GET['show_comm'] );
		$show_cur_comm = false;
		unset($_GET['show_comm']);
		unset($_GET['pid']);
	}
	/*
	 * $args = array(
		'offset'           => 0,
		'orderby'          => 'post_title',
		'meta_key'         => '',
		'meta_value'       => '',
		'post_type'        => 'property_comm',
		'post_status'      => 'publish',
		'suppress_filters' => true );

		$communications = get_posts( $args );
	*/
		global $wpdb;
		global $table_prefix;
		global $currentuser;
/*
		echo "<DIV><table id='example" $properties[$i][blog_id] . "' class='display' cellspacing='1' width='100%'>
        <thead>
            <tr>
                <th>From</th>
                <th>Date</th>
                <th>Subject</th>
                <th>View</th>
                <th>Close</th>

            </tr>
        </thead>";
*/
       $disp_data .= "<div id='fg-maint_reqs-accordion'>Newest Incoming
       <H3>Term Name? <DIV STYLE='display: inline; position: relative; float: right; font-size: 70%; color: blue; padding-right: 20px; padding-top: 7px;'> Total: term count</DIV><DIV STYLE='display: inline; position: relative; float: right; font-size:  70%; color: blue; padding-right: 20px; padding-top: 7px;'> Most Recent:" . get_the_time('D j, Y', $term->ID) . "</DIV></H3>";
       
       $disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD>
       <TR><TH>From</TH>
       <TH>Subject</TH>
       <TH>Date</TH></TR></THEAD>
					<TBODY>";

    $get_comms = "SELECT post_author,
    					post_date,
    					ID,
    					post_title,
    					guid FROM " . $table_prefix . "posts
						WHERE post_type = 'property_comm'
						AND post_status = 'publish'
						AND id
						IN ( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'cpm_dashboard_view'
								AND meta_value <> '' AND meta_value <> 0 )";


	$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);

	if (is_array($cur_comms)) {
		//echo "<H4>Array!</H4>";
		foreach ($cur_comms as $k=>$v) {
			//echo "<H4>Array Row: " . $k . " - " . $v . "</H4>";
			foreach ($v as $kv=>$vV) {

				if ($kv == 'post_author') {
					$pc_from_info = get_userdata( $vV );
					$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
					$pc_from_email = $pc_from_info->user_email;
				}
				if ($kv == 'post_date') {
					$pc_from_date = $vV;
				}
				if ($kv == 'post_title') {
					$pc_from_subject = $vV;
				}
				if ($kv == 'ID') {
					$pc_original_id = $vV;
					//$comm_link = get_permalink($vV);
				}
				if ($kv == 'guid') {
					$pc_original_id = $vV;
					$comm_link = $vV;
				}

			}
			$disp_data .= "<tr><td>" . $pc_from_name . "</td>
				<td>" . $pc_from_subject . "</td>
				<td>" . $pc_from_date . "</td>";

				$href_url = get_admin_url() . 'index.php';

				$disp_data .= "</TR>";

		}
	} else {
		$this_var = gettype($cur_comms);
		$disp_data .= "<H4>Is: " . $this_var . "</H4>";
	}
	 $get_comms = "SELECT post_author,
							post_date,
							ID,
							post_title
							FROM " . $table_prefix . "posts
						WHERE post_type = 'property_comm'
						AND post_status = 'publish'
						AND id
							IN ( SELECT post_id
							FROM " . $table_prefix . "postmeta
							WHERE meta_key = 'cpm_dashboard_view'
							AND meta_value = ''
							OR meta_value = 0 )";
							
		$cur_comms = $wpdb->get_results( $get_comms, ARRAY_A);

		if (is_array($cur_comms)) {
		//echo "<H4>Array!</H4>";
		foreach ($cur_comms as $k=>$v) {
			//echo "<H4>Array Row: " . $k . " - " . $v . "</H4>";
			foreach ($v as $kv=>$vV) {

				if ($kv == 'post_author') {
					$pc_from_info = get_userdata( $vV );
					$pc_from_name = $pc_from_info->first_name . ' ' . $pc_from_info->last_name;
					$pc_from_email = $pc_from_info->user_email;
				}
				if ($kv == 'post_date') {
					$pc_from_date = $vV;
				}
				if ($kv == 'post_title') {
					$pc_from_subject = $vV;
				}
				if ($kv == 'ID') {
					$pc_original_id = $vV;
					$comm_link = get_permalink($vV);
				}

			}
			$disp_data .= "<tr><td>" . $pc_from_name . "</td>
				<td><A HREF='" . $href_url . "?show_comm=1&pid=". $pc_original_id . "'>" . $pc_from_subject . "</A></td>
				<td>" . $pc_from_date . "</td>";

				$href_url = get_admin_url() . 'index.php';

				$disp_data .= "</tr>";

		}
	} else {
		$this_var = gettype($cur_comms);
		$disp_data .= "<H4>Is: " . $this_var . "</H4>";
	}

	$disp_data .= "</tbody><tfoot>
            <tr>
                <th>From</th>
                <th>Date</th>
                <th>Subject</th>
                <th>Close</th>

            </tr>
        </tfoot>
    </table>
    </DIV>";
    echo $disp_data;
}

function recentDocs() {

	global $wpdb;
	global $table_prefix;

		$args = array(
			'post_type'        => 'property_doc',
			'taxonomy' => 'property_document_types',
			'include' => 0,
			'hide_empty'  		=> 1,
			'show_count'         => 1,
			'hierarchical'  => true,
			'order' => ASC);

		$terms = get_terms("property_document_types", $args);


		 $count = count($terms);
		 //echo '<H2>Query 228: ' . $wpdb->last_query . ', Count: ' . $count . '</H2>';
		 if ( $count > 0 ){
			 /* $disp_data .= "<ul class='no_bullets top'>"; */
			 $disp_data .= "<div id='fg-documents-accordion'>";
			 foreach ( $terms as $term ) {

				//now get terms where ID is parent
				/* $disp_data .= "<li class='level_1'><A HREF='"  . get_bloginfo('url') . "/property_document_types/" . $term->slug . "/'>" . $term->name . " (" . $term->count . ")</A>"; */

				$disp_data .= "<H3>" . $term->name . " <DIV STYLE='display: inline; position: relative; float: right; font-size: 70%; color: blue; padding-right: 20px; padding-top: 7px;'> Total: " . $term->count . "</DIV><DIV STYLE='display: inline; position: relative; float: right; font-size:  70%; color: blue; padding-right: 20px; padding-top: 7px;'> Most Recent:" . get_the_time('D j, Y', $term->ID) . "</DIV></H3>";
				$cur_slug = $term->slug;


			 /*trustees query
			 $args2 = array(
				'post_type'        => 'property_doc',
				'meta_key' =>  'set_group_document_access',
				'meta_value' => 'Trustee',
				'property_document_types' => $cur_slug,
				'hide_empty'  		=> 0,
				'hierarchical'  => true,
				'show_count'         => 1
				);
	*/
			/*general query*/
					 $args2 = array(
						'post_type'        => 'property_doc',
						'property_document_types' => $cur_slug,
						'hide_empty'  		=> 0,
						'hierarchical'  => true,
						'show_count'         => 1
						);

	//echo $disp_data . "<H3>LINE 265 - " . $cur_slug ."</H3>";

	$terms2 = get_posts($args2);
	//echo "<H3>LINE 265 - </H3>";


			 if ( is_wp_error( $terms2 ) ) {
			    $error_string = $terms2->get_error_message();
			    echo '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
	}
			 //$disp_data .= "<H3>LINE 256 - " . $terms2 ."</H3>";
			// echo $disp_data;
			  $count2 = count($terms2);
			  if ( $count2 > 0 ){
				 /* $disp_data .= "<ul class='no_bullets'>"; */

				//get user role - certain roles can edit document data
				if ( in_array('property_manager', $cur_role) ) {
					$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
					<TBODY>";
				} else {

				  $disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View - ";

	foreach($cur_role as $k=>$v) {
				   $disp_data .= $k . " -> " . $v . "<BR>";
				  }

				  $disp_data .= $cur_role . "</TH></TR></THEAD>
				  <TBODY>";


				  }
				  foreach ( $terms2 as $term2 ) {

					$cur_doc_file = get_post_meta($term2->ID, 'property_doc_file', true);
					if (is_array($cur_doc_file)) {

						$cur_file = $cur_doc_file[url];

					} else {

						$cur_file = $cur_doc_file;

					}
					$disp_data .= "<TR><TD><a href='http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "?fg_doc_id=" . $term2->ID . "'>" . $term2->post_title . "</A></TD>
					<TD>" . get_the_time('D j, Y', $term2->ID) . "</TD>
					<TD><A HREF='" . $cur_file . "' target='_blank'>View</A></TD>";
					if ( in_array('property_manager', $cur_role) ) {
						$disp_data .= "<TD><a href='http://www.ptechinternational.com/ptiMulti/hill-condominium/manage-documents/?gform_post_id=" . $term2->ID . "'>Edit</A></TD>";
					}
					$disp_data .= "</TR>";

				  }
				  $disp_data .= "</TABLE>";
			 }


			/* $disp_data .= "</li>"; */

			 }
			/* $disp_data .= "</ul>"; */
			$disp_data .= "</DIV>";
		 }
		 echo $disp_data;
	//return $disp_data;

}


/* dashboard workorder list */
function pendingWos() {
	
	global $wpdb;
	global $disp_data;
	$disp_data = '';
	global $table_prefix;	

	$get_wos_sql = "SELECT ID,
							post_title,
							post_date,
							post_status,
							post_author,
							post_date,
							post_excerpt
						FROM  " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND post_status = 'pending'
						OR ID IN
							( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'work_order_status' AND meta_value = 'In Review' )";
								
	$terms2 = $wpdb->get_results( $wpdb->prepare($get_wos_sql), OBJECT);

	if ( is_wp_error( $terms2 ) ) {
		$error_string = $terms2->get_error_message();
		$disp_data .= '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
	}
	
	// echo $disp_data;
	$count2 = count($terms2);
			  if ( $count2 > 0 ){
				 /* echo "<ul class='no_bullets'>"; */

				//get user role - certain roles can edit document data
				if ( in_array('property_manager', $cur_role) ) {
					$disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
					<TBODY>";
				} else {

				  $disp_data .= "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'>";

				  }
				  foreach ( $terms2 as $wos ) {
					  
					$user_info = get_userdata($wos->post_author);
					$first_name = $user_info->first_name;
					$last_name = $user_info->last_name;
					  
					$disp_data .= "<THEAD><TR><TH>" . $wos->post_title . "</TH>
					<TH>" . get_the_time('D j, Y', $wos->ID) . "</TH>
					<TH>" . $first_name . " " . $first_name . "</TH></TR></THEAD>
				  <TBODY>
				  <TR><TD COLSPAN=2>" . $wos->post_excerpt . "</TD><TD>";
					edit_post_link( 'View', '<DIV>', '</DIV>', $wos->ID );
					$disp_data .= "<DIV>
					<A HREF='?send_to_maint=TRUE&work_order_status=New&ID=" . $wos->ID . "'>Send To Maintenence</A></DIV>";
					
					$disp_data .= "</TD></TR></TBODY>";

				  }
				  $disp_data .= "</TABLE>";
			 }


			/* echo "</li>"; */

			 
			/* echo "</ul>"; */
			//$disp_data .= "</DIV>";
		 
		 //echo $disp_data;
	return $disp_data;
}
/* End dashboard work order list */

//gets 'new' work orders
function getNetworkWOsWidget( $property_id, $unit_id) {//for maint dashcboard, really
	global $wpdb;
	global $current_user;
	global $disp_wos;
	$disp_wos = '';
	get_currentuserinfo();
	$postid = get_the_ID();
				
	$args = array(
				'network_id' => $wpdb->siteid,
				'public'     => null,
				'archived'   => null,
				'mature'     => null,
				'spam'       => null,
				'deleted'    => null,
				'limit'      => 100,
				'offset'     => 0,
				);
							
	$property_ids = wp_get_sites( $args );
	$property_ct = count( $property_ids);
			
	foreach ($property_ids as $k=>$v) {
		foreach ($v as $k1=>$v1) {
			//echo '<LI>Array1: ' . $k1 . ' => ' . $v1 . '</LI>';
			if ($k1 == 'blog_id') {
				$blog_details = get_blog_details($v1, true);
				$user_query = new WP_User_Query( array( 'blog_id' => $v1 ) );
				// User Loop
				if ( ! empty( $user_query->results ) && $blog_details->blogname != '' ) {
					if ( in_array( $current_user->ID, $user_query->results) ) {
						/* $disp_data .= '<H4>
							<A HREF=?blog_id=' . $blog_details->blog_id . '>' . $blog_details->blogname . '</A></H4>';
							
						*/
						
						$table_prefix = "wp_" . $blog_details->blog_id . "_";
							$get_wos_sql = "SELECT ID,
													post_title,
													post_date,
													post_status,
													post_author,
													post_date,
													post_excerpt
												FROM  " . $table_prefix . "posts
												WHERE post_type = 'maintenance_requests'
												AND post_status = 'Pending'
												OR ID IN
								( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'work_order_status' AND meta_value = 'New' )";
								
						$terms2[$blog_details->blog_id] = $wpdb->get_results( $wpdb->prepare($get_wos_sql), ARRAY_A);


						if ( is_wp_error( $terms2[$blog_details->blog_id] ) ) {
							$error_string = $terms2->get_error_message();
							$disp_wos .= '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
						}
					}
				}
			}
		}	
	}
	$disp_wos .= '<DIV class="aside"><div id="message" class="error"><p>Array? Object? ';
	foreach($terms2 as $k=>$v) {
		$disp_wos .= '<P><B>Property ID' . $k . '</B></P>';
		foreach($v as $k1=>$v1) {	
			$disp_wos .= '<P>Key: ' . $k1 . ', Value: ' . $v1['post_title'] . '</p>';
		}	
	}
	$disp_wos .= '</div></DIV>';
	//$table_prefix = '';
	$get_wos_sql = "SELECT ID,
							post_title,
							post_date,
							post_status,
							post_author,
							post_date,
							post_excerpt
						FROM  " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND post_status = 'Pending'
						OR ID IN
							( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'work_order_status' AND meta_value = 'New' )";
								
	$terms2 = $wpdb->get_results( $wpdb->prepare($get_wos_sql), OBJECT);

	if ( is_wp_error( $terms2 ) ) {
		$error_string = $terms2->get_error_message();
		//echo '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
	}
	
	// echo $disp_data;
	$count2 = count($terms2);
			  if ( $count2 > 0 ){
				 /* echo "<ul class='no_bullets'>"; */

				//get user role - certain roles can edit document data
				if ( in_array('property_manager', $cur_role) ) {
					//echo "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD><TBODY>";
				} else {

				  //echo "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'>";

				  }
				  foreach ( $terms2 as $wos ) {
					  
					$user_info = get_userdata($wos->post_author);
					$first_name = $user_info->first_name;
					$last_name = $user_info->last_name;
					  
					/*echo "<THEAD><TR><TH>" . $wos->post_title . "</TH>
					<TH>" . get_the_time('D j, Y', $wos->ID) . "</TH>
					<TH>" . $first_name . " " . $first_name . "</TH></TR></THEAD>
				  <TBODY>
				  <TR><TD COLSPAN=2>" . $wos->post_excerpt . "</TD><TD>";
					edit_post_link( 'View', '<DIV>', '</DIV>', $wos->ID );
					echo "<DIV>
					<A HREF='?send_to_maint=TRUE&work_order_status=New&ID" . $wos->post_title . "'>Send To Maintenence</A></DIV>";
					
					echo "</TD></TR></TBODY>";
					*/
				  }
				  //echo "</TABLE>";
			 }


			/* echo "</li>"; */

			 
			/* echo "</ul>"; */
			//echo "</DIV>";
		 
		 //echo $disp_wos;
	return $disp_wos;
}

//gets 'new' work orders
function assignedWos() {//for wos filtered by employee
	
	global $wpdb;
	global $current_user;
      get_currentuserinfo();
	global $table_prefix;
	
	$get_wos_sql = "SELECT ID,
							post_title,
							post_date,
							post_status,
							post_author,
							post_date,
							post_excerpt
						FROM  " . $table_prefix . "posts
						WHERE post_type = 'maintenance_requests'
						AND ( post_status = 'Assigned'
						OR ID IN
							( SELECT post_id
								FROM " . $table_prefix . "postmeta
								WHERE meta_key = 'assigned_staff' AND meta_value = $current_user->ID ) 
								
								OR post_status = 'Publish')";
								
	$terms2 = $wpdb->get_results( $wpdb->prepare($get_wos_sql), OBJECT);

	if ( is_wp_error( $terms2 ) ) {
		$error_string = $terms2->get_error_message();
		echo '<div id="message" class="error"><p>ERROR ' . $error_string . '</p></div>';
	}
	
	// echo $disp_data;
	$count2 = count($terms2);
			  if ( $count2 > 0 ){
				 /* echo "<ul class='no_bullets'>"; */

				//get user role - certain roles can edit document data
				if ( in_array('property_manager', $cur_role) ) {
					echo "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'><THEAD><TR><TH>Title</TH><TH>Date</TH><TH>View</TH><TH>Edit</TH></TR></THEAD>
					<TBODY>";
				} else {

				  echo "<TABLE STYLE='margin-top: 0px; padding-top: 0px; width: 100%;'>";

				  }
				  foreach ( $terms2 as $wos ) {
					  
					$user_info = get_userdata($wos->post_author);
					$first_name = $user_info->first_name;
					$last_name = $user_info->last_name;
					  
					echo "<THEAD><TR><TH>" . $wos->post_title . "</TH>
					<TH>" . get_the_time('D j, Y', $wos->ID) . "</TH>
					<TH>" . $first_name . " " . $first_name . "</TH></TR></THEAD>
				  <TBODY>
				  <TR><TD COLSPAN=2>" . $wos->post_excerpt . "</TD><TD>";
					edit_post_link( 'View', '<DIV>', '</DIV>', $wos->ID );
					echo "<DIV>
					<A HREF='?send_to_maint=TRUE&work_order_status=New&ID" . $wos->post_title . "'>Send To Maintenence</A></DIV>";
					
					echo "</TD></TR></TBODY>";

				  }
				  echo "</TABLE>";
			 }


			/* echo "</li>"; */

			 
			/* echo "</ul>"; */
			echo "</DIV>";
		 
		 //echo $disp_data;
	//return $disp_data;
}
/* End dashboard work order list */


function fg_dashboard_quick_press( $error_msg = false ) {
	global $post_ID;

	/* Check if a new auto-draft (= no new post_ID) is needed or if the old can be used */
	$last_post_id = (int) get_user_option( 'dashboard_quick_press_last_post_id' ); // Get the last post_ID
	if ( $last_post_id ) {
		$post = get_post( $last_post_id );
		if ( empty( $post ) || $post->post_status != 'auto-draft' ) { // auto-draft doesn't exists anymore
			$post = get_default_post_to_edit( 'post', true );
			update_user_option( get_current_user_id(), 'dashboard_quick_press_last_post_id', (int) $post->ID ); // Save post_ID
		} else {
			$post->post_title = ''; // Remove the auto draft title
		}
	} else {
		$post = get_default_post_to_edit( 'post' , true);
		$user_id = get_current_user_id();
		// Don't create an option if this is a super admin who does not belong to this site.
		if ( ! ( is_super_admin( $user_id ) && ! in_array( get_current_blog_id(), array_keys( get_blogs_of_user( $user_id ) ) ) ) )
			update_user_option( $user_id, 'dashboard_quick_press_last_post_id', (int) $post->ID ); // Save post_ID
	}

	$post_ID = (int) $post->ID;
?>

	<form name="post" action="<?php echo esc_url( admin_url( 'post.php' ) ); ?>" method="post" id="network-quick-press" class="initial-form hide-if-no-js">

		<?php if ( $error_msg ) : ?>
		<div class="error"><?php echo $error_msg; ?></div>
		<?php endif; ?>

		<div class="input-text-wrap" id="title-wrap">
			<label class="screen-reader-text prompt" for="title" id="title-prompt-text"><?php echo apply_filters( 'enter_title_here', __( 'Title' ), $post ); ?></label>
			<input type="text" name="post_title" id="title" autocomplete="off" />
		</div>

		<div class="textarea-wrap" id="description-wrap">
			<label class="screen-reader-text prompt" for="content" id="content-prompt-text"><?php _e( 'What&#8217;s on your mind?' ); ?></label>
			<textarea name="content" id="content" class="mceEditor" rows="3" cols="15"></textarea>
		</div>

		<p class="submit">
			<input type="hidden" name="action" id="network-quickpost-action" value="post-quickdraft-save" />
			<input type="hidden" name="post_ID" value="<?php echo $post_ID; ?>" />
			<input type="hidden" name="post_type" value="post" />
			<?php wp_nonce_field( 'add-post' ); ?>
			<?php submit_button( __( 'Save Draft' ), 'primary', 'save', false, array( 'id' => 'save-post' ) ); ?>
			<br class="clear" />
		</p>

	</form>
	<?php
	wp_dashboard_recent_drafts();
}


/*
 * add dahsboard widget that shows all reminders
 *
 *
 *
 */
function set_html_content_typeNA() {
	return 'text/html';
}

function fg_dashboard_reminders() {
	//use this method with acf
	//update to custom sql searching for user specific and assigned property specific reminders
	
	echo "<H3>Called in fg_dahsboard_reminders!</H3>";

	global $wpdb;
	global $switched;
	$sent_reminder = false;
	$args = array(
			'network_id' => $wpdb->siteid,
			'public'     => null,
			'archived'   => null,
			'mature'     => null,
			'spam'       => null,
			'deleted'    => null,
			'limit'      => 100,
			'offset'     => 0,
		);
	$property_ids = wp_get_sites( $args );
	$property_ct = count( $property_ids);

	foreach ($property_ids as $k=>$v) {
		$blog_details = get_blog_details($k, true);
		$check_id = $blog_details->blog_id;

		if ( isset($check_id) && $check_id !== false) {
			$sql = "SELECT post_id FROM wp_" . $blog_details->blog_id . "_postmeta WHERE meta_key = 'attach_reminders'";
		} else {
			$sql = "SELECT post_id FROM wp_postmeta WHERE meta_key = 'attach_reminders'";
		}
		$cur_reminders = $wpdb->get_results($sql, ARRAY_A);

		$this_count = count($cur_reminders);
	/*
	echo $wpdb->last_query . ";<BR>Return: " . $cur_reminders[0] . ";
	<BR>Index: " . $cur_reminders[0]['post_id']
	 . ";<BR>Count: " . $this_count;
	 */
	for( $i=0; $i < $this_count; $i++ ) {
		if ( is_array( $cur_reminders[$i] ) ) {
			if( $these_rems = have_rows( 'attach_reminders', $cur_reminders[$i]['post_id'] ) ) {

				echo "<DIV><P>The following reminders are currently set:
					<table id='example' class='display' border=1 cellspacing='0' width='100%'>
						<thead>
							<tr>
								<th>Reminder Subject</th>
								<th>Date</th>
								<th>Recipients</th>
								<th>View</th>
								<th>Deactivate</th>

							</tr>
					</thead>";


				//echo '<BR>Has Rows: ' . $these_rems;
				//$message .=  '<ul class="slides">';


					$cur_row = the_row();
					//echo "<H3>Row Ct: " . $cur_row . "</H3>";
					foreach($cur_row as $crk=>$crv){
						//echo "<H3>crk: " . $crk . ", " . $crv . "</H3>";
					}
					$reminder_subject = the_title($cur_reminders[$i]['post_id']);
					$doc_title = get_the_title( $cur_reminders[$i]['post_id'] );

					$dates = get_sub_field('reminder_dates');
					$rem_notes = get_sub_field('reminder_notes');
					$contacts = get_sub_field('reminder_recipients');

						echo "<tr><td>" . $doc_title . " " . $reminder_subject . "</td>
								<td>";
							if ( is_array($dates) ) {
							echo "<H3>" . $dates[0]['selected_date'] . "</H3>";
							}
						echo "</td><TD>";
						if ( is_array($contacts) ) {
							for( $i = 0; $i < count($contacts); $i++ ) {
								echo "<H3>" . $contacts[$i]['display_name'] . "</H3>";
							}
						}
						echo "</TD><td><A HREF=>View</A></td>
										<td><A HREF=>Close</A></td></TR>";

						if ( $sent_reminder == false ) {

							$message = $message . $title . $reminders . $closing;
							add_filter( 'wp_mail_content_type', 'set_html_content_type' );
							$admin_email = get_option( 'admin_email', $default );
							$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
							//wp_mail( $recip_email, $doc_title, $message );

							//if ( !wp_mail( 'dg_419@hotmail.com', $doc_title, $message, $headers ) ) {
								//echo "<H1>Not dg_419HOTMAIL</H1>";
							//}
							remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
							$sent_reminder = false;
						}


							echo " <tfoot>
									<tr>
										<th>Reminder Subject</th>
										<th>Date</th>
										<th>Recipients</th>
										<th>View</th>
										<th>Deactivate</th>

									</tr>
								</tfoot></TABLE></P></DIV>";
			}



		//}
		echo '';
		}

		}
	}


 }

 function fg_dashboard_remindersWKG() {
	global $wpdb;
	$cur_time = strtotime( date( 'Y-m-d' ) );
	$sent_reminder = false;
	$sql = "SELECT * FROM " . $wpdb->prefix . "postmeta WHERE meta_key = 'fg_document_reminder'";
	$cur_reminders = $wpdb->get_results($sql, ARRAY_A);

	foreach ($cur_reminders[0] as $key => $value) {
	 $message = "<P>The following reminders are currently set:";
	 	if ( $key == 'post_id' ) {
	 		$doc_title = get_the_title( $value );
	 		$title = "<LI>Document Title: " . $doc_title . "</LI>";
		}
		if ( $key == 'meta_value' ) {
	 		$value = unserialize( $value );
			$reminders = "<UL>";
				foreach ( $value as $cur_reminder ) {
					$remind_time = strtotime( $cur_reminder[fg_document_reminder_date] );
					if ( $cur_time >= $remind_time ) {
						$reminders .= "<LI>Here?Reminder Notes: " . $cur_reminder[fg_document_reminder_notes] . "</LI>
						</LI>Reminder Date: " . $cur_reminder[fg_document_reminder_date] . "</LI>";
						$sent_reminder = true;
					}
					$attachments = array( $cur_reminder[fg_document_reminder_url] );
					$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
   			$message .= $reminders . "<UL>CC LIST:
   				<LI>" . $cur_reminder[fg_document_reminder_cc];
   				$message .= "</LI>";
			//echo "<H1>CC LIST:<BR>" . $cur_reminder[fg_document_reminder_cc]  . "</H1>";
   			//wp_mail('dg_419@hotmail.com', 'subject', $message, $headers, $attachments );
   			echo $message;
				}
			$closing = "</UL>";
		}
		if ( $sent_reminder == true ) {


			$message = $message . $title . $reminders . $closing;
			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$admin_email = get_option( 'admin_email', $default );
			//wp_mail( 'dg_419@hotmail.com', 'Lease Reminders', $message );

			$cur_doc_file = get_post_meta(get_the_ID(), 'property_doc_file', true);
			if (isset($cur_doc_file) && $cur_doc_file != '') {
				if (is_array($cur_doc_file)) {

					$cur_file = $cur_doc_file[url];

				} else {

					$cur_file = $cur_doc_file;

				}
			}
			$attachments = array( $cur_file );
			//$message = "<H3>Cur doc file: " . $cur_file . "</H3>";
			//$message .= $cur_file;
			//echo "<H1>" . $cur_file . "</H1>";
			//wp_mail( 'dg_419@hotmail.com', 'Lease Reminders2', $message );
			$headers = 'From: Dennis Gannon <dg_419@hotmail.com>' . "\r\n";
   			//wp_mail('dg_419@hotmail.com', 'subject', $cur_file, $headers, $attachments );

			echo $message;

			//wp_mail( 'technologycity@icloud.com', 'Lease Reminders', $message);
			remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
			$sent_reminder = false;
		}
	}
}
//add_action( 'init', 'fg_dashboard_reminders' );
/* end dashboard reminders widget function */


function mmc_comms_dashboard_widget() {
	$dsn = "Driver={SQL Server};Server=209.67.252.250;Database=tlc;Uid=dennis;Pwd=dr.pep04";
	$username="dennis";
	$db_password="dr.pep04";

	$db_connection = odbc_connect($dsn,$username,$db_password) or die(odbc_error());


	echo "<H4>Client Communications</H4>";



	if (!isset($_REQUEST["sort_comm_by"])) {
		$_REQUEST["sort_comm_by"] = 'posted_date DESC';
	}

	if (isset($_REQUEST["invert_date"])) {
	if ($_REQUEST["sort_comm_by"] == 'to_ID DESC' || $_REQUEST["sort_comm_by"] == 'to_ID') {

		$_REQUEST["sort_comm_by"] = 'posted_date';

	}

		if ($_REQUEST["sort_comm_by"] == 'posted_date DESC') {
			$_REQUEST["sort_comm_by"] = "posted_date";
		} elseif ($_REQUEST["sort_comm_by"] == 'posted_date') {
			$_REQUEST["sort_comm_by"] = "posted_date DESC";
		}

	}

if (isset($_REQUEST["invert_to"])) {
if ($_REQUEST["sort_comm_by"] == 'posted_date' || $_REQUEST["sort_comm_by"] == 'posted_date DESC') {

	$_REQUEST["sort_comm_by"] = 'to_ID';

}
	if ($_REQUEST["sort_comm_by"] == 'to_ID DESC') {
		$_REQUEST["sort_comm_by"] = "to_ID";
	} elseif ($_REQUEST["sort_comm_by"] == 'to_ID') {
		$_REQUEST["sort_comm_by"] = "to_ID DESC";
	}

}



//echo "<H1>$_SESSION[user_ID]</H1>";





		//echo "LINE - 94 - $properties<BR>$_SESSION[assigned_properties]<BR><BR>";



		$read_communications = "SELECT
						TOP 10000 communication_ID,
 						to_ID,
 						from_ID,
 						property_ID,
 						original_comm_ID,
 						communication_type,
 						communication_subject,
 						posted_date,
 						communication_content,
 						pm_display_comm,
 						pm_close_thread,
 						archive
 						FROM client_communications
 						WHERE pm_close_thread = 0
 						AND sent_by_mgr = 0 AND

 						pm_display_comm != 0 AND
 						((from_ID IN (SELECT mmcyardi6.dbo.tenant.hmyperson FROM mmcyardi6.dbo.tenant WHERE mmcyardi6.dbo.tenant.hproperty IN ($_SESSION[assigned_properties]) AND mmcyardi6.dbo.tenant.istatus = 0)
 						AND (from_cont_lookup = 0 AND to_cont_lookup = 1))

 						OR (to_ID = $_SESSION[user_ID] AND to_cont_lookup = 1))
 						AND client_ID = from_ID
 						ORDER BY $_REQUEST[sort_comm_by]";

 						//echo "LINE - 123 - $read_communications<BR><BR>";


$display_limit = 20;
$read_communications_result = odbc_exec($db_connection, $read_communications);

	//set array of IDs here then loop through by index rather that ID + 20


$num_rows = odbc_num_rows($read_communications_result);

	while ($communications = odbc_fetch_row($read_communications_result)) {

		$request_ID_loop[] = odbc_result($read_communications_result, 1);

	}

if ($num_rows > $display_limit) {

	$num_pages = ceil ($num_rows/$display_limit);


	if (!isset($_REQUEST["first"]) || !isset($_REQUEST["last"])) {


			$read_communications = "SELECT
							TOP $display_limit tlc.dbo.client_communications.communication_ID,
	 						tlc.dbo.client_communications.to_ID,
	 						tlc.dbo.client_communications.from_ID,
	 						tlc.dbo.client_communications.property_ID,
	 						tlc.dbo.client_communications.original_comm_ID,
	 						tlc.dbo.client_communications.communication_type,
	 						tlc.dbo.client_communications.communication_subject,
	 						tlc.dbo.client_communications.posted_date,
	 						tlc.dbo.client_communications.communication_content,
	 						tlc.dbo.client_communications.pm_display_comm,
	 						tlc.dbo.client_communications.pm_close_thread,
	 						tlc.dbo.client_communications.archive
	 						FROM tlc.dbo.client_communications
	 						WHERE tlc.dbo.client_communications.pm_close_thread = 0
 						AND tlc.dbo.client_communications.sent_by_mgr = 0 AND

 						pm_display_comm != 0 AND
 						tlc.dbo.client_communications.((tlc.dbo.client_communications.from_ID IN (SELECT mmcyardi6.dbo.tenant.hmyperson FROM mmcyardi6.dbo.tenant WHERE mmcyardi6.dbo.tenant.hproperty IN ($_SESSION[assigned_properties]) AND mmcyardi6.dbo.tenant.istatus = 0)
 						AND (tlc.dbo.client_communications.from_cont_lookup = 0 AND tlc.dbo.client_communications.to_cont_lookup = 1))

 						OR (tlc.dbo.client_communications.to_ID = $_SESSION[user_ID] AND tlc.dbo.client_communications.to_cont_lookup = 1))
 						AND tlc.dbo.client_communications.client_ID = tlc.dbo.client_communications.from_ID
 						ORDER BY $_REQUEST[sort_comm_by]";



	} else {



			$read_communications = "SELECT
							TOP $display_limit tlc.dbo.client_communications.communication_ID,
	 						tlc.dbo.client_communications.to_ID,
	 						tlc.dbo.client_communications.from_ID,
	 						tlc.dbo.client_communications.property_ID,
	 						tlc.dbo.client_communications.original_comm_ID,
	 						tlc.dbo.client_communications.communication_type,
	 						tlc.dbo.client_communications.communication_subject,
	 						tlc.dbo.client_communications.posted_date,
	 						tlc.dbo.client_communications.communication_content,
	 						tlc.dbo.client_communications.pm_display_comm,
	 						tlc.dbo.client_communications.pm_close_thread,
	 						tlc.dbo.client_communications.archive
	 						FROM tlc.dbo.client_communications
	 						WHERE tlc.dbo.client_communications.pm_close_thread = 0
 						AND tlc.dbo.client_communications.sent_by_mgr = 0 AND

 						tlc.dbo.client_communications.pm_display_comm != 0 AND
 						((tlc.dbo.client_communications.from_ID IN (SELECT mmcyardi6.dbo.tenant.hmyperson FROM mmcyardi6.dbo.tenant WHERE mmcyardi6.dbo.tenant.hproperty IN ($_SESSION[assigned_properties]) AND mmcyardi6.dbo.tenant.istatus = 0)
 						AND (tlc.dbo.client_communications.from_cont_lookup = 0 AND tlc.dbo.client_communications.to_cont_lookup = 1))

 						OR (tlc.dbo.client_communications.to_ID = $_SESSION[user_ID] AND tlc.dbo.client_communications.to_cont_lookup = 1))
 						AND tlc.dbo.client_communications.client_ID = from_ID
 						ORDER BY $_REQUEST[sort_comm_by]";





}


$read_communications_result = odbc_exec($db_connection, $read_communications);



	if (!isset($read_communications_result)) {
		 print (odbc_error());
	 }
/////////////////////////////
//
}




echo "<TABLE class=\"KnockoutFormTABLE\" BGCOLOR=\"#000080\" BORDER=1 CELLSPACING=1 WIDTH=620>";



//////////////////////////////////////////////////////////
//page counting row
echo "<TR VALIGN=top><TD ALIGN=center class=\"KnockoutColumnTD\" COLSPAN=6>";

if (!isset($num_pages)) {
	$num_pages = 1;
}

if (!isset($page_number)) {
	$page_number = 1;
}


echo "<B>20 results per page; displaying page $page_number of $num_pages pages</B><BR>";


	$x=1;
	$i = 0;

	while ($i < $num_rows) {


		$first = $request_ID_loop[$i];
		$last = $i + 20;

		if (!isset($request_ID_loop[$last])) {

			$request_ID_loop[$last] = $request_ID_loop[(count($request_ID_loop)-1)];

		}




		if ($request_ID_loop[$i] < $request_ID_loop[$last]) {
		echo " <A HREF=\"pm_main.php?first=$request_ID_loop[$i]&last=$request_ID_loop[$last]&page_number=$x&cc=TRUE";


			if (isset($_REQUEST["outgoing"])) {

				echo "&outgoing=TRUE";

			}


		} else {

		echo " <A HREF=\"pm_main.php?first=$request_ID_loop[$last]&last=$request_ID_loop[$i]&page_number=$x&cc=TRUE";

			if (isset($_REQUEST["outgoing"])) {

				echo "&outgoing=TRUE";

			}


		}





		if (isset($_REQUEST["selected_resident"])) {

			echo "&selected_resident=$selected_resident";

		}

		echo "\"><FONT COLOR=white><B>Page $x</B></FONT></A> ";
		$x++;
		$i = $i + $display_limit;


	}





echo "</TD></TR>";
//end page counting row
/////////////////////////////////////////////////////////////////






echo "<TR VALIGN=top><TD class=\"KnockoutColumnTD\" WIDTH=120>
<B><A class=\"KnockoutSorterLink\" HREF=\"pm_main.php?sort_comm_by=communication_subject\">Subject</A></B></TD>
<TD class=\"KnockoutColumnTD\" WIDTH=120><B><A class=\"KnockoutSorterLink\" HREF=\"pm_main.php?invert_date=TRUE&sort_comm_by=$_REQUEST[sort_comm_by]\">Date</A></B></TD>
<TD  class=\"KnockoutColumnTD\" WIDTH=160><B><A class=\"KnockoutSorterLink\" HREF=\"pm_main.php?invert_to=TRUE&sort_comm_by=$_REQUEST[sort_comm_by]\">From</A></B></TD>
<TD class=\"KnockoutColumnTD\" WIDTH=60><B>Open</B></TD>
<TD class=\"KnockoutColumnTD\" WIDTH=60><B>Close</B></TD>
<TD class=\"KnockoutColumnTD\" WIDTH=100><B>Close Thread</B></TD></TR>";

odbc_free_result($read_communications_result);
$read_communications_result = odbc_exec($db_connection, $read_communications);


	while ($communications = odbc_fetch_row($read_communications_result)) {

		$communication_ID = odbc_result($read_communications_result, 1);
		$to_ID = odbc_result($read_communications_result, 2);
		$from_ID = odbc_result($read_communications_result, 3);
		$property_ID = odbc_result($read_communications_result, 4);
		$original_comm_ID = odbc_result($read_communications_result, 5);
		$communication_type = odbc_result($read_communications_result, 6);
		$communication_subject = odbc_result($read_communications_result, 7);
		$communication_subject = urldecode($communication_subject);
		$posted_date = odbc_result($read_communications_result, 8);

		$communication_content = odbc_result($read_communications_result, 9);
		$display_comm = odbc_result($read_communications_result, 10);
		$close_thread = odbc_result($read_communications_result, 11);
		$archive = odbc_result($read_communications_result, 12);

		$disp_year = substr($posted_date,0,4);
		$disp_month = substr($posted_date,5,2);
		$disp_day = substr($posted_date,8,2);
		$disp_hour = substr($posted_date,11,2);
		$disp_min = substr($posted_date,14,2);

		$disp_date = mktime($disp_hour, $disp_min, 0, $disp_month, $disp_day, $disp_year);
		$disp_date = date(" g:iA l F j, Y", $disp_date);




//echo "<H1>$communication_type - $property_ID - $original_comm_ID</H1>";

	$get_client = "SELECT hmyperson, hproperty, sunitcode, sfirstname, slastname, istatus, saddr1 FROM tenant WHERE hmyperson = '$from_ID'";
	$get_client_result = odbc_exec($yardi_connection, $get_client);

	$sunit = odbc_result($get_client_result, 3);
	$first_name = odbc_result($get_client_result, 4);
	$last_name = odbc_result($get_client_result, 5);
	$saddr1 = odbc_result($get_client_result, 7);









		echo "<TR VALIGN=top><TD class=\"KnockoutDataTD\" WIDTH=120>";

		if ($communication_subject == '') {
			$communication_subject = "N/A";
		}

				echo "<B>$communication_subject</B></TD>
				<TD class=\"KnockoutDataTD\" WIDTH=120><B>$disp_date</TD>
				<TD class=\"KnockoutDataTD\" WIDTH=160><B>$first_name $last_name<BR>Unit: $sunit, $saddr1</B></TD>
				<TD class=\"KnockoutDataTD\" WIDTH=60><B>
<A HREF=\"javascript:slideShowWindow('original_request.php?communication_ID=$communication_ID&comm=TRUE&client_ID=$from_ID&original_comm_ID=$original_comm_ID');\">
	Open</B></TD>
				<TD class=\"KnockoutDataTD\" WIDTH=60><B><A HREF=\"pm_main.php?close=TRUE&communication_ID=$communication_ID\">Close</A></B></TD>
				<TD class=\"KnockoutDataTD\" WIDTH=100><B><A HREF=\"pm_main.php?close_thread=TRUE&communication_ID=$original_comm_ID\">Close Thread</B></TD></TR>";


	}



echo "<TR VALIGN=top><TD ALIGN=center class=\"KnockoutFieldCaptionTD\" COLSPAN=6>";

if (!isset($num_pages)) {
	$num_pages = 1;
}

if (!isset($page_number)) {
	$page_number = 1;
}


echo "<B>20 results per page; displaying page $page_number of $num_pages pages</B><BR>";


	$x=1;
	$i = 0;

	while ($i < $num_rows) {


		$first = $request_ID_loop[$i];
		$last = $i + 20;

		if (!isset($request_ID_loop[$last])) {

			$request_ID_loop[$last] = $request_ID_loop[(count($request_ID_loop)-1)];

		}




		if ($request_ID_loop[$i] < $request_ID_loop[$last]) {
		echo " <A HREF=\"pm_main.php?first=$request_ID_loop[$i]&last=$request_ID_loop[$last]&page_number=$x&cc=TRUE";


		} else {

		echo " <A HREF=\"pm_main.php?first=$request_ID_loop[$last]&last=$request_ID_loop[$i]&page_number=$x&cc=TRUE";

		}




		if (isset($_REQUEST["selected_resident"])) {

			echo "&selected_resident=$_REQUEST[selected_resident]";

		}

		echo "\"><FONT COLOR=white><B>Page $x</B></FONT></A> ";
		$x++;
		$i = $i + $display_limit;


	}


echo "</TD></TR>";


echo "</TABLE>";





}

function fg_pm_dashboard() {
    $user = wp_get_current_user();
    $chk_pm_role = $user->roles;

    //if ( in_array( 'property_manager',$chk_pm_role ) ) {
        //remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
        //remove_meta_box( 'dashboard_primary', 'dashboard', 'normal' );
        //remove_meta_box( 'dashboard_activity', 'dashboard', 'normal' );
        //remove_meta_box( 'dashboard_primary', 'dashboard', 'normal' );

		/* wp_add_dashboard_widget(
                 'property_comms_dashboard_widget',         // Widget slug.
                 'Recent Communications',         // Title.
                 'fg_dashboard_prop_comms' // Display function.
        );
		*/
        wp_add_dashboard_widget(
		                 'network_reminders_dashboard_widget',         // Widget slug.
		                 'Active Reminders',         // Title.
		                 'fg_dashboard_reminders' // Display function.
		        );

        wp_add_dashboard_widget(
		                 'maint_reqs_dashboard_widget',         // Widget slug.
		                 'Pending Work Orders',         // Title.
		                 'pendingWos' // Display function.
		                 //this one also added an empty box
		        );
       wp_add_dashboard_widget(
		                 'new_maint_reqs_dashboard_widget',         // Widget slug.
		                 'New Work Orders',         // Title.
		                 'getNetworkWOsWidget' // Display function.
		                 //this one also added an empty box
		        );
		        
       wp_add_dashboard_widget(
		                 'assigned_maint_reqs_dashboard_widget',         // Widget slug.
		                 'Assigned Work Orders',         // Title.
		                 'assignedWos' // Display function.
		                 //this one also added an empty box
		        );
		        
		wp_add_dashboard_widget(
		                 'property_comms_dashboard_widget',         // Widget slug.
		                 'Recent Communications',         // Title.
		                 'fg_dashboard_prop_comms' // Display function.
		        );

		wp_add_dashboard_widget(
		                 'property_documents_dashboard_widget1',         // Widget slug.
		                 'Recent Documents',         // Title.
		                 'recentDocs' // Display function.
		        );

        /*
        add_meta_box('maint_reqs_dashboard_widget', 'Pending Work Orders', 'pendingWos', 'dashboard', 'normal', 'high');

        add_meta_box('property_comms_dashboard_widget', 'Recent Communications', 'fg_dashboard_prop_comms', 'dashboard', 'normal', 'high');

        add_meta_box('recent_documents_dashboard_widget1', 'Recent Documents', 'recentDocs', 'dashboard', 'normal', 'high');


        add_meta_box('property_documents_dashboard_widget1', 'Post Documents', 'fg_dashboard_reminders', 'dashboard', 'normal', 'high');


        add_meta_box('network_reminders_dashboard_widget', 'Active Reminders', 'fg_dashboard_reminders', 'dashboard', 'normal', 'high');

        add_meta_box('mmc_comms', 'MMC Communications', 'mmc_comms_dashboard_widget', 'dashboard', 'normal', 'high');
*/
		/*
		 * wp_add_dashboard_widget(
                 'network_quickpress_dashboard_widget',         // Widget slug.
                 'Network Communications',         // Title.
                 'fg_dashboard_quick_press' // Display function.
        );
*/


   // }
   


}
add_action( 'wp_dashboard_setup', 'fg_pm_dashboard' );


function remove_dashboard_meta() {
	remove_meta_box( 'dashboard_primary', 'dashboard', 'normal' );
}
//add_action( 'admin_init', 'remove_dashboard_meta' );


//add menus to admin bar - also look to Brand this


add_action( 'admin_bar_menu', 'modify_pm_admin_bar' );

function modify_pm_admin_bar( $wp_admin_bar ){
	global $wp_admin_bar;

	$wp_admin_bar->add_node( array(
		'id' => 'pm_remote_app_login',
		'title' => 'Logins',
		'href' => get_bloginfo('wpurl'),
		'parent' => false
	));
	$wp_admin_bar->add_node( array(
		'id' => 'pm_remote_yardi_login',
		'title' => 'Yardi',
		'href' => "javascript:loginWindow('yardi', 'https://www.mediatemanagement.com/voyager6');",
		'parent' => 'pm_remote_app_login'
	));
	$wp_admin_bar->add_node( array(
		'id' => 'pm_remote_dispatch_login',
		'title' => 'Maint. Disp.',
		'href' => "javascript:loginWindow('maintenance', 'http://www.mediatemanagement.com/mmcdispatch/WO_Maint.asp?ret_link=dispatch/WO_Maint.asp');",
		'parent' => 'pm_remote_app_login'
	));
	$wp_admin_bar->add_node( array(
		'id' => 'pm_remote_cs_login',
		'title' => 'Client Svcs.',
		'href' => "javascript:loginWindow('maintenance', 'javascript:loginWindow('cs', 'http://www.mediatemanagement.com/concierge/WOList.asp",
		'parent' => 'pm_remote_app_login'
	));
}
?>
