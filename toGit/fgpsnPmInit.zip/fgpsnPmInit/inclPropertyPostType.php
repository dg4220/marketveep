<?PHP

/******************************************************
 * DG Creating Data post type and meta boxes: Data type and the actual file.
*******************************************************/

function custom_post_properties() {

		$labels = array(
			'name'               => _x( 'Properties', 'post type general name' ),
			'singular_name'      => _x( 'Property', 'post type singular name' ),
			'add_new'            => _x( 'Add Property', 'properties' ),
			'add_new_item'       => __( 'Add New Property' ),
			'edit_item'          => __( 'Edit Property Data' ),
			'new_item'           => __( 'New Property' ),
			'all_items'          => __( 'All Properties' ),
			'view_item'          => __( 'View Property' ),
			'search_items'       => __( 'Search Properties' ),
			'not_found'          => __( 'No Properties Found' ),
			'not_found_in_trash' => __( 'No Properties found in the Trash' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Properties'
		);

		$args = array(
			'labels'        => $labels,
			'description'   => 'Holds our Property Data',
			'public'        => true,
			'menu_position' => 4,
			'supports'      => array( 'title', 'editor', 'author', 'revisions', 'page-attributes', 'excerpt', 'thumbnail', /*'custom-fields'*/ ),
			'taxonomies'      => array( 'properties_types'  ),
			'hierarchical' => true,
			'has_archive'   => true
		);

	register_post_type( 'properties', $args );
}
add_action( 'init', 'custom_post_properties' );

add_action( 'init', 'create_fgpsn_property_city' );

function create_fgpsn_property_city() {
 $labels = array(
    'name' => _x( 'City', 'taxonomy general name' ),
    'singular_name' => _x( 'City', 'taxonomy singular name' ),
    'search_items' =>  __( 'Cities' ),
    'all_items' => __( 'All Cities' ),
    'parent_item' => __( 'Parent City' ),
    'parent_item_colon' => __( 'Parent City' ),
    'edit_item' => __( 'Edit Cities' ),
    'update_item' => __( 'Update Cities' ),
    'add_new_item' => __( 'Add New City' ),
    'new_item_name' => __( 'New City Name' ),
  );

  register_taxonomy('fgpsn_property_city',array('properties', "unit_data"),array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    'query_vars'		=> true,
    'show_in_nav_menus' => true,
    'public' => true,
    'show_ui' => true,
    'show_tagcloud' => true,

  ));
}

/*
add_action( 'init', 'create_properties_types' );

function create_properties_types() {
 $labels = array(
    'name' => _x( 'Property Data Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Data Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Data Types' ),
    'all_items' => __( 'All Data Types' ),
    'parent_item' => __( 'Parent Data Type' ),
    'parent_item_colon' => __( 'Parent Data Type:' ),
    'edit_item' => __( 'Edit Data Type' ),
    'update_item' => __( 'Update Data Type' ),
    'add_new_item' => __( 'Add New Data Type' ),
    'new_item_name' => __( 'New Data Type Name' ),
  );

  register_taxonomy('properties_types','properties',array(
    'hierarchical'	=> true,
    'labels'		=> $labels,
    query_vars		=> true

  ));
}

*/

add_action( 'add_meta_boxes', 'property_info' );
//use Property Details
function property_info() {

  $screens = array( 'properties', 'fg_properties' );
    foreach ($screens as $screen) {
    add_meta_box(
      'property_info',
      __( 'Property Data', 'myplugin_textdomain' ),
      'property_info_content',
      $screen,
      'normal',
      'high'
    );
  }
}


function property_info_content( $post ) {


  wp_nonce_field( plugin_basename( __FILE__ ), 'property_info_content_nonce' );

  echo '<FIELDSET><DIV ID="meta_col_left_third" STYLE="position: relative; display: inline; float: left; width: 30%;">
  <P><label for="property_hmy" STYLE="width: 110px;">Property HMY</label>';

  $property_hmy = get_post_meta(get_the_ID(), 'property_hmy', true);
  echo '<input id="property_hmy" name="property_hmy" size=5 value="' . $property_hmy . '" type="text"></P>
  <P><label for="fgpsn_site_id" STYLE="width: 110px;">Site ID</label>';

  $fgpsn_site_id = get_post_meta(get_the_ID(), 'fgpsn_site_id', true);
  echo '<input id="fgpsn_site_id" name="fgpsn_site_id" size=5 value="' . $fgpsn_site_id . '" type="text"></P>

  <P><label for="fgpsn_property_address_1" STYLE="width: 110px;">Address 1</label>';

  $fgpsn_property_address_1 = get_post_meta(get_the_ID(), 'fgpsn_property_address_1', true);
  echo '<input id="fgpsn_property_address_1" name="fgpsn_property_address_1" size=5 value="' . $fgpsn_property_address_1 . '" type="text"></P>

  <P><label for="fgpsn_property_address_2" STYLE="width: 110px;">Address 2</label>';

  $fgpsn_property_address_2 = get_post_meta(get_the_ID(), 'fgpsn_property_address_2', true);
  echo '<input id="fgpsn_property_address_2" name="fgpsn_property_address_2" size=5 value="' . $fgpsn_property_address_2 . '" type="text"></P>

  <P><label for="fgpsn_property_city" STYLE="width: 110px;">City</label>';

  $fgpsn_property_city = get_post_meta(get_the_ID(), 'fgpsn_property_city', true);
  echo '<input id="fgpsn_property_city" name="fgpsn_property_city" size=5 value="' . $fgpsn_property_city . '" type="text"></P>

  <P><label for="state" STYLE="width: 110px;">State</label>';

  $fgpsn_property_state = get_post_meta(get_the_ID(), 'fgpsn_property_state', true);
  echo '<input id="fgpsn_property_state" name="fgpsn_property_state" size=5 value="' . $fgpsn_property_state . '" type="text"></P>

  <P><label for="fgpsn_property_zip" STYLE="width: 110px;">Zipcode</label>';

  $fgpsn_property_zip = get_post_meta(get_the_ID(), 'fgpsn_property_zip', true);
  echo '<input id="fgpsn_property_zip" name="fgpsn_property_zip" size=5 value="' . $fgpsn_property_zip . '" type="text"></P>';


     echo "</DIV></FIELDSET>";


}


add_action( 'save_post', 'property_info_save' );
function property_info_save( $post_id ) {
/*var_dump($_POST);
echo "<H1>ARGH " . $post_id . "</H1>";*/
//return;
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
  return;

  if ( !wp_verify_nonce( $_POST['property_info_content_nonce'], plugin_basename( __FILE__ ) ) )
  return;

  if ( 'page' == $_POST['post_type'] ) {
    if ( !current_user_can( 'edit_page', $post_id ) )
    return;
  } else {
    if ( !current_user_can( 'edit_post', $post_id ) )
    return;
  }
  /*echo "<H1>LINE 175 - " . $post_id . " - " . $_POST['fgpsn_property_address_1'] . "</H1>";*/

  $address_1 = $_POST['fgpsn_property_address_1'];
  $address_2 = $_POST['fgpsn_property_address_2'];
  $city = $_POST['fgpsn_property_city'];
  $state = $_POST['fgpsn_property_state'];
  $zip = $_POST['fgpsn_property_zip'];
  $property_hmy = $_POST['property_hmy'];
  $fgpsn_site_id = $_POST['fgpsn_site_id'];

  $term = term_exists($_POST['fgpsn_property_city'], 'fgpsn_property_city');

  if ($term !== 0 && $term !== null) {
    //echo "'City ' category exists!";
    wp_set_object_terms( $post_id, $_POST['fgpsn_property_city'], 'fgpsn_property_city' );
  } else {

    $newtid = wp_insert_term( $_POST['fgpsn_property_city'], 'fgpsn_property_city' );
    //echo "'Added City ' category exists!";
    wp_set_object_terms( $post_id, $_POST['fgpsn_property_city'], 'fgpsn_property_city' );
  }


  update_post_meta( $post_id, 'fgpsn_property_address_1', $_POST['fgpsn_property_address_1'] );
  update_post_meta( $post_id, 'fgpsn_property_address_2', $address_2 );
  update_post_meta( $post_id, 'fgpsn_property_city', $city );
  update_post_meta( $post_id, 'fgpsn_property_state', $state );
  update_post_meta( $post_id, 'fgpsn_property_zip', $zip );
  update_post_meta( $post_id, 'property_hmy', $property_hmy );
  update_post_meta( $post_id, 'fgpsn_site_id', $fgpsn_site_id );
  
  //update vendor table for zipcode searches
  update_post_meta( $post_id, 'fgpsn_property_city', $city );
  update_post_meta( $post_id, 'fgpsn_property_state', $state );
  update_post_meta( $post_id, 'fgpsn_property_zip', $zip );
  update_post_meta( $post_id, 'fgpsn_property_address_1', $_POST['fgpsn_property_address_1'] );
  
  
  
  


    if ( ! wp_is_post_revision( $post_id ) ){

      //$my_post = array();
      //$my_post['ID'] = $post_id;
      //$my_post['post_title'] = $post_title;


      // unhook this function so it doesn't loop infinitely
      remove_action('save_post', 'property_info_save');

      // update the post, which calls save_post again
      wp_update_post( $my_post );

      // re-hook this function
      add_action('save_post', 'property_info_save');
  }

}



//adding property specs, vendors, data, etc. from site options page
add_action( 'add_meta_boxes', 'propertyData' );
function propertyData() {

	$screens = array( 'properties', 'fgpsn_properties' );
    foreach ($screens as $screen) {
		add_meta_box(
			'property_data',
			__( 'Property Details', 'myplugin_textdomain' ),
			'propertyDataString',
			$screen,
			'normal',
			'high'
		);
	}
}

function propertyDataString( $post ) {
	
	wp_nonce_field( plugin_basename( __FILE__ ), 'propertyDataString_nonce' );

	$states_util = array('AL'=>"Alabama",
                'AK'=>"Alaska",
                'AZ'=>"Arizona",
                'AR'=>"Arkansas",
                'CA'=>"California",
                'CO'=>"Colorado",
                'CT'=>"Connecticut",
                'DE'=>"Delaware",
                'DC'=>"District Of Columbia",
                'FL'=>"Florida",
                'GA'=>"Georgia",
                'HI'=>"Hawaii",
                'ID'=>"Idaho",
                'IL'=>"Illinois",
                'IN'=>"Indiana",
                'IA'=>"Iowa",
                'KS'=>"Kansas",
                'KY'=>"Kentucky",
                'LA'=>"Louisiana",
                'ME'=>"Maine",
                'MD'=>"Maryland",
                'MA'=>"Massachusetts",
                'MI'=>"Michigan",
                'MN'=>"Minnesota",
                'MS'=>"Mississippi",
                'MO'=>"Missouri",
                'MT'=>"Montana",
                'NE'=>"Nebraska",
                'NV'=>"Nevada",
                'NH'=>"New Hampshire",
                'NJ'=>"New Jersey",
                'NM'=>"New Mexico",
                'NY'=>"New York",
                'NC'=>"North Carolina",
                'ND'=>"North Dakota",
                'OH'=>"Ohio",
                'OK'=>"Oklahoma",
                'OR'=>"Oregon",
                'PA'=>"Pennsylvania",
                'RI'=>"Rhode Island",
                'SC'=>"South Carolina",
                'SD'=>"South Dakota",
                'TN'=>"Tennessee",
                'TX'=>"Texas",
                'UT'=>"Utah",
                'VT'=>"Vermont",
                'VA'=>"Virginia",
                'WA'=>"Washington",
                'WV'=>"West Virginia",
                'WI'=>"Wisconsin",
                'WY'=>"Wyoming");


	echo '<FIELDSET><P><label for="fgpsn_property_title" STYLE="width: 110px;">Site ID</label>';

	$fgpsn_property_title = get_post_meta(get_the_ID(), 'fgpsn_property_title', true);
	echo '<input id="fgpsn_property_title" name="fgpsn_property_title" size=5 value="' . $fgpsn_property_title . '" type="text"></P>

	<P><label for="fgpsn_property_type" STYLE="width: 110px;">Property Type</label>';

	$property_type = get_post_meta(get_the_ID(), 'fgpsn_property_type', true);
	
	echo "<P><SELECT id='fgpsn_property_type' name='fgpsn_property_data_options[fgpsn_property_type]' />

			<OPTION value=''> - Select - </OPTION>\n
			<OPTION value='Condominium'";

			if ($property_type == 'Condominium') {
				echo " selected";
			}

			echo "> Condominium </OPTION>\n
			<OPTION value='Rental Property'";

			if ($property_type == 'Rental Property') {
				echo " selected";
			}


			echo "> Rental Property </OPTION>\n
			<OPTION value='Commercial'";

			if ($property_type == 'Commercial') {
				echo " selected";
			}


			echo "> Commercial </OPTION>\n
			<OPTION value='HOA'";

			if ($property_type == 'HOA') {
				echo " selected";
			}


			echo "> HOA </OPTION>\n
			<OPTION value='Retirement Community'";

			if ($property_type == 'Retirement Community') {
				echo " selected";
			}


			echo "> Retirement Community </OPTION>\n

		</SELECT></p>
		
		<p><label for='fgpsn_property_manager' STYLE='width: 110px;'>Property Manager </label>
		<SELECT id='fgpsn_property_manager' name='fgpsn_property_manager' />
				<OPTION VALUE=''> - Select - </OPTION>";

		$prop_managers = new WP_User_Query( array( 'role' => 'property_manager' ) );
		if ( ! empty( $prop_managers->results ) ) {
			foreach ( $prop_managers->results as $prop_manager ) {

				echo "<OPTION VALUE='" . $prop_manager->ID . "'";


					if ($cur_property_manager == $prop_manager->ID) {

						$manager_email = $prop_manager->user_email;
						$manager_phone = $prop_manager->client_phone;
						echo " selected";

					}


			echo ">" .  $prop_manager->display_name . " Title: " . $check_role . "</OPTION>";
			}
		}

		echo "</SELECT></p>";
		
	echo '<P><label for="fgpsn_property_assigned_staff">Assigned Staff</label>';

	echo "<SELECT id='fgpsn_property_desk_staff' name='fgpsn_property_desk_staff[]' multiple=multiple />
				<OPTION VALUE=''> - Select - </OPTION>";

	$args = array(
       'post_type' => 'employee_data',
       'tax_query' => array(
                   array(
                       'taxonomy' => 'employee_data_types',
                       'field' => 'slug',
                       'terms' => 'desk-staff'
                    )
                )
        );
        $posts = get_posts($args);


		if(is_array($posts)) :  foreach($posts as $post) :

			echo "<OPTION VALUE='" . $post->ID . "'";


			if ($cur_property_manager == $post->ID) {

				$emp_phone = get_post_meta($cur_property_manager, 'emp_phone', true);
				$emp_email = get_post_meta($cur_property_manager, 'emp_email', true);
				echo " selected";

			}


			echo ">" .  $post->post_title . "</OPTION>";

		endforeach; endif;

		echo "</SELECT></p>";
		
	echo '<P><label for="fgpsn_property_trustees">Property Trustees</label>';

	echo "<SELECT id='fgpsn_property_trustee' name='fgpsn_property_trustee[]' multiple=multiple />
				<OPTION VALUE=''> - Select - </OPTION>";

	$args = array(
		 'posts_per_page' => -1,
		 'orderby' => 'rand',
		 'post_type' => 'contact_data',
		 'contact_data_types' => 'trustee',
		 'post_status' => 'publish'
	);
        $posts = get_posts($args);


		if(is_array($posts)) :  foreach($posts as $post) :

			echo "<OPTION VALUE='" . $post->ID . "'";

			if ($cur_property_manager == $post->ID) {

				//$emp_phone = get_post_meta($cur_property_manager, 'emp_phone', true);
				//$emp_email = get_post_meta($cur_property_manager, 'emp_email', true);
				//echo " selected";

			}

			echo ">" .  $post->post_title . "</OPTION>";

		endforeach; endif;

		echo "</SELECT></p>
		
		<label for='fgpsn_property_number_of_units'>Number of Units</label>
		<P><input id='fgpsn_property_number_of_units' name='fgpsn_property_number_of_units' size='3' type='text' value='{$fgpsn_property_number_of_units}' /></P>
		
		<label for='fgpsn_property_additional_property_notes'>Additional Notes</label>
		<textarea name='fgpsn_property_additional_property_notes'></textarea></fieldset>
		
		
		<fieldset>
		
		<label for='additional_property_notes'>Additional Notes</label>
		
		
		<label for='additional_property_notes'>Additional Notes</label>
		
		
		<label for='additional_property_notes'>Additional Notes</label>
		
		
		<label for='additional_property_notes'>Additional Notes</label>
		
		
		<label for='additional_property_notes'>Additional Notes</label>
		
		
		<label for='additional_property_notes'>Additional Notes</label>
		
		
		<label for='additional_property_notes'>Additional Notes</label>";
		
		
		

}		





















// Add to admin_init function
add_filter('manage_edit-properties_columns', 'add_edit_properties_columns');

function add_edit_properties_columns($properties_columns) {
    $new_columns['cb'] = '<input type="checkbox" />';
    $new_columns['title'] = _x('Property No.', 'column name');
    $new_columns['address_1'] = __('Address');
    $new_columns['city'] = __('City');
    $new_columns['state'] = __('State.');
    $new_columns['zip'] = _x('Zipcode', 'column name');

    return $new_columns;
}


add_action('manage_properties_posts_custom_column', 'manage_properties_columns', 10, 2);

function manage_properties_columns($column_name, $id) {
    global $wpdb;
    switch ($column_name) {
    case 'id':
        echo $id;
            break;

    case 'properties_types':
        // Get number of images in gallery
        $terms = wp_get_post_terms( $id, 'properties_types' );
        foreach($terms as $term) {
        echo $term->name;
        }

        break;

    case 'address_1':
	        $address_1 = get_post_meta($id, 'address_1', true);
	        if ( $address_1 === false ) {$address_1 = 'false: ' . $id;}
	        echo $address_1;

        break;

    case 'monthly_payment_date':
	        // Get number of images in gallery
	        $monthly_payment_date = get_post_meta( $id, 'unit_rent_data', true );
	        echo $monthly_payment_date['unit_rent_date'];

        break;

    default:
        break;
    } // end switch
}



add_action( 'add_meta_boxes', 'property_specifications' );
function property_specifications() {

	$screens = array( 'properties', 'fg_properties' );
    foreach ($screens as $screen) {
		add_meta_box(
			'property_specifications',
			__( 'Property Specifications', 'myplugin_textdomain' ),
			'property_spec_content',
			$screen,
			'normal',
			'high'
		);
	}
}


function getPropSpecTemplate($property_id){
	global $prop_spec_temp;
	if ( !isset($property_id) || $property_id == '' ) {
		$property_id = get_post_meta( $_POST['useID'], 'fgpsn_property_id', true);
	
	}
	

 $prop_spec_temp = '<fieldset><div>';
	$meta_key_array = array('fgpsn_property_water_shutoff' => 'Water Shutoff Locations',
								'fgpsn_property_main_shutoff' => 'Main Property Water Shut Off',
								'fgpsn_property_ext_spigot_location' => 'Exterior Spigot Locations',
								'fgpsn_property_fire_sprinkler_location' => 'Fire Sprinkler Locations',
								'fgpsn_property_gas_shutoff_location' => 'Gas Shutoff Locations');


	foreach ($meta_key_array as $key => $value) {
		$prop_spec_temp .= '<label for="' . $key . '">' . $value . '</H3>';
		$prop_spec_temp .= '<p><input type=text name="" value="' . get_post_meta($property_id, $key, true) . '"></P>';
	}

     $prop_spec_temp .= "</DIV></fieldset>";


  return $prop_spec_temp;

}


function getPropSpecTemplate_fn($property_id){
	global $prop_spec_temp;
	if ( !isset($property_id) || $property_id == '' && get_post_type() != 'properties' ) {
		$property_id = get_post_meta( $_POST['useID'], 'fgpsn_property_id', true);
	
	} elseif( get_post_type() == 'properties' ){ $property_id = $_POST['useID']; }
	


 $prop_spec_temp = '<div class="fgpsn-property-data-display">';
	$meta_key_array = array('fgpsn_property_water_shutoff' => 'Water Shutoff Locations',
								'fgpsn_property_main_shutoff' => 'Main Property Water Shut Off',
								'fgpsn_property_ext_spigot_location' => 'Exterior Spigot Locations',
								'fgpsn_property_fire_sprinkler_location' => 'Fire Sprinkler Locations',
								'fgpsn_property_gas_shutoff_location' => 'Gas Shutoff Locations');
	foreach ($meta_key_array as $key => $value) {
		$prop_spec_temp .= '<H3>' . $value . '</H3>';
		$prop_spec_temp .= '<div class="fgpsn-spec-detail">' . get_post_meta($property_id, $key, true) . '</div>';
	}

     $prop_spec_temp .= "</DIV>";


    
  echo $prop_spec_temp;
 //return $prop_spec_temp;

}

add_action('wp_ajax_getPropSpecTemplate', 'getPropSpecTemplate_fn');
add_action('wp_ajax_nopriv_getPropSpecTemplate', 'getPropSpecTemplate_fn');

function property_spec_content() {

	wp_nonce_field( plugin_basename( __FILE__ ), 'property_spec_content_nonce' );
	global $prop_spec_temp;
	getPropSpecTemplate(get_the_ID());
	echo $prop_spec_temp;

	

//end add property specificat
}


add_action( 'save_post', 'property_spec_save' );
function property_spec_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['property_spec_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}


	$meta_key_array = array('fgpsn_property_water_shutoff' => 'Water Shutoff Locations',
								'fgpsn_property_main_shutoff' => 'Main Property Water Shut Off',
								'fgpsn_property_ext_spigot_location' => 'Exterior Spigot Locations',
								'fgpsn_property_fire_sprinkler_location' => 'Fire Sprinkler Locations',
								'fgpsn_property_gas_shutoff_location' => 'Gas Shutoff Locations');
	foreach ($meta_key_array as $key => $value) {
		

		update_post_meta($post_id, $key, $_POST[$key]);
	}


		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'property_spec_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'property_spec_save');
	}

}










add_action( 'add_meta_boxes', 'property_vendors' );
function property_vendors() {

	$screens = array( 'properties', 'fg_properties' );
    foreach ($screens as $screen) {
		add_meta_box(
			'property_vendors',
			__( 'Property Venodrs', 'myplugin_textdomain' ),
			'property_vend_content',
			$screen,
			'normal',
			'high'
		);
	}
}

function getPropVendorList( $property_id ) {
	global $prop_vend_temp;

		$prop_vend_temp = '<div class="fgpsn-property-data-display"><FIELDSET><DIV>';

		$terms = get_terms( 'property_vendor_services' );

		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		    
		    foreach ( $terms as $term ) {
		       //$prop_vend_temp .=  '<P><label for="' . $term->slug . '">' . $term->name . '</li>';
		       $prop_vend_temp .= '<P><label for="' . $term->slug . '">' . $term->name . '</label>';

		       $prop_vend_temp .= '<P><select name="fgpsn_property_vendor_' . $term->slug . '">
		       						<option value="0"> -- Choose ' . $term->name . ' Vendor -- </option>';

		       	$myposts = get_posts(array(
				    'showposts' => -1,
				    'post_type' => 'property_vendor',
				    'tax_query' => array(
				        array(
				        'taxonomy' => 'property_vendor_services',
				        'field' => 'slug',
				        'terms' => array($term->slug))
				    ))
				);
				 
				foreach ($myposts as $mypost) {
					$prop_vend_temp .= '<option value="' . $mypost->ID  . '"';
					$get_cur = get_post_meta(  $property_id,  'fgpsn_property_vendor_' . $term->slug, true );
					if ( $mypost->ID == $get_cur ) {

						$prop_vend_temp .= ' selected';
					}

					$prop_vend_temp .= '>' . $mypost->post_title . '</option>';
				}
				$prop_vend_temp .= '</select>';
		    }
		   
		}
	     
	$prop_vend_temp .= "</DIV></FIELDSET></div>";
	return $prop_vend_temp;

}

function getPropVendorList_fn( $property_id ) {
	global $prop_vend_temp;

	if ( !isset($property_id) || $property_id == '' ) {//this should mean an ajax call		
		$property_id = get_post_meta( $_POST['useID'], 'fgpsn_property_id', true);			
	}
		
		$prop_vend_temp = '<div class="fgpsn-property-data-display">';
		$terms = get_terms( 'property_vendor_services' );
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
			
			$checker = get_permalink($_POST['useID']);
			
		    foreach ( $terms as $term ) {
		    	$checker1 = get_permalink( get_post_meta( get_post_meta($_POST['useID'], 'fgpsn_property_id', true ), 'fgpsn_property_vendor_' . $term->slug, true ));
		       //$prop_vend_temp .=  '<P><label for="' . $term->slug . '">' . $term->name . '</li>';
		       $prop_vend_temp .= '<H3>' . $term->name . '</H3>';
				$prop_vend_temp .= '<a href="' . $checker . '"><div class="fgpsn-spec-detail">' . get_the_title( get_post_meta( get_post_meta($_POST['useID'], 'fgpsn_property_id', true ), 'fgpsn_property_vendor_' . $term->slug, true ) ) . '</div></a>
				<a href="' . $checker1 . '"><div class="fgpsn-spec-detail">' . get_the_title( get_post_meta( get_post_meta($_POST['useID'], 'fgpsn_property_id', true ), 'fgpsn_property_vendor_' . $term->slug, true ) ) . '</div></a>';
		    }
		   
		}
		     
		$prop_vend_temp .= "</DIV>";
	
	echo $prop_vend_temp;

}

add_action('wp_ajax_getPropVendorList', 'getPropVendorList_fn');
add_action('wp_ajax_nopriv_getPropVendorList', 'getPropVendorList_fn');


function property_vend_content() {

	wp_nonce_field( plugin_basename( __FILE__ ), 'property_vend_content_nonce' );
	global $prop_vend_temp;
	getPropVendorList(get_the_ID());
	echo $prop_vend_temp;

}


add_action( 'save_post', 'property_vendor_save' );
function property_vendor_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	return;

	if ( !wp_verify_nonce( $_POST['property_vend_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}


	$terms = get_terms( 'property_vendor_services' );
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		    
		    foreach ( $terms as $term ) {
				
		    	update_post_meta($post_id, 'fgpsn_property_vendor_' .$term->slug, $_POST['fgpsn_property_vendor_' . $term->slug] );
		       
		    }
		   
		}
	
		if ( ! wp_is_post_revision( $post_id ) ){

			//$my_post = array();
			//$my_post['ID'] = $post_id;
			//$my_post['post_title'] = $post_title;


			// unhook this function so it doesn't loop infinitely
			remove_action('save_post', 'property_vendor_save');

			// update the post, which calls save_post again
			wp_update_post( $my_post );

			// re-hook this function
			add_action('save_post', 'property_vendor_save');
	}

}


function getPropertySidebar( $property_id ){

	global $property_sidebar;
	$property_sidebar = '<div class="fgpsn-prop-nav-container">
						<h3>Browse Property Data</h3>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-data-' . $property_id . '">Property Data</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-specs-' . $property_id . '">Property Specifications</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-vendors-' . $property_id . '">Property Vendors</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-contacts-' . $property_id . '">Property Concacts</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-docs-' . $property_id . '">Property Documents</div>
						<div class="fgpsn-prop-nav" id = "fgpsn-property-wo-history-' . $property_id . '">Maintenance History</div>
						</div>';
	return $property_sidebar;
}

?>
