<?PHP

  
class fgpsn_quick_message extends WP_Widget {

	function fgpsn_quick_message() {
		//Load Language
		load_plugin_textdomain( 'fgpsn-quick-message', false, dirname( plugin_basename( __FILE__ ) ) .  '/lang' );
		$widget_ops = array( 'description' => __( 'Shows recent messages of selected post types.', 'fgpsn-quick-message' ) );
		//Create widget
		$this->WP_Widget( 'fgpsnquickmessage', __( 'Quick Message and Post', 'fgpsn-quick-message' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );
		echo $before_widget;
		$title = empty( $instance[ 'title' ] ) ? '' : apply_filters( 'widget_title', $instance[ 'title' ] );


		$parameters = array(
				'title' 	=> $title,
				'post_as' 	=> $instance[ 'api_key'],
			);

		if ( !empty( $title ) ) {
				echo $before_title . '' . $title . '' . $after_title;
		}

        //print recent posts
		fgpsn_get_quick_messages($parameters);
		echo $after_widget;

  } //end of widget()

	//Update widget options
  function update($new_instance, $old_instance) {

		$instance = $old_instance;
		//get old variables
		$instance['title'] = esc_attr($new_instance['title']);
		$instance['post_as'] = $new_instance['api_key'];
		
		return $instance;

	} //end of update()

	//Widget options form
  function form($instance) {

		$instance = wp_parse_args( (array) $instance, fgpsn_quick_message_defaults() );

		$title 		= esc_attr($instance['title']);
		$api_key 	= $instance['api_key'];
		$auth_token = $instance['auth_token'];
		$from_number 	= $instance['from_number'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' );?>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('post_as'); ?>"><?php _e('Create Post Types:');?>
				<input class="widefat" id="<?php echo $this->get_field_id('post_as'); ?>" name="<?php echo $this->get_field_name('post_as'); ?>" type="text" value="<?php echo $post_as; ?>" />
			</label>
		</p>
		

		<?php
	} //end of form

}

add_action( 'widgets_init', create_function('', 'return register_widget("fgpsn_quick_message");') );


function fgpsn_get_quick_messages($args = '', $echo = true) {

	global $wpdb;
	$defaults = fgpsn_quick_message_defaults();
	$args = wp_parse_args( $args, $defaults );
	extract($args);


/*include and use Sendgrid here?
	if ( !include_once( plugin_dir_path( __FILE__ ) . '/twilio-php-master/Services/Twilio.php' ) )
	{

	echo "<H3>Why Not! - " .plugin_dir_path( __FILE__ ) . '/twilio-php-master/Services/Twilio.php - </H3>';

	}
*/

	?>
	<h3 class="box-title">Quick Email</h3>

	<div class="pull-right box-tools">
                <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button></div>
                </div><div class="box-body"><form id="fgpsn-quick-message" action="#" method="post"><div class="form-group col-sm-12 col-md-6" ><select multiple size=5 name="selected_properties" class="fgpsn_properties_menu"><option value=""> -- Select Properties -- </option></select></div><div class="form-group col-sm-12 col-md-6" ><select multiple size=5 name="selected_units" class="fgpsn_units_menu"><option value=""> -- Select Units -- </option></select></div><div style="clear: both;"></div><div class="margin" id="fgpsn-inline-menu-filter"><div class="btn-group"><button type="button" class="btn btn-default">
                  <input type="checkbox" id="copy-all" name="copy-all" value="copy-all">All</button>
                
                <button type="button" class="btn btn-success" id="copy-owners">
                  <input type="checkbox" id="copy-owners" name="copy-owners" value="owner-Owner"checked>Owners</button>
                  
                <button type="button" class="btn btn-success" id="copy-tenants">
                    <input type="checkbox" id="copy-tenants" name="copy-tenants" value="tenant-Yes" checked>
                      Tenants
                  </button>
                  <button type="button" class="btn btn-success" id="copy-trustees">
                    <input type="checkbox" id="copy-trustees" name="copy-trustees" value="trustee-Trustee" checked>
                      Trustees
                  </button>
                  <button type="button" class="btn btn-success" id="copy-staff">
                    <input type="checkbox" id="copy-staff" name="copy-staff" >
                      Staff
                  </button>
                  
                </div>
                
              </div>
                <div style="clear: both;"></div>
              
               <div class="col-lg-12">
                <input type="text" class="form-control" placeholder="Subject">
               </div>
               <div style="clear: both;"></div>
               <div>
                  <textarea class="textarea" placeholder="Message"></textarea>
                </div>
               
              </form>
            </div>
            <div class="box-footer clearfix">
              <button type="button" class="pull-right btn btn-default" id="sendEmail">Send
                <i class="fa fa-arrow-circle-right"></i></button>
            </div>
          </div>
          <?php
	if ($echo)
		echo $fgpsn_quick_message_form;
	else
		return $fgpsn_quick_message_form;
}



function fgpsn_quick_message_defaults() {
	$defaults = array( 	'title' => __( 'Post a Message', 'fgpsn-quick-message' ),
				'post_as' 	=> 'desk_log', );
	return $defaults;
}



?>
