<?php
/*
* Template Name: Network Communications
* Description goes with each client theme. Must be configured for each new multi site installation.
* This template looks for property_comm post types in the Property Manager's designated site on the network.
* Any comms with the correct property ID (or blog_id) and contact ID meta values will be imported to the local property * blog.
*/

get_header();

?>



<H1>Template!!!!!!!!111111</H1>

<?php get_footer(); ?>
