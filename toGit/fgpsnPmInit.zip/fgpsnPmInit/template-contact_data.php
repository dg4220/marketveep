<?php
/*
* Template Name: Network Contacts
*/

get_header(); 
?>
<div id="primary" <?php mb_primary_attr(); ?> role="main">
<?PHP
		global $wpdb;
		global $switched;
		$args = array(
			'network_id' => $wpdb->siteid,
			'public'     => true,
			'archived'   => null,
			'mature'     => null,
			'spam'       => null,
			'deleted'    => false,
			'limit'      => 10,
			'offset'     => 0
			);
			$property_ids = wp_get_sites( $args );
			$property_ct = count( $property_ids);
			foreach ($property_ids as $k=>$v) {	
				$blog_details = get_blog_details($k, true);
				switch_to_blog($blog_details->blog_id); 
				//switch_to_blog($v->blog_id); 

				$args = array(
				'offset'           => 0,
				'orderby'          => 'post_title',
				'meta_key'         => '',
				'meta_value'       => '',
				'post_type'        => 'contact_data',
				'post_status'      => 'publish',
				'suppress_filters' => true );
						
				$recipients = get_posts( $args );
				//echo '<H4>' . $recipients . ' -- Select Properties -- ' . $wpdb->last_query . '</H4>';
				$property_ct = count( $property_ids);
				//echo '<OPTION> -- Select Properties -- </OPTION>';
				//$recip_opt = array();
				//$blog_details = get_blog_details($k, true);
				$cur_property = $blog_details->blogname;
			
				echo '<p><TABLE><TR><TH>' . $cur_property . ' contacts</TH></TR>';
						//for each property, set the message and recipients as a Metavalue?
				
					foreach ($recipients as $recipient) {
						$recip_email = get_post_meta( $recipient->ID, 'client_email', true );
						$recip_unit = get_post_meta( $recipient->ID, 'client_unit', true );
						$recip_cell = get_post_meta( $recipient->ID, 'client_cell', true );
						//$recip_all = get_post_meta( $recipient->ID );
						
						$recip_roles = get_the_terms( $recipient->ID, 'contact_data_types' );
						//////find custom taxonomy category name
						echo '<TR><TD><B>Contact:</B> ' . $recipient->post_title . '</TD></TR>';
						echo '<TR><TD><B>Email:</B>' . $recip_email . '</TD></TR>';
						echo '<TR><TF><BR></TF></TR>';
						
					}
					echo '</table>';
					//unset($recipients);
				
				
			echo '</P>';
			}
			restore_current_blog(); 
		
	?>
	</div><!-- #primary.c8 -->

<?php get_footer(); ?>
