<?PHP
$table = $_GET[table_prefix] . 'posts';
echo "<H3>" . $table . "</H3>";
$primaryKey = 'ID';
/*$columns = array(
    array( $table_prefix . 'posts' => 'post_author', 'dt' => 0 ),
    array( $table_prefix . 'posts' => 'post_date',  'dt' => 1 ),
    array( $table_prefix . 'posts' => 'ID',   'dt' => 2 ),
    array( $table_prefix . 'posts' => 'post_title',     'dt' => 3 )
	);
	*/
	
$columns = array(
    array( 'db' => 'post_author', 'dt' => 0 ),
    array( 'db' => 'post_date',  'dt' => 1 ),
    array( 'db' => 'ID',   'dt' => 2 ),
    array( 'db' => 'post_title',     'dt' => 3 )
	);
$sql_details = array(
    'user' => 'dg4220_ptiMult',
    'pass' => 'DrMulti',
    'db'   => 'dg4220_ptiMult',
    'host' => 'localhost'
);

require( 'ssp.class.php' );

echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);
?>
